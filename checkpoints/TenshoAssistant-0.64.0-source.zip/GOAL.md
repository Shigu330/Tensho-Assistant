# GOAL sélectionné

ID: COLL-002-STUDY
OBJECTIVE: Enrichir les collections natives utiles, notamment orchestrion, en vérifiant identités, chargement et unlocks ; poursuivre les 17 domaines jusqu’à la réserve quota de 5 %.
CURRENT_STATE: Tranche précédente GATHER-FISH-FORECAST-010 IMPLEMENTED / TESTED en 0.64.0, 412 tests/package/SHA-256 et probes réels 8753/4915 avec fixtures datées verts. Collections actuelles montures/mascottes/emotes/cartes, grimoire bleu partagé ; aucune extension supplémentaire prouvée à ce stade.
WHY_NOW: Base de pêche utile avec limites documentées ; progression d’un autre domaine prioritaire B, sur les mêmes catalogues/contexte et lecteurs natifs existants.
REFERENCES: docs/BASE-TOOLS-001.md ; REFERENCES.md sources Collections ; API IUnlockState et feuilles natives installées.
FILES: Collections/CollectionService, CollectionReader.Dalamud ; MainWindow collections ; modèles Item et probes/tests ciblés.
IN_SCOPE: Étude d’orchestrion et autres collections natives exposées ; identité de la feuille/acquisition distincte d’Item, indicateurs de chargement, lien vers objet/contexte et couverture explicite ; lifecycle propriétaire et lecteur partagé.
OUT_OF_SCOPE: Inventer possession/absence depuis données non chargées, requêtes réseau automatiques ou priorités hors des 17 domaines. Les 17 restent PARTIAL.
VALIDATION: Dernière tranche : Verify.ps1 412/412, zéro avertissement/erreur, package/API/versions/SHA-256/exclusion hôte verts. Probes de pêche réels passant ; aucune validation en jeu. Nouvelle collection à vérifier contre API, fichiers natifs et cas d’erreur/lifecycle avant livraison.
QUOTA: Relevé 2026-10-29 : 63 % disponibles sur 5 h et 41 % semaine ; réserve 5 %, objectif global actif.
NEXT_ACTION: Checkpoint 0.64 puis métadonnées IUnlockState/Orchestrion et code Collections, projection native avec preuves de couverture. GP et essais projection/Macro Chain différés, sans les redemander.
DEFINITION_OF_DONE: Étude sourcée et tranche utile compilée/testée, preuves/limites/docs/sauvegarde à jour ; aucun domaine global promu complet sans preuve.
