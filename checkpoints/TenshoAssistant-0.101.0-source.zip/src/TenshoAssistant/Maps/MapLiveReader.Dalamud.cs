using System.Numerics;
using Dalamud.Plugin.Services;

namespace TenshoAssistant.Maps;

// Player position copied on the framework thread; the map window only reads this managed snapshot.
public sealed record MapLiveState(uint TerritoryId,uint MapId,Vector3 Position,float Rotation,DateTimeOffset ObservedAt);

internal sealed class MapLiveReader : IDisposable
{
    private readonly IFramework framework;private readonly IClientState client;private readonly IObjectTable objects;private readonly IPluginLog log;
    private MapLiveState? state;private bool disposed;private DateTimeOffset retryAt;
    public MapLiveState? State=>Volatile.Read(ref state);
    public MapLiveReader(IFramework framework,IClientState client,IObjectTable objects,IPluginLog log)
    {this.framework=framework;this.client=client;this.objects=objects;this.log=log;framework.Update+=Update;}
    private void Update(IFramework _)
    {
        if(disposed || !framework.IsInFrameworkUpdateThread || framework.IsFrameworkUnloading)return;
        var now=DateTimeOffset.UtcNow;if(now<retryAt)return;
        try
        {
            var player=client.IsLoggedIn ? objects.LocalPlayer:null;
            Volatile.Write(ref state,player is null ? null:new MapLiveState(client.TerritoryType,client.MapId,player.Position,player.Rotation,now));
        }
        catch(Exception error){Volatile.Write(ref state,null);retryAt=now.AddSeconds(5);log.Warning(error,"Map position unavailable; retry in five seconds.");}
    }
    public void Dispose(){if(disposed)return;disposed=true;framework.Update-=Update;Volatile.Write(ref state,null);}
}
