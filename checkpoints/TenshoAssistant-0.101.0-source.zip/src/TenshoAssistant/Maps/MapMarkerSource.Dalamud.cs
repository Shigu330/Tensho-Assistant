using Dalamud.Plugin.Services;
using Lumina.Excel.Sheets;

namespace TenshoAssistant.Maps;

// Fixed map icon in texture pixels (MapMarker X/Y), with its game icon and optional label.
public sealed record MapIconMarker(float X,float Y,uint Icon,string Label);

/// <summary>Copies the MapMarker subrows of one marker range once and keeps them; game data only, no native state.</summary>
internal sealed class MapMarkerSource
{
    private readonly IDataManager data;private readonly IPluginLog log;
    private readonly Dictionary<uint,IReadOnlyList<MapIconMarker>> cache=[];
    public MapMarkerSource(IDataManager data,IPluginLog log){this.data=data;this.log=log;}
    public IReadOnlyList<MapIconMarker> For(uint range)
    {
        if(range==0)return [];
        if(cache.TryGetValue(range,out var known))return known;
        var markers=new List<MapIconMarker>();
        try
        {
            if(data.GetSubrowExcelSheet<MapMarker>().TryGetRow(range,out var rows))
                foreach(var row in rows)
                    if(row.Icon!=0)markers.Add(new(row.X,row.Y,row.Icon,row.PlaceNameSubtext.RowId!=0 ? row.PlaceNameSubtext.Value.Name.ExtractText():""));
        }
        catch(Exception error){log.Warning(error,"Map markers unavailable for range {0}.",range);}
        return cache[range]=markers.AsReadOnly();
    }
}
