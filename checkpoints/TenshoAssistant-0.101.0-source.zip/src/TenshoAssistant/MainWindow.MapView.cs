using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Textures;
using TenshoAssistant.Maps;

namespace TenshoAssistant;

/// <summary>MAP-VIEW-016: the game map texture with fixed icons, the player and a flag on right click (docs/MAP-016-PLAN.md).</summary>
internal sealed partial class MainWindow
{
    private MapLiveReader? mapLive;
    private MapMarkerSource? mapMarkers;
    private bool mapViewOpen;
    private bool mapViewFollow=true;
    private uint mapViewMapId;
    private float mapZoom=0.5f;
    private Vector2 mapPan;
    private Vector2 mapContextPixel;
    internal void ConfigureMapView(MapLiveReader live,MapMarkerSource markers){mapLive=live;mapMarkers=markers;}
    private void OpenMapView(uint mapId){mapViewMapId=mapId;mapViewFollow=mapId==0;mapViewOpen=true;}

    public void DrawMapView()
    {
        if(windowDisposed || !mapViewOpen || maps.State.Catalog is not { } catalog)return;
        using var theme=UI.FfxivTheme.Apply();
        ImGui.SetNextWindowSize(new Vector2(720,760),ImGuiCond.FirstUseEver);
        var visible=ImGui.Begin(localization.Get("MapView.Title")+"###TenshoMapView",ref mapViewOpen,ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoScrollWithMouse);
        try
        {
            if(!visible)return;
            var live=mapLive?.State;
            if(mapViewFollow && live is { MapId:>0 })mapViewMapId=live.MapId;
            var map=catalog.Find(mapViewMapId);
            ImGui.TextColored(Accent,map is null ? localization.Get("MapView.NoMap"):string.IsNullOrWhiteSpace(map.Subzone) ? map.Zone:$"{map.Zone} · {map.Subzone}");
            ImGui.SameLine();ImGui.Checkbox(localization.Get("MapView.Follow"),ref mapViewFollow);
            ImGui.SameLine();if(ImGui.SmallButton("−"))mapZoom=MapProjection.ClampZoom(mapZoom/1.25f);
            ImGui.SameLine();if(ImGui.SmallButton("+"))mapZoom=MapProjection.ClampZoom(mapZoom*1.25f);
            if(map is null || map.TexturePath.Length==0){ImGui.TextWrapped(localization.Get("MapView.Unavailable"));return;}
            DrawMapCanvas(map,live);
        }
        finally{ImGui.End();}
    }

    private void DrawMapCanvas(MapDefinition map,MapLiveState? live)
    {
        var origin=ImGui.GetCursorScreenPos();var size=Vector2.Max(ImGui.GetContentRegionAvail(),new Vector2(64));
        ImGui.InvisibleButton("MapCanvas",size,ImGuiButtonFlags.MouseButtonLeft | ImGuiButtonFlags.MouseButtonRight);
        var hovered=ImGui.IsItemHovered();var io=ImGui.GetIO();
        var player=live is not null && live.MapId==map.MapId ? MapProjection.PixelFromWorld(live.Position,map):(Vector2?)null;
        if(ImGui.IsItemActive() && ImGui.IsMouseDragging(ImGuiMouseButton.Left)){mapPan+=io.MouseDelta;mapViewFollow=false;}
        if(hovered && io.MouseWheel!=0)
        {
            // Zoom around the cursor: the pixel under the mouse stays under the mouse.
            var before=(io.MousePos-origin-mapPan)/mapZoom;
            mapZoom=MapProjection.ClampZoom(mapZoom*(io.MouseWheel>0 ? 1.15f:1/1.15f));
            mapPan=io.MousePos-origin-before*mapZoom;
        }
        if(mapViewFollow && player is { } centred)mapPan=size/2-centred*mapZoom;
        var draw=ImGui.GetWindowDrawList();
        draw.PushClipRect(origin,origin+size,true);
        try
        {
            draw.AddRectFilled(origin,origin+size,ImGui.GetColorU32(UI.FfxivTheme.Background));
            if(textures.GetFromGame(map.TexturePath).TryGetWrap(out var texture,out _) && texture is not null)
                draw.AddImage(texture.Handle,origin+mapPan,origin+mapPan+new Vector2(MapProjection.TextureSize*mapZoom));
            else draw.AddText(origin+new Vector2(8),ImGui.GetColorU32(UI.FfxivTheme.TextMuted),localization.Get("MapView.Loading"));
            string? tooltip=null;
            var iconSize=Math.Clamp(28*mapZoom*1.6f,16,40);
            foreach(var marker in mapMarkers?.For(map.MarkerRange) ?? [])
            {
                var centre=origin+mapPan+new Vector2(marker.X,marker.Y)*mapZoom;
                if(textures.TryGetFromGameIcon(new GameIconLookup(marker.Icon),out var shared) && shared.TryGetWrap(out var icon,out _) && icon is not null)
                    draw.AddImage(icon.Handle,centre-new Vector2(iconSize/2),centre+new Vector2(iconSize/2));
                if(hovered && marker.Label.Length>0 && Vector2.Distance(io.MousePos,centre)<=iconSize/2)tooltip=marker.Label;
            }
            if(player is { } here)DrawPlayerArrow(draw,origin+mapPan+here*mapZoom,live!.Rotation);
            if(hovered)
            {
                var coordinate=MapProjection.CoordinateFromPixel((io.MousePos-origin-mapPan)/mapZoom,map);
                var label=localization.Format("MapView.Cursor",coordinate.X.ToString("0.0"),coordinate.Y.ToString("0.0"));
                var box=ImGui.CalcTextSize(label)+new Vector2(10,6);
                draw.AddRectFilled(origin+new Vector2(6,size.Y-box.Y-6),origin+new Vector2(6+box.X,size.Y-6),ImGui.GetColorU32(UI.FfxivTheme.Panel),3);
                draw.AddText(origin+new Vector2(11,size.Y-box.Y-3),ImGui.GetColorU32(UI.FfxivTheme.Text),label);
            }
            if(tooltip is not null)ImGui.SetTooltip(tooltip);
        }
        finally{draw.PopClipRect();}
        if(hovered && ImGui.IsMouseClicked(ImGuiMouseButton.Right)){mapContextPixel=(io.MousePos-origin-mapPan)/mapZoom;ImGui.OpenPopup("MapViewContext");}
        if(ImGui.BeginPopup("MapViewContext"))
        {
            try
            {
                var coordinate=MapProjection.CoordinateFromPixel(mapContextPixel,map);
                ImGui.TextDisabled(localization.Format("MapView.Cursor",coordinate.X.ToString("0.0"),coordinate.Y.ToString("0.0")));
                if(ImGui.Selectable(localization.Get("MapView.Flag")))OpenMapPoint(map,coordinate.X,coordinate.Y);
                if(ImGui.Selectable(localization.Get("MapView.UseInTool"))){selectedMapId=map.MapId;mapX=coordinate.X;mapY=coordinate.Y;bookmarkSaved=false;page=Page.Maps;IsOpen=true;}
            }
            finally{ImGui.EndPopup();}
        }
        if(mapOpenError is { } error)ImGui.SetTooltip(error);
    }

    // Game rotation 0 faces +Z, which is "down" on the map texture.
    private static void DrawPlayerArrow(ImDrawListPtr draw,Vector2 centre,float rotation)
    {
        var forward=new Vector2(MathF.Sin(rotation),MathF.Cos(rotation));var side=new Vector2(-forward.Y,forward.X);
        var colour=ImGui.GetColorU32(UI.FfxivTheme.Gold);
        draw.AddTriangleFilled(centre+forward*12,centre-forward*7+side*7,centre-forward*7-side*7,colour);
        draw.AddCircle(centre,4,ImGui.GetColorU32(UI.FfxivTheme.Text),12,1.5f);
    }
}
