using System.Numerics;
using TenshoAssistant.Maps;
using TenshoAssistant.Npcs;

internal static class MapProjectionTests
{
    private static void Check(bool value,string message){if(!value)throw new Exception(message);}
    private static bool Near(float a,float b)=>Math.Abs(a-b)<0.01f;
    private static MapDefinition Map(int scale,int offsetX=0,int offsetY=0)=>new(11,128,"La Noscea","Limsa Lominsa","Le Tillac",0,scale,0,"ui/map/s1t1/00/s1t100_m.tex",offsetX,offsetY,3);
    public static IEnumerable<(string Name,Action Run)> Cases=>new (string,Action)[]
    {
        ("Map texture paths follow the game layout and refuse unexpected ids",()=>
        {
            Check(MapProjection.TexturePath("s1t1/00")=="ui/map/s1t1/00/s1t100_m.tex","city map");
            Check(MapProjection.TexturePath("")=="" && MapProjection.TexturePath("s1t1")=="" && MapProjection.TexturePath("../x/00")=="" && MapProjection.TexturePath("a/b/c")=="","invalid ids");
        }),
        ("World pixel and coordinate conversions agree with the vendor formula",()=>
        {
            foreach(var (scale,ox,oy) in new[]{(100,0,0),(200,-50,30),(400,12,-8)})
            {
                var map=Map(scale,ox,oy);var world=new Vector3(37.5f,0,-120f);
                var pixel=MapProjection.PixelFromWorld(world,map);var coordinate=MapProjection.CoordinateFromPixel(pixel,map);
                Check(Near(coordinate.X,NpcShopLinks.MapCoordinate(world.X,ox,(uint)scale)) && Near(coordinate.Y,NpcShopLinks.MapCoordinate(world.Z,oy,(uint)scale)),$"same coordinates as vendors at scale {scale}");
                var back=MapProjection.PixelFromCoordinate(coordinate,map);
                Check(Near(back.X,pixel.X) && Near(back.Y,pixel.Y),"coordinate round trip");
            }
            var centre=MapProjection.PixelFromWorld(Vector3.Zero,Map(100));
            Check(Near(centre.X,1024) && Near(centre.Y,1024) && MapProjection.OnMap(centre) && !MapProjection.OnMap(new Vector2(-1,5)),"centre and bounds");
            Check(Near(MapProjection.ClampZoom(10),4) && Near(MapProjection.ClampZoom(0),0.15f) && Near(MapProjection.ClampZoom(float.NaN),1),"zoom limits");
        }),
    };
}
