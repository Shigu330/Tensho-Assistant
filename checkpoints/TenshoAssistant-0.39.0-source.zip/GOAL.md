# GOAL sélectionné

ID: CRAFT-ACTIONS-002
OBJECTIVE: Étendre la simulation, les macros et la recherche aux actions déterministes avancées ; poursuivre les 17 domaines.
CURRENT_STATE: IMPLEMENTED / TESTED — 26 familles / 208 variantes natives, neuf actions avancées intégrées en 0.39.0, 260 tests/package verts. Probe natif niveaux/coûts/descriptions/icônes et recherche/replay ; recette niveau100 sous cible explicitement signalée. Aucune validation en jeu, Macro Chain reporté.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: CraftActionCatalog, CraftSimulation/State, CraftSolver, UI simulation/recherche ; CraftAdvancedTests, CraftSimulationProbe ; documents.
IN_SCOPE: Double gain/trait94, charges/combo, interdictions Parcimonie, ouverture/niveau, dix charges, réparation totale, protection unique persistante ; modèle normal partagé et export manuel.
OUT_OF_SCOPE: Déclarer les 17 plugins remplacés ; prétendre une validation en jeu sans observation.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: 2026-10-28, 32 % disponibles sur 5 h et 74 % semaine au dernier relevé ; continuer selon instruction utilisateur.
NEXT_ACTION: Snapshot 0.39.0 puis CRAFT-LIVE-001 : vérification des structures locales et observation native copiée de la synthèse, incluant recette/ressources/condition/effets, sans offsets présumés. Préparer les conseils en cours de craft sur des états prouvés ; garder les 17 domaines PARTIAL et le goal global actif, Macro Chain différé.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
