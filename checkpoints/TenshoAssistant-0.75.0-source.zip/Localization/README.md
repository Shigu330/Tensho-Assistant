# Adding a language

1. Copy `src/TenshoAssistant/Localization/Languages/en.json`.
2. Rename it with the language code, for example `es.json`.
3. Update `_meta` and translate the values.
4. Never rename translation keys.
5. Build the plugin and run the localization validator when available.
6. Submit a pull request.

English is the reference language. Missing keys fall back to English, then to `[Key.Name]`.
