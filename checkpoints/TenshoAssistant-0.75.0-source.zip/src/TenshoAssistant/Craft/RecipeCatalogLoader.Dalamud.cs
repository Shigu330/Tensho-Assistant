using System.Diagnostics;
using Dalamud.Plugin.Services;
using Lumina.Excel;
using Lumina.Excel.Sheets;

namespace TenshoAssistant.Craft;

internal sealed class RecipeCatalogLoader : IDisposable
{
    private readonly object gate = new();
    private readonly CancellationTokenSource cancellation = new();
    private readonly RecipeCatalogService service;
    private readonly IDataManager data;
    private readonly IFramework framework;
    private readonly IPluginLog log;
    private readonly List<RecipeDefinition> rows = [];
    private ExcelSheet<Recipe>? sheet;
    private ExcelSheet<RecipeLevelTable>? levelSheet;
    private ExcelSheet<CraftType>? craftSheet;
    private int position;
    private Task<(RecipeCatalog? Catalog, Exception? Error)>? build;
    private bool stopped;
    private bool disposed;

    public RecipeCatalogLoader(RecipeCatalogService service, IDataManager data, IFramework framework, IPluginLog log)
    {
        this.service = service;
        this.data = data;
        this.framework = framework;
        this.log = log;
        try { framework.Update += OnUpdate; }
        catch { cancellation.Dispose(); throw; }
    }

    private void OnUpdate(IFramework _)
    {
        lock (gate) { ReadUpdate(); }
    }

    private void ReadUpdate()
    {
        if (!framework.IsInFrameworkUpdateThread || framework.IsFrameworkUnloading || stopped) return;
        try
        {
            if (build is not null)
            {
                if (!build.IsCompleted) return;
                var result = build.GetAwaiter().GetResult();
                if (result.Error is not null) throw result.Error;
                service.Publish(result.Catalog!);
                Stop();
                return;
            }

            sheet ??= data.GetExcelSheet<Recipe>();
            levelSheet ??= data.GetExcelSheet<RecipeLevelTable>();
            craftSheet ??= data.GetExcelSheet<CraftType>();
            var end = Math.Min(position + 128, sheet.Count);
            var started = Stopwatch.GetTimestamp();
            while (position < end)
            {
                var row = sheet.GetRowAt(position++);
                if (row.RowId != 0 && row.ItemResult.RowId != 0)
                {
                    var ingredients = new List<RecipeIngredient>();
                    for (var i = 0; i < row.Ingredient.Count && i < row.AmountIngredient.Count; i++)
                    {
                        var itemId = row.Ingredient[i].RowId;
                        var amount = row.AmountIngredient[i];
                        if (itemId != 0 && amount > 0) ingredients.Add(new(itemId, amount));
                    }
                    var table=levelSheet.GetRow(row.RecipeLevelTable.RowId);
                    var level = table.ClassJobLevel;
                    var craftType = craftSheet.GetRow(row.CraftType.RowId).Name.ExtractText();
                    var simulation=RecipeSimulationCopy.Copy(row,table);
                    rows.Add(new RecipeDefinition(row.RowId, row.ItemResult.RowId, row.AmountResult,
                        craftType, level, ingredients, row.CraftType.RowId,simulation));
                }
                if (Stopwatch.GetElapsedTime(started) >= TimeSpan.FromMilliseconds(2)) break;
            }
            service.Progress(position, sheet.Count);
            if (position != sheet.Count) return;
            var managed = rows.ToArray();
            var dataVersion = string.Join(";", data.GameData.Repositories.Values.OrderBy(r => r.Name)
                .Select(r => $"{r.Name}={r.Version}"));
            var token = cancellation.Token;
            sheet = null; levelSheet = null; craftSheet = null; rows.Clear();
            build = Task.Run<(RecipeCatalog? Catalog, Exception? Error)>(() =>
            {
                try { return (RecipeCatalog.Build(managed, dataVersion, token), null); }
                catch (Exception error) { return (null, error); }
            });
        }
        catch (Exception error)
        {
            log.Error(error, "Tensho recipe catalog could not be built.");
            service.Fail(error);
            Stop();
        }
    }

    private void Stop()
    {
        if (stopped) return;
        stopped = true;
        framework.Update -= OnUpdate;
        sheet = null;
        levelSheet = null; craftSheet = null;
        rows.Clear();
    }

    public void Dispose()
    {
        lock (gate)
        {
            if (disposed) return;
            disposed = true; cancellation.Cancel();
            Stop(); service.Clear(); cancellation.Dispose();
        }
    }
}
