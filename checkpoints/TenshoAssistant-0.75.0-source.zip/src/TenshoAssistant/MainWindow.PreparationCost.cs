using System.Numerics;
using System.Text;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.Craft;
using TenshoAssistant.Market;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private readonly PreparationPriceSession preparationPrices=new();
    private int costBasisIndex;
    private int costQualityIndex;
    private string? preparationCostError;
    private void DrawPreparationCost(RecipeDefinition recipe,CraftPlan plan)
    {
        if (!ImGui.CollapsingHeader("Coût indicatif des achats")) return;
        var world=market.State;
        ImGui.SetNextItemWidth(230);
        var changed=ImGui.Combo("Quantités##Cost",ref costBasisIndex,new[] {"Écart aux stocks recensés","Tous les ingrédients requis"},2);
        ImGui.SetNextItemWidth(230);
        changed |= ImGui.Combo("Qualité des achats##Cost",ref costQualityIndex,new[] {"NQ","HQ","Moins cher entre NQ et HQ"},3);
        if(changed) {preparationPrices.Cancel(); preparationCostError=null;}
        PreparationCostEstimate estimate;
        try
        {
            estimate=PreparationCost.Build(plan,world.WorldId,(PreparationCostBasis)costBasisIndex,(PreparationPriceQuality)costQualityIndex,
                id=>itemCatalog.State.Catalog?.Find(id),id=>market.GetCached(world.WorldId,id),DateTimeOffset.UtcNow,market.CacheLifetime);
        }
        catch(Exception error) {ImGui.TextWrapped($"Estimation indisponible : {error.Message}"); return;}
        DrawPreparationCostDetails(recipe,plan.Requested,estimate);
    }
    private void DrawChainCost(RecipeDefinition recipe,CraftChainState chain,bool stale)
    {
        if(chain.Result is not { } result || !ImGui.CollapsingHeader("Coût des besoins terminaux de la chaîne")) return;
        if(chain.Input?.ChoiceRevision!=craftChainChoiceRevision)
        {ImGui.TextWrapped("Choix modifiés : recalculez la chaîne avant de chiffrer ses besoins.");return;}
        ImGui.PushID("ChainCost");
        try
        {
            ImGui.TextWrapped($"Besoins du calcul {chain.CalculatedAt:HH:mm:ss} UTC. Stocks déjà déduits par la chaîne ; aucune seconde déduction.");
            if(stale) ImGui.TextColored(Accent,"Les observations ont changé : recalculez pour utiliser les stocks actuels.");
            if(result.HasUnresolved) ImGui.TextWrapped("Branches non résolues : elles restent hors du chiffrage. Seuls les besoins terminaux identifiés sont consultables.");
            ImGui.SetNextItemWidth(230);
            if(ImGui.Combo("Qualité des achats##Cost",ref costQualityIndex,new[] {"NQ","HQ","Moins cher entre NQ et HQ"},3)) preparationPrices.Cancel();
            try
            {
                var world=market.State;
                var estimate=PreparationCost.FromChain(result,world.WorldId,(PreparationPriceQuality)costQualityIndex,
                    id=>itemCatalog.State.Catalog?.Find(id),id=>market.GetCached(world.WorldId,id),DateTimeOffset.UtcNow,market.CacheLifetime);
                DrawPreparationCostDetails(recipe,result.Requested,estimate,true,chain.Input.ChoiceRevision,chain.CalculatedAt,stale);
            }
            catch(Exception error) {ImGui.TextWrapped($"Estimation de chaîne indisponible : {error.Message}");}
        }
        finally {ImGui.PopID();}
    }
    private void DrawPreparationCostDetails(RecipeDefinition recipe,long requested,PreparationCostEstimate estimate,bool chain=false,int chainRevision=0,
        DateTimeOffset? quantityAt=null,bool oldQuantities=false)
    {
        var world=market.State;
        if(world.WorldId!=estimate.WorldId) {ImGui.TextWrapped("Monde modifié : estimation à recalculer.");return;}
        ImGui.TextColored(Accent,world.WorldId==0 ? "Monde inconnu" : $"Marché : {world.WorldName}");
        var ids=estimate.Lines.Where(line=>line.Quantity!=0 && line.Status!=PreparationCostStatus.UnresolvedChain).Select(line=>itemCatalog.State.Catalog?.Find(line.ItemId))
            .Where(item=>item is {IsMarketable:true} && (costQualityIndex!=1 || item.CanBeHq)).Select(item=>item!.Id).Distinct().ToArray();
        var batch=preparationPrices.State;
        if(ids.Length>32) ImGui.TextWrapped("Plus de 32 objets à consulter : consultez leurs prix individuellement depuis le contexte, puis réouvrez cette estimation.");
        ImGui.BeginDisabled(world.WorldId==0 || bankBridge.State.CharacterId==0 || ids.Length==0 || ids.Length>32 || batch.Loading);
        try
        {
            if(ImGui.Button("Consulter les prix de la liste"))
            {
                try
                {
                    _=preparationPrices.StartAsync(market,new(bankBridge.State.CharacterId,world.WorldId,(uint)itemId,recipe.RecipeId,craftPlanTarget,costBasisIndex,costQualityIndex,chain,chainRevision),ids);
                    preparationCostError=null;
                }
                catch(Exception error) {preparationCostError=error.Message;}
            }
        }
        finally {ImGui.EndDisabled();}
        if(batch.Loading)
        {
            ImGui.SameLine(); if(ImGui.SmallButton("Arrêter la consultation")) preparationPrices.Cancel();
        }
        if(batch.Context?.RecipeId==recipe.RecipeId && batch.Context.IsChain==chain)
        {
            ImGui.TextDisabled($"Prix consultés : {batch.Completed}/{batch.Items.Count}"+(batch.Loading ? " · en cours…" : ""));
            if(batch.Error is { } error) ImGui.TextWrapped(error);
        }
        if(preparationCostError is { } failed) ImGui.TextWrapped(failed);
        ImGui.TextWrapped($"Requêtes à la demande vers universalis.app : identifiants d'objets et du monde uniquement. Cache partagé {TenshoAssistant.Caching.CacheAge.Label(market.CacheLifetime)}, cadence commune ; une consultation manuelle est prioritaire.");
        var costed=estimate.Lines.Count(line=>line.Cost is not null);
        if(estimate.KnownSubtotal is not { } subtotal) ImGui.TextColored(Accent,"Total non représentable : dépassement de capacité.");
        else if(estimate.Lines.Count==0) ImGui.TextColored(Success,"Aucun achat dans les besoins calculés : 0 gil selon les stocks recensés.");
        else if(costed==0) ImGui.TextColored(Accent,"Aucune ligne chiffrée : prix ou quantités à vérifier.");
        else ImGui.TextColored(estimate.AllCosted ? Success : Accent,
            $"{(estimate.AllCosted ? "Total indicatif" : "Sous-total partiel connu")} : {subtotal:N0} gils · {costed}/{estimate.Lines.Count} lignes chiffrées");
        if(estimate.StockUncertain) ImGui.TextWrapped("Rangements inconnus : l'écart recensé ne prouve pas les quantités réellement à acheter.");
        if(estimate.CachedStock) ImGui.TextDisabled("Stocks importés : actualisez les relevés après un transfert.");
        if(estimate.StalePrices) ImGui.TextColored(Accent,"Certains prix sont anciens, non datés ou de date incohérente.");
        if(ImGui.BeginTable("PreparationPrices",5,ImGuiTableFlags.RowBg|ImGuiTableFlags.SizingStretchProp))
        {
            try
            {
                ImGui.TableSetupColumn("Ingrédient",ImGuiTableColumnFlags.WidthStretch,2);
                ImGui.TableSetupColumn("Quantité"); ImGui.TableSetupColumn("Prix unitaire"); ImGui.TableSetupColumn("Coût"); ImGui.TableSetupColumn("État");
                ImGui.TableHeadersRow();
                var clipper=ImGui.ImGuiListClipper();
                try
                {
                    clipper.Begin(estimate.Lines.Count);
                    while(clipper.Step())
                    for(var index=clipper.DisplayStart;index<clipper.DisplayEnd;index++)
                    {
                    var line=estimate.Lines[index];
                    ImGui.TableNextRow(); ImGui.TableNextColumn(); ImGui.PushID((int)line.ItemId);
                    try
                    {
                        var item=itemCatalog.State.Catalog?.Find(line.ItemId);
                        DrawItemIcon(item,new Vector2(22)); var clicked=ImGui.IsItemClicked(); ImGui.SameLine();
                        if(ImGui.SmallButton(item?.Name ?? $"ID {line.ItemId}") || clicked) SelectItem(line.ItemId);
                        ImGui.TableNextColumn(); ImGui.TextUnformatted(line.Quantity?.ToString("N0") ?? "À vérifier");
                        ImGui.TableNextColumn(); ImGui.TextUnformatted(line.UnitPrice is { } unit ? $"{unit:N0} {(line.HighQuality==true ? "HQ" : "NQ")}" : "—");
                        if(ImGui.IsItemHovered() && line.Quote is { } quote)
                            ImGui.SetTooltip($"Monde {quote.WorldId}\nConsulté : {quote.FetchedAt:yyyy-MM-dd HH:mm:ss} UTC\nRelevé : {quote.UploadedAt?.ToString("yyyy-MM-dd HH:mm:ss") ?? "inconnu"} UTC");
                        ImGui.TableNextColumn(); ImGui.TextUnformatted(line.Cost?.ToString("N0") ?? "Inconnu");
                        ImGui.TableNextColumn(); ImGui.TextUnformatted(PreparationPriceStatus(line));
                        if(ImGui.IsItemHovered()) ImGui.SetTooltip(PreparationPriceStatus(line));
                    }
                    finally {ImGui.PopID();}
                    }
                }
                finally {clipper.End();clipper.Destroy();}
            }
            finally {ImGui.EndTable();}
        }
        ImGui.TextWrapped("Minimum unitaire rapporté × quantité. Disponibilité des piles, profondeur des offres et taxes ne sont pas incluses ; ce montant ne garantit pas un panier achetable. Stocks NQ + HQ déduits ensemble, sans garantir la qualité du craft.");
        if(ImGui.SmallButton("Copier l'estimation"))
        {
            var text=new StringBuilder().AppendLine($"Préparation {recipe.ResultItemId} · {requested} objets · {world.WorldName} ({world.WorldId}) · {estimate.Basis} / {estimate.Quality}");
            if(chain) text.AppendLine($"Besoins de la chaîne calculée le {quantityAt:O}. Stocks déjà déduits."+(oldQuantities ? " Observations renouvelées depuis : recalcul nécessaire." : ""));
            foreach(var line in estimate.Lines)
                text.AppendLine($"{itemCatalog.State.Catalog?.Find(line.ItemId)?.Name ?? $"ID {line.ItemId}"} : quantité {line.Quantity?.ToString() ?? "inconnue"}, unitaire {line.UnitPrice?.ToString() ?? "inconnu"} {(line.HighQuality is { } high ? high ? "HQ" : "NQ" : "qualité non établie")}, coût {line.Cost?.ToString() ?? "inconnu"} · {PreparationPriceStatus(line)} · relevé {line.Quote?.UploadedAt?.ToString("O") ?? "inconnu"}"
                    +(line.StockUncertain ? " · stock incertain" : "")+(line.CachedStock ? " · stock importé" : ""));
            text.AppendLine($"{(estimate.AllCosted ? "Total indicatif" : "Sous-total partiel")} : {estimate.KnownSubtotal?.ToString() ?? "dépassement"} gils. Prix et stocks à vérifier ; piles/taxes non incluses.");
            ImGui.SetClipboardText(text.ToString());
        }
    }
    private static string PreparationPriceStatus(PreparationCostLine line) => line.Status switch
    {
        PreparationCostStatus.Covered=>"Couvert par les stocks recensés",
        PreparationCostStatus.Priced=>line.StalePrice ? "Prix ancien/non daté" : "Minimum rapporté",
        PreparationCostStatus.UnknownStock=>"Stock inconnu",
        PreparationCostStatus.UnknownWorld=>"Monde inconnu",
        PreparationCostStatus.UnknownItem=>"Objet non résolu",
        PreparationCostStatus.NotMarketable=>"Hors marché",
        PreparationCostStatus.UnsupportedQuality=>"HQ indisponible pour cet objet",
        PreparationCostStatus.MissingQuote=>"Prix non consulté",
        PreparationCostStatus.WrongScope=>"Prix d'un autre monde/objet rejeté",
        PreparationCostStatus.MissingPrice=>"Minimum non renseigné",
        PreparationCostStatus.UnresolvedChain=>"Branche à résoudre avant chiffrage",
        _=>"Dépassement de capacité",
    };
}
