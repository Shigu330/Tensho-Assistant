using System.Numerics;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.Items;
using TenshoAssistant.Quests;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private string questSourceQuery="";
    private string questSourceCachedQuery="";
    private uint questSourceCachedItem;
    private QuestRewardIndex? questSourceCachedIndex;
    private IReadOnlyList<QuestItemRewardSource> questSourceMatches=[];
    private void DrawQuestItemSources(uint item)
    {
        if(!ImGui.CollapsingHeader("Quêtes proposant cet objet"))return;
        var state=quests.State;
        if(ImGui.SmallButton("Actualiser les quêtes##ItemSources"))quests.RequestRefresh();
        DrawCacheStamp(TenshoAssistant.Caching.CacheArea.Quests,state.ObservedAt,state.FromCache);
        if(state.Loading){ImGui.TextDisabled("Catalogue de quêtes en cours de lecture…");return;}
        if(state.Error is not null){ImGui.TextWrapped("Catalogue de quêtes indisponible dans le relevé courant.");return;}
        if(state.RewardIndexLoading){ImGui.TextDisabled("Index des récompenses en préparation…");return;}
        if(state.RewardIndex is not { } index)
        {
            ImGui.TextWrapped(state.RewardIndexError is null ? "Index non disponible dans ce relevé.":"Index des récompenses indisponible ; les autres données de quête restent consultables.");
            if(ImGui.SmallButton("Actualiser le catalogue de quêtes"))quests.RequestRefresh();
            return;
        }
        ImGui.SetNextItemWidth(-1);
        ImGui.InputTextWithHint("##QuestSourceSearch","Nom, catégorie ou identifiant de quête…",ref questSourceQuery,128);
        if(!string.IsNullOrEmpty(questSourceQuery) && ImGui.SmallButton("Effacer le filtre##QuestSources"))questSourceQuery="";
        if(!ReferenceEquals(index,questSourceCachedIndex) || item!=questSourceCachedItem || questSourceQuery!=questSourceCachedQuery)
        {
            questSourceMatches=index.Search(item,questSourceQuery);
            questSourceCachedIndex=index;questSourceCachedItem=item;questSourceCachedQuery=questSourceQuery;
        }
        var coverage=index.Coverage;var sources=questSourceMatches;
        ImGui.TextColored(Accent,$"{sources.Count:N0}/{index.ForItem(item).Count:N0} quêtes renseignant cet objet");
        ImGui.TextWrapped("Candidats du catalogue : choix, variantes et prérequis ne sont pas vérifiés. Ce résultat ne confirme ni disponibilité ni obtention.");
        ImGui.TextDisabled($"Couverture : {coverage.CoveredQuests:N0}/{coverage.TotalQuests:N0} quêtes nommées analysées");
        if(coverage.UnresolvedReferences>0 || coverage.CoveredQuests<coverage.TotalQuests || coverage.UnknownQuantityLines>0)
            ImGui.TextWrapped($"Le catalogue conserve {coverage.UnresolvedReferences:N0} références non résolues et {coverage.UnknownQuantityLines:N0} quantités inconnues ; d’autres sources peuvent manquer.");
        if(sources.Count==0){ImGui.TextDisabled(index.ForItem(item).Count==0 ? "Aucune quête indexée ne renseigne cet objet ; aucune absence générale de source n’est déduite.":"Aucune quête ne correspond au filtre ; effacez-le pour retrouver les sources indexées.");return;}
        if(!ImGui.BeginTable("ItemQuestSources",3,ImGuiTableFlags.RowBg|ImGuiTableFlags.SizingStretchProp))return;
        try
        {
            ImGui.TableSetupColumn("Quête",ImGuiTableColumnFlags.WidthStretch,4);ImGui.TableSetupColumn("Catégorie",ImGuiTableColumnFlags.WidthStretch,2);ImGui.TableSetupColumn("Variantes",ImGuiTableColumnFlags.WidthStretch,1);ImGui.TableHeadersRow();
            var clipper=ImGui.ImGuiListClipper();
            try
            {
                clipper.Begin(sources.Count);
                while(clipper.Step())for(var position=clipper.DisplayStart;position<clipper.DisplayEnd;position++)
                {
                    var source=sources[position];ImGui.PushID((int)source.QuestId);
                    try
                    {
                        ImGui.TableNextRow();ImGui.TableNextColumn();
                        DrawItemIcon(new ItemDefinition(0,source.Name,false,source.Icon),new Vector2(28));var clicked=ImGui.IsItemClicked();ImGui.SameLine();
                        clicked|=ImGui.Selectable(source.Name);
                        if(ImGui.IsItemHovered())ImGui.SetTooltip($"{source.Name}\n{source.Category}\nID quête : {source.QuestId}\nOuvrir la fiche et toutes les récompenses renseignées.");
                        if(clicked){SelectQuest(source.QuestId);page=Page.Quests;}
                        ImGui.TableNextColumn();ImGui.TextUnformatted(source.Category);
                        ImGui.TableNextColumn();ImGui.TextDisabled($"{source.Variants.Count:N0} variantes");
                        if(ImGui.IsItemHovered())ImGui.SetTooltip(string.Join('\n',source.Variants.Take(12).Select(line=>
                            $"{QuestRewardConditionLabel(line)} · {(line.Quantity is { } count ? "× "+count:"quantité inconnue")}{(line.HighQuality==true ? " HQ":"")}"))
                            +(source.Variants.Count>12 ? "\nToutes les variantes sont accessibles dans la fiche.":""));
                    }
                    finally{ImGui.PopID();}
                }
            }
            finally{clipper.End();clipper.Destroy();}
        }
        finally{ImGui.EndTable();}
    }
}
