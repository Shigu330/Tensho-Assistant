using Dalamud.Bindings.ImGui;
using TenshoAssistant.Caching;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private DataCache? dataCacheStore;
    internal void ConfigureDataCache(DataCache store){dataCacheStore=store;craftLogSession.ConfigureCache(()=>configuration.Cache.Duration(CacheArea.CraftCalculations),store);}
    private static readonly string[] CacheChoices=["5 minutes","1 heure","24 heures","7 jours"];
    private void DrawCacheSettings()
    {
        if(!ImGui.CollapsingHeader("Cache & péremption",ImGuiTreeNodeFlags.DefaultOpen))return;
        ImGui.TextWrapped("Les données sont conservées sur disque. Consulter réutilise un cache valable ; Actualiser force sa mise à jour dans l’outil. Réduire une durée s’applique aussi aux caches déjà enregistrés.");
        foreach(var (area,label) in new[]{(CacheArea.Prices,"Price Insight · prix et estimations"),(CacheArea.Quests,"Quêtes · progression et récompenses"),
            (CacheArea.Collections,"Collections · Mage bleu, cartes, titres, succès…"),(CacheArea.Sources,"Sources · pêche, monstres et butins"),
            (CacheArea.Fashion,"Revue de mode · répertoire des équipements"),(CacheArea.ImportedStock,"Stocks importés · avertissement de péremption"),(CacheArea.CraftCalculations,"Artisanat · macros et calculs du carnet")})
        {
            var selected=(int)configuration.Cache.Get(area);ImGui.SetNextItemWidth(155);
            if(ImGui.Combo(label,ref selected,CacheChoices,CacheChoices.Length))
            {
                var previous=configuration.Cache;configuration.Cache=previous.With(area,(CacheRetention)selected);
                try{save();saveError=null;}
                catch(Exception error){configuration.Cache=previous;saveError="Échec de sauvegarde des durées du cache.";log.Warning(error,"Could not persist cache policy.");}
            }
        }
        ImGui.TextWrapped("Quêtes et collections : actualisation à expiration, au changement de personnage ou via leur bouton Actualiser. Les acquisitions nouvellement détectées invalident aussi le relevé des collections.");
        ImGui.TextWrapped("Servants et chocobo : import manuel obligatoire lorsque leur inventaire est ouvert. La durée marque un relevé ancien, sans effacer les objets ni lancer un import automatiquement.");
        ImGui.TextWrapped("Catalogues du jeu (objets, recettes, cartes, météo, usages, contenus…) : déjà chargés une seule fois et partagés en mémoire. Le rechargement/version/langue du jeu reconstruit ces catalogues locaux. Les fichiers du jeu restent leur source.");
        ImGui.TextWrapped("Inventaire en direct, attributs, synthèse et mini-jeux : cache court invalidé par leur contexte ; ils ne sont jamais figés pendant plusieurs jours. Les calculs de macros et prévisions sont réutilisés tant que leurs entrées restent identiques.");
        if(dataCacheStore?.Error is { } errorText)ImGui.TextWrapped(errorText);
    }
    private void DrawCacheStamp(CacheArea area,DateTimeOffset? date,bool restored=false)
    {
        if(date is not { } observed){ImGui.TextDisabled("Aucun relevé daté en cache.");return;}
        var duration=configuration.Cache.Duration(area);var fresh=CacheAge.Fresh(observed,DateTimeOffset.UtcNow,duration);
        ImGui.TextColored(fresh ? Muted:Accent,$"{(restored ? "Cache disque":"Dernière actualisation")} : {observed:yyyy-MM-dd HH:mm:ss} UTC · {(fresh ? "valable":"périmé")} ({CacheAge.Label(duration)})");
    }
}
