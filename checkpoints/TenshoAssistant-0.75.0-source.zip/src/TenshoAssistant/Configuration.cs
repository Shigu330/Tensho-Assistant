namespace TenshoAssistant;

// Pure managed settings; the Dalamud interface is attached in a separate partial.
public sealed partial class Configuration
{
    public int Version { get; set; } = 1;
    private Caching.CachePreferences cache=new();
    public Caching.CachePreferences Cache {get=>Volatile.Read(ref cache);set=>Volatile.Write(ref cache,value ?? new());}
    public List<TenshoAssistant.Macros.MacroSlot> MacroChainPlan { get; set; } = [];
    public List<TenshoAssistant.Maps.MapBookmark> MapBookmarks { get; set; } = [];
    public List<TenshoAssistant.Craft.CraftPreset>? CraftPresets { get; set; } = [];
    public List<uint> TripleTriadDeck { get; set; } = [];
    public List<uint> FollowedQuests { get; set; } = [];
    public bool OpenOnLoad { get; set; }
    public bool OpenOnLogin { get; set; }
    public string LanguageCode { get; set; } = "en";
    public Dictionary<string, bool> Observations { get; set; } = new();
    private bool craftLogHelperEnabled=true;
    public bool CraftLogHelperEnabled
    {
        get=>Volatile.Read(ref craftLogHelperEnabled);
        set=>Volatile.Write(ref craftLogHelperEnabled,value);
    }
    public int SortPreviewField { get; set; }
    public bool SortPreviewDescending { get; set; }
    public List<TenshoAssistant.Inventory.InventorySortProfile>? InventorySortProfiles { get; set; }=[];
    public List<TenshoAssistant.Inventory.InventorySortTemplate>? InventorySortTemplates { get; set; }=[];
    private bool marketPricesOnHover;
    private bool itemUsagesOnHover;
    private bool itemContextMenuEnabled;
    public bool ItemContextMenuEnabled
    {
        get => Volatile.Read(ref itemContextMenuEnabled);
        set => Volatile.Write(ref itemContextMenuEnabled,value);
    }
    public bool ItemUsagesOnHover
    {
        get => Volatile.Read(ref itemUsagesOnHover);
        set => Volatile.Write(ref itemUsagesOnHover,value);
    }
    public bool MarketPricesOnHover
    {
        get => Volatile.Read(ref marketPricesOnHover);
        set => Volatile.Write(ref marketPricesOnHover, value);
    }
}
