using System.Numerics;
using Dalamud.Bindings.ImGui;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private void DrawMarket()
    {
        Heading("Prix du marché", "Données Universalis pour le monde courant · consultation à la demande");
        var state = market.State;
        ImGui.TextColored(Accent, state.WorldId == 0 ? "Monde inconnu" : state.WorldName);
        if (itemId <= 0) { ImGui.TextWrapped("Sélectionnez un objet dans Recherche ou Banque pour consulter ses prix."); return; }
        DrawItemIcon(SelectedItem, new Vector2(40));
        ImGui.SameLine(); ImGui.TextUnformatted(SelectedItem?.Name ?? $"ID {itemId}");
        ImGui.BeginDisabled(state.WorldId == 0 || state.Loading);
        try
        {
            if (ImGui.Button("Consulter les prix")) _ = market.RequestAsync((uint)itemId);
            ImGui.SameLine();
            if (ImGui.Button("Actualiser")) _ = market.RequestAsync((uint)itemId, true);
        }
        finally { ImGui.EndDisabled(); }
        ImGui.TextWrapped($"Cache partagé : {TenshoAssistant.Caching.CacheAge.Label(market.CacheLifetime)}. Consulter réutilise le cache ; Actualiser force une nouvelle consultation, avec la cadence habituelle.");
        if (state.ItemId != (uint)itemId) return;
        if (state.Loading) ImGui.TextDisabled("Consultation en cours…");
        if (state.Error is { } error) ImGui.TextWrapped(error);
        if (state.Quote is not { } quote) return;
        ImGui.TextDisabled($"Consulté : {quote.FetchedAt:yyyy-MM-dd HH:mm:ss} UTC");
        ImGui.TextDisabled(market.IsFresh(quote,DateTimeOffset.UtcNow) ? "Cache encore valable":"Cache périmé · cliquez sur Actualiser");
        ImGui.TextDisabled(quote.UploadedAt is { } date ? $"Dernier relevé du monde : {date:yyyy-MM-dd HH:mm:ss} UTC" : "Date du relevé du monde inconnue");
        if (!quote.HasRecentUpload(DateTimeOffset.UtcNow))
            ImGui.TextColored(Accent, "Relevé ancien, non daté ou date incohérente : vérifier les ventes en jeu.");
        if (ImGui.BeginTable("MarketPrices", 4, ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingStretchProp))
        {
            try
            {
                ImGui.TableSetupColumn("Qualité");
                ImGui.TableSetupColumn("Minimum rapporté (gils)");
                ImGui.TableSetupColumn("Dernière vente (gils)");
                ImGui.TableSetupColumn("Date de vente UTC");
                ImGui.TableHeadersRow();
                foreach (var value in new[] { ("NQ", quote.Nq), ("HQ", quote.Hq) })
                {
                    ImGui.TableNextRow();
                    ImGui.TableNextColumn(); ImGui.TextUnformatted(value.Item1);
                    ImGui.TableNextColumn(); ImGui.TextUnformatted(value.Item2.Minimum?.ToString("N0") ?? "Non renseigné");
                    ImGui.TableNextColumn(); ImGui.TextUnformatted(value.Item2.RecentSale?.ToString("N0") ?? "Non renseigné");
                    ImGui.TableNextColumn(); ImGui.TextUnformatted(value.Item2.SaleAt?.ToString("yyyy-MM-dd HH:mm:ss") ?? "Inconnue");
                }
            }
            finally { ImGui.EndTable(); }
        }
        ImGui.TextWrapped("Les données communautaires peuvent être périmées. Aucun prix de centre de données n'est substitué à celui du monde courant.");
    }
}
