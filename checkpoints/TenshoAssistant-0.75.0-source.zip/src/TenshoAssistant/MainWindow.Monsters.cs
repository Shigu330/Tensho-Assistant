using System.Globalization;
using System.Numerics;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.Monsters;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private uint selectedMonsterMap;
    private void DrawMonsterLoot()
    {
        Heading("Matériaux des monstres","Objet en contexte · associations communautaires consultées manuellement");
        if (ImGui.CollapsingHeader("Choisir un matériau##Monster",itemId <= 0 ? ImGuiTreeNodeFlags.DefaultOpen : ImGuiTreeNodeFlags.None))
            DrawItemSearch(160);
        monsterLoot.SelectItem(itemId > 0 ? (uint)itemId : 0);
        var state = monsterLoot.State;
        if (state.ItemId == 0) { ImGui.TextWrapped("Recherchez un matériau ou sélectionnez un ingrédient, puis ouvrez cet outil depuis son contexte."); return; }
        DrawItemIcon(SelectedItem,new Vector2(40)); ImGui.SameLine();
        ImGui.TextColored(Accent,SelectedItem?.Name ?? $"Objet {state.ItemId}");
        if (state.Loading) { if (ImGui.Button("Annuler la consultation##Monster")) monsterLoot.Cancel(); ImGui.SameLine(); ImGui.TextDisabled("Lecture en cours…"); }
        else
        {
            if (ImGui.Button("Consulter les monstres associés")) _ = monsterLoot.RequestItemAsync();
            if (state.Item is not null)
            { ImGui.SameLine(); if (ImGui.SmallButton("Actualiser la liste##Monster")) _ = monsterLoot.RequestItemAsync(true); }
        }
        if (state.Error is { } error) ImGui.TextWrapped(error);
        ImGui.TextWrapped("Source : Garland Tools. Associations et positions indicatives, couverture partielle, sans taux de drop ni présence en direct. Les identifiants publics d'objet/monstre sont envoyés uniquement après clic sur Consulter ou Actualiser.");
        if (state.Item is not { } itemDocument) return;
        ImGui.TextDisabled($"Liste récupérée le {itemDocument.FetchedAt:yyyy-MM-dd HH:mm:ss} UTC · mise à jour de la source inconnue");
        DrawCacheStamp(TenshoAssistant.Caching.CacheArea.Sources,itemDocument.FetchedAt);
        if (!itemDocument.HasDrops) ImGui.TextWrapped("Liste de monstres non renseignée pour cet objet ; cela ne prouve pas l'absence de drops.");
        if (itemDocument.Monsters.Count == 0) { ImGui.TextDisabled("Aucune association renseignée dans cette réponse."); return; }
        ImGui.TextDisabled($"{itemDocument.Monsters.Count} références de monstres · cliquez pour sélectionner une fiche");
        var height = Math.Clamp(itemDocument.Monsters.Count*30+30,90,210);
        var showList = ImGui.BeginChild("MonsterReferences",new Vector2(0,height),true);
        try
        {
            if (showList && ImGui.BeginTable("MonsterReferencesTable",3,ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingStretchProp))
            {
                try
                {
                    ImGui.TableSetupColumn("Monstre",ImGuiTableColumnFlags.WidthStretch,2);
                    ImGui.TableSetupColumn("Niveau"); ImGui.TableSetupColumn("Zone"); ImGui.TableHeadersRow();
                    var clipper = ImGui.ImGuiListClipper();
                    try
                    {
                        clipper.Begin(itemDocument.Monsters.Count);
                        while (clipper.Step())
                        for (var index=clipper.DisplayStart; index<clipper.DisplayEnd; index++)
                        {
                            var monster = itemDocument.Monsters[index];
                            ImGui.TableNextRow(); ImGui.TableNextColumn();
                            if (ImGui.Selectable($"{(monster.Name.Length == 0 ? $"Monstre {monster.Id}" : monster.Name)}##Mob{monster.Id}",state.MonsterId == monster.Id))
                            { monsterLoot.SelectMonster(monster.Id); selectedMonsterMap=0; }
                            if (ImGui.IsItemHovered()) ImGui.SetTooltip($"Référence source : {monster.Id}");
                            ImGui.TableNextColumn(); ImGui.TextUnformatted(monster.Level.Length == 0 ? "Non renseigné" : monster.Level);
                            ImGui.TableNextColumn(); ImGui.TextUnformatted(MonsterZone(monster.PlaceNameId));
                        }
                    }
                    finally { clipper.End(); clipper.Destroy(); }
                }
                finally { ImGui.EndTable(); }
            }
        }
        finally { ImGui.EndChild(); }
        if (state.MonsterId == 0) return;
        ImGui.Separator();
        var selected = itemDocument.Monsters.FirstOrDefault(monster => monster.Id == state.MonsterId);
        ImGui.TextColored(Accent,selected?.Name is { Length: >0 } name ? name : $"Monstre {state.MonsterId}");
        ImGui.BeginDisabled(state.Loading);
        try
        {
            if (ImGui.Button("Consulter la fiche du monstre")) _ = monsterLoot.RequestMonsterAsync();
            if (state.Monster is not null)
            { ImGui.SameLine(); if (ImGui.SmallButton("Actualiser la fiche##Monster")) _ = monsterLoot.RequestMonsterAsync(true); }
        }
        finally { ImGui.EndDisabled(); }
        if (state.Monster is not { } detail) return;
        ImGui.TextDisabled($"Fiche récupérée le {detail.FetchedAt:yyyy-MM-dd HH:mm:ss} UTC · ID {detail.Id}");
        DrawCacheStamp(TenshoAssistant.Caching.CacheArea.Sources,detail.FetchedAt);
        ImGui.TextUnformatted($"{detail.Name} · niveau {(detail.Level.Length == 0 ? "non renseigné" : detail.Level)}");
        ImGui.TextUnformatted(MonsterZone(detail.PlaceNameId));
        if (detail.X is { } x && detail.Y is { } y) ImGui.TextDisabled($"Position indicative de la source : X {x:F2}, Y {y:F2}");
        else ImGui.TextDisabled("Position non renseignée.");
        if (detail.HasDrops && !detail.DropItemIds.Contains(state.ItemId))
            ImGui.TextWrapped("Les deux réponses de la source ne confirment pas la même association : cet objet n'apparaît pas dans la fiche du monstre.");
        DrawMonsterMap(detail);
        if (detail.InstanceId != 0)
        {
            var duty = duties.State.Catalog?.Entries.FirstOrDefault(entry => entry.InstanceId == detail.InstanceId);
            if (duty is not null && ImGui.SmallButton($"Butin du contenu : {duty.Name}"))
            { dutyLoot.Select(duty); showDutyDetails=true; page=Page.DutyLoot; }
            else if (duty is null) ImGui.TextDisabled($"Instance référencée : {detail.InstanceId} (hors catalogue courant)");
        }
        if (ImGui.CollapsingHeader($"Autres objets renseignés ({detail.DropItemIds.Count})##Monster"))
        {
            if (!detail.HasDrops) ImGui.TextDisabled("Liste d'objets non renseignée.");
            var showItems=ImGui.BeginChild("MonsterDropItems",new Vector2(0,155),true);
            try
            {
                if (showItems)
                {
                    var clipper=ImGui.ImGuiListClipper();
                    try
                    {
                        clipper.Begin(detail.DropItemIds.Count);
                        while (clipper.Step())
                        for (var index=clipper.DisplayStart;index<clipper.DisplayEnd;index++)
                        {
                            var id=detail.DropItemIds[index]; var item=itemCatalog.State.Catalog?.Find(id);
                            DrawItemIcon(item,new Vector2(24)); var clicked=ImGui.IsItemClicked(); ImGui.SameLine();
                            ImGui.BeginDisabled(item is null || id>int.MaxValue);
                            try { if ((ImGui.SmallButton($"{item?.Name ?? $"Objet {id}"}##MobDrop{id}") || clicked) && item is not null && id<=int.MaxValue) SelectItem(id); }
                            finally { ImGui.EndDisabled(); }
                        }
                    }
                    finally { clipper.End(); clipper.Destroy(); }
                }
            }
            finally { ImGui.EndChild(); }
        }
    }
    private string MonsterZone(uint placeNameId) => maps.State.Catalog?.ForPlace(placeNameId).FirstOrDefault()?.Zone
        ?? (placeNameId == 0 ? "Zone non renseignée" : $"Lieu {placeNameId}");
    private void DrawMonsterMap(MonsterDocument monster)
    {
        var choices=maps.State.Catalog?.ForPlace(monster.PlaceNameId);
        if (choices is null || choices.Count==0) { ImGui.TextDisabled("Aucune carte résolue pour ce lieu ; identité de lieu conservée."); return; }
        var chosen=choices.Count==1 ? choices[0] : choices.FirstOrDefault(map=>map.MapId==selectedMonsterMap);
        if (choices.Count>1 && ImGui.BeginCombo("Carte du lieu##Monster",chosen?.Zone ?? "Choisir une carte"))
        {
            try { foreach(var map in choices) if(ImGui.Selectable($"{map.Zone} · {map.Subzone} · carte {map.MapId}",map.MapId==selectedMonsterMap)) selectedMonsterMap=map.MapId; }
            finally { ImGui.EndCombo(); }
        }
        if (chosen is not null && ImGui.SmallButton("Consulter la carte de zone##Monster"))
        {
            selectedMapId=chosen.MapId; mapQuery=""; mapX=20.5f; mapY=20.5f;
            selectedBookmark=Guid.Empty; bookmarkName=""; bookmarkSaved=false; mapOpenError=null; page=Page.Maps;
        }
        ImGui.TextDisabled("Carte centrée sur la zone ; la position indicative n'est pas placée automatiquement.");
    }
}
