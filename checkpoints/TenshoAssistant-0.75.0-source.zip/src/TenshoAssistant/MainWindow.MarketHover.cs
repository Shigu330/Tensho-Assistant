using System.Numerics;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.Items;
using TenshoAssistant.Market;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private Vector2 hoverPanelSize=new(380,300);
    public void DrawItemHover()
    {
        var observed=itemHover.State;var now=DateTimeOffset.UtcNow;
        if(windowDisposed || !observed.Fresh(now) || observed.Item is not { } hovered)return;
        var priced=MarketHoverTracker.Eligible(hovered,itemCatalog.State.Catalog);
        var prices=configuration.MarketPricesOnHover && market.State.WorldId!=0 && priced is not null;
        var usages=configuration.ItemUsagesOnHover && observed.Stable(now);
        if(!prices && !usages)return;
        var viewport=ImGui.GetMainViewport();var position=ImGui.GetMousePos()+new Vector2(24);
        position.X=Math.Clamp(position.X,viewport.WorkPos.X,Math.Max(viewport.WorkPos.X,viewport.WorkPos.X+viewport.WorkSize.X-hoverPanelSize.X));
        position.Y=Math.Clamp(position.Y,viewport.WorkPos.Y,Math.Max(viewport.WorkPos.Y,viewport.WorkPos.Y+viewport.WorkSize.Y-hoverPanelSize.Y));
        ImGui.SetNextWindowPos(position,ImGuiCond.Always);
        ImGui.SetNextWindowSizeConstraints(Vector2.Zero,viewport.WorkSize);
        ImGui.SetNextWindowBgAlpha(0.94f);
        var visible=ImGui.Begin("Objet au survol###TenshoItemHover",ImGuiWindowFlags.NoDecoration | ImGuiWindowFlags.AlwaysAutoResize
            | ImGuiWindowFlags.NoSavedSettings | ImGuiWindowFlags.NoInputs | ImGuiWindowFlags.NoFocusOnAppearing | ImGuiWindowFlags.NoNav);
        try
        {
            if(!visible)return;
            var item=itemCatalog.State.Catalog?.Find(hovered.ItemId);DrawItemIcon(item,new Vector2(28));ImGui.SameLine();
            ImGui.PushTextWrapPos(Math.Min(350,Math.Max(120,viewport.WorkSize.X-32)));
            try
            {
                ImGui.TextColored(Accent,item?.Name ?? $"Objet {hovered.ItemId}");
                ImGui.TextDisabled(hovered.Kind switch {ItemHoverKind.Hq=>"Objet HQ",ItemHoverKind.Collectible=>"Objet collectionnable",_=>"Objet NQ"});
                if(usages)DrawHoveredUsages(hovered.ItemId);
                if(prices)
                {
                    if(usages)ImGui.Separator();
                    DrawHoveredPrices(priced!);
                }
            }
            finally{ImGui.PopTextWrapPos();}
            hoverPanelSize=ImGui.GetWindowSize();
        }
        finally{ImGui.End();}
    }
    private void DrawHoveredUsages(uint id)
    {
        ImGui.TextColored(Accent,"Usages · références de l’objet de base");
        if(recipeCatalog.State.Catalog is { } recipes)ImGui.TextUnformatted($"Recettes utilisant l’objet : {recipes.ForIngredient(id).Count}");
        else ImGui.TextDisabled("Recettes : catalogue en préparation");
        if(itemUses.State.Catalog is not { } uses)
        {ImGui.TextWrapped(itemUses.State.Error is null ? "Autres usages : catalogue en préparation":"Autres usages : catalogue indisponible");return;}
        ImGui.TextUnformatted($"Mandats d’artisanat : {uses.LevesFor(id).Count}");
        if(uses.IsSupplyCandidate(id))ImGui.TextWrapped("Livraison GC potentielle · demande du jour non observée");
        if(uses.IsAquariumFish(id))ImGui.TextUnformatted("Poisson référencé pour aquarium");
        ImGui.TextDisabled("Catalogues du jeu · déblocages et acceptation non observés");
    }
    private void DrawHoveredPrices(MarketHoverItem hovered)
    {
        var state=market.State;var quote=market.GetCached(state.WorldId,hovered.ItemId);var background=market.BackgroundState;
        ImGui.TextColored(Accent,$"Prix · {state.WorldName}");
        if(quote is { } prices)
        {
            ImGui.TextUnformatted($"Minimum NQ : {prices.Nq.Minimum?.ToString("N0") ?? "Non renseigné"} gils");
            ImGui.TextUnformatted($"Minimum HQ : {prices.Hq.Minimum?.ToString("N0") ?? "Non renseigné"} gils");
            ImGui.TextDisabled($"Consulté {prices.FetchedAt:HH:mm:ss} UTC");
            ImGui.TextDisabled(prices.UploadedAt is { } date ? $"Relevé {date:yyyy-MM-dd HH:mm} UTC":"Date du relevé inconnue");
            if(!prices.HasRecentUpload(DateTimeOffset.UtcNow))ImGui.TextColored(Accent,"Relevé ancien, non daté ou date incohérente");
            if(!market.IsFresh(prices,DateTimeOffset.UtcNow))ImGui.TextDisabled("Cache expiré · actualisation en attente");
        }
        else ImGui.TextWrapped(background?.ItemId==hovered.ItemId && background.WorldId==state.WorldId
            ? background.Loading ? "Consultation en cours…":background.Error ?? "Aucun prix renseigné"
            :"Consultation après un survol stable…");
        ImGui.TextDisabled("Universalis · données communautaires");
    }
}
