using System.Numerics;
using Dalamud.Bindings.ImGui;

namespace TenshoAssistant.UI;

internal static class FfxivTheme
{
    public static readonly Vector4 Background = new(0.075f, 0.065f, 0.055f, 1);
    public static readonly Vector4 Panel = new(0.12f, 0.105f, 0.09f, 1);
    public static readonly Vector4 Border = new(0.34f, 0.27f, 0.17f, 1);
    public static readonly Vector4 Gold = new(0.94f, 0.77f, 0.46f, 1);
    public static readonly Vector4 TextMuted = new(0.65f, 0.69f, 0.75f, 1);
    public static readonly Vector4 Success = new(0.52f, 0.85f, 0.66f, 1);

    public static void Push()
    {
        ImGui.PushStyleColor(ImGuiCol.WindowBg, Background);
        ImGui.PushStyleColor(ImGuiCol.ChildBg, Panel);
        ImGui.PushStyleColor(ImGuiCol.Border, Border);
        ImGui.PushStyleColor(ImGuiCol.HeaderHovered, new Vector4(0.28f, 0.22f, 0.14f, 1));
        ImGui.PushStyleColor(ImGuiCol.HeaderActive, new Vector4(0.38f, 0.29f, 0.17f, 1));
        ImGui.PushStyleVar(ImGuiStyleVar.WindowRounding, 2);
        ImGui.PushStyleVar(ImGuiStyleVar.ChildRounding, 2);
        ImGui.PushStyleVar(ImGuiStyleVar.FrameRounding, 2);
        ImGui.PushStyleVar(ImGuiStyleVar.FramePadding, new Vector2(6, 3));
    }

    public static void Pop()
    {
        ImGui.PopStyleVar(4);
        ImGui.PopStyleColor(5);
    }
}
