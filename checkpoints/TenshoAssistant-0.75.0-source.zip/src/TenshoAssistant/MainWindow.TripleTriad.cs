using System.Numerics;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.Collections;
using TenshoAssistant.Items;
using TenshoAssistant.MiniGames;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private CollectionState? triadViewState;
    private CollectionState? triadCatalogState;
    private CollectionEntry[] triadCards = [];
    private CollectionEntry[] triadMatches = [];
    private string triadQuery = "";
    private string triadPreviousQuery = "";
    private int triadStars;
    private int triadPreviousStars = -1;
    private int triadAcquisition;
    private int triadPreviousAcquisition = -1;
    private uint? triadType;
    private uint? triadPreviousType;
    private uint selectedTriad;
    private List<uint>? triadDeck;
    private string? triadDeckError;
    private bool triadDeckSaved;

    private void DrawTripleTriad()
    {
        Heading("Triple Triade", "Carnet du jeu et préparation d'un deck · sélectionnez une carte pour consulter ses valeurs.");
        var state = collections.State;
        if (ImGui.SmallButton("Actualiser les acquisitions##Triad")) collections.RequestRefresh();
        DrawCacheStamp(TenshoAssistant.Caching.CacheArea.Collections,collections.State.ObservedAt,collections.State.FromCache);
        ImGui.SameLine();
        ImGui.TextDisabled(state.Loading ? "Lecture en cours…" : state.ObservedAt is { } date ? $"Observation : {date:HH:mm:ss} UTC" : "Aucun personnage observé");
        if (state.Error is { } error) ImGui.TextWrapped(error);
        triadDeck ??= (configuration.TripleTriadDeck ?? []).ToList();
        if (!ReferenceEquals(triadCatalogState, state))
        {
            triadCatalogState = state;
            triadCards = state.Entries.Where(entry => entry.Kind == CollectionKind.TripleTriad && entry.Card is { IsValid: true })
                .OrderBy(entry => entry.Card!.Number).ThenBy(entry => entry.Id).ToArray();
        }
        if (ImGui.BeginTabBar("TriadNotebook"))
        {
            try
            {
                if (ImGui.BeginTabItem("Carnet des cartes"))
                {
                    try { DrawTriadNotebook(state); }
                    finally { ImGui.EndTabItem(); }
                }
                if (ImGui.BeginTabItem("Mon deck"))
                {
                    try { DrawTriadDeck(); }
                    finally { ImGui.EndTabItem(); }
                }
                if (ImGui.BeginTabItem("Simulateur & conseil"))
                {
                    try { DrawTriadSimulation(); }
                    finally { ImGui.EndTabItem(); }
                }
                if (ImGui.BeginTabItem("Match observé"))
                {
                    try { DrawTriadObservation(); }
                    finally { ImGui.EndTabItem(); }
                }
            }
            finally { ImGui.EndTabBar(); }
        }
        if (state.CharacterId == 0) ImGui.TextDisabled("Connectez un personnage pour confirmer ses acquisitions.");
        ImGui.TextWrapped("Non confirmé ne signifie pas manquant. Simulation locale avec deux mains connues ; aucun coup n'est joué dans le jeu. Règles couvertes : Inversion, Tueur d'as, Identique/Plus avec combos, Ordre et Bonus ou Malus.");
    }

    private void DrawTriadNotebook(CollectionState state)
    {
        ImGui.SetNextItemWidth(-1);
        ImGui.InputTextWithHint("##TriadSearch", "Nom ou numéro de carte…", ref triadQuery, 128);
        ImGui.SetNextItemWidth(150);
        ImGui.Combo("Rareté##Triad", ref triadStars, new[] { "Toutes", "1 étoile", "2 étoiles", "3 étoiles", "4 étoiles", "5 étoiles" }, 6);
        ImGui.SameLine(); ImGui.SetNextItemWidth(170);
        ImGui.Combo("Acquisition##Triad", ref triadAcquisition, new[] { "Toutes", "Confirmées", "Non confirmées" }, 3);
        ImGui.SetNextItemWidth(180);
        var typeName = triadType is { } type ? triadCards.FirstOrDefault(entry => entry.Card!.TypeId == type)?.Card?.TypeName : null;
        if (ImGui.BeginCombo("Type##Triad", triadType is null ? "Tous" : string.IsNullOrWhiteSpace(typeName) ? "Sans type" : typeName))
        {
            try
            {
                if (ImGui.Selectable("Tous", triadType is null)) triadType = null;
                foreach (var card in triadCards.Select(entry => entry.Card!).DistinctBy(card => card.TypeId).OrderBy(card => card.TypeId))
                    if (ImGui.Selectable($"{(string.IsNullOrWhiteSpace(card.TypeName) ? "Sans type" : card.TypeName)}##{card.TypeId}", triadType == card.TypeId)) triadType = card.TypeId;
            }
            finally { ImGui.EndCombo(); }
        }
        if (!ReferenceEquals(triadViewState, state) || triadQuery != triadPreviousQuery || triadStars != triadPreviousStars
            || triadAcquisition != triadPreviousAcquisition || triadType != triadPreviousType)
        {
            triadViewState = state;
            triadPreviousQuery = triadQuery; triadPreviousStars = triadStars;
            triadPreviousAcquisition = triadAcquisition; triadPreviousType = triadType;
            var query = triadQuery.Trim();
            triadMatches = triadCards.Where(entry => (triadStars == 0 || entry.Card!.Stars == triadStars)
                && (triadType is null || entry.Card!.TypeId == triadType)
                && (triadAcquisition == 0 || (triadAcquisition == 1 ? entry.ConfirmedUnlocked : !entry.ConfirmedUnlocked))
                && (query.Length == 0 || entry.Name.Contains(query, StringComparison.OrdinalIgnoreCase)
                    || entry.Card!.Number.ToString() == query)).ToArray();
            if (!triadMatches.Any(entry => entry.Id == selectedTriad)) selectedTriad = triadMatches.FirstOrDefault()?.Id ?? 0;
        }
        ImGui.TextColored(Accent, $"{triadMatches.Length} cartes affichées · {triadCards.Count(entry => entry.ConfirmedUnlocked)} acquisitions confirmées / {triadCards.Length} cartes du catalogue");
        if (!ImGui.BeginTable("TriadCards", 2, ImGuiTableFlags.SizingStretchProp)) return;
        try
        {
            ImGui.TableSetupColumn("Liste", ImGuiTableColumnFlags.WidthStretch, 1);
            ImGui.TableSetupColumn("Fiche", ImGuiTableColumnFlags.WidthStretch, 1.4f);
            ImGui.TableNextRow(); ImGui.TableNextColumn();
            var height = Math.Max(160, ImGui.GetContentRegionAvail().Y - 90);
            var visible = ImGui.BeginChild("TriadCardList", new Vector2(0, height), true);
            try
            {
                if (visible)
                {
                    var clipper = ImGui.ImGuiListClipper();
                    try
                    {
                        var rowHeight = 36 + ImGui.GetStyle().ItemSpacing.Y;
                        clipper.Begin(triadMatches.Length, rowHeight);
                        while (clipper.Step())
                        for (var index = clipper.DisplayStart; index < clipper.DisplayEnd; index++)
                        {
                            var entry = triadMatches[index];
                            ImGui.PushID((int)entry.Id);
                            try
                            {
                                DrawItemIcon(new ItemDefinition(0, entry.Name, false, entry.IconId), new Vector2(36));
                                var clicked = ImGui.IsItemClicked();
                                if (ImGui.IsItemHovered()) ImGui.SetTooltip(entry.Name);
                                ImGui.SameLine();
                                if (ImGui.Selectable($"{entry.Card!.Number} · {entry.Name}", selectedTriad == entry.Id, ImGuiSelectableFlags.None, new Vector2(0, 36)) || clicked)
                                    selectedTriad = entry.Id;
                            }
                            finally { ImGui.PopID(); }
                        }
                    }
                    finally { clipper.End(); clipper.Destroy(); }
                    if (triadMatches.Length == 0) ImGui.TextWrapped("Aucune carte ne correspond à ces filtres.");
                }
            }
            finally { ImGui.EndChild(); }
            ImGui.TableNextColumn();
            var detailsVisible = ImGui.BeginChild("TriadCardDetail", new Vector2(0, height), true);
            try
            {
                if (detailsVisible && triadCards.FirstOrDefault(entry => entry.Id == selectedTriad) is { } selected)
                    DrawTriadCardDetails(selected);
            }
            finally { ImGui.EndChild(); }
        }
        finally { ImGui.EndTable(); }
    }

    private void DrawTriadCardDetails(CollectionEntry entry)
    {
        var card = entry.Card!;
        DrawItemIcon(new ItemDefinition(0, entry.Name, false, entry.IconId), new Vector2(80));
        ImGui.SameLine(); ImGui.TextColored(Accent, $"{card.Number} · {entry.Name}");
        ImGui.TextUnformatted(new string('★', card.Stars));
        ImGui.TextUnformatted(string.IsNullOrWhiteSpace(card.TypeName) ? "Sans type" : card.TypeName);
        ImGui.TextColored(entry.ConfirmedUnlocked ? Success : Muted, entry.ConfirmedUnlocked ? "Acquise confirmée" : "Acquisition non confirmée");
        ImGui.Separator();
        DrawTriadValues(card);
        ImGui.TextWrapped(card.Description);
        ImGui.Spacing();
        var canAdd = triadDeck!.Count < 5 && !triadDeck.Contains(entry.Id);
        ImGui.BeginDisabled(!canAdd);
        try
        {
            if (ImGui.Button("Ajouter au deck")) { triadDeck.Add(entry.Id); triadDeckSaved = false; }
        }
        finally { ImGui.EndDisabled(); }
        if (ImGui.SmallButton("Main bleue du simulateur")) AddTriadSimulationCard(entry.Id, false);
        ImGui.SameLine();
        if (ImGui.SmallButton("Main rouge du simulateur")) AddTriadSimulationCard(entry.Id, true);
        foreach (var item in itemCatalog.State.Catalog?.ForTriadCard(card.Id) ?? [])
        {
            if (ImGui.Button($"Stocks et outils : {item.Name}##{item.Id}"))
            { SelectItem(item.Id); page = Page.Items; focusStocksTab = true; }
        }
        if (ImGui.SmallButton("Copier la carte"))
            ImGui.SetClipboardText($"{card.Number} · {entry.Name} · {card.Stars} étoiles · ↑{TriadCardDefinition.Value(card.Top)} →{TriadCardDefinition.Value(card.Right)} ↓{TriadCardDefinition.Value(card.Bottom)} ←{TriadCardDefinition.Value(card.Left)}");
    }

    private static void DrawTriadValues(TriadCardDefinition card)
    {
        if (!ImGui.BeginTable("CardSides", 3, ImGuiTableFlags.SizingFixedFit)) return;
        try
        {
            for (var column = 0; column < 3; column++) ImGui.TableSetupColumn($"Side{column}", ImGuiTableColumnFlags.WidthFixed, 38);
            for (var index = 0; index < 9; index++)
            {
                ImGui.TableNextColumn();
                var number = index switch { 1 => card.Top, 3 => card.Left, 5 => card.Right, 7 => card.Bottom, _ => 0 };
                if (number == 0) continue;
                var text = TriadCardDefinition.Value(number);
                ImGui.SetCursorPosX(ImGui.GetCursorPosX() + Math.Max(0, (ImGui.GetContentRegionAvail().X - ImGui.CalcTextSize(text).X) / 2));
                ImGui.TextColored(Accent, text);
            }
        }
        finally { ImGui.EndTable(); }
    }

    private void DrawTriadDeck()
    {
        ImGui.TextWrapped("Ajoutez jusqu'à cinq cartes depuis le carnet. Une carte 5 étoiles au maximum, deux cartes de 4 étoiles ou plus au total.");
        var analysis = TriadDeck.Analyze(triadDeck!, id => triadCards.FirstOrDefault(entry => entry.Id == id)?.Card);
        ImGui.TextColored(analysis.Valid ? Success : Accent, analysis.Valid ? "Composition valide · 5 cartes" : $"Composition à compléter ou corriger · {triadDeck!.Count}/5 cartes");
        if (!analysis.RarityAllowed) ImGui.TextWrapped("Trop de cartes rares : maximum une 5 étoiles et deux cartes de 4 étoiles ou plus.");
        if (analysis.HasDuplicates) ImGui.TextWrapped("Un deck ne peut pas contenir deux fois la même carte.");
        if (analysis.UnknownIds.Count > 0) ImGui.TextWrapped("Certaines cartes sauvegardées ne sont pas disponibles dans le catalogue courant. Elles restent conservées jusqu'au retrait manuel.");
        var remove = -1;
        for (var index = 0; index < triadDeck!.Count; index++)
        {
            var id = triadDeck[index];
            var entry = triadCards.FirstOrDefault(entry => entry.Id == id);
            ImGui.PushID(index);
            try
            {
                DrawItemIcon(new ItemDefinition(0, entry?.Name ?? $"Carte ID {id}", false, entry?.IconId ?? 0), new Vector2(44));
                ImGui.SameLine();
                ImGui.TextUnformatted(entry is null ? $"Carte indisponible · ID {id}" : $"{entry.Card!.Number} · {entry.Name} · {new string('★', entry.Card.Stars)}");
                ImGui.SameLine();
                if (ImGui.SmallButton("Retirer")) remove = index;
                ImGui.TextColored(entry?.ConfirmedUnlocked == true ? Success : Muted, entry?.ConfirmedUnlocked == true ? "Acquise confirmée" : "Acquisition non confirmée");
            }
            finally { ImGui.PopID(); }
        }
        if (remove >= 0) { triadDeck.RemoveAt(remove); triadDeckSaved = false; }
        if (ImGui.Button("Enregistrer la préparation"))
        {
            var previous = configuration.TripleTriadDeck;
            configuration.TripleTriadDeck = triadDeck.ToList();
            try { save(); triadDeckError = null; triadDeckSaved = true; }
            catch (Exception error)
            {
                configuration.TripleTriadDeck = previous;
                triadDeckSaved = false; triadDeckError = error.Message;
                log.Warning(error, "Tensho Triad deck preparation could not be saved.");
            }
        }
        if (triadDeckSaved) ImGui.TextColored(Success, "Préparation enregistrée.");
        if (triadDeckError is { } errorText) ImGui.TextWrapped($"Enregistrement impossible : {errorText}");
    }
}
