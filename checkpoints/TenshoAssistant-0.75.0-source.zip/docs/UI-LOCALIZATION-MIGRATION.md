# UI and localization migration

## Verified state

The shared palette and components live in `src/TenshoAssistant/UI`.
`LocalizationManager` loads JSON into memory; rendering uses cached translations,
language metadata and validation reports. Reload is explicit in developer settings.
English is the reference; French is maintained alongside each migrated screen.
German and Japanese are partial and use English fallback.

The navigation, selected settings, saved crafting sequences, simulation controls
and macro export have been migrated progressively. This is not a complete UI refactor.
The solution builds in Release with analyzers enabled. The managed test executable
reported 464/464 passing after the macro export migration. In-game rendering has
not been validated for these changes.

## Remaining acceptance work

- Replace the tool directory home with a concise status and activity view while retaining all tool routes.
- Finish crafting: solver, live projection, condition envelope, notebook, tooltips and model error presentation.
- Migrate gathering, fishing, collections, quests, maps, market, automation and character views in order.
- Keep Gold Saucer, duty loot, monster sources, bank, item uses and sorting reachable.
- Centralize settings into sections and finish separating developer details.
- Complete English/French extraction across remaining views and native overlays.
- Validate placeholders, invalid files, language persistence, fallback and runtime reload with targeted tests.
- Add a standalone contributor validator and document its exact invocation.
- Verify language JSON files are present in the distributed ZIP, not only the build directory.
- Validate fonts, small windows, long translations, all existing routes and performance in FFXIV.
- Remove obsolete UI only after reference checks and successful replacement.

Do not report completion based solely on a successful compilation or the existing
managed test suite. That suite does not exercise ImGui rendering or language files.
