# GOAL sélectionné

ID: CACHE-001 — IMPLEMENTED / TESTED
OBJECTIVE: Réutiliser les données et calculs coûteux, avec péremption adaptée et réglable par domaine, et actualisation explicite dans les outils.
CURRENT_STATE: Livraison 0.75.0.0 compilée ; 466/466 tests et package/SHA-256 passants, zéro avertissement/erreur. Préférences sauvegardées, anciennes configurations compatibles.
REFERENCES: RULES.md ; docs/CACHE-001.md ; demande utilisateur sur les caches et durées.
FILES: Caching ; Configuration/Plugin ; services Market/Community/Fashion/Quests/Collections ; CraftLogSession ; réglages et panneaux ; tests/probe/versions/docs.
IN_SCOPE: Cache disque borné des prix, quêtes, collections, documents externes et calculs du carnet ; dates d'origine, portée/version, annulation, corruption, force, durées indépendantes 5 min/1 h/24 h/7 j. Imports conservés manuels avec avertissement ; catalogues statiques déjà mutualisés en mémoire et observations natives courtes respectés.
OUT_OF_SCOPE: Figer les inventaires ou synthèses en direct pendant des jours, importer automatiquement un servant fermé, déclarer les données périmées exactes, supprimer les stocks manuels à expiration. Aucun des 17 domaines n'est déclaré terminé.
VALIDATION: Verify.ps1 466/466 ; identité/API/versions/SHA-256/langues/exclusion hôte verts. ConfigSerializationProbe avec cache : Newtonsoft None/Auto/Objects passant. Pas de validation en jeu du nouveau cache.
NEXT_ACTION: Livraison et reprise décrites dans docs/CACHE-001.md ; ancien goal autonome conservé en pause au seuil de réserve. Tests live précédemment différés toujours différés.
DEFINITION_OF_DONE: Réutilisation, durées, actualisation, sauvegarde, compilation, tests et checkpoint documentés ; disponibilité en jeu à confirmer.
