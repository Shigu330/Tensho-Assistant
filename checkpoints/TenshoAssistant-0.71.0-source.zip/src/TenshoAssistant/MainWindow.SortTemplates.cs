using Dalamud.Bindings.ImGui;
using TenshoAssistant.Inventory;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private Guid selectedSortTemplate;
    private string sortTemplateName=string.Empty;
    private InventorySortProfile DrawSortTemplates(InventorySortScope scope,InventorySortProfile draft)
    {
        if(!ImGui.CollapsingHeader("Modèles réutilisables###SortTemplates"))return draft;
        ImGui.TextWrapped("Bibliothèque commune aux personnages. Charger remplace seulement le brouillon ; enregistrez ensuite le profil du rangement si vous souhaitez le conserver. Aucun tri n’est lancé.");
        var templates=(configuration.InventorySortTemplates ?? []).Where(value=>value is not null).ToArray();
        var selected=templates.FirstOrDefault(value=>value.Id==selectedSortTemplate);
        ImGui.SetNextItemWidth(300);
        if(ImGui.BeginCombo("Modèle",selected?.Name ?? "Choisir un modèle"))
        {
            try
            {
                foreach(var template in templates)
                    if(ImGui.Selectable($"{template.Name} · {template.ContainerCount} × {template.SlotsPerContainer}##{template.Id}",selectedSortTemplate==template.Id))
                    {selectedSortTemplate=template.Id;sortTemplateName=template.Name ?? string.Empty;selected=template;}
            }
            finally{ImGui.EndCombo();}
        }
        ImGui.BeginDisabled(selected is null || !InventorySortTemplates.Compatible(selected,scope));
        try
        {
            if(ImGui.Button("Charger dans le brouillon"))
            {
                try{draft=InventorySortTemplates.Load(selected!,scope);sortRulesError=null;}
                catch(Exception error){sortRulesError=error.Message;}
            }
        }
        finally{ImGui.EndDisabled();}
        if(selected is not null && !InventorySortTemplates.Compatible(selected,scope))ImGui.TextWrapped("Modèle incompatible ou invalide : la géométrie et les règles doivent correspondre au rangement.");
        ImGui.SetNextItemWidth(300);ImGui.InputText("Nom du modèle",ref sortTemplateName,80);
        if(ImGui.Button("Créer un modèle depuis le brouillon"))SaveSortTemplate(scope,draft,null);
        ImGui.BeginDisabled(selected is null);
        try
        {
            ImGui.BeginDisabled(selected is null || !InventorySortTemplates.Compatible(selected,scope));
            try{if(ImGui.Button("Mettre à jour le modèle choisi depuis le brouillon"))SaveSortTemplate(scope,draft,selected!.Id);}
            finally{ImGui.EndDisabled();}
            if(ImGui.Button("Supprimer le modèle choisi"))
            {
                var previous=configuration.InventorySortTemplates;
                try{configuration.InventorySortTemplates=InventorySortTemplates.Delete(previous,selected!.Id);save();selectedSortTemplate=Guid.Empty;sortRulesError=null;}
                catch(Exception error){configuration.InventorySortTemplates=previous;sortRulesError="Échec de suppression : "+error.Message;log.Warning(error,"Could not delete inventory sort template.");}
            }
        }
        finally{ImGui.EndDisabled();}
        return draft;
    }
    private void SaveSortTemplate(InventorySortScope scope,InventorySortProfile draft,Guid? id)
    {
        var previous=configuration.InventorySortTemplates;
        try
        {
            var template=InventorySortTemplates.Create(draft,scope,sortTemplateName,id);
            configuration.InventorySortTemplates=InventorySortTemplates.Save(previous,template);
            save();selectedSortTemplate=template.Id;sortTemplateName=template.Name;sortRulesError=null;
        }
        catch(Exception error){configuration.InventorySortTemplates=previous;sortRulesError="Échec de sauvegarde du modèle : "+error.Message;log.Warning(error,"Could not save inventory sort template.");}
    }
}
