using System.Numerics;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.Gathering;
using TenshoAssistant.Items;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private uint weatherTerritory;private string weatherZone="";private long weatherPeriod=-1;private WeatherCatalog? weatherViewCatalog;
    private IReadOnlyList<WeatherPeriod> weatherForecast=[];
    private void OpenWeather(uint territory,string zone){weatherTerritory=territory;weatherZone=zone;weatherPeriod=-1;page=Page.Weather;}
    private void DrawWeather()
    {
        Heading("Météo & prévisions",weatherZone);
        if(ImGui.SmallButton("Cartes"))page=Page.Maps;ImGui.SameLine();if(ImGui.SmallButton("Récolte"))page=Page.Gathering;
        if(weather.State.Catalog is not { } catalog){ImGui.TextWrapped(weather.State.Error ?? "Lecture des tables météo du jeu…");return;}
        ImGui.TextWrapped("Prévisions calculées depuis les tables de cette zone et l'heure UTC de l'ordinateur. La météo réellement imposée par un événement ou une instance n'est pas observée. Aucun prérequis de poisson ou de point de récolte n'est déduit.");
        var now=DateTimeOffset.UtcNow;var period=now.ToUnixTimeSeconds()/1400;
        if(period!=weatherPeriod || !ReferenceEquals(catalog,weatherViewCatalog))
        {weatherForecast=catalog.Forecast(weatherTerritory,now);weatherPeriod=period;weatherViewCatalog=catalog;}
        ImGui.TextDisabled("Chaque période couvre 8 heures ET, soit 23 min 20 s réelles. Dates ci-dessous en UTC.");
        if(ImGui.BeginTable("WeatherForecast",4,ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingStretchProp))
        {
            try
            {
                foreach(var title in new[]{"Période","Début UTC","Fin UTC / ET","Météo calculée"})ImGui.TableSetupColumn(title);
                ImGui.TableHeadersRow();
                for(var i=0;i<weatherForecast.Count;i++)
                {
                    var entry=weatherForecast[i];ImGui.TableNextRow();ImGui.TableNextColumn();ImGui.TextUnformatted(i==0 ? "Courante (calculée)":$"Suivante {i}");
                    ImGui.TableNextColumn();ImGui.TextUnformatted($"{entry.StartsAt:dd/MM HH:mm:ss}");
                    ImGui.TableNextColumn();ImGui.TextUnformatted($"{entry.EndsAt:dd/MM HH:mm:ss} · {entry.EtHour:00}–{(entry.EtHour+8)%24:00} ET");
                    ImGui.TableNextColumn();
                    if(entry.Weather is { } value){DrawItemIcon(new ItemDefinition(0,value.Name,false,value.Icon),new Vector2(28));ImGui.SameLine();ImGui.TextUnformatted(value.Name);}
                    else ImGui.TextWrapped(entry.UnknownReason ?? "Inconnue");
                }
            }
            finally{ImGui.EndTable();}
        }
        if(catalog.Zone(weatherTerritory) is { } zone && ImGui.CollapsingHeader("Répartition statique et couverture"))
        {
            var total=zone.Shares.Sum(share=>(long)share.Chance);ImGui.TextUnformatted($"Couverture des taux natifs : {total}/100");
            foreach(var share in zone.Shares)ImGui.TextUnformatted($"{catalog.Weather(share.WeatherId)?.Name ?? "Météo inconnue"} : {share.Chance} %");
            if(total!=100)ImGui.TextWrapped("La table ne couvre pas tous les tirages : les périodes correspondantes restent inconnues.");
            if(zone.Individual)ImGui.TextWrapped("Cette zone référence une météo individuelle : prévision standard non appliquée.");
        }
    }
}
