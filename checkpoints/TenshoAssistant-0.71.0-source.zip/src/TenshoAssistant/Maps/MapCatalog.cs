using System.Collections.Frozen;
using System.Globalization;

namespace TenshoAssistant.Maps;

public sealed record MapDefinition(uint MapId, uint TerritoryId, string Region, string Zone, string Subzone,
    int MapIndex, int SizeFactor, uint PlaceNameId = 0);

public sealed class MapCatalog
{
    private readonly FrozenDictionary<uint, MapDefinition> byId;
    private readonly FrozenDictionary<uint, IReadOnlyList<MapDefinition>> byPlace;
    public IReadOnlyList<MapDefinition> Entries { get; }
    public MapCatalog(IEnumerable<MapDefinition> source, CancellationToken cancellation = default)
    {
        ArgumentNullException.ThrowIfNull(source);
        var copied = new Dictionary<uint, MapDefinition>();
        cancellation.ThrowIfCancellationRequested();
        foreach (var map in source)
        {
            cancellation.ThrowIfCancellationRequested();
            if (map.MapId == 0 || map.TerritoryId == 0 || map.SizeFactor <= 0 || string.IsNullOrWhiteSpace(map.Zone)) continue;
            if (!copied.TryAdd(map.MapId, map)) throw new ArgumentException("Duplicate map ID.", nameof(source));
        }
        byId = copied.ToFrozenDictionary();
        Entries = Array.AsReadOnly(copied.Values.OrderBy(map => map.Region, StringComparer.CurrentCultureIgnoreCase)
            .ThenBy(map => map.Zone, StringComparer.CurrentCultureIgnoreCase).ThenBy(map => map.MapIndex).ThenBy(map => map.MapId).ToArray());
        byPlace = Entries.Where(map => map.PlaceNameId != 0).GroupBy(map => map.PlaceNameId)
            .ToFrozenDictionary(group => group.Key,group => (IReadOnlyList<MapDefinition>)Array.AsReadOnly(group.ToArray()));
        cancellation.ThrowIfCancellationRequested();
    }
    public MapDefinition? Find(uint id) => byId.GetValueOrDefault(id);
    public IReadOnlyList<MapDefinition> ForPlace(uint placeNameId) => byPlace.GetValueOrDefault(placeNameId) ?? Array.Empty<MapDefinition>();
    public IReadOnlyList<MapDefinition> Search(string query)
    {
        ArgumentNullException.ThrowIfNull(query);
        var tokens = query.Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        if (tokens.Length == 0) return Entries;
        return Array.AsReadOnly(Entries.Where(map => tokens.All(token =>
            CultureInfo.CurrentCulture.CompareInfo.IndexOf($"{map.Region} {map.Zone} {map.Subzone} {map.MapId}", token,
                CompareOptions.IgnoreCase | CompareOptions.IgnoreNonSpace) >= 0)).ToArray());
    }
    // A generous input bound protects the native coordinate encoder; this is not a map availability check.
    public static bool CoordinatesValid(float x, float y) => float.IsFinite(x) && float.IsFinite(y)
        && x is >= -10000 and <= 10000 && y is >= -10000 and <= 10000;
}

public sealed record MapCatalogState(MapCatalog? Catalog, int Copied, int Total, string? Error);
public sealed class MapCatalogService
{
    private MapCatalogState state = new(null, 0, 0, null);
    public MapCatalogState State => Volatile.Read(ref state);
    internal void Progress(int copied, int total) => Interlocked.Exchange(ref state, new(null, copied, total, null));
    internal void Publish(MapCatalog catalog) => Interlocked.Exchange(ref state, new(catalog, 0, 0, null));
    internal void Fail(Exception error) => Interlocked.Exchange(ref state, new(null, 0, 0, error.Message));
    internal void Clear() => Interlocked.Exchange(ref state, new(null, 0, 0, null));
}
