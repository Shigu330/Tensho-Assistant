using Dalamud.Game.Gui.ContextMenu;
using Dalamud.Game.Text.SeStringHandling;
using Dalamud.Plugin.Services;

namespace TenshoAssistant.Items;

internal sealed class ItemContextMenuBridge : IDisposable
{
    private readonly Configuration configuration;
    private readonly IContextMenu menus;
    private readonly IPlayerState player;
    private readonly IClientState client;
    private readonly ItemCatalogService catalog;
    private readonly IPluginLog log;
    private readonly ItemContextMenuSession session=new();
    private bool disposed;
    private ulong Owner=>client.IsLoggedIn && player.IsLoaded ? player.ContentId:0;

    public ItemContextMenuBridge(Configuration configuration,IContextMenu menus,IPlayerState player,IClientState client,ItemCatalogService catalog,IPluginLog log)
    {
        this.configuration=configuration;this.menus=menus;this.player=player;this.client=client;this.catalog=catalog;this.log=log;
        menus.OnMenuOpened+=OnMenuOpened;
        try{client.Logout+=OnLogout;}
        catch{menus.OnMenuOpened-=OnMenuOpened;throw;}
    }

    private void OnLogout(int type,int code)=>session.Clear();
    private bool Current(ItemMenuToken token)=>!disposed && session.IsCurrent(token,configuration.ItemContextMenuEnabled,Owner,catalog.State.Catalog,DateTimeOffset.UtcNow);

    private void OnMenuOpened(IMenuOpenedArgs args)
    {
        try
        {
            session.Clear();
            if(disposed || !configuration.ItemContextMenuEnabled || args.MenuType!=ContextMenuType.Inventory || Owner==0)return;
            var owner=Owner;
            // TargetItem is read here only. Closures retain just the normalized managed token, never args/target/address.
            if(args.Target is not MenuTargetInventory inventory || inventory.TargetItem is not { } item || item.IsEmpty)return;
            var raw=item.ItemId;
            if(owner!=Owner)return;
            var token=session.Begin(true,owner,raw,catalog.State.Catalog,DateTimeOffset.UtcNow);
            if(token is null)return;
            args.AddMenuItem(new MenuItem
            {
                Name=new SeStringBuilder().AddText("Tensho — objet").Build(),PrefixChar='T',IsSubmenu=true,
                OnClicked=click=>
                {
                    if(!Current(token))return;
                    click.OpenSubmenu(new IMenuItem[]
                    {
                        Entry("Usages de l’objet",ItemContextRoute.Usages,token),
                        Entry("Stocks de l’objet",ItemContextRoute.Stocks,token),
                        Entry("Craft lié",ItemContextRoute.Craft,token),
                        Entry("Sources de récolte",ItemContextRoute.Gathering,token),
                        Entry("Tous les outils avec cet objet",ItemContextRoute.Tools,token),
                    });
                },
            });
        }
        catch(Exception error){session.Clear();log.Warning(error,"Could not add Tensho inventory context menu.");}
    }

    private MenuItem Entry(string name,ItemContextRoute route,ItemMenuToken token)=>new()
    {
        Name=new SeStringBuilder().AddText(name).Build(),PrefixChar='T',
        OnClicked=_=>
        {
            if(!disposed)session.Queue(token,route,configuration.ItemContextMenuEnabled,Owner,catalog.State.Catalog,DateTimeOffset.UtcNow);
        },
    };

    public ItemMenuRequest? Take()=>session.Take(configuration.ItemContextMenuEnabled,Owner,catalog.State.Catalog,DateTimeOffset.UtcNow);
    public void Dispose()
    {
        if(disposed)return;disposed=true;
        menus.OnMenuOpened-=OnMenuOpened;client.Logout-=OnLogout;session.Dispose();
    }
}
