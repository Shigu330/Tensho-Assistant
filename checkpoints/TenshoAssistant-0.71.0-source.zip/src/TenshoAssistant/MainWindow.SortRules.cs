using Dalamud.Bindings.ImGui;
using TenshoAssistant.Inventory;
using TenshoAssistant.Items;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private InventorySortProfile? sortRulesDraft;
    private InventorySortScope? sortRulesScope;
    private string? sortRulesError;
    private static readonly string[] SortFieldLabels=["Nom","Catégorie du jeu","Quantité","Qualité NQ/HQ"];
    private static readonly (EquipmentSlots Mask,string Name)[] SortEquipmentChoices=
    [ (EquipmentSlots.None,"Tous les objets"),(EquipmentSlots.All,"Un emplacement pris en charge"),
      (EquipmentSlots.MainHand|EquipmentSlots.OffHand,"Main principale ou secondaire"),(EquipmentSlots.MainHand,"Main principale · arme/outil"),(EquipmentSlots.OffHand,"Main secondaire"),(EquipmentSlots.SoulCrystal,"Pierre d’âme"),
      (EquipmentSlots.Wearable,"Vêtement ou accessoire"),(EquipmentSlots.Head,"Tête"),(EquipmentSlots.Body,"Torse"),(EquipmentSlots.Hands,"Mains"),
      (EquipmentSlots.Legs,"Jambes"),(EquipmentSlots.Feet,"Pieds"),(EquipmentSlots.Ears,"Boucles d’oreilles"),(EquipmentSlots.Neck,"Collier"),(EquipmentSlots.Wrists,"Bracelets"),(EquipmentSlots.Ring,"Bague") ];

    private InventorySortProfile? DrawSortRules(InventorySortScope scope,ItemCatalog catalog)
    {
        if(sortRulesScope!=scope)
        {
            sortRulesScope=scope;sortRulesDraft=null;sortRulesError=null;
            try{sortRulesDraft=InventorySortRules.Load(configuration.InventorySortProfiles,scope,(InventorySortField)Math.Clamp(configuration.SortPreviewField,0,3),configuration.SortPreviewDescending);}
            catch(Exception error){sortRulesError=error.Message;}
        }
        if(sortRulesDraft is null)
        {
            ImGui.TextWrapped(sortRulesError ?? "Profil indisponible.");
            if(ImGui.Button("Réinitialiser le brouillon de ce rangement"))
            {sortRulesDraft=InventorySortRules.Default(scope);sortRulesError=null;}
            return null;
        }
        var draft=DrawSortTemplates(scope,sortRulesDraft);
        ImGui.TextDisabled("Critères dans l’ordre de priorité");
        var criteria=draft.Criteria.ToList();var criteriaChanged=false;
        for(var index=0;index<criteria.Count;index++)
        {
            ImGui.PushID($"SortCriterion{index}");
            try
            {
                var criterion=criteria[index];var sortField=(int)criterion.Field;var descending=criterion.Descending;
                ImGui.SetNextItemWidth(170);
                if(ImGui.BeginCombo("##SortField",SortFieldLabels[sortField]))
                {
                    try
                    {
                        for(var next=0;next<SortFieldLabels.Length;next++)
                            if((next==sortField || !criteria.Any(value=>(int)value.Field==next)) && ImGui.Selectable(SortFieldLabels[next],next==sortField))
                            {sortField=next;criteriaChanged=true;}
                    }
                    finally{ImGui.EndCombo();}
                }
                ImGui.SameLine();if(ImGui.Checkbox("Décroissant",ref descending))criteriaChanged=true;
                criteria[index]=new((InventorySortField)sortField,descending);
                ImGui.SameLine();
                if(index>0 && ImGui.SmallButton("Monter")){(criteria[index-1],criteria[index])=(criteria[index],criteria[index-1]);criteriaChanged=true;}
                ImGui.SameLine();
                if(criteria.Count>1 && ImGui.SmallButton("Retirer")){criteria.RemoveAt(index);criteriaChanged=true;break;}
            }
            finally{ImGui.PopID();}
        }
        if(criteria.Count<4 && ImGui.SmallButton("Ajouter un critère"))
        {criteria.Add(new(Enum.GetValues<InventorySortField>().First(value=>!criteria.Any(c=>c.Field==value))));criteriaChanged=true;}
        if(criteriaChanged){draft=draft with{Criteria=Array.AsReadOnly(criteria.ToArray())};sortRulesError=null;}

        if(ImGui.CollapsingHeader($"Zones réservées ({draft.Zones.Count})###SortZones"))
        {
            ImGui.TextWrapped("Cases à partir de 1, de gauche à droite puis sac suivant. Les zones protégées gardent d’abord leurs cases actuelles. Les zones filtrées choisissent ensuite leurs piles par priorité ; les autres piles remplissent les cases non réservées.");
            var zones=draft.Zones.ToList();var changed=false;
            for(var index=0;index<zones.Count;index++)
            {
                ImGui.PushID($"SortZone{index}");
                try
                {
                    var zone=zones[index];
                    if(!ImGui.TreeNode($"{zone.Name} · cases {zone.Start+1}–{zone.Start+zone.Count}###ZoneDetails"))continue;
                    try
                    {
                        var name=zone.Name;var start=zone.Start+1;var count=zone.Count;var query=zone.Query;var quality=(int)zone.Quality;var category=zone.CategoryId;
                        changed|=ImGui.InputText("Nom de zone",ref name,80);
                        ImGui.SetNextItemWidth(100);changed|=ImGui.InputInt("Première case",ref start);
                        ImGui.SetNextItemWidth(100);changed|=ImGui.InputInt("Nombre de cases",ref count);
                        var preserve=zone.Preserve;var reverse=zone.ReverseFill;
                        var marketable=(int)zone.Marketable;var potentialHq=(int)zone.CanBeHq;var equipment=zone.Equipment;
                        if(ImGui.Checkbox("Protéger les cases actuelles",ref preserve)){changed=true;if(preserve)reverse=false;}
                        if(preserve)ImGui.TextWrapped("Les piles et cases vides de cette zone restent à leur position observée. Des indices visuels complets sont requis ; les filtres ci-dessous sont inactifs.");
                        ImGui.BeginDisabled(preserve);
                        try
                        {
                            changed|=ImGui.Checkbox("Remplir depuis la dernière case",ref reverse);
                            var categoryName=category==0 ? "Toutes les catégories":catalog.Categories.FirstOrDefault(value=>value.Id==category)?.Name ?? $"Catégorie {category} indisponible";
                            ImGui.SetNextItemWidth(250);
                            if(ImGui.BeginCombo("Catégorie",categoryName))
                            {
                                try
                                {
                                    if(ImGui.Selectable("Toutes les catégories",category==0)){category=0;changed=true;}
                                    foreach(var value in catalog.Categories)
                                        if(ImGui.Selectable($"{value.Name}##{value.Id}",category==value.Id)){category=value.Id;changed=true;}
                                }
                                finally{ImGui.EndCombo();}
                            }
                            ImGui.SetNextItemWidth(170);changed|=ImGui.Combo("Qualité",ref quality,"NQ + HQ\0NQ uniquement\0HQ uniquement\0");
                            changed|=ImGui.InputTextWithHint("##ZoneQuery","Nom ou identifiant, facultatif",ref query,128);
                            ImGui.SetNextItemWidth(170);changed|=ImGui.Combo("Type vendable au marché",ref marketable,"Sans filtre\0Oui\0Non\0");
                            ImGui.SetNextItemWidth(170);changed|=ImGui.Combo("Type existant en HQ",ref potentialHq,"Sans filtre\0Oui\0Non\0");
                            ImGui.SetNextItemWidth(250);
                            if(ImGui.BeginCombo("Emplacement du type d’objet",SortEquipmentChoices.FirstOrDefault(value=>value.Mask==equipment).Name ?? "Plusieurs emplacements"))
                            {
                                try{foreach(var value in SortEquipmentChoices)if(ImGui.Selectable(value.Name,equipment==value.Mask)){equipment=value.Mask;changed=true;}}
                                finally{ImGui.EndCombo();}
                            }
                            ImGui.TextWrapped("Métadonnées du type d’objet : ne prouvent ni vente de cette pile, ni possibilité de l’équiper avec ce personnage. Une propriété inconnue ne satisfait aucun filtre Oui/Non.");
                        }
                        finally{ImGui.EndDisabled();}
                        zones[index]=zone with{Name=name,Start=Math.Clamp(start,1,scope.Capacity)-1,Count=Math.Clamp(count,1,scope.Capacity),CategoryId=category,Quality=(InventoryQualityFilter)quality,Query=query,Preserve=preserve,ReverseFill=reverse,
                            Marketable=(InventoryPropertyFilter)marketable,CanBeHq=(InventoryPropertyFilter)potentialHq,Equipment=equipment};
                        if(index>0 && ImGui.SmallButton("Priorité supérieure")){(zones[index-1],zones[index])=(zones[index],zones[index-1]);changed=true;}
                        ImGui.SameLine();if(ImGui.SmallButton("Supprimer la zone")){zones.RemoveAt(index);changed=true;break;}
                    }
                    finally{ImGui.TreePop();}
                }
                finally{ImGui.PopID();}
            }
            if(zones.Count<32 && ImGui.SmallButton("Ajouter une zone"))
            {
                var free=Enumerable.Range(0,scope.Capacity).FirstOrDefault(slot=>!zones.Any(zone=>slot>=zone.Start && slot<zone.Start+zone.Count),-1);
                if(free>=0){zones.Add(new("Nouvelle zone",free,1));changed=true;}
                else sortRulesError="Toutes les cases sont déjà réservées.";
            }
            if(changed){draft=draft with{Zones=Array.AsReadOnly(zones.ToArray())};sortRulesError=null;}
        }
        sortRulesDraft=draft;
        try{InventorySortRules.Validate(draft,scope);}
        catch(Exception error){sortRulesError=error.Message;ImGui.TextWrapped(sortRulesError);return null;}
        if(ImGui.Button("Enregistrer pour ce personnage et ce rangement"))
        {
            var oldProfiles=configuration.InventorySortProfiles;var oldField=configuration.SortPreviewField;var oldDescending=configuration.SortPreviewDescending;
            try
            {
                configuration.InventorySortProfiles=InventorySortRules.Save(oldProfiles,draft,scope);
                configuration.SortPreviewField=(int)draft.Criteria[0].Field;configuration.SortPreviewDescending=draft.Criteria[0].Descending;
                save();sortRulesError=null;
            }
            catch(Exception error)
            {
                configuration.InventorySortProfiles=oldProfiles;configuration.SortPreviewField=oldField;configuration.SortPreviewDescending=oldDescending;
                sortRulesError="Échec de sauvegarde du profil : "+error.Message;log.Warning(error,"Could not persist inventory sort profile.");
            }
        }
        ImGui.TextDisabled("Brouillon : changer de rangement recharge son profil enregistré. Enregistrer ne lance aucun tri.");
        if(sortRulesError is { } message)ImGui.TextWrapped(message);
        return draft;
    }
}
