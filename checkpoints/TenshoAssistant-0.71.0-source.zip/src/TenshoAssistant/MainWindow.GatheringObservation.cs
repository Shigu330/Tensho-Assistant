using System.Numerics;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.Gathering;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private void DrawGatheringObservation()
    {
        if(!ImGui.CollapsingHeader("Point de récolte actuel · expérimental"))return;
        var state=gatheringObservation.State;var enabled=state.Enabled;
        DrawToolSettingsLink("GatheringObservation");
        if(!enabled)ImGui.TextDisabled("Observation désactivée ; activez-la dans Réglages → Récolte & pêche.");
        if(!enabled)return;
        var now=DateTimeOffset.UtcNow;
        if(!state.Fresh(now))
        {
            ImGui.TextWrapped(state.Status switch
            {
                GatheringObservationStatus.Offline=>"Connectez un personnage.",
                GatheringObservationStatus.AddonAbsent=>"Ouvrez un point de récolte en mineur ou botaniste.",
                GatheringObservationStatus.NotReady=>"Fenêtre masquée, transition, métier incompatible ou collecte collectionnable ouverte.",
                GatheringObservationStatus.Error=>state.Error ?? "Lecture indisponible.",
                _=>"En attente d’une observation récente."
            });return;
        }
        var frame=state.Frame!;
        ImGui.TextDisabled($"{(frame.JobId==16 ? "Mineur":"Botaniste")} {frame.Level} · PR {frame.Gp}/{frame.MaxGp} · {state.ObservedAt:HH:mm:ss} UTC");
        ImGui.TextWrapped($"Tentatives restantes : {frame.Attempts?.ToString() ?? "inconnues"} / {frame.TotalAttempts?.ToString() ?? "inconnu"}{(frame.NativeStatus==2 ? " · récolte rapide":"")}");
        ImGui.TextWrapped("Taux et quantités affichés par le jeu : ils peuvent déjà inclure des bonus actifs. Cliquez sur un objet pour le mettre en contexte ; le calcul PR reste un scénario manuel.");
        if(frame.Slots.Count==0)ImGui.TextDisabled("Aucune ligne d’objet visible et identifiée.");
        if(frame.Slots.Count>0 && ImGui.BeginTable("ObservedGatheringRows",4,ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingStretchProp))
        {
            try
            {
                ImGui.TableSetupColumn("Objet",ImGuiTableColumnFlags.WidthStretch,2);
                ImGui.TableSetupColumn("Réussite affichée");ImGui.TableSetupColumn("Supplément affiché");ImGui.TableSetupColumn("Quantité affichée");ImGui.TableHeadersRow();
                foreach(var slot in frame.Slots)
                {
                    ImGui.TableNextRow();ImGui.TableNextColumn();ImGui.PushID(slot.Index);
                    try
                    {
                        var item=itemCatalog.State.Catalog?.Find(slot.ItemId);DrawItemIcon(item,new Vector2(28));var click=ImGui.IsItemClicked();ImGui.SameLine();
                        ImGui.BeginDisabled(slot.ItemId==0);
                        try{click|=ImGui.SmallButton(item?.Name ?? (slot.ItemId==0 ? $"Objet spécial (ID {slot.RawItemId})":$"Objet {slot.ItemId}"));}
                        finally{ImGui.EndDisabled();}
                        if(click && slot.ItemId!=0)SelectItem(slot.ItemId);
                        ImGui.TableNextColumn();ImGui.TextUnformatted(slot.SuccessPercent is { } success ? $"{success} %":"Inconnue");
                        ImGui.TableNextColumn();ImGui.TextUnformatted(slot.BoonPercent is { } boon ? $"{boon} %":"Inconnu / indisponible");
                        ImGui.TableNextColumn();ImGui.TextUnformatted(slot.DisplayedQuantity?.ToString() ?? "Inconnue");
                    }
                    finally{ImGui.PopID();}
                }
            }
            finally{ImGui.EndTable();}
        }
        var resources=state.CopyResources(now);ImGui.BeginDisabled(resources is null);
        try
        {
            if(ImGui.SmallButton("Préparer un scénario PR avec ces ressources") && resources is { } copied)
            {
                gpJob=copied.JobId;gpLevel=copied.Level;gpBudget=copied.Budget;gpAttempts=copied.Attempts;
                gpBaseYield=0;gpSuccess=-1;gpBoon=-1;gpBountiful=0;
                gpYieldActive=gpGift1Active=gpGift2Active=gpTidingsActive=gpOtherEffects=false;gpFirstAttemptBonus=0;
                gpCopiedOwner=copied.Owner;gpCopiedAt=copied.ObservedAt;gpResult=null;
                gpError="PR, niveau et tentatives copiés. Renseignez les taux, le rendement et les effets déjà payés du scénario ; les valeurs modifiées et statuts du point n’ont pas été copiés.";
                page=Page.GatheringGp;
            }
        }
        finally{ImGui.EndDisabled();}
        if(frame.NativeStatus==2)ImGui.TextDisabled("La copie de scénario attend l’arrêt de la récolte rapide.");
    }
}
