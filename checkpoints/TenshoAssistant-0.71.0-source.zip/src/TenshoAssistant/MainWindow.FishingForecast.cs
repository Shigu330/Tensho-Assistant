using Dalamud.Bindings.ImGui;
using TenshoAssistant.Community;
using TenshoAssistant.Gathering;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private FishingConditions? fishingForecastConditions;
    private WeatherCatalog? fishingForecastCatalog;
    private FishingForecastResult? fishingForecastResult;
    private uint fishingForecastTerritory,fishingForecastItem;

    private void DrawFishingForecast(FishingConditions conditions,uint territory)
    {
        if(!ImGui.CollapsingHeader("Plages compatibles avec les critères renseignés###FishingForecast"))return;
        var catalog=weather.State.Catalog;
        if(catalog is null){ImGui.TextWrapped(weather.State.Error ?? "Lecture du catalogue météo…");return;}
        ImGui.TextWrapped("Calcul sur 12 périodes météo, depuis l’heure UTC de l’ordinateur. Les critères absents ne sont pas vérifiés ; une plage compatible ne garantit aucune capture.");
        if(ImGui.SmallButton("Calculer / actualiser les plages"))
        {
            fishingForecastResult=FishingForecast.Calculate(conditions,catalog,territory,DateTimeOffset.UtcNow);
            fishingForecastConditions=conditions;fishingForecastCatalog=catalog;
            fishingForecastTerritory=territory;fishingForecastItem=(uint)itemId;
        }
        if(!ReferenceEquals(conditions,fishingForecastConditions) || !ReferenceEquals(catalog,fishingForecastCatalog)
            || territory!=fishingForecastTerritory || (uint)itemId!=fishingForecastItem || fishingForecastResult is not { } result)return;
        if(result.Error is not null){ImGui.TextWrapped(result.Error);return;}
        ImGui.TextDisabled($"Calcul {result.CalculatedAt:dd/MM HH:mm:ss} UTC · horizon jusqu’au {result.HorizonEndsAt:dd/MM HH:mm:ss} UTC");
        var missing=new List<string>();
        if(!result.ReportedFields.HasFlag(FishingConditionFields.Time))missing.Add("horaire");
        if(!result.ReportedFields.HasFlag(FishingConditionFields.Weather))missing.Add("météo requise");
        if(!result.ReportedFields.HasFlag(FishingConditionFields.PreviousWeather))missing.Add("météo précédente");
        if(missing.Count>0)ImGui.TextColored(Accent,"Calcul partiel · non renseigné : "+string.Join(", ",missing));
        var now=DateTimeOffset.UtcNow;
        if(now<result.CalculatedAt){ImGui.TextWrapped("Horloge déplacée avant le calcul ; actualisez les plages.");return;}
        if(now>=result.HorizonEndsAt){ImGui.TextWrapped("Horizon écoulé ; actualisez le calcul.");return;}
        var candidates=result.Spans.Where(span=>span.EndsAt>now && span.ReportedConditionsMatch!=false).ToArray();
        if(candidates.Length==0)ImGui.TextWrapped("Critères renseignés non réunis sur cet horizon. Aucun constat d’impossibilité de pêche n’est déduit.");
        foreach(var span in candidates)
        {
            var label=span.ReportedConditionsMatch==true ? "Critères compatibles":"Indéterminé";
            ImGui.TextColored(span.ReportedConditionsMatch==true ? Accent:Muted,$"{span.StartsAt:dd/MM HH:mm:ss}–{span.EndsAt:dd/MM HH:mm:ss} UTC · {label}");
        }
        ImGui.TextWrapped("Prises préalables, intuition, accès, équipement, compétences et météo forcée non observés. Les plages restent des calculs sur des données communautaires possiblement incomplètes.");
    }
}
