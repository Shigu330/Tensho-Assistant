using System.Numerics;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.Quests;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private static string QuestRewardConditionLabel(QuestRewardItem item)=>item.Rule switch
    {
        QuestRewardRule.Fixed=>item.Source=="catalyst" ? "Compléments fixes":"Objets fixes",
        QuestRewardRule.Choice=>"Choix possible · un objet parmi ce groupe",
        QuestRewardRule.Masculine=>"Variante masculine",
        QuestRewardRule.Feminine=>"Variante féminine",
        QuestRewardRule.ConditionalChoice=>"Choix conditionnels · non cumulés",
        QuestRewardRule.ClassJob=>"Selon le métier · "+item.ConditionLabel,
        QuestRewardRule.TribeRankVariant=>item.ConditionLabel+" · rang non vérifié",
        QuestRewardRule.Currency=>"Monnaies renseignées",
        _=>"Conditions non interprétées",
    };
    private void DrawQuestRewards(QuestEntry entry)
    {
        if(!ImGui.CollapsingHeader("Récompenses renseignées"))return;
        ImGui.TextWrapped("Catalogue statique : variantes et choix ne se cumulent pas. Obtention, éligibilité, rang, métier et bonus du personnage non vérifiés.");
        if(entry.RewardsError is { } error){ImGui.TextWrapped(error);return;}
        if(entry.Rewards is not { } rewards){ImGui.TextWrapped("Récompenses non couvertes dans ce relevé.");return;}
        if(rewards.Gil>0)ImGui.TextColored(Accent,$"Gils renseignés (base) : {rewards.Gil:N0}");
        var index=0;
        foreach(var group in rewards.Items.GroupBy(item=>(item.Rule,item.Source,item.ConditionId,item.ConditionLabel,item.SourceId,item.Variant,item.ParentSlot)))
        {
            ImGui.PushID(index++);
            try
            {
                var key=group.Key;
                var heading=QuestRewardConditionLabel(group.First());
                if(!ImGui.CollapsingHeader(heading,key.Rule is QuestRewardRule.Fixed or QuestRewardRule.Choice or QuestRewardRule.Currency ? ImGuiTreeNodeFlags.DefaultOpen:ImGuiTreeNodeFlags.None))continue;
                foreach(var line in group)
                {
                    var item=itemCatalog.State.Catalog?.Find(line.ItemId);
                    DrawItemIcon(item,new Vector2(28));var clicked=ImGui.IsItemClicked();ImGui.SameLine();
                    ImGui.BeginDisabled(item is null);
                    try{clicked|=ImGui.SmallButton($"{item?.Name ?? "Objet non résolu"}##Reward{line.Slot}");}
                    finally{ImGui.EndDisabled();}
                    if(ImGui.IsItemHovered())ImGui.SetTooltip($"Qualité indiquée : {(line.HighQuality is null ? "non renseignée":line.HighQuality==true ? "HQ":"NQ")}\n{(line.StainId==0 ? "Pas de teinte renseignée":"Teinte renseignée dans les données de quête")}\nCliquer pour placer l’objet en contexte et consulter ses stocks.");
                    ImGui.SameLine();ImGui.TextDisabled(line.Quantity is { } quantity ? $"× {quantity:N0}{(line.HighQuality==true ? " HQ":"")}":"Quantité non renseignée");
                    if(clicked && item is not null){SelectItem(item.Id);page=Page.Items;focusStocksTab=true;}
                }
            }
            finally{ImGui.PopID();}
        }
        foreach(var unresolved in rewards.Unresolved)ImGui.TextWrapped(unresolved.Reason+(unresolved.Quantity is { } quantity ? $" Quantité renseignée : {quantity:N0}.":""));
        if(rewards.HasAdditionalRewards)ImGui.TextWrapped("D’autres récompenses ou bonus sont renseignés (expérience, actions ou autres) ; ils ne sont pas calculés ici.");
        if(rewards.Items.Count==0 && rewards.Gil==0 && rewards.Unresolved.Count==0)ImGui.TextDisabled("Aucun objet/gil direct couvert ; autres récompenses possibles.");
        ImGui.TextDisabled("Source : catalogue du jeu. Une quête terminée ne prouve ni le choix ni la possession actuelle de ses récompenses.");
    }
}
