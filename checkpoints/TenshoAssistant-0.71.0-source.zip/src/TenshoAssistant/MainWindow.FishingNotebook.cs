using Dalamud.Bindings.ImGui;
using TenshoAssistant.Gathering;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private void DrawFishingNotebook(GatheringCatalog catalog)
    {
        var entries=catalog.Fishing.ForItem((uint)itemId);
        if(entries.Count==0 || !ImGui.CollapsingHeader("Carnet de pêche · données du jeu###FishingNotebook"))return;
        static string Restriction(bool? value)=>value switch{true=>"Signalée dans le carnet",false=>"Non signalée dans le carnet",_=>"Non renseignée"};
        foreach(var entry in entries)
        {
            ImGui.PushID((int)entry.FishId);
            try
            {
                if(entries.Count>1)ImGui.TextDisabled($"Référence de carnet {entry.FishId}");
                if(!string.IsNullOrWhiteSpace(entry.Description))ImGui.TextWrapped(entry.Description);
                ImGui.TextWrapped("Restriction horaire : "+Restriction(entry.TimeRestricted));
                ImGui.TextWrapped("Restriction météo : "+Restriction(entry.WeatherRestricted));
                if(!string.IsNullOrWhiteSpace(entry.Folklore))ImGui.TextWrapped("Tome référencé : "+entry.Folklore);
                if(!entry.InLog)ImGui.TextDisabled("Cette référence n’est pas marquée pour le carnet standard.");
                if(!entry.NoteLinked)ImGui.TextDisabled("Fiche de restrictions absente ou non concordante ; valeurs conservées inconnues.");
            }
            finally{ImGui.PopID();}
        }
        ImGui.TextWrapped("Références statiques : prises et déblocages non vérifiés. Le carnet ne renseigne ici ni appâts ni conditions précises. Les chaînes communautaires sont consultables dans leur cadre séparé.");
        ImGui.Separator();
    }
}
