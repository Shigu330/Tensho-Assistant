using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Game.Text.SeStringHandling.Payloads;
using TenshoAssistant.Maps;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private string mapQuery = "";
    private string mapViewQuery = "";
    private MapCatalog? mapViewCatalog;
    private IReadOnlyList<MapDefinition> mapMatches = [];
    private uint selectedMapId;
    private float mapX = 20.5f;
    private float mapY = 20.5f;
    private string? mapOpenError;

    private void DrawMaps()
    {
        Heading("Cartes & repères", "Cartes du jeu · sélectionnez une zone et saisissez les coordonnées de votre repère");
        var state = maps.State;
        if (state.Catalog is not { } catalog)
        { ImGui.TextWrapped(state.Error ?? $"Chargement : {state.Copied:N0}/{state.Total:N0} cartes"); return; }
        DrawMapBookmarks(catalog);
        ImGui.SetNextItemWidth(-1);
        ImGui.InputTextWithHint("##MapSearch", "Région, zone, sous-zone ou identifiant de carte…", ref mapQuery, 128);
        if (!ReferenceEquals(mapViewCatalog, catalog) || mapViewQuery != mapQuery)
        { mapMatches = catalog.Search(mapQuery); mapViewCatalog = catalog; mapViewQuery = mapQuery; }
        ImGui.TextDisabled($"{mapMatches.Count:N0} cartes · l'accès et les déblocages ne sont pas vérifiés");
        var showList = ImGui.BeginChild("MapList", new Vector2(0, 210), true);
        try
        {
            if (showList)
            {
                var clipper = ImGui.ImGuiListClipper();
                try
                {
                    clipper.Begin(mapMatches.Count);
                    while (clipper.Step())
                    for (var index = clipper.DisplayStart; index < clipper.DisplayEnd; index++)
                    {
                        var map = mapMatches[index];
                        var label = string.IsNullOrWhiteSpace(map.Subzone) ? map.Zone : $"{map.Zone} · {map.Subzone}";
                        if (ImGui.Selectable($"{label}##Map{map.MapId}", selectedMapId == map.MapId))
                        { selectedMapId = map.MapId; mapOpenError = null; selectedBookmark = Guid.Empty; bookmarkName = ""; bookmarkSaved = false; }
                        if (ImGui.IsItemHovered()) ImGui.SetTooltip($"{map.Region}\n{label}\nCarte {map.MapId} · territoire {map.TerritoryId}");
                    }
                }
                finally { clipper.End(); clipper.Destroy(); }
            }
        }
        finally { ImGui.EndChild(); }
        if (catalog.Find(selectedMapId) is not { } selected)
        { ImGui.TextDisabled("Sélectionnez une carte."); return; }
        ImGui.TextColored(Accent, selected.Zone);
        if(ImGui.SmallButton("Prévisions météo de la zone")) OpenWeather(selected.TerritoryId,selected.Zone);
        ImGui.TextUnformatted($"{selected.Region} · {selected.Subzone}");
        ImGui.SetNextItemWidth(110); var changedX = ImGui.InputFloat("X##MapX", ref mapX, 0, 0, "%.1f");
        ImGui.SameLine(); ImGui.SetNextItemWidth(110); var changedY = ImGui.InputFloat("Y##MapY", ref mapY, 0, 0, "%.1f");
        if (changedX || changedY) bookmarkSaved = false;
        var valid = MapCatalog.CoordinatesValid(mapX, mapY);
        ImGui.BeginDisabled(!valid);
        try
        {
            if (ImGui.Button("Ouvrir la carte du jeu"))
                OpenMapPoint(selected, mapX, mapY);
        }
        finally { ImGui.EndDisabled(); }
        if (!valid) ImGui.TextWrapped("Saisissez des coordonnées finies comprises entre -10 000 et 10 000.");
        if (mapOpenError is { } errorText) ImGui.TextWrapped(errorText);
        DrawBookmarkEditor(selected);
        if (ImGui.SmallButton("Ressources connues dans cette zone"))
        { sourceZoneQuery = selected.Zone; sourceQuery = ""; sourceTypeFilter = null; page = Page.Gathering; }
        ImGui.TextWrapped("Le repère utilise vos coordonnées saisies. Il ne représente pas un point de récolte détecté. Les cartes événementielles ou sous-zones peuvent demander des conditions d'accès.");
    }
    private void OpenMapPoint(MapDefinition map, float x, float y)
    {
        if (!MapCatalog.CoordinatesValid(x, y)) { mapOpenError = "Coordonnées invalides."; return; }
        try
        {
            if (!gameGui.OpenMapWithMapLink(new MapLinkPayload(map.TerritoryId, map.MapId, x, y)))
                mapOpenError = "Le jeu n'a pas ouvert cette carte dans le contexte actuel.";
            else mapOpenError = null;
        }
        catch (Exception error) { mapOpenError = "Ouverture impossible ; détails dans le journal."; log.Warning(error, "Could not open selected map."); }
    }
}
