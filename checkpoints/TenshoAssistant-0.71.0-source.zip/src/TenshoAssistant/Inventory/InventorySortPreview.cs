namespace TenshoAssistant.Inventory;

public enum InventorySortField { Name, Category, Quantity, Quality }
public sealed record InventoryPreviewStack(InventoryLocation Origin, InventoryStack Stack);
public sealed record InventorySortResult(int Capacity, IReadOnlyList<InventoryPreviewStack> Stacks,IReadOnlyList<InventoryPreviewStack?>? Slots=null);

public static class InventorySortPreview
{
    public static InventorySortResult Build(IEnumerable<InventoryContainerSnapshot> containers, int capacity,
        InventorySortField field, bool descending, Func<uint, (string Name, uint Category)> describe)
        =>Build(containers,capacity,new[]{new InventorySortCriterion(field,descending)},describe);

    public static InventorySortResult Build(IEnumerable<InventoryContainerSnapshot> containers,int capacity,
        IReadOnlyList<InventorySortCriterion> criteria,Func<uint,(string Name,uint Category)> describe)
    {
        ArgumentNullException.ThrowIfNull(containers);
        ArgumentNullException.ThrowIfNull(describe);
        if(capacity<0 || criteria is null || criteria.Count is <1 or >4 || criteria.Any(c=>c is null || !Enum.IsDefined(c.Field))
            || criteria.Select(c=>c.Field).Distinct().Count()!=criteria.Count)throw new ArgumentOutOfRangeException(nameof(criteria));
        var source = containers.OrderBy(container => container.Location.Container.Value).ToArray();
        if (source.Any(container => container.Coverage != InventoryCoverage.Complete)
            || source.Select(container => container.Location.Owner).Distinct().Count() > 1
            || source.Select(container => container.Location).Distinct().Count() != source.Length)
            throw new InvalidOperationException("A complete, single-owner, nonduplicate source is required.");
        var values = source.SelectMany(container => container.Stacks.Select(stack => new InventoryPreviewStack(container.Location, stack))).ToArray();
        if (values.Length > capacity) throw new InvalidOperationException("Stacks exceed preview capacity.");
        var ordered = values.Select((value, index) => (Value: value, Index: index, Label: describe(value.Stack.Item.Id.Value))).ToArray();
        Array.Sort(ordered,(left,right)=>
        {
            foreach(var criterion in criteria)
            {
                var comparison=criterion.Field switch
                {
                    InventorySortField.Quantity=>left.Value.Stack.Quantity.CompareTo(right.Value.Stack.Quantity),
                    InventorySortField.Quality=>left.Value.Stack.Item.IsHighQuality.CompareTo(right.Value.Stack.Item.IsHighQuality),
                    InventorySortField.Category=>left.Label.Category.CompareTo(right.Label.Category),
                    _=>StringComparer.OrdinalIgnoreCase.Compare(left.Label.Name,right.Label.Name),
                };
                if(comparison!=0)return criterion.Descending ? -Math.Sign(comparison):Math.Sign(comparison);
            }
            var id=left.Value.Stack.Item.Id.Value.CompareTo(right.Value.Stack.Item.Id.Value);if(id!=0)return id;
            var quality=left.Value.Stack.Item.IsHighQuality.CompareTo(right.Value.Stack.Item.IsHighQuality);return quality!=0 ? quality:left.Index.CompareTo(right.Index);
        });
        return new(capacity,Array.AsReadOnly(ordered.Select(row=>row.Value).ToArray()));
    }
}
