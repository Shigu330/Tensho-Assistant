using System.Numerics;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.Craft;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private string craftPresetName="";private string? craftPresetError;private bool craftPresetSaved;private CraftPreset? lastSavedCraftPreset;
    private void SaveCraftPreset()
    {
        try
        {
            var preset=CraftPresets.Create(simulationRecipe!,craftPresetName,simulationActions);
            CraftPresets.Commit(configuration,save,rows=>CraftPresets.Add(rows,preset));craftPresetError=null;craftPresetSaved=true;lastSavedCraftPreset=preset;
        }
        catch(Exception error){craftPresetError=error.Message;craftPresetSaved=false;log.Warning(error,"Could not save craft sequence.");}
    }
    private void DrawCraftPresetSave()
    {
        if(ImGui.SmallButton("Séquences sauvegardées"))page=Page.CraftPresets;
        if(!ImGui.CollapsingHeader("Conserver la séquence"))return;
        ImGui.SetNextItemWidth(260);if(ImGui.InputText("Nom de la séquence",ref craftPresetName,160))craftPresetSaved=false;
        if(ImGui.Button("Sauvegarder une nouvelle séquence"))SaveCraftPreset();
        ImGui.TextDisabled("Recette et actions conservées ; attributs et résultat non enregistrés. Recalculez après chargement.");
        if(craftPresetSaved && lastSavedCraftPreset is { } saved && saved.RecipeId==simulationRecipe?.RecipeId && saved.Actions.SequenceEqual(simulationActions))ImGui.TextColored(Success,"Séquence sauvegardée.");
        if(craftPresetError is { } error)ImGui.TextWrapped(error);
    }
    private void DrawCraftPresets()
    {
        Heading("Séquences d'artisanat sauvegardées","Recettes et actions manuelles · aucune exécution automatique");
        if(ImGui.SmallButton("Retour au simulateur"))page=Page.CraftSimulation;
        var rows=configuration.CraftPresets ?? [];var catalog=recipeCatalog.State.Catalog;
        ImGui.TextDisabled($"{rows.Count}/{CraftPresets.Capacity} séquences · les attributs doivent être vérifiés et le résultat recalculé au chargement");
        if(craftPresetError is { } error)ImGui.TextWrapped(error);
        var remove=-1;
        for(var index=0;index<Math.Min(rows.Count,1000);index++)
        {
            var preset=rows[index];var recipe=CraftPresets.Resolve(preset,catalog);ImGui.PushID(index);
            try
            {
                if(preset is not null)
                {
                    var item=itemCatalog.State.Catalog?.Find(preset.ResultItemId);DrawItemIcon(item,new Vector2(28));ImGui.SameLine();
                    ImGui.TextWrapped($"{preset.Name} · {item?.Name ?? $"Objet {preset.ResultItemId}"}");
                    ImGui.TextDisabled($"Recette {preset.RecipeId} · {preset.Actions?.Count ?? 0} actions · {preset.SavedAt.ToUniversalTime():dd/MM/yyyy HH:mm} UTC");
                }
                else ImGui.TextWrapped("Entrée non lisible conservée.");
                ImGui.BeginDisabled(recipe is null);
                try
                {
                    if(ImGui.SmallButton("Charger dans le simulateur") && recipe is not null && preset?.Actions is { } actions)
                    {
                        OpenCraftSimulation(recipe);simulationActions.Clear();simulationActions.AddRange(actions);simulationResult=null;simulationError=null;
                        macroExportSimulation=null;craftMacroExport=null;craftSolve.Cancel();craftPresetName=preset.Name;craftPresetSaved=false;craftPresetError=null;
                    }
                }
                finally{ImGui.EndDisabled();}
                ImGui.SameLine();if(ImGui.SmallButton("Retirer"))remove=index;
                if(recipe is null)ImGui.TextDisabled(catalog is null ? "Catalogue en cours de chargement.":"Entrée/recette non résolue ; conservée sans exécution.");
                ImGui.Separator();
            }
            finally{ImGui.PopID();}
        }
        if(rows.Count>1000)ImGui.TextWrapped("Configuration hors limite : seules les 1 000 premières entrées sont présentées, aucune suppression automatique.");
        if(remove>=0)
        {
            try{CraftPresets.Commit(configuration,save,source=>CraftPresets.Remove(source,remove));craftPresetError=null;}
            catch(Exception saveError){craftPresetError=saveError.Message;log.Warning(saveError,"Could not remove saved craft sequence.");}
        }
    }
}
