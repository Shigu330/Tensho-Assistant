using Dalamud.Game.Command;
using Dalamud.Interface.Windowing;
using Dalamud.Plugin;
using Dalamud.Plugin.Services;
using TenshoAssistant.Inventory;
using TenshoAssistant.Items;
using TenshoAssistant.Craft;
using TenshoAssistant.Gathering;
using TenshoAssistant.Collections;
using TenshoAssistant.Market;
using TenshoAssistant.Quests;
using TenshoAssistant.Character;
using TenshoAssistant.Maps;
using TenshoAssistant.Macros;
using TenshoAssistant.MiniGames;
using TenshoAssistant.Duties;
using TenshoAssistant.Community;
using TenshoAssistant.Monsters;
using TenshoAssistant.Fashion;

namespace TenshoAssistant;

public sealed class Plugin : IDalamudPlugin
{
    private const string Command = "/tensho";
    private readonly RegistrationScope registrations = new();
    private readonly IPluginLog log;
    private readonly MainWindow mainWindow;
    private readonly WindowSystem windows = new("TenshoAssistant");
    private readonly InventoryService inventoryService = new();
    private readonly InventoryVisualSortService visualSort=new();
    private readonly ItemCatalogService itemCatalog = new();
    private readonly RecipeCatalogService recipeCatalog = new();
    private readonly CraftActionCatalogService craftActions = new();
    private readonly CraftLiveService craftLive = new();
    private readonly WeatherCatalogService weather = new();
    private readonly GatheringCatalogService gatheringCatalog = new();
    private readonly GpCatalogService gpActions = new();
    private readonly CollectionService collections = new();
    private readonly MarketService market = new();
    private readonly ItemHoverService itemHover = new();
    private readonly QuestService quests = new();
    private readonly CharacterStatsService characterStats = new();
    private readonly MapCatalogService maps = new();
    private readonly MacroObservationService macroObservations = new();
    private readonly MacroChainService macroChain = new();
    private readonly TriadObservationService triadObservation = new();
    private readonly MiniCactpotObservationService cactpotObservation = new();
    private readonly GatheringObservationService gatheringObservation = new();
    private readonly ItemUseCatalogService itemUses = new();
    private readonly DutyCatalogService duties = new();
    private readonly GarlandClient garland = new();
    private readonly DutyLootService dutyLoot;
    private readonly MonsterLootService monsterLoot;
    private readonly FashionHintService fashionHints=new();
    private readonly FashionDataService fashionData=new();
    private readonly BankImportOverlay bankOverlay;
    private readonly ItemContextMenuBridge? itemContextMenu;

    public Plugin(IDalamudPluginInterface pluginInterface, ICommandManager commands, IPluginLog log,
        IGameInventory inventory, IPlayerState player, IClientState client, IFramework framework, IDataManager data, IGameGui gameGui,
        ITextureProvider textures, IUnlockState unlocks, IGameInteropProvider interop,IObjectTable objects,IContextMenu contextMenus)
    {
        this.log = log;
        dutyLoot = new DutyLootService(garland);
        monsterLoot = new MonsterLootService(garland);
        try
        {
            registrations.Register(() => { }, market.Dispose);
            registrations.Register(() => { }, garland.Dispose);
            registrations.Register(() => { }, dutyLoot.Dispose);
            registrations.Register(() => { }, monsterLoot.Dispose);
            registrations.Register(() => { }, fashionData.Dispose);
            var configuration = pluginInterface.GetPluginConfig() as Configuration ?? new Configuration();
            if (configuration.Version != 1)
                throw new NotSupportedException($"Unsupported configuration version: {configuration.Version}");
            MarketWorldReader? marketReader = null;
            registrations.Register(() => marketReader = new MarketWorldReader(market, framework, player, client, log), () => marketReader?.Dispose());
            var bank = new InventoryBankService(new FileInventoryBankStore(
                Path.Combine(pluginInterface.GetPluginConfigDirectory(), "InventoryBank.json")));
            registrations.Register(() => { }, bank.Dispose);
            var bankBridge = new BankInventoryBridge(bank, inventory, gameGui, player, client, framework, log);
            registrations.Register(() => { }, bankBridge.Dispose);
            bankOverlay = new BankImportOverlay(bank, bankBridge);
            mainWindow = new MainWindow(configuration, () => pluginInterface.SavePluginConfig(configuration), log,
                inventoryService, itemCatalog, recipeCatalog, gatheringCatalog, collections, market, itemHover, quests, characterStats, maps, macroObservations, macroChain, triadObservation, bank, bankBridge, textures, gameGui, duties, dutyLoot, monsterLoot,gpActions,fashionHints,fashionData,craftActions,craftLive,weather,cactpotObservation,gatheringObservation,itemUses,visualSort) { IsOpen = configuration.OpenOnLoad };
            registrations.Register(() => { }, mainWindow.Dispose);
            itemContextMenu=new ItemContextMenuBridge(configuration,contextMenus,player,client,itemCatalog,log);
            registrations.Register(()=>{ },itemContextMenu.Dispose);
            InventoryVisualSortBridge? sortBridge=null;
            registrations.Register(()=>sortBridge=new InventoryVisualSortBridge(visualSort,inventory,player,client,framework,log,bankBridge),()=>sortBridge?.Dispose());
            MacroChainBridge? macroBridge = null;
            registrations.Register(() => macroBridge = new MacroChainBridge(macroChain, framework, player, client, commands, interop, log), () => macroBridge?.Dispose());
            MacroObservationReader? macroObserver = null;
            registrations.Register(() => macroObserver = new MacroObservationReader(macroObservations, framework, player, client, log), () => macroObserver?.Dispose());
            ItemHoverReader? hoverReader = null;
            registrations.Register(() => hoverReader = new ItemHoverReader(configuration, market, itemHover, itemCatalog, gameGui, player, client, framework, log),
                () => hoverReader?.Dispose());
            MapCatalogLoader? mapLoader = null;
            registrations.Register(() => mapLoader = new MapCatalogLoader(maps, data, framework, log), () => mapLoader?.Dispose());
            DutyCatalogLoader? dutyLoader = null;
            registrations.Register(() => dutyLoader = new DutyCatalogLoader(duties, data, framework, log), () => dutyLoader?.Dispose());
            CharacterStatsReader? statsReader = null;
            registrations.Register(() => statsReader = new CharacterStatsReader(characterStats, framework, player, client, log,objects), () => statsReader?.Dispose());
            GpCatalogLoader? gpLoader=null;
            WeatherCatalogLoader? weatherLoader=null;
            registrations.Register(()=>weatherLoader=new WeatherCatalogLoader(weather,data,framework,log),()=>weatherLoader?.Dispose());
            registrations.Register(()=>gpLoader=new GpCatalogLoader(gpActions,data,framework,log),()=>gpLoader?.Dispose());
            CraftActionCatalogLoader? craftActionLoader=null;
            registrations.Register(()=>craftActionLoader=new CraftActionCatalogLoader(craftActions,data,framework,log),()=>craftActionLoader?.Dispose());
            CraftLiveReader? craftLiveReader=null;
            registrations.Register(()=>craftLiveReader=new CraftLiveReader(craftLive,recipeCatalog,craftActions,itemCatalog,framework,player,client,gameGui,objects,log),()=>craftLiveReader?.Dispose());
            FashionHintLoader? fashionLoader=null;
            registrations.Register(()=>fashionLoader=new FashionHintLoader(fashionHints,data,framework,log),()=>fashionLoader?.Dispose());
            QuestReader? questReader = null;
            registrations.Register(() => questReader = new QuestReader(quests, data, framework, player, client, unlocks, log),
                () => questReader?.Dispose());
            CollectionReader? collectionReader = null;
            registrations.Register(() => collectionReader = new CollectionReader(collections, data, framework, player, client, unlocks, log),
                () => collectionReader?.Dispose());
            TriadObservationReader? triadReader = null;
            MiniCactpotObservationReader? cactpotReader=null;
            GatheringObservationReader? gatheringReader=null;
            registrations.Register(()=>gatheringReader=new GatheringObservationReader(gatheringObservation,framework,player,client,gameGui,objects,log),()=>gatheringReader?.Dispose());
            registrations.Register(()=>cactpotReader=new MiniCactpotObservationReader(cactpotObservation,framework,player,client,gameGui,log),()=>cactpotReader?.Dispose());
            registrations.Register(() => triadReader = new TriadObservationReader(triadObservation, framework, player, client, gameGui, log),
                () => triadReader?.Dispose());
            ItemCatalogLoader? catalogLoader = null;
            ItemUseCatalogLoader? usageLoader=null;
            registrations.Register(()=>usageLoader=new ItemUseCatalogLoader(itemUses,data,framework,log),()=>usageLoader?.Dispose());
            registrations.Register(() => catalogLoader = new ItemCatalogLoader(itemCatalog, data, framework, log),
                () => catalogLoader?.Dispose());
            RecipeCatalogLoader? recipeLoader = null;
            registrations.Register(() => recipeLoader = new RecipeCatalogLoader(recipeCatalog, data, framework, log),
                () => recipeLoader?.Dispose());
            GatheringCatalogLoader? gatheringLoader = null;
            registrations.Register(() => gatheringLoader = new GatheringCatalogLoader(gatheringCatalog, data, framework, log),
                () => gatheringLoader?.Dispose());
            DalamudInventoryReader? inventoryReader = null;
            registrations.Register(() => inventoryReader = new DalamudInventoryReader(inventoryService, inventory, player, client, framework, log),
                () => inventoryReader?.Dispose());
            registrations.Register(() => windows.AddWindow(mainWindow), () => windows.RemoveWindow(mainWindow));
            registrations.Register(() =>
            {
                if (!commands.AddHandler(Command, new CommandInfo(OnCommand)
                    { HelpMessage = "Ouvrir Tensho--Assistant." }))
                    throw new InvalidOperationException($"Command already registered: {Command}");
            }, () => commands.RemoveHandler(Command));
            registrations.Register(() => pluginInterface.UiBuilder.Draw += Draw,
                () => pluginInterface.UiBuilder.Draw -= Draw);
            registrations.Register(() => pluginInterface.UiBuilder.OpenMainUi += Open,
                () => pluginInterface.UiBuilder.OpenMainUi -= Open);
            registrations.Register(() => pluginInterface.UiBuilder.OpenConfigUi += Open,
                () => pluginInterface.UiBuilder.OpenConfigUi -= Open);
            Action openOnLogin = () =>
            {
                if (configuration.OpenOnLogin) Open();
            };
            registrations.Register(() => client.Login += openOnLogin,
                () => client.Login -= openOnLogin);
        }
        catch
        {
            Dispose();
            throw;
        }
    }

    private void OnCommand(string command, string arguments) => Open();
    private void Open() => mainWindow.IsOpen = true;
    private void Draw()
    {
        if(itemContextMenu?.Take() is { } request)mainWindow.OpenItemContext(request);
        windows.Draw();
        bankOverlay.Draw();
        mainWindow.DrawItemHover();
    }

    public void Dispose()
    {
        try { registrations.Dispose(); }
        catch (AggregateException error) { log.Error(error, "Failed to release some Tensho registrations."); }
    }
}
