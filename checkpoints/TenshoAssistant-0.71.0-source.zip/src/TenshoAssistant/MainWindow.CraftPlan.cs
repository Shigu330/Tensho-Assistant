using System.Numerics;
using System.Text;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.Craft;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private void DrawCraftPlan(RecipeDefinition recipe)
    {
        if(ImGui.SmallButton("Simuler cette recette")) OpenCraftSimulation(recipe);
        if (!ImGui.CollapsingHeader("Préparer la fabrication##CraftPlan", ImGuiTreeNodeFlags.DefaultOpen)) return;
        ImGui.SetNextItemWidth(150);
        ImGui.InputInt("Objets à produire##CraftPlanTarget", ref craftPlanTarget);
        craftPlanTarget = Math.Clamp(craftPlanTarget, 1, 999999);
        var plan = CraftPlan.Build(recipe, craftPlanTarget, GetRecipeHoldings);
        ImGui.TextColored(Accent, $"{plan.Crafts:N0} craft(s) → {plan.Produced:N0} objet(s)");
        if (plan.Produced > plan.Requested) ImGui.TextDisabled($"Surplus lié au rendement : {plan.Produced - plan.Requested:N0}");
        if (plan.Materials.Count == 0)
        {
            ImGui.TextDisabled("Aucun ingrédient connu : préparation indisponible.");
            return;
        }
        if (ImGui.BeginTable("CraftPlanMaterials", 4, ImGuiTableFlags.SizingStretchProp | ImGuiTableFlags.RowBg))
        {
            try
            {
                ImGui.TableSetupColumn("Ingrédient", ImGuiTableColumnFlags.WidthStretch, 2);
                ImGui.TableSetupColumn("Requis");
                ImGui.TableSetupColumn("Recensé NQ + HQ");
                ImGui.TableSetupColumn("À compléter");
                ImGui.TableHeadersRow();
                foreach (var material in plan.Materials)
                {
                    ImGui.TableNextRow();
                    ImGui.TableNextColumn();
                    ImGui.PushID((int)material.ItemId);
                    try
                    {
                        var item = itemCatalog.State.Catalog?.Find(material.ItemId);
                        DrawItemIcon(item, new Vector2(24));
                        var clicked = ImGui.IsItemClicked();
                        ImGui.SameLine();
                        if (ImGui.SmallButton(item?.Name ?? $"ID {material.ItemId}") || clicked) SelectItem(material.ItemId);
                        ImGui.SameLine();
                        if (ImGui.SmallButton("Lieux")) OpenGathering(material.ItemId);
                    }
                    finally { ImGui.PopID(); }
                    ImGui.TableNextColumn(); ImGui.TextUnformatted(material.Required.ToString("N0"));
                    ImGui.TableNextColumn();
                    ImGui.TextUnformatted(material.Holdings.HasObservation ? material.Holdings.Total.ToString("N0") : "Inconnu");
                    ImGui.TableNextColumn();
                    if (!material.Holdings.HasObservation) ImGui.TextDisabled("À vérifier");
                    else ImGui.TextColored(material.Uncovered == 0 ? Success : Accent, material.Uncovered.ToString("N0"));
                }
            }
            finally { ImGui.EndTable(); }
        }
        ImGui.TextWrapped("Calcul sur NQ + HQ, sans garantir la qualité du résultat. À compléter : écart par rapport aux stocks recensés.");
        DrawPreparationCost(recipe,plan);
        DrawCraftChain(recipe);
        if (plan.Materials.Any(material => !material.Holdings.HasObservation || material.Holdings.HasUnknown))
            ImGui.TextWrapped("Certains rangements sont inconnus : vérifiez les stocks avant de récolter ou d'acheter.");
        if (plan.Materials.Any(material => material.Holdings.HasCached))
            ImGui.TextDisabled("Imports manuels : actualisez les relevés après un transfert.");
        if (ImGui.Button("Copier la liste des ingrédients"))
        {
            var text = new StringBuilder();
            var name = itemCatalog.State.Catalog?.Find(recipe.ResultItemId)?.Name ?? $"ID {recipe.ResultItemId}";
            text.AppendLine($"{name} : {plan.Requested} demandé(s), {plan.Crafts} craft(s), {plan.Produced} produit(s)");
            foreach (var material in plan.Materials)
            {
                var ingredient = itemCatalog.State.Catalog?.Find(material.ItemId)?.Name ?? $"ID {material.ItemId}";
                text.AppendLine($"{ingredient} : requis {material.Required}, recensé "
                    + (material.Holdings.HasObservation ? $"{material.Holdings.Total}, à compléter {material.Uncovered}" : "inconnu")
                    + (material.Holdings.HasCached || material.Holdings.HasUnknown ? " (stock à vérifier)" : ""));
            }
            ImGui.SetClipboardText(text.ToString());
        }
    }
}
