using Dalamud.Bindings.ImGui;
using TenshoAssistant.Inventory;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private void DrawSettings()
    {
        Heading("Réglages", "Options communes et réglages des outils, regroupés par domaine.");
        ImGui.TextColored(Accent, "Fenêtre · préférences sauvegardées");
        var openOnLoad = configuration.OpenOnLoad;
        var openOnLogin = configuration.OpenOnLogin;
        var loadChanged = ImGui.Checkbox("Ouvrir au chargement du plugin", ref openOnLoad);
        ImGui.TextDisabled("À l'activation ou au rechargement de Tensho--Assistant.");
        ImGui.Spacing();
        var loginChanged = ImGui.Checkbox("Ouvrir à la connexion du personnage", ref openOnLogin);
        ImGui.TextDisabled("À chaque connexion ou reconnexion d'un personnage.");
        if (loadChanged || loginChanged)
        {
            var previous = configuration.OpenOnLoad;
            var previousLogin = configuration.OpenOnLogin;
            configuration.OpenOnLoad = openOnLoad;
            configuration.OpenOnLogin = openOnLogin;
            try
            {
                save();
                saveError = null;
            }
            catch (Exception error)
            {
                configuration.OpenOnLoad = previous;
                configuration.OpenOnLogin = previousLogin;
                saveError = "Échec de sauvegarde. Réessayez ; les détails sont dans le journal Dalamud.";
                log.Error(error, "Could not persist Tensho configuration.");
            }
        }
        ImGui.Spacing(); ImGui.Separator();
        ImGui.TextColored(Accent, "Objets & marché · préférences sauvegardées");
        var hoverPrices = configuration.MarketPricesOnHover;
        if (ImGui.Checkbox("Afficher les prix au survol des objets en jeu", ref hoverPrices))
        {
            var previous = configuration.MarketPricesOnHover;
            configuration.MarketPricesOnHover = hoverPrices;
            try { save(); saveError = null; if (!hoverPrices) market.CancelBackground(); }
            catch (Exception error)
            { configuration.MarketPricesOnHover = previous; saveError = "Échec de sauvegarde de l'option de prix."; log.Warning(error, "Could not save market hover preference."); }
        }
        ImGui.TextWrapped("Désactivé par défaut. Après un survol stable, consulte Universalis avec les seuls identifiants publics d'objet et de monde. Cache partagé de cinq minutes ; au plus une requête réseau toutes les trois secondes pour les prix manuels et au survol réunis.");
        var hoverUsages=configuration.ItemUsagesOnHover;
        if(ImGui.Checkbox("Afficher les usages au survol des objets en jeu",ref hoverUsages))
        {
            var previous=configuration.ItemUsagesOnHover;configuration.ItemUsagesOnHover=hoverUsages;
            try{save();saveError=null;}
            catch(Exception error){configuration.ItemUsagesOnHover=previous;saveError="Échec de sauvegarde de l’option d’usages.";log.Warning(error,"Could not save item usage hover preference.");}
        }
        ImGui.TextWrapped("Désactivé par défaut. Affiche les références de recettes, mandats, livraisons GC et aquarium après un survol stable. Fonctionne avec les données du jeu, sans activer les prix ou une requête réseau. Les deux options partagent un seul panneau.");
        var itemMenu=configuration.ItemContextMenuEnabled;
        if(ImGui.Checkbox("Ajouter Tensho au clic droit des objets d’inventaire",ref itemMenu))
        {
            var previous=configuration.ItemContextMenuEnabled;configuration.ItemContextMenuEnabled=itemMenu;
            try{save();saveError=null;}
            catch(Exception error){configuration.ItemContextMenuEnabled=previous;saveError="Échec de sauvegarde du menu d’objets.";log.Warning(error,"Could not save item context menu preference.");}
        }
        ImGui.TextWrapped("Désactivé par défaut. Le sous-menu Tensho ouvre les usages, stocks, crafts, sources de récolte ou tous les outils avec l’objet choisi. Aucun prix n’est demandé par ce menu. Les liens de discussion et objets spéciaux ne sont pas couverts.");
        if (saveError is not null) ImGui.TextWrapped(saveError);
        ImGui.Spacing(); ImGui.Separator();
        ImGui.TextWrapped("Les observations et paramètres ci-dessous s’appliquent à la session. Les observations restent désactivées au rechargement du plugin. Les données et scénarios se modifient dans leurs outils respectifs.");
        if(ImGui.CollapsingHeader("Artisanat · observation, recherche et export",ImGuiTreeNodeFlags.DefaultOpen))
        {
            DrawObservationSetting("Observer la synthèse en cours",craftLive.State.Enabled,craftLive.SetEnabled);
            ImGui.TextWrapped("Lecture seule et comparaison du prochain coup ; aucune action de craft lancée.");
            ImGui.TextColored(Accent,"Limites de recherche d’une séquence");
            ImGui.SetNextItemWidth(130);
            if(ImGui.InputInt("Étapes maximum (1–100)",ref craftSolveSteps,0))craftSolveSteps=Math.Clamp(craftSolveSteps,1,100);
            ImGui.SetNextItemWidth(130);
            if(ImGui.InputInt("États conservés par étape (1–512)",ref craftSolveWidth,0))craftSolveWidth=Math.Clamp(craftSolveWidth,1,512);
            ImGui.SetNextItemWidth(130);
            if(ImGui.InputInt("Transitions maximum (1–500 000)",ref craftSolveBudget,0))craftSolveBudget=Math.Clamp(craftSolveBudget,1,500000);
            ValidateCraftSearch();
            ImGui.TextDisabled("Modifier une limite invalide la proposition courante ; relancez la recherche dans Artisanat.");
            ImGui.TextColored(Accent,"Export des macros de craft");
            ImGui.SetNextItemWidth(130);
            var exportChanged=ImGui.InputInt("Secondes ajoutées à chaque attente (0–3)",ref craftMacroExtraWait,0);
            if(exportChanged)craftMacroExtraWait=Math.Clamp(craftMacroExtraWait,0,3);
            exportChanged|=ImGui.Checkbox("Message sonore de fin de bloc (une ligne)",ref craftMacroEcho);
            if(exportChanged){craftMacroExport=null;craftMacroError=null;}
            ImGui.TextDisabled("Préparez à nouveau le texte dans Artisanat après modification de l’export.");
        }
        if(ImGui.CollapsingHeader("Récolte & pêche · observation",ImGuiTreeNodeFlags.DefaultOpen))
        {
            DrawObservationSetting("Observer le point MIN/BTN ouvert dans le jeu",gatheringObservation.State.Enabled,gatheringObservation.SetEnabled);
            ImGui.TextWrapped("Lecture seule du point courant. Les paramètres du scénario PR se modifient dans l’outil d’optimisation.");
        }
        if(ImGui.CollapsingHeader("Mini-jeux · observations expérimentales",ImGuiTreeNodeFlags.DefaultOpen))
        {
            DrawObservationSetting("Observer le ticket Mini Cactpot et actualiser les conseils",cactpotObservation.State.Enabled,enabled=>
            {
                cactpotObservation.SetEnabled(enabled);
                Array.Clear(cactpotBoard);cactpotObservedOwner=0;InvalidateCactpot();
            });
            DrawObservationSetting("Observer la fenêtre Triple Triade visible",triadObservation.State.Enabled,triadObservation.SetEnabled);
            ImGui.TextWrapped("Aucun clic automatique. Triple Triade : les faces observées ne prouvent pas les identités, règles ou joueur au trait.");
        }
        if(ImGui.CollapsingHeader("Macros · observation passive",ImGuiTreeNodeFlags.DefaultOpen))
        {
            DrawObservationSetting("Observer les transitions natives des macros",macroObservations.State.Enabled,macroObservations.SetEnabled);
            ImGui.TextWrapped("Lecture seule. L’activation ne lance ni n’annule de macro. Les séquences et leur lancement restent dans Macro Chain.");
        }
        if(ImGui.CollapsingHeader("Profils & données enregistrées"))
        {
            ImGui.TextWrapped("Ouvrez l’éditeur correspondant pour modifier vos données sauvegardées. Ces raccourcis ne lancent aucune action en jeu.");
            if(ImGui.Button("Profils et modèles de tri"))page=Page.SortPreview;
            if(ImGui.Button("Scénarios d’artisanat enregistrés"))page=Page.CraftPresets;
            if(ImGui.Button("Favoris des cartes"))page=Page.Maps;
            if(ImGui.Button("Deck Triple Triade"))page=Page.TripleTriad;
            if(ImGui.Button("Quêtes suivies"))page=Page.Quests;
            if(ImGui.Button("Séquence Macro Chain"))page=Page.MacroChain;
        }
        ImGui.Spacing(); ImGui.Separator();
        ImGui.TextWrapped("Vous pouvez toujours ouvrir la fenêtre avec /tensho. Profils de tri, modèles, favoris, decks et séquences restent éditables dans leurs outils.");
    }

    private static void DrawObservationSetting(string label,bool enabled,Action<bool> apply)
    {
        if(ImGui.Checkbox(label,ref enabled))apply(enabled);
    }

    private void DrawToolSettingsLink(string id)
    {
        if(ImGui.SmallButton($"Réglages de l’outil##{id}"))page=Page.Settings;
    }

    private void DrawDiagnostics()
    {
        Heading("Diagnostics", "État et provenance des données communes. Ces informations facilitent les vérifications en jeu.");
        ImGui.TextUnformatted($"Plugin : {BuildVersion} · Configuration : v{configuration.Version}");
        DrawMacroObservation();
        ImGui.Spacing();
        ImGui.TextColored(Accent, "Catalogue d'objets");
        DrawCatalogStatus();
        if (itemCatalog.State.Catalog is { } catalog)
        {
            ImGui.TextUnformatted($"Génération : {catalog.Metadata.Generation}");
            ImGui.TextWrapped($"Source : {catalog.Metadata.Source}");
            ImGui.TextWrapped($"Version des données : {catalog.Metadata.DataVersion}");
        }
        ImGui.Spacing();
        ImGui.TextColored(Accent, "Catalogue de recettes");
        var recipeState = recipeCatalog.State;
        if (recipeState.Catalog is { } recipes)
            ImGui.TextColored(Success, $"Catalogue prêt : {recipes.Count:N0} recettes · source {recipes.Source}");
        else if (recipeState.Error is { } recipeError)
            ImGui.TextWrapped($"Erreur : {recipeError}");
        else if (recipeState.TotalRows > 0)
            ImGui.TextWrapped($"Chargement : {recipeState.RowsCopied:N0}/{recipeState.TotalRows:N0} lignes copiées.");
        else
            ImGui.TextDisabled("Catalogue de recettes en préparation…");
        ImGui.Spacing();
        ImGui.Separator();
        var gathering = gatheringCatalog.State;
        ImGui.TextColored(Accent, "Catalogue de récolte");
        var mapState = maps.State;
        ImGui.TextDisabled(mapState.Catalog is { } mapCatalog ? $"Cartes : {mapCatalog.Entries.Count:N0} entrées natives"
            : mapState.Error ?? $"Cartes : {mapState.Copied:N0}/{mapState.Total:N0}");
        if (gathering.Catalog is { } gathered)
        {
            ImGui.TextColored(Success, $"Catalogue prêt : {gathered.Count:N0} liens objet/lieu");
            ImGui.TextWrapped($"Source : GatheringItem → GatheringPointBase → GatheringPoint + FishingSpot ; {gathered.Source}");
        }
        else ImGui.TextWrapped(gathering.Error ?? $"Chargement : {gathering.Copied:N0}/{gathering.Total:N0} points");
        ImGui.Spacing();
        ImGui.TextColored(Accent, "Collections, quêtes et services consultatifs");
        ImGui.TextDisabled($"Collections : {collections.State.Entries.Count:N0} entrées · personnage {collections.State.CharacterId} · lecture {collections.State.Loading}");
        if (collections.State.Error is { } collectionError) ImGui.TextWrapped(collectionError);
        var questState = quests.State;
        ImGui.TextDisabled($"Quêtes : {questState.Entries.Count:N0} entrées · personnage {questState.CharacterId} · lecture {questState.Loading}");
        if (questState.Error is { } questError) ImGui.TextWrapped(questError);
        if (questState.RewardIndexLoading) ImGui.TextDisabled("Sources de récompenses : index en construction…");
        else if (questState.RewardIndex is { } rewardIndex)
        {
            var coverage = rewardIndex.Coverage;
            ImGui.TextDisabled($"Sources de récompenses : {rewardIndex.ItemCount:N0} objets · {coverage.CoveredQuests:N0}/{coverage.TotalQuests:N0} quêtes couvertes");
            ImGui.TextDisabled($"Références non résolues : {coverage.UnresolvedReferences:N0} · quantités inconnues : {coverage.UnknownQuantityLines:N0} · quêtes sans version : {coverage.UnversionedQuests:N0}");
            ImGui.TextDisabled("Index de données statiques ; disponibilité et réception des récompenses non confirmées.");
        }
        else ImGui.TextDisabled("Sources de récompenses : index indisponible dans ce relevé");
        if (questState.RewardIndexError is { } rewardIndexError) ImGui.TextWrapped($"Index des récompenses : {rewardIndexError}");
        ImGui.TextDisabled($"Marché : monde {market.State.WorldName} · survol {(configuration.MarketPricesOnHover ? "activé" : "désactivé")}");
        ImGui.TextDisabled($"Usages au survol : {(configuration.ItemUsagesOnHover ? "activés":"désactivés")} · contexte {(itemHover.State.Item is { } hovered ? hovered.ItemId.ToString():"absent")}");
        if (market.State.Error is { } marketError) ImGui.TextWrapped(marketError);
        var stats = characterStats.State;
        ImGui.TextDisabled(stats.CharacterId == 0 ? "Attributs : aucune observation" : $"Attributs : {stats.Values.Count} valeurs · {stats.ObservedAt:HH:mm:ss} UTC");
        ImGui.TextDisabled(cactpotSolve.State.Loading ? "Mini Cactpot : calcul en cours" : $"Mini Cactpot : {(cactpotObservation.State.Enabled ? cactpotObservation.State.Status.ToString():"saisie manuelle ; observation désactivée")}");
        ImGui.TextDisabled($"Point de récolte : {(gatheringObservation.State.Enabled ? gatheringObservation.State.Status.ToString():"observation désactivée")}");
        if(itemUses.State.Catalog is { } uses)ImGui.TextDisabled($"Usages : {uses.LeveCount} mandats · {uses.SupplyItemCount} candidats GC · {uses.AquariumItemCount} poissons d’aquarium · {uses.Language}");
        else ImGui.TextDisabled($"Usages : lecture {itemUses.State.Copied}/{itemUses.State.Total}");
        if(itemUses.State.Error is { } usageError)ImGui.TextWrapped(usageError);
        var chain = craftChain.State;
        ImGui.TextDisabled(chain.Loading ? "Sous-recettes : calcul en cours" : chain.Result is { } chainResult
            ? $"Sous-recettes : {chainResult.Steps.Count} étapes · calcul {chain.CalculatedAt:HH:mm:ss} UTC"
            : "Sous-recettes : calcul manuel sur observations capturées");
        if (chain.Error is { } chainError) ImGui.TextWrapped(chainError);
        ImGui.Spacing();
        ImGui.TextColored(Accent, "Banque d'objets");
        var bankState = bank.State;
        ImGui.TextWrapped(bankState.Loading ? "Chargement du fichier…"
            : bankState.Error ?? $"{bankState.Entries.Count} relevés sauvegardés, tous personnages confondus.");
        ImGui.TextUnformatted(bankState.Importing ? "Écriture d'un import en cours." : "Actualisation manuelle uniquement.");
        var menus = bankBridge.State;
        ImGui.TextWrapped($"Fenêtre servant détectée : {menus.Retainer?.AddonName ?? "aucune"}");
        ImGui.TextWrapped($"Fenêtre chocobo détectée : {menus.Saddlebag?.AddonName ?? "aucune"}");
        if (menus.Message is { } message) ImGui.TextWrapped(message);
        ImGui.Spacing();
        ImGui.Separator();
        ImGui.TextColored(Accent, "Inventaire du personnage");
        var snapshot = inventory.Current;
        if (snapshot is null)
        {
            ImGui.TextWrapped("Inconnu : aucune observation valide actuellement publiée.");
            return;
        }
        ImGui.TextUnformatted($"Observation : {snapshot.ObservedAt:yyyy-MM-dd HH:mm:ss} UTC");
        ImGui.TextWrapped($"Source : {snapshot.Source}");
        foreach (var container in snapshot.Containers.Values.OrderBy(c => c.Location.Container.Value))
        {
            var state = container.Coverage switch
            {
                InventoryCoverage.Complete => "complet",
                InventoryCoverage.Partial => "partiel",
                _ => "inconnu",
            };
            var name = container.Location.Container.Value == 2001
                ? "Cristaux"
                : $"Sac {container.Location.Container.Value + 1}";
            ImGui.TextUnformatted($"{name} : {state}");
        }
        ImGui.TextWrapped("Cette observation couvre les quatre sacs et le rangement des cristaux, pas tous les autres rangements du personnage.");
    }
}
