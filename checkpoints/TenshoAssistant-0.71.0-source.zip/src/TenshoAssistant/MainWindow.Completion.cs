using System.Numerics;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.Collections;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private bool focusTitleTab,focusAchievementTab,completionDetailsRequested;
    private uint selectedCompletionId;
    private CollectionKind selectedCompletionKind;
    private uint? achievementCategoryFilter;
    private CollectionState? achievementCategoryState,completionDetailState;
    private CollectionEntry[] achievementCategories=[],relatedCompletion=[];
    private CollectionEntry? completionDetail;
    private uint cachedCompletionId;
    private CollectionKind cachedCompletionKind;

    private static string CollectionAcquisitionLabel(CollectionEntry entry)=>entry.Acquisition switch
    {
        CollectionAcquisition.Acquired=>entry.Kind==CollectionKind.Achievement ? "Terminé confirmé":"Acquis confirmé",
        CollectionAcquisition.NotAcquired=>entry.Kind==CollectionKind.Achievement ? "Non terminé au relevé":"Non acquis au relevé",
        _=>"Non confirmé",
    };

    private void OpenCompletion(CollectionEntry entry)
    {
        selectedCompletionKind=entry.Kind;selectedCompletionId=entry.Id;completionDetailsRequested=true;
        focusTitleTab=entry.Kind==CollectionKind.Title;focusAchievementTab=entry.Kind==CollectionKind.Achievement;
        collectionKind=entry.Kind;collectionQuery=entry.Name;collectionFilter=0;achievementCategoryFilter=entry.Achievement?.CategoryId;
        page=Page.Collections;
    }

    private void DrawAchievementCategories(CollectionState state)
    {
        if(!ReferenceEquals(state,achievementCategoryState))
        {
            achievementCategoryState=state;
            achievementCategories=state.Entries.Where(entry=>entry.Kind==CollectionKind.Achievement && entry.Achievement is {CategoryName.Length:>0})
                .GroupBy(entry=>entry.Achievement!.CategoryId).Select(group=>group.First())
                .OrderBy(entry=>entry.Achievement!.KindOrder).ThenBy(entry=>entry.Achievement!.CategoryOrder).ToArray();
            if(achievementCategoryFilter is { } selected && !achievementCategories.Any(entry=>entry.Achievement!.CategoryId==selected))achievementCategoryFilter=null;
        }
        var current=achievementCategories.FirstOrDefault(entry=>entry.Achievement!.CategoryId==achievementCategoryFilter);
        ImGui.SetNextItemWidth(330);
        if(!ImGui.BeginCombo("Catégorie de succès",current?.Achievement?.CategoryName ?? "Toutes les catégories"))return;
        try
        {
            if(ImGui.Selectable("Toutes les catégories",achievementCategoryFilter is null))achievementCategoryFilter=null;
            foreach(var entry in achievementCategories)
            {
                var meta=entry.Achievement!;
                if(ImGui.Selectable($"{meta.KindName} · {meta.CategoryName}##AchievementCategory{meta.CategoryId}",meta.CategoryId==achievementCategoryFilter))achievementCategoryFilter=meta.CategoryId;
            }
        }
        finally{ImGui.EndCombo();}
    }

    private void DrawCompletionDetails(CollectionState state)
    {
        ImGui.SetNextWindowSize(new Vector2(560,0),ImGuiCond.Appearing);var open=true;
        if(!ImGui.BeginPopupModal("Fiche de titre ou de succès",ref open,ImGuiWindowFlags.AlwaysAutoResize))return;
        try
        {
            if(!ReferenceEquals(completionDetailState,state) || cachedCompletionId!=selectedCompletionId || cachedCompletionKind!=selectedCompletionKind)
            {
                completionDetailState=state;cachedCompletionId=selectedCompletionId;cachedCompletionKind=selectedCompletionKind;
                completionDetail=state.Entries.FirstOrDefault(entry=>entry.Kind==selectedCompletionKind && entry.Id==selectedCompletionId);
                relatedCompletion=completionDetail?.Title is not null
                    ? state.Entries.Where(entry=>entry.Achievement?.RewardTitleId==selectedCompletionId).ToArray()
                    : completionDetail?.Achievement is {RewardTitleId:>0} reward
                        ? state.Entries.Where(entry=>entry.Kind==CollectionKind.Title && entry.Id==reward.RewardTitleId).ToArray():[];
            }
            if(completionDetail is not { } entry)ImGui.TextWrapped("Entrée indisponible dans le relevé courant.");
            else
            {
                ImGui.TextColored(Accent,entry.Name);ImGui.TextColored(entry.ConfirmedUnlocked ? Success:Muted,CollectionAcquisitionLabel(entry));
                if(entry.Title is { } title)
                {
                    ImGui.TextWrapped($"Masculin : {title.Masculine}\nFéminin : {title.Feminine}");
                    ImGui.TextDisabled(title.IsPrefix ? "Titre placé avant le nom":"Titre placé après le nom");
                    ImGui.TextColored(Accent,$"Succès indiquant ce titre en récompense ({relatedCompletion.Length})");
                }
                if(entry.Achievement is { } achievement)
                {
                    ImGui.TextDisabled($"{achievement.KindName} · {achievement.CategoryName} · {achievement.Points} points du catalogue");
                    ImGui.TextWrapped(entry.Description);
                    if(achievement.RewardItemId!=0)
                    {
                        var item=itemCatalog.State.Catalog?.Find(achievement.RewardItemId);
                        if(item is null)ImGui.TextWrapped("Objet de récompense non résolu dans le catalogue courant.");
                        else
                        {
                            DrawItemIcon(item,new Vector2(32));var clicked=ImGui.IsItemClicked();ImGui.SameLine();
                            clicked|=ImGui.SmallButton($"Stocks et outils : {item.Name}");
                            if(clicked){SelectItem(item.Id);page=Page.Items;focusStocksTab=true;ImGui.CloseCurrentPopup();}
                        }
                    }
                    if(achievement.RewardTitleId!=0 && relatedCompletion.Length==0)ImGui.TextWrapped("Titre de récompense non résolu dans le catalogue courant.");
                    ImGui.TextWrapped("Terminer un succès ne prouve ni la réclamation de sa récompense ni la possession de l’objet ou du titre.");
                }
                foreach(var related in relatedCompletion)
                {
                    if(ImGui.SmallButton($"{related.Name}##Related{related.Kind}{related.Id}"))
                    {OpenCompletion(related);ImGui.CloseCurrentPopup();}
                }
                ImGui.TextWrapped("Les états sont ceux du relevé daté ; disponibilité, objectifs cachés et progression chiffrée ne sont pas calculés.");
            }
            if(ImGui.Button("Fermer"))ImGui.CloseCurrentPopup();
        }
        finally{ImGui.EndPopup();}
    }
}
