using System.Globalization;
using System.Numerics;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.Duties;
using TenshoAssistant.Items;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private string dutyQuery = "";
    private string dutyCategory = "";
    private string dutyItemQuery = "";
    private int dutySourceFilter;
    private bool showDutyDetails;
    private DutyCatalog? dutyViewCatalog;
    private string dutyViewQuery = "";
    private string dutyViewCategory = "";
    private DutyDefinition[] dutyMatches = [];
    private string[] dutyCategories = [];
    private DutyLootDocument? dutyViewDocument;
    private ItemCatalog? dutyViewItems;
    private string dutyViewItemQuery = "";
    private int dutyViewSourceFilter = -1;
    private (uint Id, string Name, DutyLootEntry[] Sources)[] dutyItemMatches = [];

    private void DrawDutyLoot()
    {
        Heading("Butins des contenus", "Catalogue du jeu · données de butin consultées manuellement auprès de Garland Tools");
        var catalogState = duties.State;
        if (catalogState.Catalog is not { } catalog)
        { ImGui.TextWrapped(catalogState.Error ?? $"Chargement des contenus : {catalogState.Copied}/{catalogState.Total}"); return; }
        if (showDutyDetails && dutyLoot.State.Duty is not null)
        {
            if (ImGui.SmallButton("Retour aux contenus")) showDutyDetails = false;
            DrawDutyLootDetails(); return;
        }
        if (dutyLoot.State.Duty is not null && ImGui.SmallButton("Revoir le butin sélectionné")) showDutyDetails = true;
        ImGui.SetNextItemWidth(-1);
        ImGui.InputTextWithHint("##DutySearch","Nom du contenu ou identifiant du menu de missions…",ref dutyQuery,128);
        if (!ReferenceEquals(dutyViewCatalog,catalog))
            dutyCategories = catalog.Entries.Select(duty => duty.Category).Where(name => !string.IsNullOrWhiteSpace(name))
                .Distinct(StringComparer.Ordinal).OrderBy(name => name,StringComparer.CurrentCultureIgnoreCase).ToArray();
        ImGui.SetNextItemWidth(240);
        if (ImGui.BeginCombo("Catégorie##Duty",dutyCategory.Length == 0 ? "Toutes" : dutyCategory))
        {
            try
            {
                if (ImGui.Selectable("Toutes",dutyCategory.Length == 0)) dutyCategory = "";
                foreach (var category in dutyCategories)
                    if (ImGui.Selectable(category,dutyCategory == category)) dutyCategory = category;
            }
            finally { ImGui.EndCombo(); }
        }
        if (!ReferenceEquals(dutyViewCatalog,catalog) || dutyViewQuery != dutyQuery || dutyViewCategory != dutyCategory)
        {
            var query = dutyQuery.Trim();
            dutyMatches = catalog.Entries.Where(duty => (dutyCategory.Length == 0 || duty.Category == dutyCategory)
                && (query.Length == 0 || duty.Name.Contains(query,StringComparison.CurrentCultureIgnoreCase)
                    || duty.DutyId.ToString(CultureInfo.InvariantCulture) == query)).ToArray();
            dutyViewCatalog = catalog; dutyViewQuery = dutyQuery; dutyViewCategory = dutyCategory;
        }
        ImGui.TextDisabled($"{dutyMatches.Length} contenus · accès et disponibilité du butin non garantis");
        if (!ImGui.BeginTable("DutyCatalog",3,ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingStretchProp)) return;
        try
        {
            ImGui.TableSetupColumn("Contenu",ImGuiTableColumnFlags.WidthStretch,3);
            ImGui.TableSetupColumn("Type"); ImGui.TableSetupColumn("Niveau"); ImGui.TableHeadersRow();
            var clipper = ImGui.ImGuiListClipper();
            try
            {
                clipper.Begin(dutyMatches.Length);
                while (clipper.Step())
                for (var index = clipper.DisplayStart; index < clipper.DisplayEnd; index++)
                {
                    var duty = dutyMatches[index];
                    ImGui.TableNextRow(); ImGui.TableNextColumn();
                    DrawItemIcon(new ItemDefinition(0,duty.Name,false,duty.Icon),new Vector2(24));
                    var clicked = ImGui.IsItemClicked(); ImGui.SameLine();
                    if (ImGui.Selectable($"{duty.Name}##Duty{duty.DutyId}",dutyLoot.State.Duty?.DutyId == duty.DutyId,ImGuiSelectableFlags.None,new Vector2(0,24)) || clicked)
                    { dutyLoot.Select(duty); showDutyDetails = true; dutyItemQuery = ""; }
                    if (ImGui.IsItemHovered()) ImGui.SetTooltip($"Mission {duty.DutyId} · instance {duty.InstanceId} · territoire {duty.TerritoryId}");
                    ImGui.TableNextColumn(); ImGui.TextUnformatted(duty.Category);
                    ImGui.TableNextColumn(); ImGui.TextUnformatted(duty.Level.ToString(CultureInfo.InvariantCulture));
                }
            }
            finally { clipper.End(); clipper.Destroy(); }
        }
        finally { ImGui.EndTable(); }
    }

    private void DrawDutyLootDetails()
    {
        var state = dutyLoot.State;
        if (state.Duty is not { } duty) return;
        DrawItemIcon(new ItemDefinition(0,duty.Name,false,duty.Icon),new Vector2(32)); ImGui.SameLine();
        ImGui.TextColored(Accent,duty.Name);
        ImGui.TextDisabled($"{duty.Category} · niveau {duty.Level} · mission {duty.DutyId} / instance {duty.InstanceId}");
        if (state.Loading)
        { if (ImGui.Button("Annuler la consultation")) dutyLoot.Cancel(); ImGui.SameLine(); ImGui.TextDisabled("Lecture en cours…"); }
        else
        {
            if (ImGui.Button("Consulter le butin")) _ = dutyLoot.RequestAsync();
            if (state.Document is not null)
            { ImGui.SameLine(); if (ImGui.Button("Actualiser auprès de la source")) _ = dutyLoot.RequestAsync(true); }
        }
        if (state.Error is { } error) ImGui.TextWrapped(error);
        ImGui.TextWrapped("Source : Garland Tools. Données communautaires partielles, sans taux de drop ni garantie d'exhaustivité. Seul l'identifiant d'instance est envoyé lors d'une consultation.");
        if (state.Document is not { } document)
        { ImGui.TextDisabled("Cliquez sur Consulter le butin pour charger les données de ce contenu."); return; }
        ImGui.TextDisabled($"Récupéré le {document.FetchedAt:yyyy-MM-dd HH:mm:ss} UTC · date de mise à jour de la source inconnue");
        if (DateTimeOffset.UtcNow - document.FetchedAt >= DutyLootService.FreshFor)
            ImGui.TextColored(Accent,"Cache ancien : actualisez la source si nécessaire.");
        if (!document.HasRewards || !document.HasFights || !document.HasCoffers)
            ImGui.TextWrapped("Certaines catégories ne sont pas renseignées par la source. Une absence n'indique pas un contenu sans butin.");
        if (document.HasUnparsedFightDrops)
            ImGui.TextColored(Accent,"La source mentionne aussi des drops directs de combat, non interprétés dans cette version.");
        if (itemId > 0)
        {
            ImGui.TextDisabled($"En contexte : {SelectedItem?.Name ?? $"Objet {itemId}"}");
            if (ImGui.SmallButton("Stocks##Duty")) { page = Page.Items; focusStocksTab = true; }
            ImGui.SameLine(); if (ImGui.SmallButton("Recettes##Duty")) OpenContextTool("Craftimizer");
            ImGui.SameLine(); if (ImGui.SmallButton("Prix##Duty")) OpenContextTool("Price Insight");
        }
        ImGui.SetNextItemWidth(-1);
        ImGui.InputTextWithHint("##DutyItemSearch","Nom ou identifiant d'objet…",ref dutyItemQuery,128);
        var labels = new[] { "Tous", "Récompenses", "Coffres de combat", "Coffres de zone" };
        for (var index = 0; index < labels.Length; index++)
        {
            if (index > 0) ImGui.SameLine();
            if (ImGui.RadioButton(labels[index],dutySourceFilter == index)) dutySourceFilter = index;
        }
        var items = itemCatalog.State.Catalog;
        if (!ReferenceEquals(dutyViewDocument,document) || !ReferenceEquals(dutyViewItems,items)
            || dutyViewItemQuery != dutyItemQuery || dutyViewSourceFilter != dutySourceFilter)
        {
            var query = dutyItemQuery.Trim();
            dutyItemMatches = document.Entries.Where(entry => dutySourceFilter == 0 || (int)entry.Kind == dutySourceFilter-1)
                .GroupBy(entry => entry.ItemId).Select(group => (Id:group.Key,Name:items?.Find(group.Key)?.Name ?? $"Objet {group.Key}",Sources:group.ToArray()))
                .Where(item => query.Length == 0 || item.Name.Contains(query,StringComparison.CurrentCultureIgnoreCase)
                    || item.Id.ToString(CultureInfo.InvariantCulture) == query)
                .OrderBy(item => item.Name,StringComparer.CurrentCultureIgnoreCase).ThenBy(item => item.Id).ToArray();
            dutyViewDocument = document; dutyViewItems = items; dutyViewItemQuery = dutyItemQuery; dutyViewSourceFilter = dutySourceFilter;
        }
        ImGui.TextDisabled($"{dutyItemMatches.Length} objets renseignés pour ces filtres · cliquez pour sélectionner en contexte");
        if (dutyItemMatches.Length == 0) { ImGui.TextWrapped("Aucun objet renseigné pour ces filtres ; les données peuvent être incomplètes."); return; }
        if (!ImGui.BeginTable("DutyLootEntries",2,ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingStretchProp)) return;
        try
        {
            ImGui.TableSetupColumn("Objet",ImGuiTableColumnFlags.WidthStretch,3);
            ImGui.TableSetupColumn("Sources"); ImGui.TableHeadersRow();
            var clipper = ImGui.ImGuiListClipper();
            try
            {
                clipper.Begin(dutyItemMatches.Length);
                while (clipper.Step())
                for (var index = clipper.DisplayStart; index < clipper.DisplayEnd; index++)
                {
                    var item = dutyItemMatches[index];
                    var local = items?.Find(item.Id);
                    ImGui.TableNextRow(); ImGui.TableNextColumn();
                    DrawItemIcon(local,new Vector2(28)); var clicked = ImGui.IsItemClicked(); ImGui.SameLine();
                    var selectable = local is not null && item.Id <= int.MaxValue;
                    ImGui.BeginDisabled(!selectable);
                    try
                    {
                        if ((ImGui.Selectable($"{item.Name}##DutyLoot{item.Id}",itemId == item.Id,ImGuiSelectableFlags.None,new Vector2(0,28)) || clicked) && selectable)
                            SelectItem(item.Id);
                    }
                    finally { ImGui.EndDisabled(); }
                    if (ImGui.IsItemHovered(ImGuiHoveredFlags.AllowWhenDisabled)) ImGui.SetTooltip($"ID {item.Id}" + (selectable ? "" : "\nObjet absent du catalogue local ; référence conservée."));
                    ImGui.TableNextColumn();
                    ImGui.TextUnformatted(item.Sources.Length == 1 ? DutySourceLabel(item.Sources[0]) : $"{item.Sources.Length} sources");
                    if (ImGui.IsItemHovered())
                        ImGui.SetTooltip(string.Join('\n',item.Sources.Select(DutySourceLabel)));
                }
            }
            finally { clipper.End(); clipper.Destroy(); }
        }
        finally { ImGui.EndTable(); }
    }
    private static string DutySourceLabel(DutyLootEntry entry) => entry.Kind switch
    {
        DutyLootSourceKind.Reward => "Récompense renseignée",
        DutyLootSourceKind.FightCoffer => $"Combat {entry.SourceIndex+1}" + (string.IsNullOrWhiteSpace(entry.SourceName) ? "" : $" · {entry.SourceName}"),
        _ => $"Coffre de zone {entry.SourceIndex+1}"
    };
}
