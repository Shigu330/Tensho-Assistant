using Dalamud.Bindings.ImGui;
using TenshoAssistant.Gathering;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private long gatheringTimeSecond=-1;
    private readonly Dictionary<string,GatheringTimeline> gatheringTimeCache=[];
    private void DrawGatheringClock()
    {
        var now=DateTimeOffset.UtcNow;var minute=GatheringTime.MinuteOfDay(now);
        ImGui.TextColored(Accent,$"Heure d'Éorzéa calculée : {minute/60:00}:{minute%60:00} ET");
        ImGui.TextDisabled($"Horloge de l'ordinateur · {now:HH:mm:ss} UTC · une plage horaire ne certifie pas la présence du point");
    }
    private void DrawGatheringTime(GatheringSchedule schedule)
    {
        ImGui.TextWrapped(schedule.Label);
        if(schedule.Kind!=GatheringScheduleKind.Limited)return;
        var now=DateTimeOffset.UtcNow;var second=now.ToUnixTimeSeconds();
        if(second!=gatheringTimeSecond){gatheringTimeSecond=second;gatheringTimeCache.Clear();}
        if(!gatheringTimeCache.TryGetValue(schedule.Key,out var timeline) || timeline.Openings.FirstOrDefault() is { } cached && cached.EndsAt<=now)
        {timeline=GatheringTime.Next(schedule,now);gatheringTimeCache[schedule.Key]=timeline;}
        if(timeline.Openings.FirstOrDefault() is not { } first)return;
        var current=first.StartsAt<=now && now<first.EndsAt;
        ImGui.TextColored(current ? Success:Muted,current ? $"Plage horaire en cours · fin {first.EndsAt:HH:mm:ss} UTC":$"Prochaine plage : {first.StartsAt:dd/MM HH:mm:ss} UTC");
        if(ImGui.IsItemHovered())ImGui.SetTooltip(string.Join('\n',timeline.Openings.Select(window=>$"{window.StartsAt:dd/MM HH:mm:ss}–{window.EndsAt:dd/MM HH:mm:ss} UTC"))+"\nMétéo et prérequis non vérifiés ; pas de détection du point.");
    }
}
