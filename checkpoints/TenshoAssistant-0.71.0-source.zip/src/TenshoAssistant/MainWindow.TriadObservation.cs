using System.Numerics;
using System.Text;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.MiniGames;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private void DrawTriadObservation()
    {
        ImGui.TextColored(Accent,"Observation expérimentale du match · lecture seule");
        var state = triadObservation.State;
        DrawToolSettingsLink("TriadObservation");
        ImGui.TextWrapped("Faces et couleurs copiées de l'interface. Les identités des cartes, règles et joueur au trait ne sont pas établis par cette lecture. Aucun conseil automatique ni transfert au simulateur.");
        var status = state.Status switch
        {
            TriadObservationStatus.Disabled => "Observation désactivée.",
            TriadObservationStatus.Waiting => "En attente d'une lecture…",
            TriadObservationStatus.Offline => "Aucun personnage connecté.",
            TriadObservationStatus.AddonAbsent => "La fenêtre Triple Triade n'est pas ouverte.",
            TriadObservationStatus.NotReady => "La fenêtre est masquée ou pas encore prête.",
            TriadObservationStatus.Error => $"Lecture indisponible : {state.Error}",
            _ => "Observation disponible.",
        };
        ImGui.TextWrapped(status);
        if (state.Frame is not { } frame) return;
        if (state.CharacterId != bankBridge.State.CharacterId)
        { ImGui.TextDisabled("Changement de personnage : en attente d'une nouvelle observation."); return; }
        var phase = frame.NativePhase switch {0 => "attente",1 => "coup libre",2 => "coup contraint",_ => "phase non reconnue"};
        ImGui.TextDisabled($"Phase UI : {phase} · observation {state.ObservedAt:HH:mm:ss} UTC");
        if (ImGui.GetContentRegionAvail().X >= 620 && ImGui.BeginTable("ObservedTriadLayout",2,ImGuiTableFlags.SizingFixedFit))
        {
            try
            {
                ImGui.TableSetupColumn("Plateau",ImGuiTableColumnFlags.WidthFixed,260);
                ImGui.TableSetupColumn("Mains",ImGuiTableColumnFlags.WidthStretch);
                ImGui.TableNextRow(); ImGui.TableNextColumn();
                DrawObservedTriadGroup("Plateau observé",frame.Board,3);
                ImGui.TableNextColumn();
                DrawObservedTriadGroup("Main bleue observée",frame.BlueHand,5);
                DrawObservedTriadGroup("Main rouge observée",frame.RedHand,5);
            }
            finally { ImGui.EndTable(); }
        }
        else
        {
            DrawObservedTriadGroup("Plateau observé",frame.Board,3);
            DrawObservedTriadGroup("Main bleue observée",frame.BlueHand,5);
            DrawObservedTriadGroup("Main rouge observée",frame.RedHand,5);
        }
        ImGui.TextWrapped("Une carte masquée reste inconnue. Une lecture incomplète peut correspondre à une animation ou à un état non couvert. Les valeurs sont celles des champs UI ; leur interprétation base/effectives reste à confirmer en jeu.");
        if (ImGui.SmallButton("Copier l'observation"))
        {
            var text = new StringBuilder().AppendLine($"{frame.Source} · {state.ObservedAt:O} · phase UI {frame.NativePhase}");
            foreach (var group in new[] {("Plateau",frame.Board),("Bleu",frame.BlueHand),("Rouge",frame.RedHand)})
                for (var index=0;index<group.Item2.Count;index++) text.AppendLine($"{group.Item1} {index+1}: {ObservedTriadDescription(group.Item2[index])}");
            ImGui.SetClipboardText(text.ToString());
        }
    }
    private static void DrawObservedTriadGroup(string label,IReadOnlyList<TriadObservedCard> cards,int columns)
    {
        ImGui.TextColored(Accent,label);
        if (!ImGui.BeginTable(label,columns,ImGuiTableFlags.SizingFixedFit)) return;
        try
        {
            for (var column=0;column<columns;column++) ImGui.TableSetupColumn($"Slot{column}",ImGuiTableColumnFlags.WidthFixed,columns==3?76:54);
            for (var index=0;index<cards.Count;index++)
            {
                ImGui.TableNextColumn();
                var card=cards[index];
                var size=new Vector2(columns==3?68:48,72);
                var start=ImGui.GetCursorScreenPos();
                ImGui.Dummy(size);
                var color=card.Owner switch {TriadPlayer.Blue=>TriadBlue,TriadPlayer.Red=>TriadRed,_=>Muted};
                var draw=ImGui.GetWindowDrawList();
                draw.AddRectFilled(start,start+size,ImGui.GetColorU32(new Vector4(color.X*0.18f,color.Y*0.18f,color.Z*0.18f,0.95f)),4);
                draw.AddRect(start,start+size,ImGui.GetColorU32(color),4);
                void Center(string text,float y)
                    => draw.AddText(start+new Vector2(Math.Max(0,(size.X-ImGui.CalcTextSize(text).X)/2),y),ImGui.GetColorU32(color),text);
                if (card.Presence==TriadObservedPresence.Known)
                {
                    Center(TriadCardDefinition.Value(card.Top),5);
                    draw.AddText(start+new Vector2(5,25),ImGui.GetColorU32(color),TriadCardDefinition.Value(card.Left));
                    var right=TriadCardDefinition.Value(card.Right);
                    draw.AddText(start+new Vector2(size.X-5-ImGui.CalcTextSize(right).X,25),ImGui.GetColorU32(color),right);
                    Center(TriadCardDefinition.Value(card.Bottom),45);
                }
                else Center(card.Presence switch {TriadObservedPresence.Hidden=>"?",TriadObservedPresence.Empty=>"—",_=>"…"},25);
                if (ImGui.IsItemHovered()) ImGui.SetTooltip($"Emplacement {index+1}\n{ObservedTriadDescription(card)}");
            }
        }
        finally { ImGui.EndTable(); }
    }
    private static string ObservedTriadDescription(TriadObservedCard card)
    {
        var owner=card.Owner switch {TriadPlayer.Blue=>"bleu",TriadPlayer.Red=>"rouge",_=>"couleur inconnue"};
        return card.Presence switch
        {
            TriadObservedPresence.Empty=>"case vide",
            TriadObservedPresence.Hidden=>$"carte masquée · {owner}",
            TriadObservedPresence.Incomplete=>$"lecture incomplète · {owner}",
            _=>$"{owner} · {card.Stars} étoile(s) · famille UI {card.TypeId}\n↑{TriadCardDefinition.Value(card.Top)} →{TriadCardDefinition.Value(card.Right)} ↓{TriadCardDefinition.Value(card.Bottom)} ←{TriadCardDefinition.Value(card.Left)}",
        };
    }
}
