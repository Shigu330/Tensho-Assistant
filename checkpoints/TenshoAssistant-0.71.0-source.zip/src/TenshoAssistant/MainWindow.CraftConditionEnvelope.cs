using Dalamud.Bindings.ImGui;
using TenshoAssistant.Craft;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private CraftSimulationResult? conditionEnvelopeSource;
    private CraftConditionEnvelopeResult? conditionEnvelope;
    private string? conditionEnvelopeError;
    private int conditionEnvelopeTool;

    private void DrawCraftConditionEnvelope(CraftSimulationResult simulation)
    {
        if(!ImGui.CollapsingHeader("Variations de qualité · séquence fixe"))return;
        ImGui.TextWrapped("Cette séquence commence en condition Normale. L’enveloppe couvre les transitions ordinaires du modèle : Favorable et Mauvaise reviennent à Normale, Excellente impose Mauvaise. Les actions restent identiques. Aucune probabilité ou garantie HQ ; les recettes spéciales et les influences non modélisées restent exclues.");
        ImGui.SetNextItemWidth(330);
        if(ImGui.Combo("Bonus favorable · scénario manuel",ref conditionEnvelopeTool,"Deux facteurs du modèle (×1,50 à ×1,75)\0Standard (×1,50)\0Amélioré (×1,75)\0"))conditionEnvelopeSource=null;
        if(!ReferenceEquals(conditionEnvelopeSource,simulation))
        {
            conditionEnvelopeSource=simulation;conditionEnvelope=null;conditionEnvelopeError=null;
            try
            {
                conditionEnvelope=CraftConditionEnvelope.Evaluate(simulationRecipe!,simulation.Stats,simulation.StartingQuality,simulationActions,
                    conditionEnvelopeTool==0 ? null:conditionEnvelopeTool==1 ? 150:175);
            }
            catch(ArgumentException error){conditionEnvelopeError=error.Message;}
            catch(InvalidOperationException error){conditionEnvelopeError=error.Message;}
        }
        if(conditionEnvelopeError is { } errorText)ImGui.TextWrapped(errorText);
        if(conditionEnvelope is not { } result)return;
        ImGui.TextColored(Accent,$"Qualité finale dans le modèle : {result.Quality} · scénario toujours normal : {simulation.Final.Quality}");
        ImGui.TextWrapped("Progression, solidité et PS restent ceux de la simulation normale. Les bornes finales sont calculées sur des parcours cohérents de conditions ; les minima de chaque étape ne composent pas nécessairement un même parcours.");
        if(simulation.Final.Finish!=CraftFinish.Completed || simulation.Error is not null)ImGui.TextWrapped("Séquence incomplète ou invalide : l’enveloppe porte uniquement sur les actions effectivement simulées.");
        if(ImGui.TreeNode("Bornes par étape"))
        {
            try {foreach(var band in result.Steps)ImGui.TextUnformatted($"{band.Step}. qualité {band.Quality}");}
            finally {ImGui.TreePop();}
        }
    }
}
