# GOAL sélectionné

ID: UI-SETTINGS-001 — DONE côté code/tests
OBJECTIVE: Regrouper les réglages dans la section Réglages selon la demande utilisateur du 2026-10-29.
CURRENT_STATE: Livraison 0.71.0.0 compilée, 435/435 tests/package/SHA-256 passants, zéro avertissement/erreur. UI en jeu non observée.
REFERENCES: RULES.md ; Configuration.cs ; docs/UI-SETTINGS-001.md ; TESTING.md.
FILES: MainWindow.Settings.cs ; pages observation/mini-jeux/export/recherche ; manifest/csproj ; documents.
IN_SCOPE: Préférences communes, cinq activations d’observation, limites de recherche artisanat et export macro. Sections par domaine, raccourcis depuis les outils, liens vers les éditeurs des données persistantes.
OUT_OF_SCOPE: Déplacer les données d’un scénario métier dans les préférences globales, activer des observations au démarrage, modifier le format de configuration, lancer des actions en jeu. Les 17 domaines restent PARTIAL.
VALIDATION: Verify.ps1 final 435/435 ; compilation sans avertissement/erreur et package/API/versions/SHA-256/exclusion hôte verts. Contrôle des sites SetEnabled et paramètres déplacés ; valeurs bornées et invalidations conservées.
NEXT_ACTION: Demande ponctuelle terminée. L’objectif autonome antérieur reste en pause à la réserve de quota ; reprise préparée dans docs/QUEST-ITEM-PROGRESS-007-PLAN.md. Essais craft/Macro Chain toujours différés.
DEFINITION_OF_DONE: Réglages réunis, anciens contrôles remplacés par liens, livraison vérifiée/documentée et sauvegardée. Aucun fonctionnement en jeu déduit des tests.
