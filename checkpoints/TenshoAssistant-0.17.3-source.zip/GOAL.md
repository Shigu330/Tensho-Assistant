# GOAL sélectionné

ID: MACRO-001A
OBJECTIVE: Préparer des séquences explicites de macros et prouver la propriété/l'interruption avant un exécuteur natif ; voir docs/MACRO-001A.md.
CURRENT_STATE: CHECKPOINT QUOTA — moteur et observateur passif en 0.17.3, 110 tests/package validés ; exécuteur natif et interface de lancement non implémentés.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: Domaines Gathering, Inventory, Collections, Market, Quests, Character, MiniGames ; MainWindow.* ; Plugin.cs ; tests et documents.
IN_SCOPE: Séquence managée copiée, preuve des transitions natives, annulation/identité/ownership, interface puis tests ; aucune action implicite.
OUT_OF_SCOPE: Déclarer les 17 plugins remplacés ; prétendre une validation en jeu sans observation.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: 100 % hebdomadaires affichés et 69 % sur 5 h au dernier relevé ; limite de continuation demandée atteinte. État sauvegardé avant arrêt.
NEXT_ACTION: Après reprise/quota disponible, collecter une trace passive puis prouver les transitions natives, y compris macros très courtes et appels ignorés. Voir docs/MACRO-001A.md ; aucun succès déduit d'un timeout.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
