using Lumina;
using Lumina.Data;
using Lumina.Excel.Sheets;
using TenshoAssistant.Gathering;
using TenshoAssistant.Craft;
using TenshoAssistant.Inventory;
using TenshoAssistant.Maps;
using TenshoAssistant.Items;
using TenshoAssistant.Market;

if (args.Length != 1) throw new ArgumentException("Supply the installed game's sqpack directory.");
using var data = new GameData(args[0], new LuminaOptions { DefaultExcelLanguage = Language.French });
var points = data.Excel.GetSheet<GatheringPoint>();
var items = data.Excel.GetSheet<GatheringItem>();
var fishing = data.Excel.GetSheet<FishingSpot>();
var count = 0;
var fishingCount = 0;
var examples = new HashSet<uint>();
var managed = new List<GatheringSource>();
void Add(GatheringPoint point, uint id, bool hidden = false)
{
    if (point.GatheringPointBase.RowId == 0 || point.TerritoryType.RowId == 0) return;
    var basis = point.GatheringPointBase.Value;
    var type = basis.GatheringType.Value;
    var territory = point.TerritoryType.Value;
    managed.Add(new(id, point.RowId, basis.RowId, type.RowId, type.Name.ExtractText(),
        (uint)Math.Max(0, type.IconMain), basis.GatheringLevel, territory.RowId,
        territory.PlaceName.Value.Name.ExtractText(), point.PlaceName.Value.Name.ExtractText(), territory.Map.RowId, false, hidden));
}
var links = data.Excel.GetSubrowSheet<GatheringItemPoint>();
foreach (var item in items)
{
    if (item.Item.RowId == 0 || item.Item.RowType != typeof(Item)) continue;
    if (links.TryGetRow(item.RowId, out var nodeLinks))
        foreach (var link in nodeLinks)
            if (link.GatheringPoint.RowId != 0) Add(link.GatheringPoint.Value, item.Item.RowId, item.IsHidden);
}
foreach (var point in points)
{
    if (point.GatheringPointBase.RowId == 0 || point.TerritoryType.RowId == 0) continue;
    var basis = point.GatheringPointBase.Value;
    foreach (var reference in basis.Item)
    {
        if (reference.RowId == 0 || reference.RowType != typeof(GatheringItem)) continue;
        var item = items.GetRow(reference.RowId).Item;
        if (item.RowId == 0 || item.RowType != typeof(Item)) continue;
        count++;
        Add(point, item.RowId);
        if (item.RowId is 12893 or 12891 or 8 && examples.Add(item.RowId))
            Console.WriteLine($"Item {item.RowId}: {basis.GatheringType.Value.Name.ExtractText()} / {point.TerritoryType.Value.PlaceName.Value.Name.ExtractText()} / {point.PlaceName.Value.Name.ExtractText()}");
    }
}
foreach (var spot in fishing)
    if (spot.TerritoryType.RowId != 0)
    {
        fishingCount += spot.Item.Count(item => item.RowId != 0);
        foreach (var item in spot.Item)
            if (item.RowId != 0)
                managed.Add(new(item.RowId, spot.RowId, spot.RowId, 100, "Pêche", 62118, spot.GatheringLevel,
                    spot.TerritoryType.RowId, spot.TerritoryType.Value.PlaceName.Value.Name.ExtractText(),
                    spot.PlaceName.Value.Name.ExtractText(), spot.TerritoryType.Value.Map.RowId, true));
    }
var catalog = new GatheringCatalog(managed, "installed-game");
Console.WriteLine($"Deduplicated sources: {catalog.Count}");
var chestnut = catalog.ForItem(12893).FirstOrDefault() ?? throw new InvalidOperationException("Missing hidden chestnut source.");
Console.WriteLine($"Marron sombre: {chestnut.TypeName}, level {chestnut.Level}, {chestnut.Zone}, {chestnut.Place}, hidden={chestnut.IsHidden}");
Console.WriteLine($"Gathering links: {count}; fishing links: {fishingCount}; points: {points.Count}");
if (count == 0 || fishingCount == 0) throw new InvalidOperationException("Real data join produced an empty domain.");
var blue = data.Excel.GetSheet<AozAction>();
var blueDetails = data.Excel.GetSheet<AozActionTransient>();
foreach (var spell in blue.Where(row => row.RowId != 0 && row.Action.RowId != 0).Take(5))
{
    var details = blueDetails.GetRow(spell.RowId);
    Console.WriteLine($"Blue {spell.RowId}: {spell.Action.Value.Name.ExtractText()}, number={details.Number}, rank={spell.Rank}, location={details.Location.RowType?.Name}:{details.Location.RowId}");
}
Console.WriteLine($"Static catalog rows: mounts={data.Excel.GetSheet<Mount>().Count}, companions={data.Excel.GetSheet<Companion>().Count}, emotes={data.Excel.GetSheet<Emote>().Count}, quests={data.Excel.GetSheet<Quest>().Count}");
var recipeRows = new List<RecipeDefinition>();
foreach (var row in data.Excel.GetSheet<Recipe>())
{
    if (row.RowId == 0 || row.ItemResult.RowId == 0 || row.AmountResult == 0) continue;
    var ingredients = new List<RecipeIngredient>();
    for (var index = 0; index < row.Ingredient.Count; index++)
        if (row.Ingredient[index].RowId != 0 && row.AmountIngredient[index] > 0)
            ingredients.Add(new(row.Ingredient[index].RowId, row.AmountIngredient[index]));
    recipeRows.Add(new(row.RowId, row.ItemResult.RowId, row.AmountResult, row.CraftType.Value.Name.ExtractText(),
        row.RecipeLevelTable.Value.ClassJobLevel, ingredients, row.CraftType.RowId));
}
var recipes = RecipeCatalog.Build(recipeRows, "installed-game");
var itemSheet = data.Excel.GetSheet<Item>();
foreach (var recipe in recipes.ForResult(12892))
{
    var plan = CraftChain.Build(recipe, 7, recipes, _ => new([], 0, 0, false, true, false, false));
    Console.WriteLine($"Real craft chain {itemSheet.GetRow(recipe.ResultItemId).Name.ExtractText()}: {plan.Requested} requested, {plan.Produced} produced, {plan.Steps.Count} steps, unresolved={plan.HasUnresolved}");
    foreach (var material in plan.Materials)
        Console.WriteLine($"  {itemSheet.GetRow(material.ItemId).Name.ExtractText()}: {material.Amount}, {material.Reason}");
    if (plan.Produced != 9 || plan.Materials.Single(material => material.ItemId == 12891).Amount != 9)
        throw new InvalidOperationException("Real birch syrup yield or ingredient join does not match expected quantities.");
}
if (recipes.ForResult(12892).Count == 0) throw new InvalidOperationException("Real birch syrup recipe missing.");
var maps = new MapCatalog(data.Excel.GetSheet<Map>().Where(row => row.RowId != 0 && row.TerritoryType.RowId != 0)
    .Select(row => new MapDefinition(row.RowId, row.TerritoryType.RowId, row.PlaceNameRegion.Value.Name.ExtractText(),
        row.PlaceName.Value.Name.ExtractText(), row.PlaceNameSub.Value.Name.ExtractText(), row.MapIndex, row.SizeFactor)));
var sampleSource = catalog.ForItem(8).First(source => source.MapId != 0);
var sampleMap = maps.Find(sampleSource.MapId) ?? throw new InvalidOperationException("Gathering source references a missing map.");
if (sampleMap.TerritoryId != sampleSource.TerritoryId) throw new InvalidOperationException("Map and gathering territory mismatch.");
Console.WriteLine($"Native map catalog: {maps.Entries.Count} maps; sample {sampleMap.Zone}, map={sampleMap.MapId}, territory={sampleMap.TerritoryId}");
var hoverExamples = new uint[] { 12892, 4551, 1 }.Select(id => itemSheet.GetRow(id)).Select(row =>
    new ItemDefinition(row.RowId, row.Name.ExtractText(), row.CanBeHq, row.Icon,
        row.ItemUICategory.RowId, row.ItemUICategory.Value.Name.ExtractText(), !row.IsUntradable && row.ItemSearchCategory.RowId != 0)).ToArray();
var hoverCatalog = ItemCatalog.Build(hoverExamples, new("installed-game", "French", "local-probe", 1));
foreach (var example in hoverExamples)
    Console.WriteLine($"Hover eligibility {example.Id} {example.Name}: marketable={example.IsMarketable}, HQ={example.CanBeHq}");
if (MarketHoverTracker.Normalize(1012892, hoverCatalog) != new MarketHoverItem(12892, true)
    || MarketHoverTracker.Normalize(1, hoverCatalog) is not null || MarketHoverTracker.Normalize(2012892, hoverCatalog) is not null)
    throw new InvalidOperationException("Native market eligibility or HQ normalization did not match the copied game data.");
