using System.Collections.Frozen;
using System.Globalization;
using System.Text;

namespace TenshoAssistant.Items;

public sealed record ItemDefinition(uint Id, string Name, bool CanBeHq, uint IconId = 0,
    uint UiCategoryId = 0, string UiCategoryName = "", bool IsMarketable = false);
public sealed record ItemCatalogMetadata(string Source, string Language, string DataVersion, int Generation);

/// <summary>One immutable index shared by all item consumers; no Lumina row survives here.</summary>
public sealed class ItemCatalog
{
    private readonly FrozenDictionary<uint, ItemDefinition> byId;
    private readonly (ItemDefinition Item, string SearchName)[] searchable;
    public ItemCatalogMetadata Metadata { get; }
    public int Count => byId.Count;

    private ItemCatalog(ItemCatalogMetadata metadata, Dictionary<uint, ItemDefinition> items,
        (ItemDefinition Item, string SearchName)[] searchable)
    {
        Metadata = metadata;
        byId = items.ToFrozenDictionary();
        this.searchable = searchable;
    }

    public static ItemCatalog Build(IEnumerable<ItemDefinition> source, ItemCatalogMetadata metadata,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(source);
        ArgumentNullException.ThrowIfNull(metadata);
        var items = new Dictionary<uint, ItemDefinition>();
        var names = new List<(ItemDefinition Item, string SearchName)>();
        foreach (var item in source)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (item.Id == 0 || string.IsNullOrWhiteSpace(item.Name)) continue;
            if (!items.TryAdd(item.Id, item)) throw new ArgumentException("Duplicate item ID.", nameof(source));
            names.Add((item, Normalize(item.Name)));
        }
        cancellationToken.ThrowIfCancellationRequested();
        var sorted = names.OrderBy(entry => entry.SearchName, StringComparer.Ordinal)
            .ThenBy(entry => entry.Item.Id).ToArray();
        cancellationToken.ThrowIfCancellationRequested();
        return new ItemCatalog(metadata, items, sorted);
    }

    public ItemDefinition? Find(uint id) => byId.GetValueOrDefault(id);

    public IReadOnlyList<ItemDefinition> Search(string query, int limit = 30)
    {
        ArgumentNullException.ThrowIfNull(query);
        if (limit is < 1 or > 100) throw new ArgumentOutOfRangeException(nameof(limit));
        if (query.Length > 128 || string.IsNullOrWhiteSpace(query)) return [];
        var trimmed = query.Trim();
        if (uint.TryParse(trimmed, NumberStyles.None, CultureInfo.InvariantCulture, out var id))
            return Find(id) is { } item ? Array.AsReadOnly(new[] { item }) : [];

        var tokens = Normalize(trimmed).Split(' ', StringSplitOptions.RemoveEmptyEntries);
        if (tokens.Length == 0) return [];
        var results = new List<ItemDefinition>(limit);
        foreach (var entry in searchable)
        {
            if (!MatchesAll(entry.SearchName, tokens)) continue;
            results.Add(entry.Item);
            if (results.Count == limit) break;
        }
        return results.AsReadOnly();
    }

    private static bool MatchesAll(string name, string[] tokens)
    {
        foreach (var token in tokens)
            if (!name.Contains(token, StringComparison.Ordinal)) return false;
        return true;
    }

    private static string Normalize(string value)
    {
        var text = new StringBuilder(value.Length);
        foreach (var character in value.Normalize(NormalizationForm.FormD))
        {
            if (CharUnicodeInfo.GetUnicodeCategory(character) == UnicodeCategory.NonSpacingMark) continue;
            text.Append(char.IsWhiteSpace(character) ? ' ' : char.ToUpperInvariant(character));
        }
        return text.ToString();
    }
}
