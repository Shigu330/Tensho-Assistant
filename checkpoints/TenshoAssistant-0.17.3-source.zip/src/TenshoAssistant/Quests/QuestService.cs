namespace TenshoAssistant.Quests;

public enum QuestProgress { Unconfirmed, Active, Complete }
public sealed record QuestEntry(uint Id, string Name, string Category, uint Icon, QuestProgress Progress, byte? Sequence);
public sealed record QuestState(ulong CharacterId, DateTimeOffset? ObservedAt, IReadOnlyList<QuestEntry> Entries, bool Loading, string? Error);

public sealed class QuestService
{
    private QuestState state = new(0, null, Array.Empty<QuestEntry>(), true, null);
    private int refresh;
    public QuestState State => Volatile.Read(ref state);
    public void RequestRefresh() => Interlocked.Exchange(ref refresh, 1);
    internal bool ConsumeRefresh() => Interlocked.Exchange(ref refresh, 0) == 1;
    internal void Publish(ulong character, IEnumerable<QuestEntry> entries) => Interlocked.Exchange(ref state,
        new(character, character == 0 ? null : DateTimeOffset.UtcNow,
            Array.AsReadOnly(entries.Select(entry => character == 0 ? entry with { Progress = QuestProgress.Unconfirmed, Sequence = null } : entry)
                .OrderBy(entry => entry.Name, StringComparer.OrdinalIgnoreCase).ThenBy(entry => entry.Id).ToArray()), false, null));
    internal void Invalidate() => Interlocked.Exchange(ref state,
        new(0, null, Array.AsReadOnly(State.Entries.Select(entry => entry with { Progress = QuestProgress.Unconfirmed, Sequence = null }).ToArray()), true, null));
    internal void Fail(Exception error) { Invalidate(); Interlocked.Exchange(ref state, State with { Loading = false, Error = error.Message }); }
    internal void Clear() => Interlocked.Exchange(ref state, new(0, null, Array.Empty<QuestEntry>(), false, null));
}
