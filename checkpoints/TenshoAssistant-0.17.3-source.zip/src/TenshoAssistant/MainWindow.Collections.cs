using System.Numerics;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.Collections;
using TenshoAssistant.Items;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private CollectionState? collectionViewState;
    private CollectionKind collectionViewKind;
    private string collectionViewQuery = "";
    private int collectionViewFilter = -1;
    private CollectionEntry[] collectionViewEntries = [];
    private CollectionEntry[] collectionViewMatches = [];
    private void DrawCollections(bool blueMagic = false)
    {
        Heading(blueMagic ? "Grimoire Mage bleu" : "Collections", blueMagic
            ? "Sorts du catalogue natif · cliquez sur un sort pour ouvrir sa fiche"
            : "Montures, mascottes et emotes du catalogue du jeu, avec acquisitions confirmées pour le personnage.");
        var state = collections.State;
        if (ImGui.Button("Actualiser les acquisitions")) collections.RequestRefresh();
        ImGui.SameLine();
        ImGui.TextDisabled(state.Loading ? "Lecture en cours…" : state.ObservedAt is { } date ? $"Observation : {date:HH:mm:ss} UTC" : "Aucun personnage observé");
        if (state.Error is { } error) ImGui.TextWrapped(error);
        if (!blueMagic && ImGui.BeginTabBar("CollectionKinds"))
        {
            try
            {
                if (ImGui.BeginTabItem("Montures")) { collectionKind = CollectionKind.Mount; ImGui.EndTabItem(); }
                if (ImGui.BeginTabItem("Mascottes")) { collectionKind = CollectionKind.Companion; ImGui.EndTabItem(); }
                if (ImGui.BeginTabItem("Emotes")) { collectionKind = CollectionKind.Emote; ImGui.EndTabItem(); }
            }
            finally { ImGui.EndTabBar(); }
        }
        ImGui.SetNextItemWidth(-1);
        ImGui.InputTextWithHint("##CollectionSearch", "Rechercher par nom…", ref collectionQuery, 128);
        var filters = new[] { "Tous", "Acquis confirmés", "Non confirmés" };
        for (var index = 0; index < filters.Length; index++)
        {
            if (index > 0) ImGui.SameLine();
            if (ImGui.RadioButton(filters[index], collectionFilter == index)) collectionFilter = index;
        }
        var kind = blueMagic ? CollectionKind.BlueMagic : collectionKind;
        if (!ReferenceEquals(collectionViewState, state) || collectionViewKind != kind
            || collectionViewFilter != collectionFilter || collectionViewQuery != collectionQuery)
        {
            collectionViewState = state; collectionViewKind = kind;
            collectionViewFilter = collectionFilter; collectionViewQuery = collectionQuery;
            collectionViewEntries = state.Entries.Where(entry => entry.Kind == kind)
                .OrderBy(entry => blueMagic ? entry.Number : 0).ThenBy(entry => entry.Name, StringComparer.OrdinalIgnoreCase).ToArray();
            collectionViewMatches = collectionViewEntries.Where(entry => (collectionFilter == 0 || (collectionFilter == 1 ? entry.ConfirmedUnlocked : !entry.ConfirmedUnlocked))
                && (string.IsNullOrWhiteSpace(collectionQuery) || entry.Name.Contains(collectionQuery.Trim(), StringComparison.OrdinalIgnoreCase))).ToArray();
        }
        var entries = collectionViewEntries;
        ImGui.TextColored(Accent, $"{entries.Count(entry => entry.ConfirmedUnlocked):N0} acquisitions confirmées · {entries.Length:N0} entrées du catalogue");
        ImGui.TextWrapped("Non confirmé ne signifie pas manquant. Le catalogue peut inclure des entrées indisponibles ; les prérequis et sources d'obtention ne sont pas encore couverts.");
        if (state.CharacterId == 0) ImGui.TextDisabled("Connectez un personnage pour lire ses acquisitions.");
        var openDetails = false;
        var visibleEntries = collectionViewMatches;
        if (!ImGui.BeginTable("CollectionEntries", 2, ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingStretchProp)) return;
        try
        {
            ImGui.TableSetupColumn("Collection", ImGuiTableColumnFlags.WidthStretch, 3);
            ImGui.TableSetupColumn("État", ImGuiTableColumnFlags.WidthStretch, 1);
            ImGui.TableHeadersRow();
            var clipper = ImGui.ImGuiListClipper();
            try
            {
            clipper.Begin(visibleEntries.Length);
            while (clipper.Step())
            for (var index = clipper.DisplayStart; index < clipper.DisplayEnd; index++)
            {
                var entry = visibleEntries[index];
                ImGui.TableNextRow();
                ImGui.TableNextColumn();
                DrawItemIcon(new ItemDefinition(0, entry.Name, false, entry.IconId), new Vector2(32));
                ImGui.SameLine();
                if (blueMagic)
                {
                    if (ImGui.Selectable($"{entry.Number} · {entry.Name}##{entry.Id}"))
                    { selectedBlueSpell = entry.Id; openDetails = true; }
                }
                else ImGui.TextUnformatted(entry.Name);
                if (ImGui.IsItemHovered()) ImGui.SetTooltip($"{entry.Name}\nIdentifiant {entry.Kind} : {entry.Id}");
                ImGui.TableNextColumn();
                ImGui.TextColored(entry.ConfirmedUnlocked ? Success : Muted, entry.ConfirmedUnlocked ? "Acquis confirmé" : "Non confirmé");
            }
            }
            finally { clipper.End(); clipper.Destroy(); }
        }
        finally { ImGui.EndTable(); }
        if (openDetails) ImGui.OpenPopup("Fiche de sort Mage bleu");
        ImGui.SetNextWindowSize(new Vector2(520, 0), ImGuiCond.Appearing);
        var popupOpen = true;
        if (ImGui.BeginPopupModal("Fiche de sort Mage bleu", ref popupOpen, ImGuiWindowFlags.AlwaysAutoResize))
        {
            try
            {
                var spell = state.Entries.FirstOrDefault(entry => entry.Kind == CollectionKind.BlueMagic && entry.Id == selectedBlueSpell);
                if (spell is not null)
                {
                    DrawItemIcon(new ItemDefinition(0, spell.Name, false, spell.IconId), new Vector2(40));
                    ImGui.SameLine(); ImGui.TextColored(Accent, $"{spell.Number} · {spell.Name}");
                    ImGui.TextUnformatted($"Rang : {spell.Rank}");
                    ImGui.TextWrapped(spell.Description);
                    ImGui.TextWrapped(string.IsNullOrWhiteSpace(spell.Location) ? "Lieu d'apprentissage non renseigné dans les données couvertes." : $"Lieu indiqué : {spell.Location}");
                    ImGui.TextColored(spell.ConfirmedUnlocked ? Success : Muted, spell.ConfirmedUnlocked ? "Appris confirmé" : "Acquisition non confirmée");
                    if (ImGui.Button("Copier le nom du sort")) ImGui.SetClipboardText(spell.Name);
                }
                if (ImGui.Button("Fermer")) ImGui.CloseCurrentPopup();
            }
            finally { ImGui.EndPopup(); }
        }
    }
}
