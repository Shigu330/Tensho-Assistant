using System.Numerics;
using System.Text;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.Craft;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private readonly CraftChainSession craftChain = new();
    private readonly Dictionary<uint, uint> craftChainChoices = [];
    private int craftChainChoiceRevision;

    private void DrawCraftChain(RecipeDefinition recipe)
    {
        if (recipeCatalog.State.Catalog is not { } catalog) return;
        var character = bankBridge.State.CharacterId;
        craftChain.ValidateContext(character, (uint)Math.Max(0, itemId), craftPlanTarget, catalog);
        var state = craftChain.State;
        if (ImGui.Button("Calculer la chaîne des sous-recettes"))
            _ = craftChain.StartAsync(new(character, (uint)Math.Max(0, itemId), recipe, craftPlanTarget, catalog, inventory.Current, bank.State,
                craftChainChoices, craftChainChoiceRevision));
        if (craftChainChoices.Count > 0)
        {
            ImGui.SameLine();
            if (ImGui.SmallButton("Réinitialiser les choix"))
            { craftChainChoices.Clear(); craftChainChoiceRevision++; craftChain.Cancel(); return; }
        }
        if (state.Input?.Recipe.RecipeId != recipe.RecipeId) return;
        ImGui.SameLine();
        if (ImGui.SmallButton("Effacer le calcul")) { craftChain.Cancel(); return; }
        if (state.Loading) { ImGui.TextDisabled("Calcul des sous-recettes en cours…"); return; }
        if (state.Error is { } error) ImGui.TextWrapped(error);
        if (state.Result is not { } result) return;
        var stale = !ReferenceEquals(state.Input.Live, inventory.Current) || !ReferenceEquals(state.Input.Bank, bank.State);
        ImGui.TextDisabled($"Calcul : {state.CalculatedAt:HH:mm:ss} UTC · cible {result.Requested:N0} · produit {result.Produced:N0}");
        if (stale) ImGui.TextColored(Accent, "Observations renouvelées : recalculez pour utiliser les stocks actuels.");
        if (state.Input.ChoiceRevision != craftChainChoiceRevision)
            ImGui.TextColored(Accent, "Choix de recettes modifiés : relancez le calcul de la chaîne.");
        if (result.HasUnknown) ImGui.TextWrapped("Stocks incomplets : les quantités à compléter sont une proposition basée sur les seules observations disponibles.");
        if (result.HasCached) ImGui.TextDisabled("Des imports manuels sont utilisés : actualisez-les après un transfert.");
        if (result.HasUnresolved) ImGui.TextColored(Accent, "Chaîne partielle : certaines branches demandent un choix ou une vérification.");
        ImGui.TextWrapped("Les sous-recettes univoques ou choisies sont développées. Déblocages, niveau, qualité et réussite de fabrication ne sont pas garantis.");
        if (ImGui.CollapsingHeader($"Étapes de fabrication ({result.Steps.Count})##ChainSteps"))
        {
            DrawChainList("ChainStepsList", result.Steps.Count, index =>
            {
                var step = result.Steps[index];
                ImGui.PushID($"ChainStep{index}");
                try
                {
                    DrawChainItem(step.Recipe.ResultItemId);
                    ImGui.SameLine();
                    ImGui.TextDisabled($"{step.Crafts:N0} craft(s) → {step.Produced:N0} · {step.Recipe.CraftType} niv. {step.Recipe.Level}");
                }
                finally { ImGui.PopID(); }
            });
        }
        if (ImGui.CollapsingHeader($"Matières à compléter ({result.Materials.Count})##ChainMaterials", ImGuiTreeNodeFlags.DefaultOpen))
        {
            if (result.Materials.Count == 0) ImGui.TextColored(Success, "Les besoins sont couverts par les stocks recensés.");
            DrawChainList("ChainMaterialsList", result.Materials.Count, index =>
            {
                var material = result.Materials[index];
                ImGui.PushID($"ChainMaterial{material.ItemId}/{material.Reason}");
                try
                {
                    DrawChainItem(material.ItemId);
                    ImGui.SameLine(); ImGui.TextColored(material.Reason == CraftChainReason.RawMaterial ? Muted : Accent,
                        $"× {material.Amount:N0} · {ChainReason(material.Reason)}");
                    ImGui.SameLine();
                    if (ImGui.SmallButton("Lieux")) OpenGathering(material.ItemId);
                    ImGui.SameLine();
                    if (ImGui.SmallButton("Prix")) { SelectItem(material.ItemId); OpenContextTool("Price Insight"); }

                }
                finally { ImGui.PopID(); }
            });
        }

        var choices = result.Materials.Where(material => material.Reason == CraftChainReason.RecipeChoice).ToArray();
        if (choices.Length > 0 && ImGui.CollapsingHeader("Choisir les sous-recettes##ChainChoices", ImGuiTreeNodeFlags.DefaultOpen))
        {
            DrawChainList("ChainChoicesList", choices.Length, index =>
            {
                var material = choices[index];
                ImGui.PushID($"RecipeChoice{material.ItemId}");
                try
                {
                    ImGui.TextUnformatted(itemCatalog.State.Catalog?.Find(material.ItemId)?.Name ?? $"ID {material.ItemId}");
                    var variants = catalog.ForResult(material.ItemId);
                    var chosen = craftChainChoices.TryGetValue(material.ItemId, out var selected)
                        ? variants.FirstOrDefault(variant => variant.RecipeId == selected) : null;
                    ImGui.SetNextItemWidth(-1);
                    if (ImGui.BeginCombo("##ChainRecipeChoice", chosen is null ? "Choisir une sous-recette…" : ChainVariant(chosen)))
                    {
                        try
                        {
                            foreach (var variant in variants)
                                if (ImGui.Selectable(ChainVariant(variant), variant.RecipeId == chosen?.RecipeId))
                                { craftChainChoices[material.ItemId] = variant.RecipeId; craftChainChoiceRevision++; }
                        }
                        finally { ImGui.EndCombo(); }
                    }
                }
                finally { ImGui.PopID(); }
            });
        }
        if (ImGui.Button("Copier la chaîne et les besoins"))
        {
            string Name(uint id) => itemCatalog.State.Catalog?.Find(id)?.Name ?? $"ID {id}";
            var text = new StringBuilder($"{Name(recipe.ResultItemId)} : {result.Requested} à produire, {result.Produced} produits\nCalcul UTC : {state.CalculatedAt:O}\n");
            if (stale || result.HasUnknown || result.HasCached) text.AppendLine("Stocks à revérifier ; ce calcul conserve les observations de son lancement.");
            if (state.Input.ChoiceRevision != craftChainChoiceRevision) text.AppendLine("Choix de recettes modifiés après ce calcul ; recalcul nécessaire.");
            if (result.HasUnresolved) text.AppendLine("Chaîne partielle : branches à résoudre manuellement.");
            foreach (var step in result.Steps) text.AppendLine($"{step.Crafts} craft(s) : {Name(step.Recipe.ResultItemId)} × {step.Produced} ({step.Recipe.CraftType})");
            text.AppendLine("À compléter :");
            foreach (var material in result.Materials) text.AppendLine($"{Name(material.ItemId)} × {material.Amount} — {ChainReason(material.Reason)}");
            ImGui.SetClipboardText(text.ToString());
        }
    }

    private void DrawChainItem(uint id)
    {
        var item = itemCatalog.State.Catalog?.Find(id);
        DrawItemIcon(item, new Vector2(24));
        var clicked = ImGui.IsItemClicked();
        ImGui.SameLine();
        if (ImGui.SmallButton(item?.Name ?? $"ID {id}") || clicked) SelectItem(id);
    }
    private static void DrawChainList(string id, int count, Action<int> drawRow)
    {
        if (count == 0) return;
        var rowHeight = 24 + ImGui.GetStyle().ItemSpacing.Y;
        var visible = ImGui.BeginChild(id, new Vector2(0, Math.Clamp(count * rowHeight + 8, 40, 260)), true);
        try
        {
            if (!visible) return;
            var clipper = ImGui.ImGuiListClipper();
            try
            {
                clipper.Begin(count);
                while (clipper.Step())
                    for (var index = clipper.DisplayStart; index < clipper.DisplayEnd; index++) drawRow(index);
            }
            finally { clipper.End(); clipper.Destroy(); }
        }
        finally { ImGui.EndChild(); }
    }
    private static string ChainReason(CraftChainReason reason) => reason switch
    {
        CraftChainReason.RawMaterial => "à obtenir",
        CraftChainReason.RecipeChoice => "plusieurs recettes : choisir manuellement",
        CraftChainReason.Cycle => "cycle : vérifier la branche",
        CraftChainReason.DepthLimit => "profondeur limite : vérifier la branche",
        _ => "ingrédients non renseignés",
    };
    private static string ChainVariant(RecipeDefinition recipe) => $"{recipe.CraftType} · niv. {recipe.Level} · rendement {recipe.ResultAmount} · recette {recipe.RecipeId}";
}
