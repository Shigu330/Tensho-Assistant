using Dalamud.Bindings.ImGui;
using TenshoAssistant.Quests;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private QuestState? questViewState;
    private string questViewQuery = "";
    private string questViewCategory = "";
    private int questViewFilter = -1;
    private string[] questCategories = [];
    private QuestEntry[] questMatches = [];
    private int questActiveCount;
    private int questCompleteCount;

    private void DrawQuests()
    {
        Heading("Suivi des quêtes", "Catalogue et progression observée du personnage courant");
        var state = quests.State;
        if (!ReferenceEquals(questViewState, state))
        {
            questCategories = state.Entries.Select(entry => entry.Category).Where(name => !string.IsNullOrWhiteSpace(name))
                .Distinct(StringComparer.Ordinal).OrderBy(name => name, StringComparer.Ordinal).ToArray();
            questActiveCount = state.Entries.Count(entry => entry.Progress == QuestProgress.Active);
            questCompleteCount = state.Entries.Count(entry => entry.Progress == QuestProgress.Complete);
        }
        if (ImGui.Button("Actualiser les quêtes")) quests.RequestRefresh();
        ImGui.SameLine();
        ImGui.TextDisabled(state.Loading ? "Lecture en cours…" : state.ObservedAt is { } date ? $"Observation : {date:HH:mm:ss} UTC" : "Personnage non observé");
        if (state.Error is { } error) ImGui.TextWrapped(error);
        ImGui.SetNextItemWidth(-1);
        ImGui.InputTextWithHint("##QuestSearch", "Rechercher une quête…", ref questQuery, 128);
        ImGui.SetNextItemWidth(260);
        if (ImGui.BeginCombo("Catégorie", string.IsNullOrWhiteSpace(questCategory) ? "Toutes" : questCategory))
        {
            try
            {
                if (ImGui.Selectable("Toutes", string.IsNullOrWhiteSpace(questCategory))) questCategory = string.Empty;
                foreach (var category in questCategories)
                    if (ImGui.Selectable(category, questCategory == category)) questCategory = category;
            }
            finally { ImGui.EndCombo(); }
        }
        var labels = new[] { "Toutes", "En cours", "Terminées", "Non confirmées" };
        for (var index = 0; index < labels.Length; index++)
        {
            if (index > 0) ImGui.SameLine();
            if (ImGui.RadioButton(labels[index], questFilter == index)) questFilter = index;
        }
        ImGui.TextDisabled($"{questActiveCount} en cours · {questCompleteCount:N0} terminées confirmées");
        ImGui.TextWrapped("Non confirmée ne signifie pas disponible. Prérequis, objectifs détaillés et quêtes répétables nécessitent des vérifications supplémentaires.");
        if (!ReferenceEquals(questViewState, state) || questViewQuery != questQuery
            || questViewCategory != questCategory || questViewFilter != questFilter)
        {
            questMatches = state.Entries.Where(entry => (string.IsNullOrWhiteSpace(questCategory) || entry.Category == questCategory)
                && (questFilter == 0 || entry.Progress == (questFilter == 1 ? QuestProgress.Active : questFilter == 2 ? QuestProgress.Complete : QuestProgress.Unconfirmed))
                && (string.IsNullOrWhiteSpace(questQuery) || entry.Name.Contains(questQuery.Trim(), StringComparison.OrdinalIgnoreCase))).ToArray();
            questViewState = state; questViewQuery = questQuery;
            questViewCategory = questCategory; questViewFilter = questFilter;
        }
        var matches = questMatches;
        if (matches.Length == 0) { ImGui.TextDisabled("Aucune quête observée correspondant à ces filtres."); return; }
        if (!ImGui.BeginTable("QuestEntries", 3, ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingStretchProp)) return;
        try
        {
            ImGui.TableSetupColumn("Quête", ImGuiTableColumnFlags.WidthStretch, 2);
            ImGui.TableSetupColumn("Catégorie");
            ImGui.TableSetupColumn("Progression");
            ImGui.TableHeadersRow();
            var clipper = ImGui.ImGuiListClipper();
            try
            {
            clipper.Begin(matches.Length);
            while (clipper.Step())
            for (var index = clipper.DisplayStart; index < clipper.DisplayEnd; index++)
            {
                var entry = matches[index];
                ImGui.TableNextRow(); ImGui.TableNextColumn(); ImGui.TextUnformatted(entry.Name);
                if (ImGui.IsItemHovered()) ImGui.SetTooltip($"{entry.Name}\n{entry.Category}\nID quête : {entry.Id}");
                ImGui.TableNextColumn(); ImGui.TextUnformatted(entry.Category);
                ImGui.TableNextColumn();
                ImGui.TextColored(entry.Progress == QuestProgress.Complete ? Success : Muted,
                    entry.Progress switch { QuestProgress.Active => $"En cours · séquence {entry.Sequence}", QuestProgress.Complete => "Terminée confirmée", _ => "Non confirmée" });
            }
            }
            finally { clipper.End(); clipper.Destroy(); }
        }
        finally { ImGui.EndTable(); }
    }
}
