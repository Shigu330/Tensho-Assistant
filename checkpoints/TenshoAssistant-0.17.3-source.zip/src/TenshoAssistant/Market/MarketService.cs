using System.Diagnostics;
using System.Net.Http;

namespace TenshoAssistant.Market;

public sealed record MarketState(uint WorldId, string WorldName, uint ItemId, MarketQuote? Quote, bool Loading, string? Error);
public sealed record MarketBackgroundState(uint WorldId, uint ItemId, bool Loading, string? Error, DateTimeOffset? RetryAt = null);

public sealed class MarketService : IDisposable
{
    private readonly object gate = new();
    private readonly HttpClient client;
    private readonly bool ownsClient;
    private readonly Dictionary<(uint World, uint Item), MarketQuote> cache = [];
    private CancellationTokenSource? request;
    private MarketState state = new(0, "", 0, null, false, null);
    private ulong owner;
    private int generation;
    private bool disposed;
    private long? lastRequest;
    private bool requestActive;
    private bool activeBackground;
    private MarketBackgroundState? backgroundState;
    public MarketBackgroundState? BackgroundState => Volatile.Read(ref backgroundState);
    public MarketState State => Volatile.Read(ref state);

    public MarketService(HttpClient? client = null)
    {
        ownsClient = client is null;
        this.client = client ?? new HttpClient { Timeout = TimeSpan.FromSeconds(12), MaxResponseContentBufferSize = 1048576 };
        this.client.DefaultRequestHeaders.UserAgent.ParseAdd($"TenshoAssistant/{typeof(MarketService).Assembly.GetName().Version?.ToString(3) ?? "1.0.0"}");
    }
    public void SetWorld(ulong character, uint worldId, string worldName)
    {
        lock (gate)
        {
            if (disposed || (owner == character && state.WorldId == worldId)) return;
            owner = character;
            generation++;
            request?.Cancel();
            requestActive = false; backgroundState = null;
            state = new(character == 0 ? 0 : worldId, character == 0 ? "" : worldName, 0, null, false, null);
        }
    }
    public MarketQuote? GetCached(uint worldId, uint itemId)
    { lock (gate) { return disposed ? null : cache.GetValueOrDefault((worldId, itemId)); } }
    public void CancelBackground()
    {
        lock (gate)
        {
            if (disposed) return;
            backgroundState = null;
            if (!requestActive || !activeBackground) return;
            generation++; request?.Cancel(); requestActive = false;
        }
    }
    public async Task RequestAsync(uint itemId, bool force = false, bool background = false)
    {
        uint world;
        int ticket;
        CancellationToken token;
        lock (gate)
        {
            if (disposed || itemId == 0 || state.WorldId == 0) return;
            if (requestActive)
            {
                if (background || !activeBackground) return;
                generation++; request?.Cancel(); requestActive = false; backgroundState = null;
            }
            world = state.WorldId;
            if (!force && cache.TryGetValue((world, itemId), out var quote) && DateTimeOffset.UtcNow - quote.FetchedAt < TimeSpan.FromMinutes(5))
            {
                if (background) backgroundState = new(world, itemId, false, null);
                else state = state with { ItemId = itemId, Quote = quote, Error = null };
                return;
            }
            if (lastRequest is { } last && Stopwatch.GetElapsedTime(last) < TimeSpan.FromSeconds(3))
            {
                if (background) backgroundState = new(world, itemId, false, "Patientez quelques secondes.");
                else state = state with { ItemId = itemId, Quote = null, Error = "Patientez quelques secondes avant une nouvelle requête." };
                return;
            }
            lastRequest = Stopwatch.GetTimestamp();
            request?.Dispose();
            request = new CancellationTokenSource();
            token = request.Token;
            ticket = ++generation;
            requestActive = true; activeBackground = background;
            if (background) backgroundState = new(world, itemId, true, null);
            else state = state with { ItemId = itemId, Quote = null, Loading = true, Error = null };
        }
        try
        {
            var json = await client.GetStringAsync($"https://universalis.app/api/v2/aggregated/{world}/{itemId}", token).ConfigureAwait(false);
            var quote = MarketQuote.Parse(json, world, itemId, DateTimeOffset.UtcNow);
            lock (gate)
            {
                if (disposed || ticket != generation) return;
                if (cache.Count >= 128) cache.Remove(cache.MinBy(pair => pair.Value.FetchedAt).Key);
                cache[(world, itemId)] = quote;
                requestActive = false;
                if (background) backgroundState = new(world, itemId, false, null);
                else state = state with { Quote = quote, Loading = false, Error = null };
            }
        }
        catch (Exception error)
        {
            lock (gate)
                if (!disposed && ticket == generation)
                {
                    requestActive = false;
                    var message = error is OperationCanceledException ? "Requête annulée ou délai dépassé." : $"Lecture des prix impossible : {error.Message}";
                    if (background) backgroundState = new(world, itemId, false, message, DateTimeOffset.UtcNow.AddSeconds(30));
                    else state = state with { Loading = false, Quote = null, Error = message };
                }
        }
    }
    public void Dispose()
    {
        lock (gate)
        {
            if (disposed) return;
            disposed = true;
            generation++;
            request?.Cancel(); request?.Dispose();
            cache.Clear();
            requestActive = false; backgroundState = null;
            state = new(0, "", 0, null, false, null);
            if (ownsClient) client.Dispose();
        }
    }
}
