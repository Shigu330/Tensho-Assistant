namespace TenshoAssistant.Collections;

public enum CollectionKind { Mount, Companion, Emote, BlueMagic }
public sealed record CollectionEntry(CollectionKind Kind, uint Id, string Name, uint IconId, bool ConfirmedUnlocked,
    int Number = 0, int Rank = 0, string Description = "", string Location = "");
public sealed record CollectionState(ulong CharacterId, DateTimeOffset? ObservedAt,
    IReadOnlyList<CollectionEntry> Entries, bool Loading, string? Error);

public sealed class CollectionService
{
    private CollectionState state = new(0, null, Array.Empty<CollectionEntry>(), true, null);
    private int refresh;
    public CollectionState State => Volatile.Read(ref state);
    public void RequestRefresh() => Interlocked.Exchange(ref refresh, 1);
    internal bool ConsumeRefresh() => Interlocked.Exchange(ref refresh, 0) == 1;
    internal void Publish(ulong characterId, IEnumerable<CollectionEntry> entries)
    {
        var copied = entries.Select(entry => characterId == 0 ? entry with { ConfirmedUnlocked = false } : entry)
            .OrderBy(entry => entry.Name, StringComparer.OrdinalIgnoreCase).ThenBy(entry => entry.Id).ToArray();
        Interlocked.Exchange(ref state, new(characterId, characterId == 0 ? null : DateTimeOffset.UtcNow,
            Array.AsReadOnly(copied), false, null));
    }
    internal void Invalidate()
    {
        var previous = State;
        Interlocked.Exchange(ref state, new(0, null,
            Array.AsReadOnly(previous.Entries.Select(entry => entry with { ConfirmedUnlocked = false }).ToArray()), true, null));
    }
    internal void Fail(Exception error)
    {
        Invalidate();
        Interlocked.Exchange(ref state, State with { Loading = false, Error = error.Message });
    }
    internal void Clear() => Interlocked.Exchange(ref state, new(0, null, Array.Empty<CollectionEntry>(), false, null));
}
