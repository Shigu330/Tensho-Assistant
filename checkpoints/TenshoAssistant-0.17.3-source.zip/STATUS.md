# État courant

CURRENT_GOAL: MACRO-001A — CHECKPOINT QUOTA ; moteur et observateur testés, exécuteur natif non implémenté
CURRENT_MODEL_CLASS: HEAVY (GPT-6.1 Sol)
RECOMMENDED_MODEL: LIGHT pour les adaptations bornées ; continuation du modèle actuel autorisée par l'utilisateur
MODEL_ESCALATION: None
QUOTA: Limite demandée atteinte : relevé 2026-10-27, 69 % consommés sur 5 h et 100 % hebdomadaires affichés (31 % / 0 % restants affichés). Arrêt conformément à l'instruction de poursuivre jusqu'à la fin du quota.
BUILD: COMPILED Release 0.17.3.0 ; sortie canonique bin/x64/Release
TESTS: TESTED — 110/110 tests ; identité, versions, contenu ZIP et exclusion des assemblies hôte vérifiés
RUNTIME: Banque, stocks, carnet et préparation jusqu'à 0.5.27 confirmés par l'utilisateur. Nouvelles fonctions 0.6–0.17 non validées en jeu.
WORK_COMPLETED: Navigateur récolte/pêche et cartes, sous-recettes avec variantes, liens contextuels, tri en aperçu, collections, quêtes, grimoire bleu, attributs, Mini Cactpot manuel et prix manuels/survol opt-in. 110 tests (dont moteur et observation macros sans exécution native) ; probes statiques recettes/cartes/éligibilité marché passants. Checkpoint source 0.17.1 sauvegardé, sans bin/obj/assemblies hôte.
BLOCKER: Aucune erreur de compilation ; validation visuelle/native finale exige un client Dalamud.
RESUME_FROM: GOAL.md ; TESTING.md pour le protocole de la base.
NEXT_ACTION: À la reprise après renouvellement du quota : collecter une trace passive dans Diagnostics selon docs/MACRO-001A.md, puis prouver les transitions et l'ownership avant l'exécuteur.

| Plugin | Coverage |
|---|---|
| Avant-Garde | NOT_STARTED |
| Blue Mage Helper | PARTIAL — grimoire, numéros, descriptions, lieux renseignés et acquisition confirmée |
| Character Panel Refined | PARTIAL — attributs natifs, sans formules dérivées |
| Collections | PARTIAL — montures, mascottes, emotes ; inconnu distinct d'absent |
| Craftimizer | PARTIAL — recettes, carnet, préparation et sous-recettes avec choix de variantes ; simulation/macros à développer |
| Duty Loot Preview | NOT_STARTED |
| ezMiniCactpot | PARTIAL — solveur optimal manuel ; adaptation native à développer |
| GatherBuddy | PARTIAL — sources statiques récolte/pêche, objets cachés, carte de zone ; pas d'horaires/météo |
| Item Use | PARTIAL — usages du catalogue de recettes |
| LazyGatherer | NOT_STARTED |
| Macro Chain | NOT_STARTED |
| Mappy | PARTIAL — navigateur natif, repères saisis et lien vers les ressources de zone |
| Monster Loot Hunter | NOT_STARTED |
| Price Insight | PARTIAL — prix manuels et au survol opt-in, cache et cadence communs, dates NQ/HQ par monde |
| QuestTracker | PARTIAL — états natifs et séquence ; prérequis non modélisés |
| SortaKinda | PARTIAL — aperçu de règles sauvegardées, sans déplacement natif |
| TriadBuddy | NOT_STARTED |

