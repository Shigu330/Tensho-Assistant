# GOAL sélectionné

ID: CRAFT-CONDITION-RANGE-005
OBJECTIVE: Distinguer le scénario normal et l’enveloppe de qualité d’une séquence fixe, puis poursuivre une base d’outils correcte jusqu’à 5 % de quota disponible.
CURRENT_STATE: IMPLEMENTED / TESTED en 0.47.0, 302 tests/package verts ; enveloppe par transitions ordinaires cohérentes, mêmes ressources hors qualité, sept groupes de tests dont oracle exhaustif. Aucun résultat runtime nouveau déclaré.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: CraftConditionEnvelope ; MainWindow.CraftConditionEnvelope/Simulation ; CraftConditionEnvelopeTests ; docs de preuve.
IN_SCOPE: Séquence fixe et déterministe des 26 actions, premier état Normal, transitions ordinaires ; qualité minimale/maximale du modèle et scénario manuel de bonus. Pas de probabilité HQ, de recherche adaptative ou d’état natif inféré.
OUT_OF_SCOPE: Revendiquer remplacement intégral ou validation native sans preuve ; commander une action depuis cette comparaison.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: Relevé 2026-10-29 : 73 % disponibles sur 5 h et 65 % semaine ; réserve utilisateur 5 % sur la fenêtre limitante. Objectif global actif.
NEXT_ACTION: CACT-LIVE-002 : étudier métadonnées et source primaire Mini Cactpot pour une copie native opt-in vers le solveur existant, sans commande de jeu. Garder les tests projection/Macro Chain différés sans redemande.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
