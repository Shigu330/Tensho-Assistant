# GOAL sélectionné

ID: CRAFT-MACRO-001
OBJECTIVE: Export manuel de macros localisées depuis une simulation normale terminée ; poursuivre la couverture du projet.
CURRENT_STATE: IMPLEMENTED / TESTED — simulation 0.36 et export 0.37 intégrés, 243 tests/package verts. Noms natifs, blocs <=15 lignes, attentes 2/3s ajustables et copie par bloc ; probe des huit métiers passant. Aucune activation ou validation en jeu ; Macro Chain reporté.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: CraftSimulation/ActionCatalog/RecipeCatalog, CraftMacroExport ; MainWindow.CraftSimulation/CraftPlan/Tools ; Plugin ; CraftSimulationTests/CraftMacroTests ; CraftSimulationProbe ; documents.
IN_SCOPE: Simulation normale et export de son préfixe terminé vers textes localisés immuables, attentes explicites, aucune écriture/exécution native.
OUT_OF_SCOPE: Déclarer les 17 plugins remplacés ; prétendre une validation en jeu sans observation.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: 2026-10-28, 41 % disponibles sur 5 h et 75 % semaine au dernier relevé ; continuer selon instruction utilisateur.
NEXT_ACTION: Snapshot 0.37.0 puis CRAFT-SOLVE-001 : solveur borné sur modèle normal, cible explicite progression/qualité, annulation/générations et absence de garantie d'optimalité universelle. Garder les 17 domaines PARTIAL et le goal global actif ; Macro Chain différé.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
