# Roadmap des 17 plugins

État courant 0.20.0 (2026-10-28) : [horaires ET de récolte](docs/GATHER-002.md), [base multi-outils](docs/BASE-TOOLS-001.md), [sous-recettes](docs/CRAFT-CHAIN-001.md), [favoris de cartes](docs/MAP-002.md), [prix au survol](docs/MARKET-HOVER-001.md) et [séquences de macros](docs/MACRO-001A.md). 123/123 tests et package vérifiés. L'utilisateur testera Macro Chain plus tard ; validation native différée, sans acceptation supposée.

Source autoritaire : docs/PROMPT-MAITRE.md, §4. Toutes les lignes sont conservées. State décrit le travail ; Coverage décrit la capacité réellement validée. TODO/READY/ACTIVE/BLOCKED/DONE ; NOT_STARTED/PARTIAL/FUNCTIONAL/REPLACEABLE. NEEDS_STUDY est une note d'incertitude, pas une suppression. Aucun pourcentage arbitraire.

## Fondations

GATHER-001A 0.6.0 : consultation des sources récolte/pêche implémentée, objets cachés inclus ; jointures vérifiées sur les fichiers locaux du jeu (4 199 sources), 66 tests/package verts. Rendu en jeu à confirmer. SORT-001A et les tranches 0.8–0.13 sont maintenant intégrées, voir le checkpoint actuel.

État réconcilié au 2026-10-27 : CRAFT-001A, CRAFT-BOOK et CRAFT-PREP clos dans leurs périmètres, préparation 0.5.27 acceptée par retour utilisateur. GATHER-001A est terminé dans son périmètre statique ; BASE-TOOLS-001 consolide les tranches suivantes. Les notices anciennes ci-dessous sont historiques.

CRAFT-PREP 0.5.27 : préparation de fabrication implémentée (quantité cible, rendement, besoins, écarts et copie). 63 tests et package validés ; nouveau panneau à vérifier en jeu. Carnet CRAFT-BOOK confirmé OK par capture utilisateur v0.5.26. Craftimizer conserve une couverture partielle : simulation et macros à développer.

CRAFT-BOOK 0.5.26 : carnet Utilisé dans implémenté avec filtres métier natifs, recherche, liste et fiche sélectionnée. Build/61 tests/package validés ; rendu en jeu à confirmer. Banque filtrée validée par retour utilisateur et capture du Sac 3 sous catégorie Appât de pêche.

Banque UI 0.5.25 : implémentation terminée (tri ItemOrderModule, cadres par sac, Global et origines, catégories natives, qualité/recherche, masquage des sacs vides sous filtre, sélection en contexte et persistance des positions). Compilation et 61/61 tests réussis ; validation visuelle finale encore requise. Voir TESTING.md.

| ID | Plugin | Description | Dependencies | State | Tests | References |
|---|---|---|---|---|---|---|
| CORE-000 | Socle transversal | Solution, plugin, manifest, configuration, fenêtre, commande, lifecycle | SDK local | DONE | 5 tests managés et paquet ; runtime non validé | REF-LOCAL-001, REF-DALAMUD, REF-SAMPLE |
| CORE-001 | Fondation SortaKinda/Craftimizer/GatherBuddy | Snapshot inventaire managé avec portée et couverture | CORE-000 | DONE | 8 tests inventaire ; 13/13 avec socle, build et paquet verts | REF-DALAMUD, REF-INVENTORY, REF-SNAPSHOT, REF-INV-MODEL |
| INV-001 | Fondation commune | Lecture des quatre sacs via Dalamud et invalidation ; diagnostic | CORE-001 | DONE | 7 tests coordinateur ; 20/20 avec fondations, build/paquet verts ; runtime à valider | REF-DALAMUD, REF-INV-API |
| INV-002 | Fondation commune | Vérification de chargement natif et total exact des quatre sacs si lecture complète | INV-001 | DONE | 25/25 tests, build/paquet 0.1.1 ; quatre sacs complets visibles et total confirmé correct en jeu | REF-INV-LOAD ; preuve dans TESTING.md |
| UI-001 | Socle transversal | Options indépendantes d'ouverture au chargement et à la connexion | CORE-000 ; IClientState.Login | DONE | Build 0.1.2, 26/26 tests ; confirmation utilisateur du comportement | TESTING.md |
| UI-002 | Fondation inventaire | Affichage simultané NQ, HQ et total pour l'objet recherché | INV-002 | DONE | Build 0.1.3 et 26/26 tests ; rendu simultané live à confirmer | TESTING.md |
| UI-003 | Interface commune | Accueil, navigation, objets/inventaire, répertoire des 17 outils, réglages et diagnostics | ITEM-001 ; UI-001 ; UI-002 | DONE | Build/paquet 0.2.0, 31/31 tests ; répertoire exact des 17 plugins contrôlé ; visuel à vérifier | TESTING.md ; ARCHITECTURE.md |
| UI-004 | Interface commune | Grille d'icônes natives et fiches détaillées ouvertes uniquement au clic | UI-003 | DONE | Build/paquet 0.2.1, 31/31 tests ; 17 références conservées ; interaction visuelle à confirmer | REF-UI-ICONS ; TESTING.md |
| BANK-001 | Inventaire commun | Banque persistante servant/chocobo par imports manuels attachés aux menus et intégrée aux recherches | INV-002 ; ITEM-001 | DONE | Build/paquet 0.3.0 et 43/43 tests ; imports natifs et attache visuelle à valider | REF-BANK-API ; TESTING.md |
| BANK-001-RUNTIME | Inventaire commun | Vérifier boutons attachés, imports, recherche et persistance servant/chocobo | BANK-001 | TODO | Capture 0.3.0 : cache chocobo et cumul visibles ; servant/attache/persistance encore à confirmer | TESTING.md |
| UI-005 | Interface inventaire commune | Icônes d'objets du jeu et vue unique groupée Personnage/Chocobo/Servants | BANK-001 ; ITEM-001 | DONE | Build/paquet 0.4.0, 55/55 tests ; nouveau rendu à vérifier | REF-ITEM-TEXTURES ; TESTING.md |
| UI-006 | Interface commune | Corriger dimensions et centrage des icônes d'outils après capture | UI-004 | DONE | Build/paquet 0.4.1, 55/55 tests ; correction acceptée par l'utilisateur | TESTING.md |
| UI-005-RUNTIME | Interface inventaire commune | Vérifier les icônes, filtres et regroupements des stocks en jeu | UI-005 | ACTIVE | Essai ciblé sur cordial après rechargement de la DLL compilée | TESTING.md |
| UI-003-RUNTIME | Interface commune | Vérifier navigation, taille et conservation de sélection entre pages | UI-003 | ACTIVE | Protocole visuel ciblé après build dans TESTING.md | TESTING.md |
| ITEM-001 | Fondation commune | Index Item partagé et recherche bornée par nom/ID | CORE-000 | DONE | Build/paquet 0.1.4, 31/31 tests ; catalogue réel de 50 880 objets français et sélection validés en jeu | REF-ITEM-API |
| ITEM-001-RUNTIME | Fondation commune | Recherche par nom et sélection reliée au total des sacs | ITEM-001 | DONE | Capture : recherche sirop, sélection 12892, 0 NQ/156 HQ/total 156 ; retour utilisateur OK | TESTING.md |
| CRAFT-001A | Craftimizer #5 — première tranche | Catalogue recettes et ingrédients relié au catalogue Item commun | ITEM-001 | DONE | Build/paquet 0.5.0, 57/57 tests ; rendu et recette réelle à vérifier | REF-CRAFT ; API locale vérifiée |
| CRAFT-001A-RUNTIME | Craftimizer #5 | Vérifier une recette et ses ingrédients en jeu | CRAFT-001A | DONE | Captures du carnet 0.5.26 et confirmation préparation 0.5.27 | TESTING.md |
| GATHER-001A | GatherBuddy #8 | Sources statiques récolte/pêche et objets cachés | ITEM-001 ; CRAFT-PREP | DONE | Jointures locales vérifiées ; tests verts, runtime à confirmer | docs/BASE-TOOLS-001.md |
| USE-001 | Item Use | Usages d'un objet reliés aux recettes connues | ITEM-001 ; CRAFT-001A | PARTIAL | Section Utilisé dans et ouverture directe de Craft lié ; couverture recettes uniquement | TESTING.md |
| RUNTIME-001 | Fondation commune | Smoke test réel du socle et de l'acquisition des sacs | INV-001 ; session Dalamud | DONE | Protocole utilisateur accepté, quantités et options confirmées ; cas avancés non revendiqués dans TESTING.md | REF-INV-API ; preuves dans TESTING.md |

## Matrice principale

| # | ID | Plugin | Auteur(s) | Description | Dependencies | State | Coverage | Tests | References | Groupe |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | FASHION-001 | Avant-Garde | NeNeppie | Équipements valides associés aux indices Fashion Report | ITEM-001 ; source des indices | TODO | NOT_STARTED | Solutions connues, mise à jour des indices | REF-SCOPE ; source actuelle NEEDS_STUDY | C |
| 2 | BLU-001 | Blue Mage Helper | Infi, Sl0nderman, harbingerftw | Grimoire Mage bleu : sorts, acquisition et progression | ITEM-001 ; collections ; sources | ACTIVE | PARTIAL | Grimoire natif, numéros distincts des IDs, acquisitions confirmées ; build/tests verts, runtime à confirmer | docs/BASE-TOOLS-001.md | C |
| 3 | CHAR-001 | Character Panel Refined | Kouzukii | Statistiques utiles du personnage | Lecture des stats locale ; formules vérifiées | ACTIVE | PARTIAL | Attributs natifs copiés et invalidés ; formules dérivées à développer | docs/BASE-TOOLS-001.md | D |
| 4 | COLL-001 | Collections | Seventh | Découverte, progression et interactions avec les collections | ITEM-001 ; unlocks ; couverture runtime | ACTIVE | PARTIAL | Montures/mascottes/emotes ; confirmations et lifecycle testés, runtime à confirmer | docs/BASE-TOOLS-001.md | B |
| 5 | CRAFT-001 | Craftimizer | Asriel | Simulation de craft, macros assistées et suggestions en cours de craft | ITEM-001 ; Recipe/RecipeLevelTable ; inventaire ; simulateur | ACTIVE | PARTIAL | Recettes/carnet/préparation validés ; simulation et macros à développer | REF-CRAFT | A |
| 6 | DUTY-001 | Duty Loot Preview | grittyfrog | Aperçu du butin des contenus | ITEM-001 ; table contenu/butin | TODO | NOT_STARTED | Liens contenu/objet et couverture des sources | REF-SCOPE ; source actuelle NEEDS_STUDY | C |
| 7 | CACT-001 | ezMiniCactpot | daemitus, Minmoose, MidoriKami | Calcul du meilleur choix au Mini Cactpot | Solveur managé ; adaptateur du plateau | ACTIVE | PARTIAL | Solveur manuel exact, espérance de référence et annulation testées ; adaptateur natif à développer | docs/BASE-TOOLS-001.md | D |
| 8 | GATHER-001 | GatherBuddy | Ottermandias | Récolte et pêche : ressources, lieux, horaires et météo | ITEM-001 ; Gathering/FishingSpot ; carte ; disponibilité | ACTIVE | PARTIAL | Sources et horaires ET testés ; météo/harpon à développer, runtime à confirmer | docs/GATHER-002.md | A |
| 9 | USE-001 | Item Use | PunishedPineapple | Usages courants d'un objet | ITEM-001 ; recettes ; index des usages | ACTIVE | PARTIAL | Usages issus des recettes disponibles ; autres usages à développer | REF-SCOPE ; source actuelle NEEDS_STUDY | C |
| 10 | GP-001 | LazyGatherer | Hiroa | Optimisation des PA/GP de récolte | GATHER-001 ; actions ; état runtime | TODO | NOT_STARTED | Coûts, seuils et recommandations selon état | REF-SCOPE ; source actuelle NEEDS_STUDY | D |
| 11 | MACRO-001 | Macro Chain | Caraxi | Exécution de macros successives | Macro lifecycle ; marqueur final ; hook d'intervention externe | ACTIVE | PARTIAL | Plan persistant, protocole de marqueur, arrêt/identité et tests managés ; test natif en attente | docs/MACRO-001A.md ; REF-MACRO-BRIDGE-20261028 | D |
| 12 | MAP-001 | Mappy | MidoriKami, harbingerftw | Carte en jeu polyvalente | Territory/Map ; coordonnées ; points partagés | ACTIVE | PARTIAL | Catalogue et favoris persistants, édition/retrait/rollback ; tests managés verts, rendu à confirmer | docs/MAP-001A.md ; docs/MAP-002.md | C |
| 13 | LOOT-001 | Monster Loot Hunter | Sylf | Sources de matériaux sur les monstres | ITEM-001 ; index des sources ; carte | TODO | NOT_STARTED | Matériau/monstre/zone et provenance des données | REF-SCOPE ; source actuelle NEEDS_STUDY | B |
| 14 | MARKET-001 | Price Insight | Kouzukii | Prix du marché au survol d'un objet | ITEM-001 ; service marché ; cache horodaté | ACTIVE | PARTIAL | Consultation manuelle et survol opt-in NQ/HQ/monde, cache/cadence communs et annulation testés ; runtime à confirmer | docs/BASE-TOOLS-001.md | B |
| 15 | QUEST-001 | QuestTracker | isaiahcat, keifufu | Progression et complétion des quêtes | Catalogue Quest ; prérequis ; snapshots | ACTIVE | PARTIAL | États/séquences natifs et invalidation testés ; prérequis à développer | docs/BASE-TOOLS-001.md | B |
| 16 | SORT-001 | SortaKinda | MidoriKami | Personnalisation de l'inventaire, règles, aperçu et application | CORE-001 ; INV-001 ; ITEM-001 ; règles persistantes | ACTIVE | PARTIAL | Aperçu/règle persistée, piles/qualités préservées ; application native à développer | docs/BASE-TOOLS-001.md | A |
| 17 | TRIAD-001 | TriadBuddy | MgAl2O4 | Solveur Triple Triade | Cartes ; règles ; solveur ; état du plateau | TODO | NOT_STARTED | Règles, coups légaux, adversaires et annulation | REF-SCOPE ; source actuelle NEEDS_STUDY | C |

Les IDs métier désignent la capacité globale à découper en petits GOAL au moment de l'activation. CRAFT-001 commence par le catalogue, puis simulation, macros et suggestions ; GATHER-001 par les lieux, puis horaires/météo/pêche ; SORT-001 par l'aperçu avant toute application native. Les autres capacités suivent le même principe, sans déclarer le plugin couvert dès la première tranche.

## Domaine complémentaire

Combat/ACT/IINACT : étude facultative, séparée des 17 lignes et sans priorité devant elles.

