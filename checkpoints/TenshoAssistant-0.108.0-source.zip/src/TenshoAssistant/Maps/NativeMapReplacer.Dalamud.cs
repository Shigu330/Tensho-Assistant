using Dalamud.Game.ClientState.Keys;
using Dalamud.Plugin.Services;
using FFXIVClientStructs.FFXIV.Client.UI.Agent;
using FFXIVClientStructs.FFXIV.Component.GUI;

namespace TenshoAssistant.Maps;

/// <summary>
/// When enabled, the game's map window (AreaMap) is closed the frame it appears and the Tensho map shows the same map.
/// Polling the addon each framework tick replaced the 0.107 lifecycle listener, which did not stop the game map in practice.
/// AltGr held while opening keeps the game map (option); Shift is left to the game.
/// </summary>
internal sealed class NativeMapReplacer : IDisposable
{
    private readonly IFramework framework;private readonly IGameGui gui;private readonly IKeyState keys;private readonly IClientState client;private readonly IPluginLog log;
    private readonly Func<MapViewSettings> settings;private readonly Action<uint> open;
    private bool wasVisible;private bool keepGameMap;private bool disposed;private DateTimeOffset retryAt;
    public NativeMapReplacer(IFramework framework,IGameGui gui,IKeyState keys,IClientState client,Func<MapViewSettings> settings,Action<uint> open,IPluginLog log)
    {
        this.framework=framework;this.gui=gui;this.keys=keys;this.client=client;this.settings=settings;this.open=open;this.log=log;
        framework.Update+=Update;
    }
    private bool AltGr=>keys[VirtualKey.RMENU] || keys[VirtualKey.CONTROL] && keys[VirtualKey.MENU];
    private unsafe void Update(IFramework _)
    {
        if(disposed || !framework.IsInFrameworkUpdateThread || framework.IsFrameworkUnloading)return;
        var now=DateTimeOffset.UtcNow;if(now<retryAt)return;
        try
        {
            var addon=gui.GetAddonByName("AreaMap");
            var visible=!addon.IsNull && addon.IsVisible;
            if(visible && !wasVisible)
            {
                var options=settings();
                // Decided once, when the game map appears: kept for the whole time it stays open.
                keepGameMap=!options.ReplaceGameMap || options.KeepGameMapWithAltGr && AltGr;
                if(!keepGameMap)
                {
                    var agent=AgentMap.Instance();
                    var selected=agent==null ? 0:agent->SelectedMapId;
                    ((AtkUnitBase*)addon.Address)->Close(true);
                    open(selected==0 || selected==client.MapId ? 0:selected);
                    visible=false;
                }
            }
            if(!visible)keepGameMap=false;
            wasVisible=visible;
        }
        catch(Exception error){retryAt=now.AddSeconds(5);log.Warning(error,"Could not replace the game map; it stays open.");}
    }
    public void Dispose(){if(disposed)return;disposed=true;framework.Update-=Update;}
}
