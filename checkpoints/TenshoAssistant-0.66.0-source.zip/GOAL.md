# GOAL sélectionné

ID: QUEST-REWARDS-003-STUDY
OBJECTIVE: Intégrer les récompenses natives utiles aux quêtes et au contexte d’objet, sur preuves de types/quantités ; poursuivre les 17 domaines jusqu’à la réserve quota de 5 %.
CURRENT_STATE: COLL-003 IMPLEMENTED / TESTED en 0.66.0, 421 tests/package/SHA-256 et CollectionProbe verts. 885 titres et 4 003 succès, acquisition à trois états selon couverture, récompenses Item/Title liées ; callbacks/acquisitions/rendu en jeu non observés.
WHY_NOW: Progression d’un autre domaine B et liens utiles quêtes → objets → stocks/outils, en réutilisant les catalogues et contexte communs.
REFERENCES: docs/QUEST-002.md ; docs/BASE-TOOLS-001.md ; API/feuilles Quest locales et source primaire ciblée si sémantique incertaine.
FILES: Quests/QuestService, QuestReader.Dalamud ; MainWindow.Quests et détails ; modèles Item et probes/tests ciblés.
IN_SCOPE: Récompenses statiques fixes/choix, quantités et identités Item/currency selon preuves ; source/provenance, données inconnues et navigation contexte. Lecteur/catalogue existants, copie bornée framework.
OUT_OF_SCOPE: Déduire obtention effective, disponibilité de quête, progression non observée, choix/requête/commande native ou réseau automatique. Les 17 restent PARTIAL.
VALIDATION: Dernière tranche Verify.ps1 421/421, zéro avertissement/erreur, package/API/versions/SHA-256/exclusion hôte verts ; probes statiques natifs passants. Nouvelle projection à prouver sur les fichiers du jeu et tester avant livraison.
QUOTA: Relevé 2026-10-29 : 45 % disponibles sur 5 h et 38 % semaine ; réserve 5 %, objectif global actif.
NEXT_ACTION: Checkpoint 0.66 puis lire le modèle/lecteur Quests, les colonnes reward et un consommateur primaire pour les sémantiques de quantité/choix. GP et essais projection/Macro Chain différés, sans les redemander.
DEFINITION_OF_DONE: Tranche utile compilée/testée, preuves/limites/docs/sauvegarde à jour ; aucun domaine global promu complet sans preuve.
