# GOAL sélectionné

ID: BASE-AUDIT-003
OBJECTIVE: Vérifier et améliorer la cohérence de la base des 17 outils, de ses documents et de la livraison ; poursuivre jusqu’à la réserve quota utilisateur de 5 %.
CURRENT_STATE: Livraison 0.68.0, 434 tests/package verts ; index Item → quêtes vérifié. Étude QUEST-CURRENCIES-005 clôturée sur UNKNOWN précis : quinze clés Item/GCTypeReward nulles, aucune relation de résolution prouvée ; quantités conservées et aucun blocage global.
WHY_NOW: Plusieurs domaines ont été enrichis ; vérifier la cohérence globale, les chemins canoniques et les écarts concrets avant de nouvelles capacités.
REFERENCES: RULES.md ; ROADMAP.md ; TESTING.md ; docs/BASE-AUDIT-002.md ; docs/QUEST-CURRENCIES-005-STUDY.md et contrats récents.
FILES: Documents racine/docs ; répertoire et pages MainWindow ; manifests/csproj/scripts ; correctifs et tests ciblés si problème démontré.
IN_SCOPE: Dix-sept références conservées, capacités/UI/limites cohérentes ; chemins DLL x64 Release/paquet, liens locaux, versions et exclusion hôte ; correction de bugs précis et garde-fous utiles.
OUT_OF_SCOPE: Revendiquer du runtime non observé, retirer un outil, réinterpréter des champs natifs non prouvés, publication externe ou action sur le client de jeu. Les 17 restent PARTIAL.
VALIDATION: Dernière livraison Verify.ps1 434/434, zéro avertissement/erreur, package/API/versions/SHA-256/exclusion hôte verts ; census et index natifs passants. Audit à exécuter contre l’état actuel, sans refaire les tests verts pour seuls changements de documentation.
QUOTA: Relevé 2026-10-29 : 16 % disponibles sur 5 h et 34 % semaine ; réserve 5 %, objectif global actif.
NEXT_ACTION: Audit des Markdown/liens/versions, matrice 17 et répertoire UI ; comparaison des capacités nouvellement implémentées avec les textes présents, puis correction concrète/compilation si code changé.
DEFINITION_OF_DONE: Audit tracé, incohérences matérielles corrigées ou limites précises enregistrées ; tests pertinents/build si code changé, sauvegarde et point de reprise à jour ; aucune complétion globale déduite.
