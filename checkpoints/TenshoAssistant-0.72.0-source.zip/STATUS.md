# État courant

CURRENT_GOAL: CRAFT-LOG-001 — DONE côté code/tests, demande utilisateur ; liaison et placement en jeu non confirmés
CURRENT_MODEL_CLASS: HEAVY — identités natives, acquisition et couverture
RECOMMENDED_MODEL: HEAVY pour l’intégration native des menus/tri ; LIGHT pour les tâches mécaniques ; continuation autorisée
MODEL_ESCALATION: None
QUOTA: Relevé 2026-10-29 : 95 % consommés sur 5 h, 68 % semaine (5 % / 32 % disponibles). Réserve utilisateur atteinte ; pause conditionnelle demandée, développement global non achevé.
LAST_READ: RULES/STATUS/GOAL, simulateur/recherche/export/presets/stats, overlays et lifecycle relus. Bindings RecipeNote/RecipeData/RecipeEntry/AgentRecipeNote vérifiés par ApiProbe ; sources primaires FFXIVClientStructs consultées.
BUILD: COMPILED Release 0.72.0.0 ; sortie canonique bin/x64/Release
TESTS: TESTED — Verify.ps1 final 442/442, package/API/versions/SHA-256/exclusion hôte verts, zéro avertissement/erreur. Sept groupes carnet : identité/job/fraîcheur, propositions/copies, génération/annulation/reconnexion, copies producteurs/erreurs et préférence v1.
RUNTIME: Banque, stocks, carnet et préparation jusqu’à 0.5.27 confirmés par l’utilisateur. Fonctions 0.6–0.72 non validées en jeu. Tests projection et Macro Chain explicitement différés ; ne pas les redemander.
WORK_COMPLETED: Panneau macro indépendant de la fenêtre principale, attaché au carnet RecipeNote. Simuler cette recette demande l’ouverture native via queue framework ; lecture bornée de la sélection, recherche et évaluation des presets sur worker, icônes/copie/transfert au simulateur. Préférence sauvegardée dans Réglages, défaut activé selon demande. Manipulation non observée exclue, qualité initiale 0 explicite.
BLOCKER: Aucun blocage global. Le bonus natif d’Abondance reste inconnu : sources divergentes et aucun getter nommé confirmé dans les bindings étudiés. Ne pas inventer une formule ; travaux indépendants poursuivis.
RESUME_FROM: GOAL.md ; TESTING.md pour le protocole de la base.
NEXT_ACTION: Demande carnet implémentée/compilée/testée, documentation docs/CRAFT-LOG-001.md. Vérifier le placement et la sélection en jeu après rechargement si l’utilisateur le souhaite ; ne pas revendiquer du runtime. Objectif autonome antérieur toujours en pause ; essais projection/Macro Chain différés.

| Plugin | Coverage |
|---|---|
| Avant-Garde | PARTIAL — répertoire manuel d'indices natifs, équipements signalés, emplacements/stock/contexte et source datée ; thème courant/teintures/score/attache non déduits |
| Blue Mage Helper | PARTIAL — grimoire, numéros, descriptions, lieux renseignés et acquisition confirmée |
| Character Panel Refined | PARTIAL — attributs natifs, sans formules dérivées |
| Collections | PARTIAL — montures, mascottes, emotes, cartes, orchestrion, titres et succès ; preuve de chargement, catégories/fiches/récompenses, runtime à confirmer |
| Craftimizer | PARTIAL — simulation/recherche/export/séquences, projection ordinaire et aide macro attachée au carnet natif ; placement/lecture en jeu, rotation adaptative et recettes spéciales à compléter |
| Duty Loot Preview | PARTIAL — consultation manuelle par contenu, coffres/récompenses, icônes/contexte, provenance et cache ; drops directs non interprétés, données externes partielles |
| ezMiniCactpot | PARTIAL — solveur exact manuel et mode observé opt-in LotteryDaily ; conseil actualisé, aucune commande ; adaptation/rendu natifs non validés en jeu |
| GatherBuddy | PARTIAL — sources/maps/horaires/météo statiques, point courant MIN/BTN opt-in, carnet natif pêche, appâts/conditions explicites et plages ET/UTC et météo localisée ; plages des critères renseignés, présence/prérequis/harpon et runtime à compléter |
| Item Use | PARTIAL — recettes, mandats, candidats GC/aquarium, orchestrion et sources de quête, survol et menu Inventory opt-in ; autres usages/disponibilité, liens de discussion et runtime à compléter |
| LazyGatherer | PARTIAL — optimiseur manuel avec effets explicitement déclarés, observation du point et copie de ressources ; décodeur natif/bonus/régénération/procs/collectionnables et validation runtime à compléter |
| Macro Chain | PARTIAL — séquences à marqueur final, lancement explicite, arrêt, persistance ; natif à confirmer |
| Mappy | PARTIAL — navigateur natif, repères favoris persistants, ressources de zone et prévisions météo statiques ; météo forcée non observée |
| Monster Loot Hunter | PARTIAL — associations matériau/monstre, fiches/niveaux/lieux et carte de zone, transport/cadence partagés, contexte ; données communautaires partielles |
| Price Insight | PARTIAL — consultation manuelle et prix au survol opt-in, NQ/HQ/monde, cache/cadence/priorités partagés ; contexte mutualisé et scope owner/monde, runtime à confirmer |
| QuestTracker | PARTIAL — états natifs, séquence, fiches/liens et récompenses conditionnelles vers Item ; sources inverses managées, couverture/inconnus et disponibilité non calculée |
| SortaKinda | PARTIAL — profils/modèles, critères, zones protégées/filtrées et inversion, application visuelle après capture directe ; autres filtres/automatisations choisies et validation runtime à compléter |
| TriadBuddy | PARTIAL — carnet/deck/solveur manuel, observation des faces opt-in expérimentale ; identités/règles/trait natifs et autres règles non établis |

