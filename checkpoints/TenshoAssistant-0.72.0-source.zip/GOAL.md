# GOAL sélectionné

ID: CRAFT-LOG-001 — DONE côté code/tests
OBJECTIVE: Fournir une interface à côté du carnet de synthèse du jeu avec la recette sélectionnée, ses attributs et une macro générée, dans l’esprit de la capture utilisateur.
CURRENT_STATE: Livraison 0.72.0.0 compilée, 442/442 tests/package/SHA-256 passants, zéro avertissement/erreur. Placement et lecture native non observés en jeu.
REFERENCES: RULES.md ; docs/CRAFT-LOG-001.md ; bindings locaux et sources primaires FFXIVClientStructs RecipeNote/AgentRecipeNote ; TESTING.md.
FILES: CraftLogObservation/Reader/Session ; MainWindow.CraftLog/Plan/Settings ; Plugin/lifecycle ; Configuration ; tests CraftLog ; manifest/csproj/docs.
IN_SCOPE: Sélection native bornée, ouverture du carnet sur demande explicite, panneau suivant le carnet même si Tensho principal fermé ; contexte propriétaire/métier/recette récent ; recherche et comparaison des séquences hors rendu ; icônes, copies et transfert au simulateur. Préférence sauvegardée centralisée.
OUT_OF_SCOPE: Écriture ou exécution des macros du jeu, lancement de synthèse, garantie HQ, déduction de Manipulation, qualité des ingrédients HQ ou recettes spéciales, validation runtime non observée. Les 17 domaines restent PARTIAL.
VALIDATION: Verify.ps1 final 442/442 ; zéro avertissement/erreur, paquet/API/versions/SHA-256/exclusion hôte verts. ApiProbe confirme noms/types/signatures ; aucune API native exécutée dans le probe. Sept groupes couvrent contexte, copie/export, annulation/réponses tardives, copies et préférence v1.
NEXT_ACTION: Recharger la DLL 0.72.0.0 et ouvrir le carnet sur une recette du métier équipé pour observer le panneau, lorsque l’utilisateur le souhaite. Essais projection/Macro Chain toujours différés ; objectif autonome antérieur conservé en pause à la réserve demandée.
DEFINITION_OF_DONE: Chaîne sélection → calcul → icônes → copie opérationnelle dans le code, vérifiée par compilation/tests et documentée/sauvegardée. Fonctionnement en jeu explicitement non confirmé.
