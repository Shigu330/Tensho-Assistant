using System.Numerics;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.Craft;
using TenshoAssistant.Items;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private readonly CraftLogObservationService craftLog=new();
    internal CraftLogObservationService CraftLog=>craftLog;
    private readonly CraftLogSession craftLogSession=new();
    private CraftLogInput? craftLogInput;
    private DateTimeOffset craftLogStableSince;
    private bool craftLogStarted;
    private string? craftLogOpenError;

    private void OpenCraftLog(RecipeDefinition recipe)
    {
        try
        {
            var owner=bankBridge.State.CharacterId;
            if(owner==0)throw new InvalidOperationException("Connectez un personnage avant d’ouvrir le carnet.");
            if(!configuration.CraftLogHelperEnabled)
            {
                configuration.CraftLogHelperEnabled=true;
                try{save();}catch{configuration.CraftLogHelperEnabled=false;throw;}
            }
            craftLog.RequestOpen(new(owner,recipe.RecipeId,recipe.ResultItemId));craftLogOpenError=null;
        }
        catch(Exception error){craftLogOpenError="Ouverture du carnet impossible : "+error.Message;log.Warning(error,"Could not request crafting log.");}
    }
    private void ClearCraftLogCalculation()
    {
        if(craftLogInput is not null || craftLogStarted)craftLogSession.Cancel();
        craftLogInput=null;craftLogStarted=false;
    }
    internal void DrawCraftLogHelper()
    {
        var now=DateTimeOffset.UtcNow;var observed=craftLog.Observation;
        if(windowDisposed || !configuration.CraftLogHelperEnabled || observed is null || observed.Revision!=craftLog.Revision || !observed.Fresh(now))
        {ClearCraftLogCalculation();return;}
        var context=CraftLogContext.Resolve(observed,characterStats.State,recipeCatalog.State.Catalog,now);
        var actions=craftActions.State.Catalog;
        var presets=(IReadOnlyList<CraftPreset>?)configuration.CraftPresets ?? Array.Empty<CraftPreset>();
        CraftLogInput? input=context is {Recipe:{ } recipe,Stats:{ } stats} && actions is not null
            ? new(observed.Owner,recipe,stats,actions,presets,new(recipe.Simulation!.Quality,craftSolveSteps,craftSolveWidth,craftSolveBudget),craftMacroExtraWait,craftMacroEcho,observed.Revision):null;
        if(input!=craftLogInput)
        {craftLogSession.Cancel();craftLogInput=input;craftLogStableSince=now;craftLogStarted=false;}
        if(now<craftLogStableSince)craftLogStableSince=now;
        if(input is not null && !craftLogStarted && now-craftLogStableSince>=TimeSpan.FromMilliseconds(350))
        {craftLogStarted=true;_=craftLogSession.StartAsync(input);}
        var viewport=ImGui.GetMainViewport();var width=Math.Min(350,viewport.WorkSize.X);var height=Math.Min(590,viewport.WorkSize.Y);
        var position=viewport.Pos+observed.Position+new Vector2(observed.Size.X+6,0);
        if(position.X+width>viewport.WorkPos.X+viewport.WorkSize.X)position.X=viewport.Pos.X+observed.Position.X-width-6;
        position=Vector2.Clamp(position,viewport.WorkPos,Vector2.Max(viewport.WorkPos,viewport.WorkPos+viewport.WorkSize-new Vector2(width,height)));
        ImGui.SetNextWindowPos(position,ImGuiCond.Always);ImGui.SetNextWindowSize(new Vector2(width,height),ImGuiCond.Always);
        var visible=ImGui.Begin("Tensho · Carnet de synthèse###TenshoCraftLog",ImGuiWindowFlags.NoMove|ImGuiWindowFlags.NoSavedSettings|ImGuiWindowFlags.NoFocusOnAppearing|ImGuiWindowFlags.NoResize);
        try
        {
            if(!visible)return;
            DrawToolSettingsLink("CraftLog");
            if(context.Recipe is { } selected)
            {
                var item=itemCatalog.State.Catalog?.Find(selected.ResultItemId);
                DrawItemIcon(item,new Vector2(36));ImGui.SameLine();ImGui.TextWrapped(item?.Name ?? $"Objet {selected.ResultItemId}");
                ImGui.TextColored(Accent,$"{selected.CraftType} · niveau {selected.Level}");
                if(selected.Simulation is { } parameters)ImGui.TextUnformatted($"Progression {parameters.Progress:N0} · qualité {parameters.Quality:N0}\nSolidité {parameters.Durability}");
            }
            if(context.Stats is { } current)ImGui.TextUnformatted($"Habileté {current.Craftsmanship} · contrôle {current.Control}\nPS {current.Cp} · niveau {current.Level}");
            if(context.Issue is { } issue){ImGui.TextWrapped(issue);return;}
            if(actions is null){ImGui.TextWrapped(craftActions.State.Error ?? "Actions du jeu en cours de lecture…");return;}
            ImGui.TextWrapped("Condition normale · qualité initiale 0. Manipulation exclue : déblocage non observé. Aucune garantie HQ.");
            if(context.Recipe is { } forSimulator && ImGui.SmallButton("Ouvrir le simulateur détaillé")){OpenCraftSimulation(forSimulator);IsOpen=true;}
            var state=craftLogSession.State;
            if(state.Loading || !craftLogStarted)ImGui.TextDisabled("Calcul de la macro proposée…");
            if(state.Error is { } error)ImGui.TextWrapped(error);
            if(ImGui.SmallButton("Recalculer")){craftLogSession.Cancel();craftLogStarted=false;craftLogStableSince=now;}
            if(state.Result is not { } result)return;
            DrawCraftLogMacro("Meilleure séquence enregistrée",result.Saved,actions);
            DrawCraftLogMacro("Macro proposée",result.Suggested,actions);
            if(result.SearchIssue is { } searchIssue)ImGui.TextWrapped(searchIssue);
            ImGui.TextDisabled("Recherche bornée ; copie manuelle, aucune action lancée.");
        }
        finally{ImGui.End();}
    }
    private void DrawCraftLogMacro(string title,CraftLogMacro? macro,CraftActionCatalog catalog)
    {
        ImGui.PushID(title);
        try
        {
            ImGui.Separator();ImGui.TextColored(Accent,title);
            if(macro is null){ImGui.TextDisabled("Aucune séquence terminée compatible.");return;}
            ImGui.TextWrapped(macro.Name);
            var simulation=macro.Simulation;var maximum=craftLogInput!.Recipe.Simulation!.Quality;
            ImGui.TextUnformatted($"Qualité {simulation.Final.Quality:N0}/{maximum:N0} · {macro.Export.Actions} actions · {macro.Export.WaitSeconds} s");
            var job=craftLogInput.Recipe.CraftTypeId+8;var steps=simulation.Steps;
            for(var index=0;index<Math.Min(30,steps.Count);index++)
            {
                if(index%10!=0)ImGui.SameLine(0,3);
                var metadata=catalog.Find(job,steps[index].Action);
                DrawItemIcon(metadata is null ? null:new ItemDefinition(0,metadata.Name,false,metadata.Icon),new Vector2(25));
                if(ImGui.IsItemHovered())ImGui.SetTooltip($"{index+1}. {metadata?.Name ?? steps[index].Action.ToString()}");
            }
            if(steps.Count>30)ImGui.TextDisabled($"+ {steps.Count-30} actions · texte complet ci-dessous");
            foreach(var block in macro.Export.Pages)if(ImGui.SmallButton($"Copier bloc {block.Number}/{macro.Export.Pages.Count}"))ImGui.SetClipboardText(block.Text);
            if(ImGui.SmallButton("Modifier / enregistrer cette séquence"))
            {
                var source=craftLogInput;
                OpenCraftSimulation(source.Recipe);simulationActions.Clear();simulationActions.AddRange(simulation.Steps.Select(step=>step.Action));
                simulationLevel=source.Stats.Level;simulationCs=source.Stats.Craftsmanship;simulationControl=source.Stats.Control;
                simulationCp=source.Stats.Cp;simulationManipulation=source.Stats.ManipulationAllowed;simulationQuality=0;
                simulationCopiedOwner=source.Owner;simulationCopiedAt=characterStats.State.ObservedAt;
                simulationResult=simulation;simulationError=null;macroExportSimulation=simulation;craftMacroExport=macro.Export;craftMacroError=null;
                craftSolve.Cancel();IsOpen=true;
            }
            if(ImGui.TreeNode("Texte de la macro"))
            {
                try{foreach(var block in macro.Export.Pages)foreach(var line in block.Lines)ImGui.TextUnformatted(line);}
                finally{ImGui.TreePop();}
            }
        }
        finally{ImGui.PopID();}
    }
}
