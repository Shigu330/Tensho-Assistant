# GOAL sélectionné

ID: USE-002
OBJECTIVE: Étendre les usages d’objets à partir des catalogues natifs et du contexte partagé, puis poursuivre les 17 outils jusqu’à la réserve de quota de 5 %.
CURRENT_STATE: IMPLEMENTED / TESTED en 0.51.0, 334 tests/package verts ; 1 240 mandats et leurs demandes, candidats GC/aquarium et recettes dans un onglet Usages. Projection native partagée vérifiée sur sqpack ; aucune capture ou validation visuelle Dalamud nouvelle.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: ItemUseCatalog/SheetCopy/Loader ; MainWindow.ItemUses/Items/Tools/Settings ; DI ; ItemUseCatalogTests ; ItemUseProbe ; ApiProbe méthode de recherche ; docs.
IN_SCOPE: Références de catalogue statiques, icônes et remises déclarées par ligne, liens de contexte commun ; pas de demande quotidienne, acceptation ou déblocage inférés. Recettes conservées via service partagé.
OUT_OF_SCOPE: Revendiquer disponibilité actuelle ou validation native sans preuve, additionner les lignes/répétitions en quantités globales supposées, exécuter des remises. Bonus natif d’Abondance toujours non établi ; décodeur et autres capacités des 17 outils restent à développer.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: Relevé 2026-10-29 : 70 % disponibles sur 5 h et 57 % semaine ; réserve utilisateur 5 %. Objectif global actif.
NEXT_ACTION: USE-HOVER-003 : lire docs/USE-002.md puis MarketHoverReader/MarketHover/MainWindow.MarketHover. Le lecteur actuel est privé au marché et refuse les objets non commercialisables ; extraire un contexte commun, garder la politique réseau du marché et proposer des usages au survol opt-in sans dépendre d’un monde. GP inconnu documenté, tests projection/Macro Chain différés.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
