# État courant

CURRENT_GOAL: USE-002 — IMPLEMENTED / TESTED ; usages natifs reliés au contexte, voir docs/USE-002.md
CURRENT_MODEL_CLASS: HEAVY — index partagés, projection native et routage UI
RECOMMENDED_MODEL: HEAVY pour mutualiser le survol natif ; LIGHT pour les tâches mécaniques ; continuation autorisée
MODEL_ESCALATION: None
QUOTA: Relevé 2026-10-29 : 30 % consommés sur 5 h, 43 % semaine (70 % / 57 % disponibles). Réserve utilisateur 5 % sur la fenêtre limitante ; objectif global actif.
LAST_READ: RULES/STATUS/GOAL et étude GP relus ; bindings de calcul inspectés sans getter de bonus confirmé, puis sources ItemUse et feuilles locales vérifiées pour USE-002.
BUILD: COMPILED Release 0.51.0.0 ; sortie canonique bin/x64/Release
TESTS: TESTED — 334/334 tests ; package/versions/ZIP/exclusion hôte verts, zéro avertissement/erreur. Probe avec projection de production : 1 240 mandats, 2 516 candidats GC, 263 poissons, tous les objets et icônes renseignés résolus.
RUNTIME: Banque, stocks, carnet et préparation jusqu’à 0.5.27 confirmés par l’utilisateur. Fonctions 0.6–0.51 non validées en jeu. Tests projection et Macro Chain différés explicitement ; ne pas les redemander.
WORK_COMPLETED: Dix-sept domaines PARTIAL ; Item Use enrichi au-delà des recettes : mandats, candidats GC et aquarium, fiches natives repliables, demandes séparées, variantes et inconnus conservés. Usages et Craftimizer ont leurs routes distinctes, sélection commune. GP et observations précédentes conservés.
BLOCKER: Aucun blocage global. Le bonus natif d’Abondance reste inconnu : sources divergentes et aucun getter nommé confirmé dans les bindings étudiés. Ne pas inventer une formule ; travaux indépendants poursuivis.
RESUME_FROM: GOAL.md ; TESTING.md pour le protocole de la base.
NEXT_ACTION: Snapshot 0.51 puis USE-HOVER-003 : mutualiser le contexte d’objet survolé actuellement privé à MarketHoverReader pour afficher les usages en option. Conserver délai/cadence/priorités du marché, fonctionner sans prix activés ni monde connu pour les usages, éviter deux lecteurs ou deux panneaux concurrents. GP reste au périmètre avec son étude.

| Plugin | Coverage |
|---|---|
| Avant-Garde | PARTIAL — répertoire manuel d'indices natifs, équipements signalés, emplacements/stock/contexte et source datée ; thème courant/teintures/score/attache non déduits |
| Blue Mage Helper | PARTIAL — grimoire, numéros, descriptions, lieux renseignés et acquisition confirmée |
| Character Panel Refined | PARTIAL — attributs natifs, sans formules dérivées |
| Collections | PARTIAL — montures, mascottes, emotes et cartes Triple Triade ; inconnu distinct d'absent |
| Craftimizer | PARTIAL — simulation/recherche/export/séquences, observation et projection d'un coup normal ; conditions/rotation native/recettes spéciales et runtime à compléter |
| Duty Loot Preview | PARTIAL — consultation manuelle par contenu, coffres/récompenses, icônes/contexte, provenance et cache ; drops directs non interprétés, données externes partielles |
| ezMiniCactpot | PARTIAL — solveur exact manuel et mode observé opt-in LotteryDaily ; conseil actualisé, aucune commande ; adaptation/rendu natifs non validés en jeu |
| GatherBuddy | PARTIAL — sources/maps/horaires/météo statiques et point courant observé opt-in (objets/icônes/taux affichés, contexte) ; présence/prérequis/harpon et validation native non couverts |
| Item Use | PARTIAL — recettes, remises de mandats, candidats GC et poissons d’aquarium issus du jeu, onglet commun et icônes/contexte ; autres usages, demandes du jour, survol et runtime à compléter |
| LazyGatherer | PARTIAL — optimiseur manuel avec effets explicitement déclarés, observation du point et copie de ressources ; décodeur natif/bonus/régénération/procs/collectionnables et validation runtime à compléter |
| Macro Chain | PARTIAL — séquences à marqueur final, lancement explicite, arrêt, persistance ; natif à confirmer |
| Mappy | PARTIAL — navigateur natif, repères favoris persistants, ressources de zone et prévisions météo statiques ; météo forcée non observée |
| Monster Loot Hunter | PARTIAL — associations matériau/monstre, fiches/niveaux/lieux et carte de zone, transport/cadence partagés, contexte ; données communautaires partielles |
| Price Insight | PARTIAL — prix manuels/survol, coût direct et terminal des chaînes, cache/cadence/priorités communs, dates NQ/HQ par monde |
| QuestTracker | PARTIAL — états natifs, séquence, fiche et liens de prérequis/suivantes ; disponibilité non calculée |
| SortaKinda | PARTIAL — aperçu de règles sauvegardées, sans déplacement natif |
| TriadBuddy | PARTIAL — carnet/deck/solveur manuel, observation des faces opt-in expérimentale ; identités/règles/trait natifs et autres règles non établis |

