# GOAL sélectionné

ID: TRIAD-001E
OBJECTIVE: Ajouter Ordre et Bonus/Malus, avec timing et interactions cohérents, au simulateur et solveur Triple Triade ; poursuivre la couverture du projet.
CURRENT_STATE: IMPLEMENTED / TESTED — Ordre/Bonus/Malus intégrés en 0.25.0, 150 tests/package valides ; 384 fins de partie supplémentaires sur 96 combinaisons comparées au moteur indépendant, probe cartes natives passant. Macro Chain attend un essai reporté par l'utilisateur, sans bloquer ce travail indépendant.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: Domaines Gathering, Inventory, Collections, Market, Quests, Character, MiniGames ; MainWindow.* ; Plugin.cs ; tests et documents.
IN_SCOPE: Ordre des deux mains connues, préfixes de reconstruction, familles et rangs effectifs, timing avant/après captures et combos ; incompatibilité Bonus/Malus refusée.
OUT_OF_SCOPE: Déclarer les 17 plugins remplacés ; prétendre une validation en jeu sans observation.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: 2026-10-28, 46 % disponibles sur 5 h et 92 % semaine au dernier relevé ; continuer selon instruction utilisateur.
NEXT_ACTION: Sauvegarder 0.25.0 puis étudier TRIAD-002 : API de lecture passive du match, des cartes et règles ; sonder les structures locales avant adaptation. Conserver les informations cachées inconnues et le simulateur manuel distinct. Les autres domaines de la roadmap restent dans le goal global.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
