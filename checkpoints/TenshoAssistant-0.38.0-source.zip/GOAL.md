# GOAL sélectionné

ID: CRAFT-SOLVE-001
OBJECTIVE: Suggestions de séquences sur le modèle de craft normal, cible explicite et recherche bornée/annulable ; poursuivre le projet.
CURRENT_STATE: IMPLEMENTED / TESTED — moteur partagé, faisceau borné, replay et session/états UI intégrés en 0.38.0, 252 tests/package verts. Oracle indépendant 36 scénarios et témoin multi-effets passant ; probe natif à attributs fictifs 2 actions / 204 transitions. Aucune activation ou validation en jeu ; Macro Chain reporté.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: CraftSolver/CraftSolveSession, transition CraftSimulation commune ; MainWindow.CraftSolver/Simulation/Tools ; lifecycle ; CraftSolverTests ; CraftSimulationProbe ; documents.
IN_SCOPE: Recettes/actions normales couvertes, cible qualité, proposition ou résultat sous cible/absence explicites, limites visibles, annulation, contexte et replay, application manuelle dans le simulateur.
OUT_OF_SCOPE: Déclarer les 17 plugins remplacés ; prétendre une validation en jeu sans observation.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: 2026-10-28, 37 % disponibles sur 5 h et 75 % semaine au dernier relevé ; continuer selon instruction utilisateur.
NEXT_ACTION: Snapshot 0.38.0 puis CRAFT-ACTIONS-002 : actions déterministes avancées, traits/prérequis natifs et couverture du même moteur/solveur/export ; suggestions en cours de synthèse à étudier avec preuves ensuite. Garder les 17 domaines PARTIAL et le goal global actif ; Macro Chain différé.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
