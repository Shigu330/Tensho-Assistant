namespace TenshoAssistant.Inventory;

public enum InventoryQualityFilter { Any, Normal, HighQuality }
public sealed record InventorySortCriterion(InventorySortField Field,bool Descending=false);
public sealed record InventorySortZone(string Name,int Start,int Count,uint CategoryId=0,InventoryQualityFilter Quality=InventoryQualityFilter.Any,string Query="",bool Preserve=false,bool ReverseFill=false);
public sealed record InventorySortProfile(ulong CharacterId,BankStorageKind? Kind,ulong StorageId,IReadOnlyList<InventorySortCriterion> Criteria,IReadOnlyList<InventorySortZone> Zones);

public static class InventorySortRules
{
    public static bool MatchesScope(InventorySortProfile profile,InventorySortScope scope)
        =>profile.CharacterId==scope.CharacterId && profile.Kind==scope.Storage?.Kind && profile.StorageId==(scope.Storage?.StorageId ?? 0);
    public static InventorySortProfile Default(InventorySortScope scope,InventorySortField sort=InventorySortField.Name,bool descending=false)
        =>new(scope.CharacterId,scope.Storage?.Kind,scope.Storage?.StorageId ?? 0,Array.AsReadOnly(new[]{new InventorySortCriterion(sort,descending)}),Array.AsReadOnly(Array.Empty<InventorySortZone>()));
    public static InventorySortProfile Copy(InventorySortProfile value)
        =>value with{Criteria=Array.AsReadOnly(value.Criteria.ToArray()),Zones=Array.AsReadOnly(value.Zones.ToArray())};
    public static void Validate(InventorySortProfile profile,InventorySortScope scope)
    {
        if(!MatchesScope(profile,scope) || profile.Criteria is null || profile.Zones is null || profile.Criteria.Count is <1 or >4
            || profile.Criteria.Any(c=>c is null || !Enum.IsDefined(c.Field)) || profile.Criteria.Select(c=>c.Field).Distinct().Count()!=profile.Criteria.Count
            || profile.Zones.Count>32)throw new InvalidOperationException("Profil de tri invalide : propriétaire, critères ou nombre de zones.");
        var reserved=new bool[scope.Capacity];
        foreach(var zone in profile.Zones)
        {
            if(zone is null || string.IsNullOrWhiteSpace(zone.Name) || zone.Name.Length>80 || zone.Query is null || zone.Query.Length>128
                || !Enum.IsDefined(zone.Quality) || zone.Start<0 || zone.Count<=0 || zone.Start>scope.Capacity-zone.Count || zone.Preserve && zone.ReverseFill)
                throw new InvalidOperationException("Zone invalide : nom, filtres ou limites de cases.");
            for(var slot=zone.Start;slot<zone.Start+zone.Count;slot++)
            {
                if(reserved[slot])throw new InvalidOperationException("Les zones de cases ne doivent pas se chevaucher.");
                reserved[slot]=true;
            }
        }
    }
    public static InventorySortProfile Load(IEnumerable<InventorySortProfile>? saved,InventorySortScope scope,InventorySortField legacy,bool descending)
    {
        var matches=(saved ?? []).Where(profile=>profile is not null && MatchesScope(profile,scope)).Take(2).ToArray();
        if(matches.Length>1)throw new InvalidOperationException("Plusieurs profils existent pour ce rangement ; réinitialisez son brouillon puis enregistrez-le.");
        var profile=matches.SingleOrDefault() ?? Default(scope,legacy,descending);Validate(profile,scope);return Copy(profile);
    }
    public static List<InventorySortProfile> Save(IEnumerable<InventorySortProfile>? saved,InventorySortProfile profile,InventorySortScope scope)
    {
        Validate(profile,scope);
        var next=(saved ?? []).Where(value=>value is not null && !MatchesScope(value,scope)).ToList();
        if(next.Count>=128)throw new InvalidOperationException("La limite de 128 profils de rangement est atteinte.");
        next.Add(Copy(profile));return next;
    }

    public static InventorySortResult Build(IEnumerable<InventoryContainerSnapshot> containers,InventorySortScope scope,InventorySortProfile profile,
        Func<uint,(string Name,uint Category)> describe)
    {
        Validate(profile,scope);
        var source=containers.ToArray();
        var all=InventorySortPreview.Build(source,scope.Capacity,profile.Criteria,describe);
        if(profile.Zones.Count==0)return all;
        var slots=new InventoryPreviewStack?[scope.Capacity];var reserved=new bool[scope.Capacity];
        var remaining=all.Stacks.ToList();
        foreach(var zone in profile.Zones)
            for(var slot=zone.Start;slot<zone.Start+zone.Count;slot++)reserved[slot]=true;
        if(profile.Zones.Any(zone=>zone.Preserve))
        {
            // A protected zone needs actual visual indices, never a guessed packed order from an old cache.
            var physical=scope.Extract(source);
            if(physical.Count!=all.Stacks.Count)throw new InvalidOperationException("Les positions visuelles ne couvrent pas exactement le rangement protégé.");
            foreach(var zone in profile.Zones.Where(zone=>zone.Preserve))
            foreach(var value in all.Stacks.Where(value=>value.Stack.DisplayIndex>=zone.Start && value.Stack.DisplayIndex<zone.Start+zone.Count))
            {slots[value.Stack.DisplayIndex]=value;remaining.Remove(value);}
        }
        foreach(var zone in profile.Zones.Where(zone=>!zone.Preserve))
        {
            var matches=remaining.Where(value=>Matches(value,zone,describe(value.Stack.Item.Id.Value))).Take(zone.Count).ToArray();
            for(var index=0;index<matches.Length;index++)
            {slots[zone.ReverseFill ? zone.Start+zone.Count-1-index:zone.Start+index]=matches[index];remaining.Remove(matches[index]);}
        }
        var free=Enumerable.Range(0,scope.Capacity).Where(slot=>!reserved[slot]).ToArray();
        if(remaining.Count>free.Length)
            throw new InvalidOperationException("Les cases non réservées ne suffisent pas aux autres piles. Réduisez les zones ou libérez des cases.");
        for(var index=0;index<remaining.Count;index++)slots[free[index]]=remaining[index];
        return new(scope.Capacity,Array.AsReadOnly(slots.OfType<InventoryPreviewStack>().ToArray()),Array.AsReadOnly(slots));
    }
    private static bool Matches(InventoryPreviewStack value,InventorySortZone zone,(string Name,uint Category) label)
        =>(zone.CategoryId==0 || label.Category==zone.CategoryId)
          && (zone.Quality==InventoryQualityFilter.Any || value.Stack.Item.IsHighQuality==(zone.Quality==InventoryQualityFilter.HighQuality))
          && (string.IsNullOrWhiteSpace(zone.Query) || label.Name.Contains(zone.Query.Trim(),StringComparison.OrdinalIgnoreCase)
              || value.Stack.Item.Id.Value.ToString().Contains(zone.Query.Trim(),StringComparison.Ordinal));
}
