using System.Numerics;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.Inventory;
using TenshoAssistant.Items;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private InventorySnapshot? sortingViewSnapshot;
    private ItemCatalog? sortingViewCatalog;
    private InventorySortResult? sortingViewResult;
    private InventorySortProfile? sortingViewRules;
    private string? sortApplyError;
    private void DrawSortPreview()
    {
        Heading("Organisation de l'inventaire", "Prévisualisez une règle, puis appliquez-la au rangement en direct.");
        var character = bankBridge.State.CharacterId;
        if (character == 0) { ImGui.TextDisabled("Connectez un personnage pour préparer son inventaire."); return; }
        var entries = bank.State.Entries.Where(entry => entry.Key.CharacterId == character).ToArray();
        var open=new[]{bankBridge.State.Retainer,bankBridge.State.Saddlebag,bankBridge.State.Premium}
            .Where(context=>context is not null && context.Key.CharacterId==character).Select(context=>context!).ToArray();
        var captured=visualSort.State.Capture;
        var choices=entries.Select(entry=>(entry.Key,entry.Name)).Concat(open.Select(context=>(context.Key,context.Name))).ToList();
        if(captured?.Scope.Storage is { } capturedKey && capturedKey.CharacterId==character)choices.Add((capturedKey,captured.Name));
        var origins=choices.DistinctBy(value=>value.Key).ToArray();
        if(sortPreviewOrigin is { } selected && !origins.Any(origin=>origin.Key==selected))sortPreviewOrigin=null;
        var chosenName=sortPreviewOrigin is { } chosenKey ? origins.First(origin=>origin.Key==chosenKey).Name:"Inventaire personnel";
        ImGui.SetNextItemWidth(260);
        if (ImGui.BeginCombo("Rangement", chosenName))
        {
            try
            {
                if (ImGui.Selectable("Inventaire personnel", sortPreviewOrigin is null)) sortPreviewOrigin = null;
                foreach (var origin in origins)
                    if (ImGui.Selectable($"{origin.Name}##{origin.Key}", sortPreviewOrigin == origin.Key)) {sortPreviewOrigin=origin.Key;sortApplyError=null;}
            }
            finally { ImGui.EndCombo(); }
        }
        var scope=sortPreviewOrigin is { } storage ? InventorySortScope.FromStorage(storage):InventorySortScope.Personal(character);
        var live=captured is not null && captured.Scope==scope ? captured:null;
        var context=open.FirstOrDefault(value=>value.Key==sortPreviewOrigin);
        if(scope.Storage is not null)
        {
            ImGui.BeginDisabled(visualSort.State.Pending || context?.Loaded!=true);
            try
            {
                if(ImGui.Button("Lire le rangement ouvert pour l’aperçu"))
                {visualSort.RequestCapture(scope,DateTimeOffset.UtcNow);sortApplyError=null;}
            }
            finally{ImGui.EndDisabled();}
            ImGui.TextWrapped("Lecture manuelle en direct, distincte de l’import en banque. Ouvrez ce rangement pour le lire ou appliquer son ordre.");
        }
        if(visualSort.State.Message is { } status)ImGui.TextWrapped(status);
        var imported=entries.FirstOrDefault(entry=>entry.Key==sortPreviewOrigin);
        var snapshot=scope.Storage is null ? inventory.Current:live?.Snapshot ?? imported?.Snapshot;
        var containers=snapshot?.Containers.Values.Where(container=>container.Location.Owner.Value==scope.InventoryOwner
            && container.Location.Container.Value>=scope.FirstContainer && container.Location.Container.Value<scope.FirstContainer+scope.ContainerCount).ToArray() ?? [];
        if (containers.Length != scope.ContainerCount || containers.Any(container => container.Coverage != InventoryCoverage.Complete))
        {
            ImGui.TextWrapped("Le rangement doit être entièrement observé pour calculer l'aperçu.");
            return;
        }
        if (itemCatalog.State.Catalog is not { } catalog) { DrawCatalogStatus(); return; }
        var rules=DrawSortRules(scope,catalog);if(rules is null)return;
        var capacity=scope.Capacity;
        if (sortingViewResult is null || !ReferenceEquals(sortingViewSnapshot, snapshot) || !ReferenceEquals(sortingViewCatalog, catalog)
            || !ReferenceEquals(sortingViewRules,rules))
        {
            try{sortingViewResult=InventorySortRules.Build(containers,scope,rules,id=>(catalog.Find(id)?.Name ?? $"ID {id}",catalog.Find(id)?.UiCategoryId ?? 0));}
            catch(Exception error){ImGui.TextWrapped("Aperçu impossible : "+error.Message);return;}
            sortingViewSnapshot = snapshot; sortingViewCatalog = catalog;
            sortingViewRules=rules;
        }
        var preview = sortingViewResult;
        ImGui.Spacing();
        if(scope.Storage is null || live is not null)
        {
            ImGui.BeginDisabled(visualSort.State.Pending || scope.Storage is not null
                && (context?.Loaded!=true || live?.Fresh(character,DateTimeOffset.UtcNow)!=true));
            try
            {
                if(ImGui.Button(scope.Storage is null ? "Appliquer cet ordre aux quatre sacs":"Appliquer cet ordre au rangement ouvert"))
                {
                    try
                    {
                        sortApplyError=visualSort.Request(InventoryVisualSortPlan.Build(snapshot!,preview,scope),DateTimeOffset.UtcNow)
                            ? null:"Demande refusée ; relisez le rangement ouvert avant de réessayer.";
                    }
                    catch(Exception error){sortApplyError=error.Message;}
                }
            }
            finally{ImGui.EndDisabled();}
            ImGui.TextWrapped("Modifie seulement l’ordre affiché dans le jeu. Les piles et quantités physiques sont conservées. Enregistrer la règle ne lance aucun tri.");
        }
        else ImGui.TextWrapped("Aperçu du cache importé. Lisez le rangement ouvert avant de pouvoir appliquer le tri.");
        if(sortApplyError is { } applyError)ImGui.TextWrapped(applyError);
        ImGui.TextDisabled($"{preview.Stacks.Count}/{capacity} cases occupées · piles et qualités conservées");
        if(scope.Storage is not null)ImGui.TextDisabled(live is null ? $"Cache manuel : {snapshot!.ObservedAt:yyyy-MM-dd HH:mm:ss} UTC"
            : $"Lecture directe : {live.Snapshot.ObservedAt:HH:mm:ss} UTC · validité deux minutes, rangement ouvert requis");
        const float slot = 34;
        var padding=ImGui.GetStyle().WindowPadding;
        var frameWidth=5*(slot+4)+2*padding.X+2;
        var frameHeight=(scope.SlotsPerContainer/5)*(slot+4)+ImGui.GetTextLineHeightWithSpacing()+2*padding.Y+4;
        var spacing=ImGui.GetStyle().ItemSpacing.X;
        var framesPerRow=Math.Max(1,(int)((ImGui.GetContentRegionAvail().X+spacing)/(frameWidth+spacing)));
        for (var bag = 0; bag < scope.ContainerCount; bag++)
        {
            if (bag % framesPerRow != 0) ImGui.SameLine();
            var visible = ImGui.BeginChild($"SortPreviewBag{bag}", new Vector2(frameWidth,frameHeight), true,
                ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoScrollWithMouse);
            try
            {
                if (!visible) continue;
                ImGui.TextColored(Accent,$"Sac {bag+1} · {bag*scope.SlotsPerContainer+1}–{(bag+1)*scope.SlotsPerContainer}");
                ImGui.PushStyleVar(ImGuiStyleVar.CellPadding,new Vector2(2));
                try
                {
                    if (!ImGui.BeginTable("Slots", 5, ImGuiTableFlags.SizingFixedFit)) continue;
                    try
                    {
                        for (var index = 0; index < scope.SlotsPerContainer; index++)
                        {
                            ImGui.TableNextColumn();
                            ImGui.PushID(index);
                            try
                            {
                                var target = bag * scope.SlotsPerContainer + index;
                                var previewStack=preview.Slots is { } positions ? positions[target]:target<preview.Stacks.Count ? preview.Stacks[target]:null;
                                if (previewStack is { } positioned)
                                {
                                    var stack=positioned.Stack;
                                    var corner=ImGui.GetCursorScreenPos();
                                    DrawBankSlot(new(stack.Item.Id.Value, stack.Item.IsHighQuality ? 0 : stack.Quantity,
                                        stack.Item.IsHighQuality ? stack.Quantity : 0, ""), slot);
                                    ImGui.SetCursorScreenPos(corner);ImGui.Dummy(new Vector2(slot));
                                }
                                else
                                {
                                    var corner=ImGui.GetCursorScreenPos();
                                    ImGui.GetWindowDrawList().AddRectFilled(corner,corner+new Vector2(slot),ImGui.GetColorU32(ImGuiCol.FrameBg),4);
                                    ImGui.Dummy(new Vector2(slot));
                                }
                                if(rules.Zones.FirstOrDefault(zone=>target>=zone.Start && target<zone.Start+zone.Count) is { } reserved)
                                {
                                    var min=ImGui.GetItemRectMin();
                                    ImGui.GetWindowDrawList().AddRect(min,min+new Vector2(slot),ImGui.GetColorU32(reserved.Preserve ? Success:Accent),4);
                                    if(ImGui.IsItemHovered())ImGui.SetTooltip(previewStack is { } zoneItem
                                        ? $"{catalog.Find(zoneItem.Stack.Item.Id.Value)?.Name ?? $"Objet {zoneItem.Stack.Item.Id.Value}"}\n{(zoneItem.Stack.Item.IsHighQuality ? "HQ":"NQ")} : {zoneItem.Stack.Quantity:N0}\nCase {target+1} · {reserved.Name}{(reserved.Preserve ? " · protégée":"") }"
                                        : $"Case vide {target+1} · {reserved.Name}{(reserved.Preserve ? " · protégée":"")}");
                                }
                            }
                            finally { ImGui.PopID(); }
                        }
                    }
                    finally { ImGui.EndTable(); }
                }
                finally { ImGui.PopStyleVar(); }
            }
            finally { ImGui.EndChild(); }
        }
    }
}
