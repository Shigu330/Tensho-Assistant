# GOAL sélectionné

ID: SORT-PROTECTED-005
OBJECTIVE: Protéger les cases choisies et contrôler le sens de remplissage, puis poursuivre les 17 domaines jusqu’à la réserve de quota de 5 %.
CURRENT_STATE: IMPLEMENTED / TESTED en 0.57.0, 374 tests/package et Newtonsoft trois modes verts ; protection prioritaire, vrais indices visuels et permutation partagée. Rendu/application/persistance natifs non observés.
FILES: Inventory/InventorySortRules et InventorySortScope ; MainWindow.SortRules/SortPreview/Tools ; InventoryProtectedSortTests ; ConfigSerializationProbe ; docs/SORT-PROTECTED-005.md.
IN_SCOPE: Cases occupées/vides protégées avant les filtres, inversion des cibles de zone filtrée, refus des indices incomplets/ambigus, compatibilité des profils v1. Aucun nouveau lecteur ou bridge natif.
OUT_OF_SCOPE: Deviner l’ordre d’un cache, promettre une identité physique particulière d’une case vide, appliquer sans capture directe, tri automatique ; filtres avancés à compléter. Tous les domaines restent PARTIAL.
VALIDATION: Verify.ps1 374/374, package/versions/ZIP/exclusion hôte verts, zéro avertissement/erreur ; cinq groupes dont 20 scènes multi-scopes, positions/provenance physique/quantités et JSON v1. Newtonsoft None/Auto/Objects passants.
QUOTA: Relevé 2026-10-29 : 21 % disponibles sur 5 h et 49 % semaine ; réserve utilisateur 5 %. Objectif global actif.
NEXT_ACTION: Snapshot 0.57 puis SORT-FILTERS-006 : filtres équipement/marché sur les métadonnées Item communes, avec Unknown distinct de false. Garder l’inconnu GP ; essais projection/Macro Chain différés, sans les redemander.
DEFINITION_OF_DONE: Tranche intégrée compilée, tests/package verts, limites documentées et sauvegarde source ; aucun domaine global promu complet sans preuve.
