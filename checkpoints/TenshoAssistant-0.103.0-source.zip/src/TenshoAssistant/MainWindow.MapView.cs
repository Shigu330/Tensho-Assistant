using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Textures;
using TenshoAssistant.Maps;

namespace TenshoAssistant;

/// <summary>MAP-VIEW-016: the game map texture with fixed icons, the player and a flag on right click (docs/MAP-016-PLAN.md).</summary>
internal sealed partial class MainWindow
{
    // Game map icon of the red flag marker (to confirm in game; a drawn flag is the fallback).
    private const uint FlagIcon=60561;
    private MapLiveReader? mapLive;
    private MapMarkerSource? mapMarkers;
    private bool mapViewOpen;
    private bool mapViewFollow=true;
    private uint mapViewMapId;
    private float mapZoom=0.5f;
    private Vector2 mapPan;
    private Vector2 mapContextPixel;
    internal void ConfigureMapView(MapLiveReader live,MapMarkerSource markers){mapLive=live;mapMarkers=markers;}
    private void OpenMapView(uint mapId){mapViewMapId=mapId;mapViewFollow=mapId==0;mapViewOpen=true;}

    public void DrawMapView()
    {
        if(windowDisposed || !mapViewOpen || maps.State.Catalog is not { } catalog)return;
        using var theme=UI.FfxivTheme.Apply();
        var viewport=ImGui.GetMainViewport();
        if(mapResize is { } resize)
        {
            // Enlarge: 90 % of the screen, centred; a second click restores the previous size.
            ImGui.SetNextWindowSize(resize.Size,ImGuiCond.Always);ImGui.SetNextWindowPos(resize.Position,ImGuiCond.Always);mapResize=null;
        }
        else ImGui.SetNextWindowSize(new Vector2(720,760),ImGuiCond.FirstUseEver);
        var visible=ImGui.Begin(localization.Get("MapView.Title")+"###TenshoMapView",ref mapViewOpen,ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoScrollWithMouse);
        try
        {
            if(!visible)return;
            var live=mapLive?.State;
            if(mapViewFollow && live is { MapId:>0 })mapViewMapId=live.MapId;
            var map=catalog.Find(mapViewMapId) ?? mapMarkers?.Overview(mapViewMapId);
            if(map is not null)mapLive?.Watch(map.TerritoryId);
            DrawMapPath(catalog,map);
            DrawMapToolbar(map,live,viewport);
            if(map is null || map.TexturePath.Length==0){ImGui.TextWrapped(localization.Get("MapView.Unavailable"));return;}
            DrawMapCanvas(map,live);
        }
        finally{ImGui.End();}
    }

    private (Vector2 Size,Vector2 Position)? mapResize;
    private (Vector2 Size,Vector2 Position)? mapRestore;
    private bool mapFitRequested;
    private bool mapDragged;
    private void NavigateMap(uint mapId){if(mapId==0)return;mapViewMapId=mapId;mapViewFollow=false;mapFitRequested=true;}

    // Breadcrumb like the game map: world › region › zone · subzone, each level clickable.
    private void DrawMapPath(MapCatalog catalog,MapDefinition? map)
    {
        if(map is null || mapMarkers is null){ImGui.TextColored(Accent,localization.Get("MapView.NoMap"));return;}
        var chain=new List<MapDefinition>();
        for(var current=map;current is not null && chain.Count<4;)
        {
            chain.Insert(0,current);
            var parent=mapMarkers.Parent(current);
            current=parent==0 || parent==current.MapId ? null:catalog.Find(parent) ?? mapMarkers.Overview(parent);
        }
        for(var index=0;index<chain.Count;index++)
        {
            var step=chain[index];var last=index==chain.Count-1;
            var label=last && step.Subzone.Length>0 ? $"{step.Zone} · {step.Subzone}":step.Zone.Length>0 ? step.Zone:localization.Get("MapView.NoMap");
            if(index>0){ImGui.SameLine(0,4);ImGui.TextDisabled(">");ImGui.SameLine(0,4);}
            if(last)ImGui.TextColored(Accent,label);
            else if(ImGui.SmallButton($"{label}##Path{step.MapId}"))NavigateMap(step.MapId);
        }
    }

    private void DrawMapToolbar(MapDefinition? map,MapLiveState? live,ImGuiViewportPtr viewport)
    {
        ImGui.BeginDisabled(map is null || mapMarkers?.Parent(map) is null or 0);
        try{if(ImGui.SmallButton(localization.Get("MapView.Up")) && map is not null)NavigateMap(mapMarkers!.Parent(map));}
        finally{ImGui.EndDisabled();}
        ImGui.SameLine();ImGui.Checkbox(localization.Get("MapView.Follow"),ref mapViewFollow);
        // ASCII minus: the game font has no U+2212 glyph (it rendered as "=").
        ImGui.SameLine();if(ImGui.SmallButton(" - "))mapZoom=MapProjection.ClampZoom(mapZoom/1.25f);
        ImGui.SameLine();var percent=mapZoom*100;ImGui.SetNextItemWidth(110);
        if(ImGui.SliderFloat("##MapZoom",ref percent,15,400,"%.0f %%"))mapZoom=MapProjection.ClampZoom(percent/100);
        ImGui.SameLine();if(ImGui.SmallButton("+"))mapZoom=MapProjection.ClampZoom(mapZoom*1.25f);
        ImGui.SameLine();if(ImGui.SmallButton(localization.Get("MapView.Fit"))){mapFitRequested=true;mapViewFollow=false;}
        ImGui.SameLine();
        if(ImGui.SmallButton(localization.Get(mapRestore is null ? "MapView.Enlarge":"MapView.Restore")))
        {
            if(mapRestore is { } previous){mapResize=previous;mapRestore=null;}
            else{mapRestore=(ImGui.GetWindowSize(),ImGui.GetWindowPos());var size=viewport.WorkSize*0.9f;mapResize=(size,viewport.WorkPos+(viewport.WorkSize-size)/2);}
            mapFitRequested=true;
        }
        if(map is not null && map.TerritoryId!=0 && live?.Flight is { } flight && flight.TerritoryId==map.TerritoryId)
        {
            ImGui.SameLine();
            if(flight.Total==0)ImGui.TextDisabled(localization.Get(flight.MountAllowed ? "MapView.FlightNoCurrents":"MapView.FlightNoMount"));
            else if(flight.Complete)ImGui.TextColored(Success,localization.Get("MapView.FlightYes"));
            else ImGui.TextColored(UI.FfxivTheme.Warning,localization.Format("MapView.FlightPartial",flight.Unlocked,flight.Total));
        }
    }

    private void DrawMapCanvas(MapDefinition map,MapLiveState? live)
    {
        var origin=ImGui.GetCursorScreenPos();var size=Vector2.Max(ImGui.GetContentRegionAvail(),new Vector2(64));
        ImGui.InvisibleButton("MapCanvas",size,ImGuiButtonFlags.MouseButtonLeft | ImGuiButtonFlags.MouseButtonRight);
        var hovered=ImGui.IsItemHovered();var io=ImGui.GetIO();
        var player=live is not null && live.MapId==map.MapId ? MapProjection.PixelFromWorld(live.Position,map):(Vector2?)null;
        if(hovered && ImGui.IsMouseClicked(ImGuiMouseButton.Left))mapDragged=false;
        if(ImGui.IsItemActive() && ImGui.IsMouseDragging(ImGuiMouseButton.Left)){mapPan+=io.MouseDelta;mapViewFollow=false;mapDragged=true;}
        if(hovered && io.MouseWheel!=0)
        {
            // Zoom around the cursor: the pixel under the mouse stays under the mouse.
            var before=(io.MousePos-origin-mapPan)/mapZoom;
            mapZoom=MapProjection.ClampZoom(mapZoom*(io.MouseWheel>0 ? 1.15f:1/1.15f));
            mapPan=io.MousePos-origin-before*mapZoom;
        }
        if(mapFitRequested)
        {
            // Fit: the whole 2048-pixel map inside the canvas, centred.
            mapZoom=MapProjection.ClampZoom(Math.Min(size.X,size.Y)/MapProjection.TextureSize);
            mapPan=(size-new Vector2(MapProjection.TextureSize*mapZoom))/2;mapFitRequested=false;
        }
        if(mapViewFollow && player is { } centred)mapPan=size/2-centred*mapZoom;
        var draw=ImGui.GetWindowDrawList();
        draw.PushClipRect(origin,origin+size,true);
        try
        {
            draw.AddRectFilled(origin,origin+size,ImGui.GetColorU32(UI.FfxivTheme.Background));
            if(textures.GetFromGame(map.TexturePath).TryGetWrap(out var texture,out _) && texture is not null)
                draw.AddImage(texture.Handle,origin+mapPan,origin+mapPan+new Vector2(MapProjection.TextureSize*mapZoom));
            else draw.AddText(origin+new Vector2(8),ImGui.GetColorU32(UI.FfxivTheme.TextMuted),localization.Get("MapView.Loading"));
            string? tooltip=null;
            var iconSize=Math.Clamp(28*mapZoom*1.6f,16,40);
            var markers=mapMarkers?.For(map.MarkerRange) ?? [];
            // Place names first, under the icons, in large outlined text like the game map.
            var font=ImGui.GetFont();var nameSize=Math.Clamp(ImGui.GetFontSize()*2.4f*mapZoom,ImGui.GetFontSize(),ImGui.GetFontSize()*2.2f);
            foreach(var marker in markers.Where(marker=>marker.Icon==0))
            {
                var centre=origin+mapPan+new Vector2(marker.X,marker.Y)*mapZoom;
                var text=ImGui.CalcTextSize(marker.Label)*(nameSize/ImGui.GetFontSize());var corner=centre-text/2;
                var outline=ImGui.GetColorU32(new Vector4(0.96f,0.93f,0.84f,0.9f));
                foreach(var shift in new[]{new Vector2(-1,0),new Vector2(1,0),new Vector2(0,-1),new Vector2(0,1)})
                    draw.AddText(font,nameSize,corner+shift,outline,marker.Label);
                draw.AddText(font,nameSize,corner,ImGui.GetColorU32(new Vector4(0.30f,0.22f,0.12f,1)),marker.Label);
            }
            uint? linkUnderMouse=null;
            foreach(var marker in markers.Where(marker=>marker.Icon!=0))
            {
                var centre=origin+mapPan+new Vector2(marker.X,marker.Y)*mapZoom;
                if(hovered && marker.LinkMapId!=0 && Vector2.Distance(io.MousePos,centre)<=iconSize/2)linkUnderMouse=marker.LinkMapId;
                if(textures.TryGetFromGameIcon(new GameIconLookup(marker.Icon),out var shared) && shared.TryGetWrap(out var icon,out _) && icon is not null)
                    draw.AddImage(icon.Handle,centre-new Vector2(iconSize/2),centre+new Vector2(iconSize/2));
                if(hovered && marker.Label.Length>0 && Vector2.Distance(io.MousePos,centre)<=iconSize/2)tooltip=marker.Label;
            }
            if(live is { Flag:{ } flag } && live.FlagMapId==map.MapId)
            {
                var flagPixel=MapProjection.PixelFromWorld(new Vector3(flag.X,0,flag.Y),map);var at=origin+mapPan+flagPixel*mapZoom;
                if(textures.TryGetFromGameIcon(new GameIconLookup(FlagIcon),out var shared) && shared.TryGetWrap(out var icon,out _) && icon is not null)
                    draw.AddImage(icon.Handle,at-new Vector2(iconSize/2),at+new Vector2(iconSize/2));
                else draw.AddTriangleFilled(at,at+new Vector2(0,-14),at+new Vector2(10,-10),ImGui.GetColorU32(UI.FfxivTheme.Error));
            }
            if(player is { } here)DrawPlayerArrow(draw,origin+mapPan+here*mapZoom,live!.Rotation);
            if(hovered)
            {
                var coordinate=MapProjection.CoordinateFromPixel((io.MousePos-origin-mapPan)/mapZoom,map);
                var label=localization.Format("MapView.Cursor",coordinate.X.ToString("0.0"),coordinate.Y.ToString("0.0"));
                var box=ImGui.CalcTextSize(label)+new Vector2(10,6);
                draw.AddRectFilled(origin+new Vector2(6,size.Y-box.Y-6),origin+new Vector2(6+box.X,size.Y-6),ImGui.GetColorU32(UI.FfxivTheme.Panel),3);
                draw.AddText(origin+new Vector2(11,size.Y-box.Y-3),ImGui.GetColorU32(UI.FfxivTheme.Text),label);
            }
            if(tooltip is not null)ImGui.SetTooltip(linkUnderMouse is null ? tooltip:tooltip+"\n"+localization.Get("MapView.OpenLink"));
            // Region and world maps: a click (not a drag) on a linked icon opens that map, like the game.
            if(linkUnderMouse is { } link && ImGui.IsMouseReleased(ImGuiMouseButton.Left) && !mapDragged)NavigateMap(link);
        }
        finally{draw.PopClipRect();}
        if(hovered && ImGui.IsMouseClicked(ImGuiMouseButton.Right)){mapContextPixel=(io.MousePos-origin-mapPan)/mapZoom;ImGui.OpenPopup("MapViewContext");}
        if(ImGui.BeginPopup("MapViewContext"))
        {
            try
            {
                var coordinate=MapProjection.CoordinateFromPixel(mapContextPixel,map);
                ImGui.TextDisabled(localization.Format("MapView.Cursor",coordinate.X.ToString("0.0"),coordinate.Y.ToString("0.0")));
                ImGui.BeginDisabled(map.TerritoryId==0);
                try{if(ImGui.Selectable(localization.Get("MapView.Flag")))OpenMapPoint(map,coordinate.X,coordinate.Y);}
                finally{ImGui.EndDisabled();}
                ImGui.BeginDisabled(live?.Flag is null);
                try{if(ImGui.Selectable(localization.Get("MapView.RemoveFlag")))mapLive?.RemoveFlag();}
                finally{ImGui.EndDisabled();}
                ImGui.BeginDisabled(map.TerritoryId==0);
                try{if(ImGui.Selectable(localization.Get("MapView.UseInTool"))){selectedMapId=map.MapId;mapX=coordinate.X;mapY=coordinate.Y;bookmarkSaved=false;page=Page.Maps;IsOpen=true;}}
                finally{ImGui.EndDisabled();}
            }
            finally{ImGui.EndPopup();}
        }
        if(mapOpenError is { } error)ImGui.SetTooltip(error);
    }

    // Game rotation 0 faces +Z, which is "down" on the map texture.
    private static void DrawPlayerArrow(ImDrawListPtr draw,Vector2 centre,float rotation)
    {
        var forward=new Vector2(MathF.Sin(rotation),MathF.Cos(rotation));var side=new Vector2(-forward.Y,forward.X);
        var colour=ImGui.GetColorU32(UI.FfxivTheme.Gold);
        draw.AddTriangleFilled(centre+forward*12,centre-forward*7+side*7,centre-forward*7-side*7,colour);
        draw.AddCircle(centre,4,ImGui.GetColorU32(UI.FfxivTheme.Text),12,1.5f);
    }
}
