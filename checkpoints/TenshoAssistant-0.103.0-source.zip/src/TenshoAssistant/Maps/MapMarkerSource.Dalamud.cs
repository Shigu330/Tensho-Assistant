using Dalamud.Plugin.Services;
using Lumina.Excel.Sheets;

namespace TenshoAssistant.Maps;

// Fixed map icon in texture pixels (MapMarker X/Y), with its game icon and optional label. Icon 0 = a place name drawn as text.
// LinkMapId: on region and world maps, DataType 1 markers open that map (probe: checkpoints/0.103.0-maps-probe.log).
public sealed record MapIconMarker(float X,float Y,uint Icon,string Label,uint LinkMapId=0);

/// <summary>
/// Game data for the map window, copied once per key: fixed markers per range, and the overview maps (regions, world)
/// that the zone catalogue leaves out because they have no territory.
/// </summary>
internal sealed class MapMarkerSource
{
    private readonly IDataManager data;private readonly IPluginLog log;
    private readonly Dictionary<uint,IReadOnlyList<MapIconMarker>> cache=[];
    private Dictionary<uint,MapDefinition>? overviews;
    private Dictionary<uint,uint>? regionMaps;
    private uint worldMap;
    public MapMarkerSource(IDataManager data,IPluginLog log){this.data=data;this.log=log;}
    public IReadOnlyList<MapIconMarker> For(uint range)
    {
        if(range==0)return [];
        if(cache.TryGetValue(range,out var known))return known;
        var markers=new List<MapIconMarker>();
        try
        {
            if(data.GetSubrowExcelSheet<MapMarker>().TryGetRow(range,out var rows))
                foreach(var row in rows)
                {
                    var label=row.PlaceNameSubtext.RowId!=0 ? row.PlaceNameSubtext.Value.Name.ExtractText():"";
                    if(row.Icon!=0 || label.Length>0)markers.Add(new(row.X,row.Y,row.Icon,label,row.DataType==1 ? row.DataKey.RowId:0));
                }
        }
        catch(Exception error){log.Warning(error,"Map markers unavailable for range {0}.",range);}
        return cache[range]=markers.AsReadOnly();
    }

    private void LoadOverviews()
    {
        if(overviews is not null)return;
        overviews=[];regionMaps=[];
        try
        {
            foreach(var row in data.GetExcelSheet<Map>())
            {
                var id=row.Id.ExtractText();
                if(!(id.StartsWith("region/",StringComparison.Ordinal) || id.StartsWith("world/",StringComparison.Ordinal)) || row.SizeFactor==0)continue;
                var name=row.PlaceName.RowId!=0 ? row.PlaceName.Value.Name.ExtractText():"";
                overviews[row.RowId]=new(row.RowId,0,name,name,"",row.MapIndex,row.SizeFactor,row.PlaceName.RowId,MapProjection.TexturePath(id),row.OffsetX,row.OffsetY,row.MapMarkerRange,row.PlaceNameRegion.RowId);
                if(id.StartsWith("world/",StringComparison.Ordinal)){if(worldMap==0)worldMap=row.RowId;}
                else regionMaps.TryAdd(row.PlaceNameRegion.RowId,row.RowId);
            }
        }
        catch(Exception error){log.Warning(error,"Overview maps unavailable.");}
    }
    public MapDefinition? Overview(uint mapId){LoadOverviews();return overviews!.GetValueOrDefault(mapId);}
    /// <summary>One level up: zone → its region map, region → world map, world → none.</summary>
    public uint Parent(MapDefinition map)
    {
        LoadOverviews();
        if(map.MapId==worldMap)return 0;
        if(overviews!.ContainsKey(map.MapId))return worldMap;
        return regionMaps!.GetValueOrDefault(map.RegionPlaceId,worldMap);
    }
    public uint World{get{LoadOverviews();return worldMap;}}
}
