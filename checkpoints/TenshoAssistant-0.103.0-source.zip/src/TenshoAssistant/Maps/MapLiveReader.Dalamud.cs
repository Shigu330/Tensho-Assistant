using System.Numerics;
using Dalamud.Plugin.Services;
using FFXIVClientStructs.FFXIV.Client.Game.UI;
using FFXIVClientStructs.FFXIV.Client.UI.Agent;
using Lumina.Excel.Sheets;

namespace TenshoAssistant.Maps;

// Aether currents of one territory: Total 0 means flying is not governed by aether currents there (or unknown).
public sealed record MapFlightState(uint TerritoryId,int Total,int Unlocked,bool Complete,bool MountAllowed);

// Player position, the game's map flag and the flight state of the watched territory, copied on the framework thread.
// Flag is a world X/Z position on FlagMapId, or null when no flag is set.
public sealed record MapLiveState(uint TerritoryId,uint MapId,Vector3 Position,float Rotation,DateTimeOffset ObservedAt,uint FlagMapId=0,Vector2? Flag=null,MapFlightState? Flight=null);

internal sealed class MapLiveReader : IDisposable
{
    private readonly IFramework framework;private readonly IClientState client;private readonly IObjectTable objects;private readonly IPluginLog log;
    private readonly Dictionary<uint,(uint Set,uint[] Currents)> currents=[];
    private readonly Dictionary<uint,bool> mounts=[];
    private MapLiveState? state;private bool disposed;private DateTimeOffset retryAt;private DateTimeOffset flightAt;private MapFlightState? flight;
    private uint watched;private int removeFlag;
    public MapLiveState? State=>Volatile.Read(ref state);
    /// <summary>Territory whose flight state the map window shows (the displayed map's territory).</summary>
    public void Watch(uint territoryId)=>Volatile.Write(ref watched,territoryId);
    /// <summary>Queues the flag removal; it is written on the next framework tick, never from the UI thread.</summary>
    public void RemoveFlag()=>Interlocked.Exchange(ref removeFlag,1);

    public MapLiveReader(IFramework framework,IClientState client,IObjectTable objects,IDataManager data,IPluginLog log)
    {
        this.framework=framework;this.client=client;this.objects=objects;this.log=log;
        try
        {
            foreach(var set in data.GetExcelSheet<AetherCurrentCompFlgSet>())
                if(set.Territory.RowId!=0)currents.TryAdd(set.Territory.RowId,(set.RowId,set.AetherCurrents.Select(current=>current.RowId).Where(id=>id!=0).ToArray()));
            foreach(var territory in data.GetExcelSheet<TerritoryType>())mounts[territory.RowId]=territory.Mount;
        }
        catch(Exception error){log.Warning(error,"Aether current data unavailable; flight state stays unknown.");}
        framework.Update+=Update;
    }
    private void Update(IFramework _)
    {
        if(disposed || !framework.IsInFrameworkUpdateThread || framework.IsFrameworkUnloading)return;
        var now=DateTimeOffset.UtcNow;if(now<retryAt)return;
        try
        {
            if(Interlocked.Exchange(ref removeFlag,0)==1)ClearFlag();
            var player=client.IsLoggedIn ? objects.LocalPlayer:null;
            if(player is null){Volatile.Write(ref state,null);return;}
            var (flagMap,flag)=ReadFlag();
            var territory=Volatile.Read(ref watched);if(territory==0)territory=client.TerritoryType;
            if(flight is null || flight.TerritoryId!=territory || now>=flightAt){flight=ReadFlight(territory);flightAt=now.AddSeconds(1);}
            Volatile.Write(ref state,new MapLiveState(client.TerritoryType,client.MapId,player.Position,player.Rotation,now,flagMap,flag,flight));
        }
        catch(Exception error){Volatile.Write(ref state,null);retryAt=now.AddSeconds(5);log.Warning(error,"Map position unavailable; retry in five seconds.");}
    }
    private unsafe MapFlightState ReadFlight(uint territory)
    {
        var mount=mounts.GetValueOrDefault(territory);
        var player=PlayerState.Instance();
        if(player==null || !currents.TryGetValue(territory,out var set))return new(territory,0,0,false,mount);
        var unlocked=set.Currents.Count(id=>player->IsAetherCurrentUnlocked(id));
        return new(territory,set.Currents.Length,unlocked,player->IsAetherCurrentZoneComplete(set.Set),mount);
    }
    // Values are copied out of the agent here; no pointer survives this call.
    private static unsafe (uint MapId,Vector2? Flag) ReadFlag()
    {
        var agent=AgentMap.Instance();
        if(agent==null || agent->FlagMarkerCount==0)return (0,null);
        var marker=agent->FlagMapMarkers[0];
        return marker.MapId==0 || !float.IsFinite(marker.XFloat) || !float.IsFinite(marker.YFloat) ? (0,null):(marker.MapId,new Vector2(marker.XFloat,marker.YFloat));
    }
    // The game shows the flag while FlagMarkerCount is non-zero; resetting it removes the flag from the map and minimap.
    private static unsafe void ClearFlag()
    {
        var agent=AgentMap.Instance();
        if(agent!=null)agent->FlagMarkerCount=0;
    }
    public void Dispose(){if(disposed)return;disposed=true;framework.Update-=Update;Volatile.Write(ref state,null);}
}
