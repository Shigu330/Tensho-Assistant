# GOAL sélectionné

ID: COLL-003-STUDY
OBJECTIVE: Étendre les collections natives aux titres/succès selon preuves de chargement et identité/propriétaire ; poursuivre les 17 domaines jusqu’à la réserve quota de 5 %.
CURRENT_STATE: COLL-002 IMPLEMENTED / TESTED en 0.65.0, 416 tests/package/SHA-256 et CollectionProbe verts. Orchestrion : 886 morceaux/12 catégories, 886 objets liés, confirmations positives et erreurs isolées ; UI/acquisitions en jeu non observées.
WHY_NOW: Orchestrion et liens Item/contexte utiles ; étendre le domaine Collections en respectant les indicateurs de chargement dédiés déjà exposés par IUnlockState.
REFERENCES: docs/COLL-002.md ; REFERENCES.md sources Collections/Dalamud ; API locale IUnlockState.IsTitleListLoaded/IsAchievementListLoaded et feuilles natives.
FILES: Collections/CollectionService, CollectionReader.Dalamud ; MainWindow.Collections et détails ; probes/tests ciblés.
IN_SCOPE: Métadonnées Title/Achievement, méthodes d’acquisition et chargement, portée du personnage, couverture explicite et erreurs isolées ; extension du lecteur commun et navigation utile.
OUT_OF_SCOPE: Déduire non-acquisition depuis une liste non chargée ou ancienne, forcer des requêtes natives non établies, réseau automatique ou priorités hors des 17 domaines. Les 17 restent PARTIAL.
VALIDATION: Dernière tranche Verify.ps1 416/416, zéro avertissement/erreur, package/API/versions/SHA-256/exclusion hôte verts ; CollectionProbe statique hors jeu. Toute nouvelle acquisition/couverture doit être prouvée contre l’API et les états de propriétaire.
QUOTA: Relevé 2026-10-29 : 54 % disponibles sur 5 h et 40 % semaine ; réserve 5 %, objectif global actif.
NEXT_ACTION: Checkpoint 0.65 puis signatures/source chargement des titres/succès, métadonnées natives et modèle de preuve d’acquisition. GP et essais projection/Macro Chain différés, sans les redemander.
DEFINITION_OF_DONE: Tranche utile compilée/testée, preuves/limites/docs/sauvegarde à jour ; aucun domaine global promu complet sans preuve.
