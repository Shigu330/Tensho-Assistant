using Lumina;
using Lumina.Data;
using Lumina.Excel.Sheets;
using TenshoAssistant.Collections;
using TenshoAssistant.Items;

if(args.Length!=1)throw new ArgumentException("Supply installed sqpack directory; no network or native client calls.");
var entries=new List<CollectionEntry>();var copiedItems=new List<ItemDefinition>();var linked=0;var missingUi=0;var distinctIds=0;
using(var data=new GameData(args[0],new LuminaOptions{DefaultExcelLanguage=Language.French}))
{
    var sheet=data.Excel.GetSheet<Orchestrion>();var uiSheet=data.Excel.GetSheet<OrchestrionUiparam>();var categories=data.Excel.GetSheet<OrchestrionCategory>();
    foreach(var row in sheet)
    {
        OrchestrionUiparam? ui=uiSheet.TryGetRow(row.RowId,out var detail) ? detail:null;
        OrchestrionCategory? category=ui is { } value && categories.TryGetRow(value.OrchestrionCategory.RowId,out var group) ? group:null;
        if(OrchestrionCopy.FromRows(row,ui,category,false) is not { } entry)continue;
        entries.Add(entry);if(entry.Music is null)missingUi++;
        if(entry.IconId!=0 && !data.FileExists($"ui/icon/{entry.IconId/1000*1000:D6}/{entry.IconId:D6}.tex"))throw new Exception("Missing native category icon.");
        if(OrchestrionCopy.FromRows(row,null,null,false)!.Music is not null)throw new Exception("Missing UI metadata fabricated.");
        var foreign=uiSheet.First(other=>other.RowId!=row.RowId);
        if(OrchestrionCopy.FromRows(row,foreign,category,false)!.Music is not null)throw new Exception("Foreign UI metadata accepted.");
        if(ui is { } nativeUi)
        {
            var foreignCategory=categories.First(other=>other.RowId!=nativeUi.OrchestrionCategory.RowId);
            var unlinked=OrchestrionCopy.FromRows(row,ui,foreignCategory,false)!;
            if(unlinked.Music?.CategoryId!=nativeUi.OrchestrionCategory.RowId || unlinked.Music.CategoryName.Length!=0 || unlinked.IconId!=0)
                throw new Exception("Foreign category supplied a label or icon.");
        }
    }
    foreach(var item in data.Excel.GetSheet<Item>())
    {
        var id=ItemOrchestrionCopy.Identity(item);
        if(id!=0)
        {
            if(!sheet.HasRow(id))throw new Exception("Orchestrion Item additional data unresolved.");
            linked++;if(item.RowId!=id)distinctIds++;
        }
        copiedItems.Add(new(item.RowId,item.Name.ExtractText(),item.CanBeHq,item.Icon,OrchestrionId:id));
    }
}
var catalog=ItemCatalog.Build(copiedItems,new("native Item/AdditionalData","French","installed-game",1));
var withItems=entries.Count(entry=>catalog.ForOrchestrion(entry.Id).Count>0);
var multiple=entries.Count(entry=>catalog.ForOrchestrion(entry.Id).Count>1);
Console.WriteLine($"PASS native orchestrion: {entries.Count} named rows, {entries.Select(entry=>entry.Music?.CategoryId).Distinct().Count()} category identities, {missingUi} missing UI rows, {linked} item links, {distinctIds} different Item/music IDs, {withItems} entries with items, {multiple} multiple-item associations");
foreach(var entry in entries.Take(4))Console.WriteLine($"MUSIC {entry.Id} {entry.Name}, category={entry.Music?.CategoryId} {entry.Music?.CategoryName}, order={entry.Music?.Order}, icon={entry.IconId}; Item={string.Join(',',catalog.ForOrchestrion(entry.Id).Select(item=>item.Id))}");
if(entries.Count<100 || withItems<100)throw new Exception("Unexpected empty/small native domain.");
var service=new CollectionService();service.Publish(0,entries.Select(entry=>entry with {ConfirmedUnlocked=true}));
if(service.State.Entries.Any(entry=>entry.ConfirmedUnlocked) || service.State.ObservedAt is not null)throw new Exception("Offline native fixture fabricated ownership.");
Console.WriteLine("PASS static projection remains usable after GameData disposal; missing/foreign UI metadata rejected; acquisition not observed offline");
