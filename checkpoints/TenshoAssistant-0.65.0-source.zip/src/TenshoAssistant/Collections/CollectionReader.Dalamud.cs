using System.Diagnostics;
using Dalamud.Plugin.Services;
using Lumina.Excel;
using Lumina.Excel.Sheets;
using TenshoAssistant.MiniGames;

namespace TenshoAssistant.Collections;

internal sealed class CollectionReader : IDisposable
{
    private readonly object gate = new();
    private readonly CollectionService service;
    private readonly IDataManager data;
    private readonly IFramework framework;
    private readonly IPlayerState player;
    private readonly IClientState client;
    private readonly IUnlockState unlocks;
    private readonly IPluginLog log;
    private ExcelSheet<Mount>? mounts;
    private ExcelSheet<Companion>? companions;
    private ExcelSheet<Emote>? emotes;
    private ExcelSheet<AozAction>? blue;
    private ExcelSheet<AozActionTransient>? blueDetails;
    private ExcelSheet<TripleTriadCard>? cards;
    private ExcelSheet<TripleTriadCardResident>? cardDetails;
    private ExcelSheet<Orchestrion>? orchestrion;
    private ExcelSheet<OrchestrionUiparam>? orchestrionUi;
    private ExcelSheet<OrchestrionCategory>? orchestrionCategories;
    private bool orchestrionUnavailable,orchestrionUnlockUnavailable;
    private string? orchestrionIssue;
    private readonly List<CollectionEntry> entries = [];
    private int position;
    private ulong character;
    private bool scanning = true;
    private bool disposed;
    private long nextRefresh;

    public CollectionReader(CollectionService service, IDataManager data, IFramework framework,
        IPlayerState player, IClientState client, IUnlockState unlocks, IPluginLog log)
    {
        this.service = service; this.data = data; this.framework = framework;
        this.player = player; this.client = client; this.unlocks = unlocks; this.log = log;
        framework.Update += OnUpdate;
    }
    private void OnUpdate(IFramework _)
    {
        lock (gate) { ReadUpdate(); }
    }
    private void ReadUpdate()
    {
        if (disposed || !framework.IsInFrameworkUpdateThread || framework.IsFrameworkUnloading) return;
        var owner = client.IsLoggedIn && player.IsLoaded ? player.ContentId : 0;
        var now = Stopwatch.GetTimestamp();
        if (owner != character || service.ConsumeRefresh() || (!scanning && now >= nextRefresh))
        {
            character = owner;
            scanning = true;
            position = 0;
            entries.Clear();
            orchestrionUnavailable=false;orchestrionUnlockUnavailable=false;orchestrionIssue=null;
            service.Invalidate();
        }
        if (!scanning) return;
        try
        {
            mounts ??= data.GetExcelSheet<Mount>();
            companions ??= data.GetExcelSheet<Companion>();
            emotes ??= data.GetExcelSheet<Emote>();
            blue ??= data.GetExcelSheet<AozAction>();
            blueDetails ??= data.GetExcelSheet<AozActionTransient>();
            cards ??= data.GetExcelSheet<TripleTriadCard>();
            cardDetails ??= data.GetExcelSheet<TripleTriadCardResident>();
            if(!orchestrionUnavailable)
            {
                try
                {
                    orchestrion ??= data.GetExcelSheet<Orchestrion>();
                    orchestrionUi ??= data.GetExcelSheet<OrchestrionUiparam>();
                    orchestrionCategories ??= data.GetExcelSheet<OrchestrionCategory>();
                }
                catch(Exception error)
                {
                    orchestrionUnavailable=true;orchestrionIssue="Catalogue d’orchestrion indisponible ; les autres collections restent consultables.";
                    log.Warning(error,"Orchestrion sheets unavailable; other collection categories retained.");
                }
            }
            var musicStart=mounts.Count+companions.Count+emotes.Count+blue.Count+cards.Count;
            var total = musicStart+(orchestrionUnavailable ? 0:orchestrion!.Count);
            var end = Math.Min(position + 32, total);
            var start = Stopwatch.GetTimestamp();
            while (position < end)
            {
                if (position < mounts.Count)
                {
                    var row = mounts.GetRowAt(position++);
                    var name = row.Singular.ExtractText();
                    if (row.RowId != 0 && !string.IsNullOrWhiteSpace(name))
                        entries.Add(new(CollectionKind.Mount, row.RowId, name, row.Icon, character != 0 && unlocks.IsMountUnlocked(row)));
                }
                else if (position < mounts.Count + companions.Count)
                {
                    var row = companions.GetRowAt(position++ - mounts.Count);
                    var name = row.Singular.ExtractText();
                    if (row.RowId != 0 && !string.IsNullOrWhiteSpace(name))
                        entries.Add(new(CollectionKind.Companion, row.RowId, name, row.Icon, character != 0 && unlocks.IsCompanionUnlocked(row)));
                }
                else if (position < mounts.Count + companions.Count + emotes.Count)
                {
                    var row = emotes.GetRowAt(position++ - mounts.Count - companions.Count);
                    var name = row.Name.ExtractText();
                    if (row.RowId != 0 && !string.IsNullOrWhiteSpace(name))
                        entries.Add(new(CollectionKind.Emote, row.RowId, name, row.Icon, character != 0 && unlocks.IsEmoteUnlocked(row)));
                }
                else if(position>=musicStart)
                {
                    try
                    {
                        var row=orchestrion!.GetRowAt(position++-musicStart);
                        OrchestrionUiparam? detail=orchestrionUi!.TryGetRow(row.RowId,out var found) ? found:null;
                        OrchestrionCategory? category=detail is { } info && orchestrionCategories!.TryGetRow(info.OrchestrionCategory.RowId,out var group) ? group:null;
                        var copied=OrchestrionCopy.FromRows(row,detail,category,false);
                        var confirmed=false;
                        if(copied is not null && character!=0 && !orchestrionUnlockUnavailable)
                        {
                            try{confirmed=unlocks.IsOrchestrionUnlocked(row);}
                            catch(Exception error)
                            {
                                orchestrionUnlockUnavailable=true;orchestrionIssue="Acquisitions d’orchestrion partiellement lues ; les résultats non confirmés restent inconnus.";
                                log.Warning(error,"Orchestrion acquisitions unavailable; static catalogue retained.");
                            }
                        }
                        if(copied is not null)entries.Add(copied with {ConfirmedUnlocked=confirmed});
                    }
                    catch(Exception error)
                    {
                        orchestrionUnavailable=true;position=total;
                        orchestrionIssue="Catalogue d’orchestrion partiellement lu ; les autres collections restent consultables.";
                        log.Warning(error,"Orchestrion row unavailable; other collection categories retained.");
                    }
                }
                else if (position >= mounts.Count + companions.Count + emotes.Count + blue.Count)
                {
                    var row = cards.GetRowAt(position++ - mounts.Count - companions.Count - emotes.Count - blue.Count);
                    var name = row.Name.ExtractText();
                    if (row.RowId != 0 && !string.IsNullOrWhiteSpace(name) && cardDetails.TryGetRow(row.RowId, out var details))
                    {
                        var card = new TriadCardDefinition(row.RowId, details.Order, details.TripleTriadCardRarity.Value.Stars,
                            details.Top, details.Right, details.Bottom, details.Left, details.TripleTriadCardType.RowId,
                            details.TripleTriadCardType.Value.Name.ExtractText(), row.Description.ExtractText());
                        if (card.IsValid)
                            entries.Add(new(CollectionKind.TripleTriad, row.RowId, name, card.IconId,
                                character != 0 && unlocks.IsTripleTriadCardUnlocked(row), Card: card));
                    }
                }
                else
                {
                    var row = blue.GetRowAt(position++ - mounts.Count - companions.Count - emotes.Count);
                    if (row.RowId != 0 && row.Action.RowId != 0)
                    {
                        var action = row.Action.Value;
                        var name = action.Name.ExtractText();
                        if (!string.IsNullOrWhiteSpace(name))
                        {
                            var number = 0;
                            var description = "";
                            var location = "";
                            if (blueDetails.TryGetRow(row.RowId, out var details))
                            {
                                number = details.Number;
                                description = details.Description.ExtractText();
                                var source = details.Location;
                                if (source.RowId != 0)
                                {
                                    if (source.RowType == typeof(PlaceName)) location = data.GetExcelSheet<PlaceName>().GetRow(source.RowId).Name.ExtractText();
                                    else if (source.RowType == typeof(TerritoryType)) location = data.GetExcelSheet<TerritoryType>().GetRow(source.RowId).PlaceName.Value.Name.ExtractText();
                                    else if (source.RowType == typeof(ContentFinderCondition)) location = data.GetExcelSheet<ContentFinderCondition>().GetRow(source.RowId).Name.ExtractText();
                                }
                            }
                            entries.Add(new(CollectionKind.BlueMagic, row.RowId, name, action.Icon,
                                character != 0 && unlocks.IsAozActionUnlocked(row), number, row.Rank, description, location));
                        }
                    }
                }
                if (Stopwatch.GetElapsedTime(start) >= TimeSpan.FromMilliseconds(2)) break;
            }
            if (position != total) return;
            var after = client.IsLoggedIn && player.IsLoaded ? player.ContentId : 0;
            if (after != character) { service.Invalidate(); character = after; position = 0; entries.Clear(); orchestrionUnavailable=false;orchestrionUnlockUnavailable=false;orchestrionIssue=null; return; }
            service.Publish(character, entries,orchestrionIssue is null ? []:[new(CollectionKind.Orchestrion,orchestrionIssue)]);
            entries.Clear();
            scanning = false;
            nextRefresh = Stopwatch.GetTimestamp() + 30 * Stopwatch.Frequency;
        }
        catch (Exception error)
        {
            service.Fail(error);
            entries.Clear();
            scanning = false;
            nextRefresh = Stopwatch.GetTimestamp() + 30 * Stopwatch.Frequency;
            log.Warning(error, "Tensho collections read failed; retry in thirty seconds.");
        }
    }
    public void Dispose()
    {
        lock (gate)
        {
        if (disposed) return;
        disposed = true;
        framework.Update -= OnUpdate;
        service.Clear();
        entries.Clear(); mounts = null; companions = null; emotes = null; blue = null; blueDetails = null;
        cards = null; cardDetails = null;
        orchestrion=null;orchestrionUi=null;orchestrionCategories=null;orchestrionIssue=null;
        }
    }
}
