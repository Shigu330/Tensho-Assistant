using System.Net.Http;
using System.Text;

namespace TenshoAssistant.Community;

public enum GarlandResource { Instance, Item, Monster }

/// <summary>Shared bounded transport and cadence; parsed domain caches remain with their services.</summary>
public sealed class GarlandClient : IDisposable
{
    public const int MaximumBytes = 1024 * 1024;
    public static readonly TimeSpan RequestInterval = TimeSpan.FromSeconds(3);
    private readonly object gate = new();
    private readonly HttpClient client;
    private readonly bool ownsClient;
    private readonly TimeProvider clock;
    private readonly CancellationTokenSource lifetime = new();
    private long? lastRequest;
    private bool disposed;
    public GarlandClient(HttpClient? client = null, TimeProvider? clock = null)
    { ownsClient = client is null; this.client = client ?? new HttpClient { Timeout = TimeSpan.FromSeconds(15) }; this.clock = clock ?? TimeProvider.System; }

    public async Task<string> ReadAsync(GarlandResource resource, ulong id, CancellationToken cancellation)
    {
        if (id == 0 || id > long.MaxValue || (resource != GarlandResource.Monster && id > uint.MaxValue))
            throw new ArgumentOutOfRangeException(nameof(id));
        var route = resource switch
        {
            GarlandResource.Instance => "instance/en/2",
            GarlandResource.Item => "item/fr/3",
            GarlandResource.Monster => "mob/fr/2",
            _ => throw new ArgumentOutOfRangeException(nameof(resource))
        };
        CancellationTokenSource linked;
        lock (gate)
        {
            ObjectDisposedException.ThrowIf(disposed,this);
            cancellation.ThrowIfCancellationRequested();
            if (lastRequest is { } last && clock.GetElapsedTime(last) < RequestInterval)
                throw new InvalidOperationException("Patientez trois secondes entre deux consultations Garland Tools.");
            lastRequest = clock.GetTimestamp();
            linked = CancellationTokenSource.CreateLinkedTokenSource(cancellation,lifetime.Token);
            linked.CancelAfter(TimeSpan.FromSeconds(12));
        }
        using (linked)
        using (var message = new HttpRequestMessage(HttpMethod.Get,$"https://www.garlandtools.org/db/doc/{route}/{id}.json"))
        {
            message.Headers.UserAgent.ParseAdd($"TenshoAssistant/{typeof(GarlandClient).Assembly.GetName().Version?.ToString(3) ?? "1.0.0"}");
            using var response = await client.SendAsync(message,HttpCompletionOption.ResponseHeadersRead,linked.Token).ConfigureAwait(false);
            response.EnsureSuccessStatusCode();
            if (response.Content.Headers.ContentLength > MaximumBytes) throw new InvalidDataException("Réponse communautaire trop volumineuse.");
            await using var stream = await response.Content.ReadAsStreamAsync(linked.Token).ConfigureAwait(false);
            using var buffer = new MemoryStream();
            var bytes = new byte[8192]; int read;
            while ((read = await stream.ReadAsync(bytes,linked.Token).ConfigureAwait(false)) > 0)
            {
                if (buffer.Length + read > MaximumBytes) throw new InvalidDataException("Réponse communautaire trop volumineuse.");
                buffer.Write(bytes,0,read);
            }
            linked.Token.ThrowIfCancellationRequested();
            return new UTF8Encoding(false,true).GetString(buffer.GetBuffer(),0,(int)buffer.Length);
        }
    }
    public void Dispose()
    {
        lock (gate)
        {
            if (disposed) return;
            disposed = true; lifetime.Cancel(); lifetime.Dispose();
            if (ownsClient) client.Dispose();
        }
    }
}
