# GOAL sélectionné

ID: LOOT-001
OBJECTIVE: Sources de matériaux sur monstres avec identités et lieux fiables ; poursuivre la couverture du projet.
CURRENT_STATE: IMPLEMENTED / TESTED — modèles/service/UI et transport Garland partagé intégrés en 0.33.0, 206 tests/package verts. Probe réel Peau de bouquetin, identités et nom natifs, lieu/carte passant. Données communautaires partielles et positions indicatives ; aucune validation en jeu. Macro Chain reporté.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: Domaines Community, Monsters, Duties, Maps, Gathering, Inventory, Collections, Market, Quests, Character, MiniGames ; MainWindow.* ; Plugin.cs ; tests, probe et documents.
IN_SCOPE: Consultation explicite matériau/monstres/fiches, grandes identités et lieux PlaceName, couverture/dates, cache/annulation, transport commun et contexte ; carte de zone sans spawn exact inventé.
OUT_OF_SCOPE: Déclarer les 17 plugins remplacés ; prétendre une validation en jeu sans observation.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: 2026-10-28, 81 % disponibles sur 5 h et 81 % semaine au dernier relevé ; continuer selon instruction utilisateur.
NEXT_ACTION: Snapshot 0.33.0 puis étudier GP-001 (LazyGatherer) : actions/coûts/conditions natifs pour aide explicite de récolte ; aucun conseil prétendument optimal sans données et hypothèses vérifiées. Conserver les 17 domaines et le goal global, Macro Chain différé.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
