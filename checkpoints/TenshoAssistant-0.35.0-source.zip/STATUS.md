# État courant

CURRENT_GOAL: FASHION-001 — IMPLEMENTED / TESTED ; répertoire manuel d'indices et équipements signalés, voir docs/FASHION-001.md
CURRENT_MODEL_CLASS: HEAVY (GPT-6.1 Sol)
RECOMMENDED_MODEL: LIGHT pour les adaptations bornées ; continuation du modèle actuel autorisée par l'utilisateur
MODEL_ESCALATION: None
QUOTA: Vérifié le 2026-10-28 : 39 % consommés sur 5 h, 22 % semaine (61 % / 78 % disponibles). Continuation autorisée ; objectif global actif.
LAST_READ: Tous les Markdown du projet et la note de checkpoint relus le 2026-10-28 avant modification ; prompt maître, historique et états récents distingués.
BUILD: COMPILED Release 0.35.0.0 ; sortie canonique bin/x64/Release
TESTS: TESTED — 225/225 tests ; versions, ZIP et exclusion hôte vérifiés ; probe 269 indices natifs, 214 catégories/3 882 liens et filtres d'emplacement passant
RUNTIME: Banque, stocks, carnet et préparation jusqu'à 0.5.27 confirmés par l'utilisateur. Nouvelles fonctions 0.6–0.35 non validées en jeu.
WORK_COMPLETED: Chaque domaine des 17 plugins possède une première capacité partielle : objets/recettes/préparation/chaînes/coûts, récolte/pêche/cartes et PR, tri en aperçu, collections/quêtes/BLU, statistiques, Mini Cactpot/Triple Triade, marché, macros, butins de contenus/monstres et répertoire Revue de mode. 225 tests ; fonctions 0.6+ non validées en jeu. Aucun outil déclaré intégralement remplacé.
BLOCKER: Aucun blocage global. L'utilisateur a répondu « Je testerai plus tard » pour Macro Chain ; sa validation native reste différée, sans redemande. Cartes et horaires ET statiques intégrés.
RESUME_FROM: GOAL.md ; TESTING.md pour le protocole de la base.
NEXT_ACTION: Snapshot 0.35.0 puis CRAFT-SIM-001 : étudier formules et données natives de simulation de craft, priorité A. Conserver les limites de chaque tranche, adapters GP/Triad/Fashion à développer avec preuves ; Macro Chain reporté.

| Plugin | Coverage |
|---|---|
| Avant-Garde | PARTIAL — répertoire manuel d'indices natifs, équipements signalés, emplacements/stock/contexte et source datée ; thème courant/teintures/score/attache non déduits |
| Blue Mage Helper | PARTIAL — grimoire, numéros, descriptions, lieux renseignés et acquisition confirmée |
| Character Panel Refined | PARTIAL — attributs natifs, sans formules dérivées |
| Collections | PARTIAL — montures, mascottes, emotes et cartes Triple Triade ; inconnu distinct d'absent |
| Craftimizer | PARTIAL — recettes, carnet, préparation et sous-recettes avec choix de variantes ; simulation/macros à développer |
| Duty Loot Preview | PARTIAL — consultation manuelle par contenu, coffres/récompenses, icônes/contexte, provenance et cache ; drops directs non interprétés, données externes partielles |
| ezMiniCactpot | PARTIAL — solveur optimal manuel ; adaptation native à développer |
| GatherBuddy | PARTIAL — sources statiques récolte/pêche, objets cachés, carte et horaires ET ; météo/prérequis non couverts |
| Item Use | PARTIAL — usages du catalogue de recettes |
| LazyGatherer | PARTIAL — optimiseur de scénario manuel MIN/BTN, espérances/seuils et copie des PR courants ; régénération/procs/collectionnables et adaptation du point natif non couverts |
| Macro Chain | PARTIAL — séquences à marqueur final, lancement explicite, arrêt, persistance ; natif à confirmer |
| Mappy | PARTIAL — navigateur natif, repères favoris persistants, édition/retrait et ressources de zone |
| Monster Loot Hunter | PARTIAL — associations matériau/monstre, fiches/niveaux/lieux et carte de zone, transport/cadence partagés, contexte ; données communautaires partielles |
| Price Insight | PARTIAL — prix manuels/survol, coût direct et terminal des chaînes, cache/cadence/priorités communs, dates NQ/HQ par monde |
| QuestTracker | PARTIAL — états natifs, séquence, fiche et liens de prérequis/suivantes ; disponibilité non calculée |
| SortaKinda | PARTIAL — aperçu de règles sauvegardées, sans déplacement natif |
| TriadBuddy | PARTIAL — carnet/deck/solveur manuel, observation des faces opt-in expérimentale ; identités/règles/trait natifs et autres règles non établis |

