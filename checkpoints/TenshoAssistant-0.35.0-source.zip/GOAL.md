# GOAL sélectionné

ID: FASHION-001
OBJECTIVE: Répertoire d'indices et équipements signalés avec emplacements/provenance vérifiés ; poursuivre la couverture du projet.
CURRENT_STATE: IMPLEMENTED / TESTED — indices natifs, source communautaire manuelle et UI intégrés en 0.35.0, 225 tests/package verts. Probe 269 indices et 3 882 liens, emplacements positifs/bloqués vérifiés. La semaine courante et les teintures ne sont pas déduites ; aucune validation en jeu. Macro Chain reporté.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: Domaines Fashion, Items, Community, Monsters, Duties, Maps, Gathering, Inventory, Collections, Market, Quests, Character, MiniGames ; MainWindow.* ; Plugin.cs ; tests, probes et documents.
IN_SCOPE: Répertoire manuel des indices, associations observées, identités/emplacements natifs, dates et provenance, cache/annulation et contexte commun ; aucune validité hebdomadaire ou équippabilité personnelle inventée.
OUT_OF_SCOPE: Déclarer les 17 plugins remplacés ; prétendre une validation en jeu sans observation.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: 2026-10-28, 61 % disponibles sur 5 h et 78 % semaine au dernier relevé ; continuer selon instruction utilisateur.
NEXT_ACTION: Snapshot 0.35.0 puis CRAFT-SIM-001 : étudier formules, actions et données natives pour simulation de craft (priorité A), sans succès/qualité garantis hors périmètre vérifié. Les 17 capacités restent PARTIAL ; garder le goal global actif, Macro Chain différé.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
