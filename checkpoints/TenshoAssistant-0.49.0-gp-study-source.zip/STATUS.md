# État courant

CURRENT_GOAL: GATHER-NATIVE-004 — IMPLEMENTED / TESTED ; point observé relié au contexte et aux ressources PR, voir docs/GATHER-NATIVE-004.md
CURRENT_MODEL_CLASS: HEAVY — adaptateur UI natif et inconnus explicites
RECOMMENDED_MODEL: HEAVY pour les influences natives et leur interprétation ; LIGHT pour tâches mécaniques ; continuation autorisée
MODEL_ESCALATION: None
QUOTA: Relevé 2026-10-29 : 43 % consommés sur 5 h, 38 % semaine (57 % / 62 % disponibles). Réserve utilisateur 5 % ; objectif global actif.
LAST_READ: RULES/STATUS/GOAL et étude GATHER-NATIVE-004 relus le 2026-10-29 ; sources ciblées, signatures GUI et ULD installé vérifiés.
BUILD: COMPILED Release 0.49.0.0 ; sortie canonique bin/x64/Release
TESTS: TESTED — 320/320 tests ; package/versions/ZIP/exclusion hôte verts, zéro avertissement/erreur ; GatheringUiProbe confirme huit lignes, types texte/icône et bornes depuis les constantes de production.
RUNTIME: Banque, stocks, carnet et préparation jusqu'à 0.5.27 confirmés par l'utilisateur. Fonctions 0.6–0.49 non validées en jeu. Tests projection et Macro Chain différés explicitement ; ne pas les redemander.
WORK_COMPLETED: Dix-sept domaines PARTIAL ; observation GatherBuddy/PR du point MIN/BTN, objets/icônes en contexte, taux et quantités affichés nullable, copie bornée PR/niveau/tentatives. Le modèle manuel ne reçoit pas les valeurs déjà modifiées par les effets. Mini Cactpot et craft conservés.
BLOCKER: Aucun blocage global. Tests projection et Macro Chain différés ; les travaux indépendants continuent.
RESUME_FROM: GOAL.md ; TESTING.md pour le protocole de la base.
NEXT_ACTION: Snapshot 0.49.0 créé (553843 octets). GP-ACTIVE-005 : lire la fin de docs/GATHER-NATIVE-004.md ; le probe confirme StatusGainSelf=0 pour20/20 actions et aucune magnitude dans les cinq métadonnées Status examinées. Étendre le noyau pour des effets explicitement fournis, puis établir leur décodeur avant toute liaison native ; aucune absence ou magnitude déduite de ces zéros.

| Plugin | Coverage |
|---|---|
| Avant-Garde | PARTIAL — répertoire manuel d'indices natifs, équipements signalés, emplacements/stock/contexte et source datée ; thème courant/teintures/score/attache non déduits |
| Blue Mage Helper | PARTIAL — grimoire, numéros, descriptions, lieux renseignés et acquisition confirmée |
| Character Panel Refined | PARTIAL — attributs natifs, sans formules dérivées |
| Collections | PARTIAL — montures, mascottes, emotes et cartes Triple Triade ; inconnu distinct d'absent |
| Craftimizer | PARTIAL — simulation/recherche/export/séquences, observation et projection d'un coup normal ; conditions/rotation native/recettes spéciales et runtime à compléter |
| Duty Loot Preview | PARTIAL — consultation manuelle par contenu, coffres/récompenses, icônes/contexte, provenance et cache ; drops directs non interprétés, données externes partielles |
| ezMiniCactpot | PARTIAL — solveur exact manuel et mode observé opt-in LotteryDaily ; conseil actualisé, aucune commande ; adaptation/rendu natifs non validés en jeu |
| GatherBuddy | PARTIAL — sources/maps/horaires/météo statiques et point courant observé opt-in (objets/icônes/taux affichés, contexte) ; présence/prérequis/harpon et validation native non couverts |
| Item Use | PARTIAL — usages du catalogue de recettes |
| LazyGatherer | PARTIAL — optimiseur manuel MIN/BTN ; observation du point et copie PR/niveau/tentatives sans taux modifiés ; effets actifs/régénération/procs/collectionnables et validation native à compléter |
| Macro Chain | PARTIAL — séquences à marqueur final, lancement explicite, arrêt, persistance ; natif à confirmer |
| Mappy | PARTIAL — navigateur natif, repères favoris persistants, ressources de zone et prévisions météo statiques ; météo forcée non observée |
| Monster Loot Hunter | PARTIAL — associations matériau/monstre, fiches/niveaux/lieux et carte de zone, transport/cadence partagés, contexte ; données communautaires partielles |
| Price Insight | PARTIAL — prix manuels/survol, coût direct et terminal des chaînes, cache/cadence/priorités communs, dates NQ/HQ par monde |
| QuestTracker | PARTIAL — états natifs, séquence, fiche et liens de prérequis/suivantes ; disponibilité non calculée |
| SortaKinda | PARTIAL — aperçu de règles sauvegardées, sans déplacement natif |
| TriadBuddy | PARTIAL — carnet/deck/solveur manuel, observation des faces opt-in expérimentale ; identités/règles/trait natifs et autres règles non établis |

