using System.Numerics;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.Gathering;
using TenshoAssistant.Items;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private uint gpJob=16;
    private int gpLevel=100,gpBudget=600,gpAttempts=4,gpBaseYield=1,gpSuccess=100,gpBoon=15,gpBountiful=3;
    private ulong gpCopiedOwner;
    private DateTimeOffset? gpCopiedAt;
    private GpOptimization? gpResult;
    private string? gpError;
    private void ValidateGpCopy()
    {
        if(gpCopiedOwner==0 || gpCopiedOwner==characterStats.State.CharacterId) return;
        gpCopiedOwner=0; gpCopiedAt=null; gpBudget=0; gpLevel=1; gpResult=null;
        gpError="Personnage changé ou déconnecté : renseignez ou recopiez vos PR et votre niveau.";
    }
    private void DrawGatheringGp()
    {
        Heading("Optimisation des PR","Scénario manuel MIN/BTN · récolte ordinaire, sans cristaux ni collectionnables");
        DrawGatheringObservation();
        if(gpActions.State.Catalog is not { } catalog)
        { ImGui.TextWrapped(gpActions.State.Error ?? "Lecture des actions et coûts du jeu…"); return; }
        ImGui.TextWrapped("Saisissez les valeurs de votre point de récolte avant tout effet. Le calcul compare les actions modélisées sans régénération de PR, restauration de tentatives ni effets déjà actifs. Les conditions et déblocages hors niveau restent à vérifier dans le jeu.");
        var stats=characterStats.State;
        var canCopy=stats.CharacterId!=0 && stats.JobId is 16 or 17 && stats.CurrentGp is not null
            && stats.ObservedAt is { } observed && DateTimeOffset.UtcNow-observed<TimeSpan.FromSeconds(5);
        ImGui.BeginDisabled(!canCopy);
        try
        {
            if(ImGui.SmallButton("Copier PR et niveau observés"))
            {
                gpJob=stats.JobId; gpLevel=stats.Level; gpBudget=(int)stats.CurrentGp!.Value;
                gpCopiedOwner=stats.CharacterId; gpCopiedAt=stats.ObservedAt; gpResult=null; gpError=null;
            }
        }
        finally { ImGui.EndDisabled(); }
        if(canCopy) { ImGui.SameLine(); ImGui.TextDisabled($"{stats.Job} · PR {stats.CurrentGp}/{stats.MaximumGp}"); }
        if(gpCopiedAt is { } date) ImGui.TextDisabled($"PR/niveau copiés à {date:HH:mm:ss} UTC ; scénario figé depuis cette copie");
        var changed=false; var resourceChanged=false;
        if(ImGui.RadioButton("Mineur",gpJob==16)) { gpJob=16; changed=resourceChanged=true; }
        ImGui.SameLine(); if(ImGui.RadioButton("Botaniste",gpJob==17)) { gpJob=17; changed=resourceChanged=true; }
        if(ImGui.CollapsingHeader("Paramètres du scénario",ImGuiTreeNodeFlags.DefaultOpen))
        {
            if(ImGui.BeginTable("GpInputs",ImGui.GetContentRegionAvail().X<760 ? 1:2,ImGuiTableFlags.SizingStretchSame))
            {
                try
                {
                    ImGui.TableNextRow(); ImGui.TableNextColumn(); ImGui.SetNextItemWidth(110);
                    resourceChanged|=ImGui.InputInt("Niveau (1–100)",ref gpLevel,0);
                    ImGui.TableNextColumn(); ImGui.SetNextItemWidth(110); resourceChanged|=ImGui.InputInt("PR disponibles",ref gpBudget,0);
                    ImGui.TableNextRow(); ImGui.TableNextColumn(); ImGui.SetNextItemWidth(110);
                    changed|=ImGui.InputInt("Tentatives (1–12)",ref gpAttempts,0);
                    ImGui.TableNextColumn(); ImGui.SetNextItemWidth(110); changed|=ImGui.InputInt("Objets par réussite",ref gpBaseYield,0);
                    ImGui.TableNextRow(); ImGui.TableNextColumn(); ImGui.SetNextItemWidth(110);
                    changed|=ImGui.InputInt("Réussite de base (%)",ref gpSuccess,0);
                    ImGui.TableNextColumn(); ImGui.SetNextItemWidth(110); changed|=ImGui.InputInt("Récolte supplémentaire (%)",ref gpBoon,0);
                    ImGui.TableNextRow(); ImGui.TableNextColumn(); ImGui.SetNextItemWidth(110);
                    changed|=ImGui.InputInt("Bonus d'Abondance II (1–3)",ref gpBountiful,0);
                    if(ImGui.IsItemHovered()) ImGui.SetTooltip("Relevez le bonus réel selon votre Collecte. Avant le niveau 68, Abondance I ajoute toujours un objet.");
                }
                finally { ImGui.EndTable(); }
            }
        }
        if(resourceChanged) { gpCopiedOwner=0; gpCopiedAt=null; }
        if(changed || resourceChanged) { gpResult=null; gpError=null; }
        if(ImGui.Button("Comparer les combinaisons"))
        {
            try { gpResult=GpOptimizer.Solve(new(gpJob,gpLevel,gpBudget,gpAttempts,gpBaseYield,gpSuccess,gpBoon,gpBountiful),catalog); gpError=null; }
            catch(ArgumentException) { gpResult=null; gpError="Vérifiez : niveau 1–100, PR 0–10 000, tentatives 1–12, objets 1–20, pourcentages 0–100 et bonus 1–3."; }
        }
        if(gpError is { } error) ImGui.TextWrapped(error);
        if(gpResult is not { } result) return;
        var best=result.Best;
        ImGui.Separator();
        ImGui.TextColored(Accent,$"Meilleure espérance du modèle : {best.ExpectedYield:0.00} objets · coût {best.Cost} PR");
        ImGui.TextDisabled($"Sans action : {result.Baseline:0.00} · gain moyen {best.ExpectedYield-result.Baseline:0.00} · reste {result.Scenario.Budget-best.Cost} PR hors régénération");
        ImGui.TextWrapped("L'espérance est une moyenne probabiliste. Le résultat optimise uniquement le scénario et les actions pris en charge ; il ne commande aucune action en jeu.");
        if(best.Actions.Count==0) ImGui.TextUnformatted("Conserver les PR : aucune combinaison payante n'améliore ce scénario à ce budget.");
        foreach(var use in best.Actions)
        {
            DrawItemIcon(new ItemDefinition(0,use.Action.Name,false,use.Action.Icon),new Vector2(28)); ImGui.SameLine();
            var repeat=use.Action.Spec.Effect is GpEffect.Bountiful1 or GpEffect.Bountiful2;
            ImGui.TextWrapped($"{use.Action.Name} × {use.Count} · {use.Action.Spec.Cost*use.Count} PR" + (repeat ? " · avant chacune des premières tentatives concernées" : " · avant les tentatives"));
            if(ImGui.IsItemHovered()) ImGui.SetTooltip(use.Action.Description);
        }
        if(result.NextUpgrade is { } next)
            ImGui.TextColored(Accent,$"Prochain seuil du modèle : {next.Cost} PR ({next.Cost-result.Scenario.Budget} de plus) → {next.ExpectedYield:0.00} objets en moyenne");
        if(ImGui.CollapsingHeader("Seuils de budget utiles"))
        {
            if(ImGui.BeginTable("GpFrontier",3,ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingStretchProp))
            {
                try
                {
                    ImGui.TableSetupColumn("PR requis"); ImGui.TableSetupColumn("Objets moyens"); ImGui.TableSetupColumn("Gain moyen"); ImGui.TableHeadersRow();
                    foreach(var plan in result.Frontier)
                    {
                        ImGui.TableNextRow(); ImGui.TableNextColumn(); ImGui.TextUnformatted(plan.Cost.ToString());
                        ImGui.TableNextColumn(); ImGui.TextUnformatted($"{plan.ExpectedYield:0.00}");
                        ImGui.TableNextColumn(); ImGui.TextUnformatted($"{plan.ExpectedYield-result.Baseline:0.00}");
                    }
                }
                finally { ImGui.EndTable(); }
            }
        }
    }
}
