# GOAL sélectionné

ID: GATHER-NATIVE-004
OBJECTIVE: Relier le point de récolte courant aux objets et ressources de l’outil PR sans confondre taux affichés et bases, puis poursuivre les outils jusqu’à la réserve de quota de 5 %.
CURRENT_STATE: IMPLEMENTED / TESTED en 0.49.0, 320 tests/package verts ; point opt-in, huit lignes copiées avec valeurs nullable, sélection en contexte et transfert ressources PR uniquement. ULD installé vérifié ; aucun essai runtime ou rendu nouveau déclaré.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: GatheringObservation/Reader ; MainWindow.GatheringObservation/Gathering/GatheringGp/Settings/Tools ; DI ; GatheringObservationTests ; GatheringUiProbe ; docs.
IN_SCOPE: Lecture bornée du point courant, taux/quantités affichés et inconnus explicites, copies managées stables, contexte commun et PR/niveau/tentatives cohérents. Modèle PR de base encore manuel ; aucune commande de récolte.
OUT_OF_SCOPE: Revendiquer validation native ou remplacement intégral sans preuve ; interpréter des taux déjà modifiés comme valeurs de base sans tenir compte des statuts.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: Relevé 2026-10-29 : 57 % disponibles sur 5 h et 62 % semaine ; réserve utilisateur 5 % sur la fenêtre limitante. Objectif global actif.
NEXT_ACTION: GP-ACTIVE-005 : relire docs/GATHER-NATIVE-004.md, établir statuts/actions/métadonnées de récolte puis adapter le modèle PR aux influences connues déjà actives. Copier les taux affichés exige d’abord de prouver cette prise en compte ; bonus et influences ambigus restent inconnus. Tests projection/Macro Chain différés.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
