# État courant

CURRENT_GOAL: MAP-002 — IMPLEMENTED / TESTED ; horaires de récolte prêts à étudier
CURRENT_MODEL_CLASS: HEAVY (GPT-6.1 Sol)
RECOMMENDED_MODEL: LIGHT pour les adaptations bornées ; continuation du modèle actuel autorisée par l'utilisateur
MODEL_ESCALATION: None
QUOTA: Vérifié le 2026-10-28 : 20 % consommés sur 5 h, 3 % semaine (80 % / 97 % disponibles). Continuation autorisée ; aucun arrêt quota requis.
LAST_READ: Tous les Markdown du projet et la note de checkpoint relus le 2026-10-28 avant modification ; prompt maître, historique et états récents distingués.
BUILD: COMPILED Release 0.19.0.0 ; sortie canonique bin/x64/Release
TESTS: TESTED — 119/119 tests ; identité, versions, contenu ZIP et exclusion des assemblies hôte vérifiés
RUNTIME: Banque, stocks, carnet et préparation jusqu'à 0.5.27 confirmés par l'utilisateur. Nouvelles fonctions 0.6–0.17 non validées en jeu.
WORK_COMPLETED: Navigateur récolte/pêche et cartes, sous-recettes avec variantes, liens contextuels, tri en aperçu, collections, quêtes, grimoire bleu, attributs, Mini Cactpot manuel et prix manuels/survol opt-in. 110 tests (dont moteur et observation macros sans exécution native) ; probes statiques recettes/cartes/éligibilité marché passants. Checkpoint source 0.17.1 sauvegardé, sans bin/obj/assemblies hôte.
BLOCKER: Aucun blocage global. L'utilisateur a répondu « Je testerai plus tard » pour Macro Chain ; sa validation native reste différée, sans redemande. Travail indépendant sur les cartes terminé.
RESUME_FROM: GOAL.md ; TESTING.md pour le protocole de la base.
NEXT_ACTION: Étudier les fenêtres ET des points de récolte, jointures/units d'abord ; conserver Macro Chain en PARTIAL et son protocole d'essai pour plus tard.

| Plugin | Coverage |
|---|---|
| Avant-Garde | NOT_STARTED |
| Blue Mage Helper | PARTIAL — grimoire, numéros, descriptions, lieux renseignés et acquisition confirmée |
| Character Panel Refined | PARTIAL — attributs natifs, sans formules dérivées |
| Collections | PARTIAL — montures, mascottes, emotes ; inconnu distinct d'absent |
| Craftimizer | PARTIAL — recettes, carnet, préparation et sous-recettes avec choix de variantes ; simulation/macros à développer |
| Duty Loot Preview | NOT_STARTED |
| ezMiniCactpot | PARTIAL — solveur optimal manuel ; adaptation native à développer |
| GatherBuddy | PARTIAL — sources statiques récolte/pêche, objets cachés, carte de zone ; pas d'horaires/météo |
| Item Use | PARTIAL — usages du catalogue de recettes |
| LazyGatherer | NOT_STARTED |
| Macro Chain | PARTIAL — séquences à marqueur final, lancement explicite, arrêt, persistance ; natif à confirmer |
| Mappy | PARTIAL — navigateur natif, repères favoris persistants, édition/retrait et ressources de zone |
| Monster Loot Hunter | NOT_STARTED |
| Price Insight | PARTIAL — prix manuels et au survol opt-in, cache et cadence communs, dates NQ/HQ par monde |
| QuestTracker | PARTIAL — états natifs et séquence ; prérequis non modélisés |
| SortaKinda | PARTIAL — aperçu de règles sauvegardées, sans déplacement natif |
| TriadBuddy | NOT_STARTED |

