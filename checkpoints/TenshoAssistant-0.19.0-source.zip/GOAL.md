# GOAL sélectionné

ID: GATHER-002
OBJECTIVE: Ajouter les horaires statiques ET des points de récolte, avec distinction des horaires inconnus, permanents et limités, en réutilisant le catalogue partagé.
CURRENT_STATE: READY — MAP-002 implémenté en 0.19.0, 119 tests/package valides. Macro Chain attend un essai reporté par l'utilisateur, sans bloquer ce travail indépendant.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: Domaines Gathering, Inventory, Collections, Market, Quests, Character, MiniGames ; MainWindow.* ; Plugin.cs ; tests et documents.
IN_SCOPE: Inspection ciblée de GatheringPointTransient et GatheringRarePopTimeTable, jointures/units vérifiées sur le jeu et une source primaire ; index managé, affichage ET sans fausse disponibilité.
OUT_OF_SCOPE: Déclarer les 17 plugins remplacés ; prétendre une validation en jeu sans observation.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: 2026-10-28, 80 % disponibles sur 5 h et 97 % semaine au dernier relevé ; continuer selon instruction utilisateur.
NEXT_ACTION: Vérifier si les clés transitoires référencent GatheringPoint ou GatheringPointBase, puis les unités de StartTime/Duration/EphemeralStartTime/EphemeralEndTime avant toute conversion. Aucun horaire implémenté à ce stade.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
