# GATHER-002 — horaires statiques de récolte

État READY, 2026-10-28. Aucune conversion ou disponibilité ajoutée.

Métadonnées locales vérifiées par ApiProbe : GatheringPointTransient possède GatheringRarePopTimeTable, EphemeralStartTime et EphemeralEndTime (UInt16). GatheringRarePopTimeTable possède des collections StartTime et Duration (UInt16). Les types seuls ne prouvent ni leurs unités ni la jointure.

Suite : sonder des données du jeu pour déterminer la clé transitoire, les sentinelles et unités, puis comparer à une source primaire ciblée GatherBuddy/Teamcraft. Copier au framework et construire les fenêtres managées. Ne pas confondre horaire ET et prérequis du personnage, ni données manquantes et ressource toujours disponible.

Points de vigilance : horaires traversant minuit, plusieurs fenêtres, durées nulles, points éphémères et cas non couverts de pêche ; ne pas étendre la déduplication actuelle BaseId/Territory/Place sans conserver toutes les fenêtres si elles diffèrent entre points. Aucun pointeur ni ligne native différée vers worker.
