# GOAL sélectionné

ID: SORT-SCOPES-003
OBJECTIVE: Étendre le tri visuel aux rangements ouverts, puis poursuivre les 17 domaines jusqu’à la réserve de quota de 5 %.
CURRENT_STATE: IMPLEMENTED / TESTED en 0.55.0, 361 tests/package verts ; capture directe indépendante du cache, personnage/servant distingués et permutation du scope exact. Capture/écriture/rendu/persistance non observés en jeu.
FILES: Inventory/InventorySortScope, InventoryVisualSort et Bridge ; BankInventoryBridge ; MainWindow.SortPreview/Tools ; Plugin ; InventorySortScopeTests ; docs/SORT-SCOPES-003.md.
IN_SCOPE: Personnel 140, sacoches 70 chacune, servant 175 en 7 × 25. Lecture manuelle sans import, snapshot exact comme reçu de capture, inspection deux minutes, recapture fraîche et fenêtre/identité/chargement contrôlés avant écriture.
OUT_OF_SCOPE: Application fondée seulement sur cache importé, transfert/fusion, tri automatique/hook, persistance confirmée et zones personnalisées. Tous les domaines restent PARTIAL dans l’objectif global.
VALIDATION: Verify.ps1 361/361, package/versions/ZIP/exclusion hôte verts, zéro avertissement/erreur ; six groupes dont 144 scénarios avec oracle indépendant. Bindings et conventions du lecteur commun réutilisés ; protocole runtime conservé.
QUOTA: Relevé 2026-10-29 : 33 % disponibles sur 5 h et 51 % semaine ; réserve utilisateur 5 %. Objectif global actif.
NEXT_ACTION: Snapshot 0.55 puis SORT-RULES-004 : zones de cases, filtres des catégories natives et critères multiples, aperçu/permutation communs et application explicite. Garder l’inconnu GP ; essais projection/Macro Chain différés, sans les redemander.
DEFINITION_OF_DONE: Tranche intégrée compilée, tests/package verts, limites documentées et sauvegarde source ; aucun domaine global promu complet sans preuve.
