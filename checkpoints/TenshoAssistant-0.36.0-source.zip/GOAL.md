# GOAL sélectionné

ID: CRAFT-SIM-001
OBJECTIVE: Simulation de séquences manuelles sur recettes ordinaires en condition normale ; poursuivre la couverture du projet.
CURRENT_STATE: IMPLEMENTED / TESTED — paramètres de recette, 136 métadonnées natives d'actions, moteur et page dédiés intégrés en 0.36.0, 239 tests/package verts. Probe 11 361 recettes acceptées / 2 531 exclues ; scénario fictif sur recette 2819 passant. Aucune validation en jeu ; Macro Chain reporté.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: Domaine Craft ; RecipeCatalog/Loader ; CraftActionCatalog/Loader ; CraftSimulation ; MainWindow.CraftSimulation/CraftPlan/Tools ; Plugin ; tests, CraftSimulationProbe et documents.
IN_SCOPE: Attributs manuels/copie du même métier frais, qualité initiale manuelle, 17 actions déterministes, séquence éditable et états par étape, validation/limites explicites ; aucune commande en jeu.
OUT_OF_SCOPE: Déclarer les 17 plugins remplacés ; prétendre une validation en jeu sans observation.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: 2026-10-28, 44 % disponibles sur 5 h et 76 % semaine au dernier relevé ; continuer selon instruction utilisateur.
NEXT_ACTION: Snapshot 0.36.0 puis CRAFT-MACRO-001 : export manuel localisé de la séquence simulée, limites de lignes/attentes vérifiées, copie texte seulement. Ensuite solveur borné et suggestions à étudier ; garder les 17 domaines PARTIAL et le goal global actif, Macro Chain différé.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
