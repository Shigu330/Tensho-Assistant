# GOAL sélectionné

ID: MARKET-002
OBJECTIVE: Estimer le coût indicatif d'une préparation en réutilisant stocks, besoins et prix partagés, avec consultation de liste possédée et inconnus explicites ; poursuivre la couverture du projet.
CURRENT_STATE: IMPLEMENTED / TESTED — coût et consultation de liste intégrés en 0.27.0, 164 tests/package valides ; réponse publique de l'API vérifiée. Rendu en jeu non observé. Macro Chain reste reporté ; observation Triple Triade expérimentale sans liaison automatique.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: Domaines Gathering, Inventory, Collections, Market, Quests, Character, MiniGames ; MainWindow.* ; Plugin.cs ; tests et documents.
IN_SCOPE: Coût des ingrédients directs, quantités écart/tous requis, qualité NQ/HQ/moins cher, sous-total/provenance, liste bornée, cadence/cache/priorités partagés et annulation de contexte.
OUT_OF_SCOPE: Déclarer les 17 plugins remplacés ; prétendre une validation en jeu sans observation.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: 2026-10-28, 27 % disponibles sur 5 h et 89 % semaine au dernier relevé ; continuer selon instruction utilisateur.
NEXT_ACTION: Sauvegarder 0.27.0 puis MARKET-003 : coût des besoins terminaux d'une chaîne, sans double déduction des stocks et avec variantes/cycles/inconnus explicites. Les autres domaines de la roadmap restent dans le goal global.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
