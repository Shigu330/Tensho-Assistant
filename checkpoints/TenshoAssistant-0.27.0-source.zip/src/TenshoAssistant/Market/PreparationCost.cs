using TenshoAssistant.Craft;
using TenshoAssistant.Items;

namespace TenshoAssistant.Market;

public enum PreparationCostBasis { Missing, AllRequired }
public enum PreparationPriceQuality { Nq, Hq, Cheapest }
public enum PreparationCostStatus { Covered, Priced, UnknownStock, UnknownWorld, UnknownItem, NotMarketable, UnsupportedQuality, MissingQuote, WrongScope, MissingPrice, Overflow }
public sealed record PreparationCostLine(uint ItemId, long Required, long? Quantity, PreparationCostStatus Status,
    decimal? UnitPrice, decimal? Cost, bool? HighQuality, MarketQuote? Quote, bool StockUncertain, bool CachedStock, bool StalePrice);
public sealed record PreparationCostEstimate(uint WorldId, PreparationCostBasis Basis, PreparationPriceQuality Quality,
    DateTimeOffset EvaluatedAt, IReadOnlyList<PreparationCostLine> Lines, decimal? KnownSubtotal)
{
    public bool AllCosted => KnownSubtotal is not null && Lines.All(line => line.Cost is not null);
    public bool StockUncertain => Lines.Any(line => line.StockUncertain);
    public bool CachedStock => Lines.Any(line => line.CachedStock);
    public bool StalePrices => Lines.Any(line => line.StalePrice);
}

/// <summary>Unit reference price times indicative quantity; not an executable basket, listing supply or tax calculation.</summary>
public static class PreparationCost
{
    public static PreparationCostEstimate Build(CraftPlan plan, uint world, PreparationCostBasis basis, PreparationPriceQuality quality,
        Func<uint,ItemDefinition?> item, Func<uint,MarketQuote?> quote, DateTimeOffset now)
    {
        ArgumentNullException.ThrowIfNull(plan); ArgumentNullException.ThrowIfNull(item); ArgumentNullException.ThrowIfNull(quote);
        if (!Enum.IsDefined(basis) || !Enum.IsDefined(quality)) throw new ArgumentOutOfRangeException(nameof(basis));
        var rows = new List<PreparationCostLine>();
        decimal? subtotal = 0;
        var seen = new HashSet<uint>();
        foreach (var material in plan.Materials)
        {
            if (material.ItemId == 0 || material.Required < 1 || !seen.Add(material.ItemId) || material.Holdings.Nq < 0 || material.Holdings.Hq < 0)
                throw new ArgumentException("Préparation invalide.",nameof(plan));
            var stockRelevant = basis == PreparationCostBasis.Missing;
            var unknownStock = stockRelevant && (!material.Holdings.HasObservation || material.Holdings.HasUnknown);
            var cachedStock = stockRelevant && material.Holdings.HasCached;
            long? quantity = !stockRelevant ? material.Required : !material.Holdings.HasObservation ? null : material.Uncovered;
            var definition = item(material.ItemId);
            var price = quote(material.ItemId);
            decimal? unit = null, cost = null;
            bool? hq = null;
            var stale = false;
            var status = PreparationCostStatus.Priced;
            if (quantity == 0) { status=PreparationCostStatus.Covered; cost=0; price=null; }
            else if (world == 0) { status=PreparationCostStatus.UnknownWorld; price=null; }
            else if (definition is null || definition.Id != material.ItemId) { status=PreparationCostStatus.UnknownItem; price=null; }
            else if (!definition.IsMarketable) { status=PreparationCostStatus.NotMarketable; price=null; }
            else if (quality == PreparationPriceQuality.Hq && !definition.CanBeHq) { status=PreparationCostStatus.UnsupportedQuality; price=null; }
            else if (price is null) status=PreparationCostStatus.MissingQuote;
            else if (price.WorldId != world || price.ItemId != material.ItemId) { status=PreparationCostStatus.WrongScope; price=null; }
            else
            {
                decimal? nq = price.Nq.Minimum is > 0 ? price.Nq.Minimum : null;
                decimal? high = definition.CanBeHq && price.Hq.Minimum is > 0 ? price.Hq.Minimum : null;
                hq = quality == PreparationPriceQuality.Hq || quality == PreparationPriceQuality.Cheapest && high is { } hp && (nq is null || hp < nq);
                unit = hq.Value ? high : nq;
                stale = !price.HasRecentUpload(now) || price.FetchedAt > now.AddMinutes(5) || now-price.FetchedAt >= TimeSpan.FromMinutes(5);
                if (unit is null) status=PreparationCostStatus.MissingPrice;
            }
            if (quantity is null) status=PreparationCostStatus.UnknownStock;
            else if (status == PreparationCostStatus.Priced)
            {
                try { cost=checked(unit!.Value*quantity.Value); }
                catch (OverflowException) { status=PreparationCostStatus.Overflow; }
            }
            if (subtotal is { } total && cost is { } lineCost)
            {
                try { subtotal=checked(total+lineCost); }
                catch (OverflowException) { subtotal=null; }
            }
            rows.Add(new(material.ItemId,material.Required,quantity,status,unit,cost,hq,price,unknownStock,cachedStock,stale));
        }
        return new(world,basis,quality,now,Array.AsReadOnly(rows.ToArray()),subtotal);
    }
}
