# État courant

CURRENT_GOAL: MARKET-002 — IMPLEMENTED / TESTED ; coût indicatif d'une préparation et consultation de liste
CURRENT_MODEL_CLASS: HEAVY (GPT-6.1 Sol)
RECOMMENDED_MODEL: LIGHT pour les adaptations bornées ; continuation du modèle actuel autorisée par l'utilisateur
MODEL_ESCALATION: None
QUOTA: Vérifié le 2026-10-28 : 73 % consommés sur 5 h, 11 % semaine (27 % / 89 % disponibles). Continuation autorisée ; aucun arrêt quota requis.
LAST_READ: Tous les Markdown du projet et la note de checkpoint relus le 2026-10-28 avant modification ; prompt maître, historique et états récents distingués.
BUILD: COMPILED Release 0.27.0.0 ; sortie canonique bin/x64/Release
TESTS: TESTED — 164/164 tests ; identité, versions, ZIP et exclusion des assemblies hôte vérifiés ; requête Universalis publique vérifiée hors tests
RUNTIME: Banque, stocks, carnet et préparation jusqu'à 0.5.27 confirmés par l'utilisateur. Nouvelles fonctions 0.6–0.27 non validées en jeu.
WORK_COMPLETED: Navigateur récolte/pêche et horaires ET, cartes/favoris, sous-recettes, liens contextuels, tri en aperçu, collections, quêtes, grimoire bleu, attributs, Mini Cactpot manuel, prix manuels/survol et coût des préparations, macros expérimentales, carnet/deck/solveur Triple Triade et observation des faces UI. 164 tests ; nouvelles fonctions non validées en jeu. Aucun outil déclaré intégralement remplacé.
BLOCKER: Aucun blocage global. L'utilisateur a répondu « Je testerai plus tard » pour Macro Chain ; sa validation native reste différée, sans redemande. Cartes et horaires ET statiques intégrés.
RESUME_FROM: GOAL.md ; TESTING.md pour le protocole de la base.
NEXT_ACTION: MARKET-003 : coût des besoins terminaux d'une chaîne sans double déduction et sans masquer ses branches non résolues. Liaison observation/conseil Triple Triade à valider ; Macro Chain reporté.

| Plugin | Coverage |
|---|---|
| Avant-Garde | NOT_STARTED |
| Blue Mage Helper | PARTIAL — grimoire, numéros, descriptions, lieux renseignés et acquisition confirmée |
| Character Panel Refined | PARTIAL — attributs natifs, sans formules dérivées |
| Collections | PARTIAL — montures, mascottes, emotes et cartes Triple Triade ; inconnu distinct d'absent |
| Craftimizer | PARTIAL — recettes, carnet, préparation et sous-recettes avec choix de variantes ; simulation/macros à développer |
| Duty Loot Preview | NOT_STARTED |
| ezMiniCactpot | PARTIAL — solveur optimal manuel ; adaptation native à développer |
| GatherBuddy | PARTIAL — sources statiques récolte/pêche, objets cachés, carte et horaires ET ; météo/prérequis non couverts |
| Item Use | PARTIAL — usages du catalogue de recettes |
| LazyGatherer | NOT_STARTED |
| Macro Chain | PARTIAL — séquences à marqueur final, lancement explicite, arrêt, persistance ; natif à confirmer |
| Mappy | PARTIAL — navigateur natif, repères favoris persistants, édition/retrait et ressources de zone |
| Monster Loot Hunter | NOT_STARTED |
| Price Insight | PARTIAL — prix manuels/survol opt-in et coût de préparation, cache/cadence/priorités communs, dates NQ/HQ par monde |
| QuestTracker | PARTIAL — états natifs et séquence ; prérequis non modélisés |
| SortaKinda | PARTIAL — aperçu de règles sauvegardées, sans déplacement natif |
| TriadBuddy | PARTIAL — carnet/deck/solveur manuel, observation des faces opt-in expérimentale ; identités/règles/trait natifs et autres règles non établis |

