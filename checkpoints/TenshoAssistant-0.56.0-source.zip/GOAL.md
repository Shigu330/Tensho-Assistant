# GOAL sélectionné

ID: SORT-RULES-004
OBJECTIVE: Personnaliser le tri par zones et critères, puis poursuivre les 17 domaines jusqu’à la réserve de quota de 5 %.
CURRENT_STATE: IMPLEMENTED / TESTED en 0.56.0, 369 tests/package et Newtonsoft trois modes verts ; zones filtrées et profils par scope, trous conservés jusqu’à la permutation native. Rendu/application/persistance en jeu non observés.
FILES: Inventory/InventorySortRules, InventorySortPreview, InventoryVisualSort ; Configuration ; ItemCatalog.Categories ; MainWindow.SortRules/SortPreview/Tools ; InventorySortRulesTests ; ConfigSerializationProbe ; docs/SORT-RULES-004.md.
IN_SCOPE: Quatre critères prioritaires, 32 zones sans chevauchement par scope, catégorie native/qualité/recherche, conservation de toutes les piles et cases vides ; 128 profils par personnage/rangement, v1 et rollback. Sauvegarde distincte de l’application.
OUT_OF_SCOPE: Ignorer une règle sans motif, perdre/fusionner des piles, appliquer depuis un cache importé seul, tri automatique ; protection des positions et filtres avancés restent à développer. Tous les domaines restent PARTIAL.
VALIDATION: Verify.ps1 369/369, package/versions/ZIP/exclusion hôte verts, zéro avertissement/erreur ; huit groupes dont 24 scènes multi-scopes avec oracles indépendants de coordonnées et quantités. Newtonsoft None/Auto/Objects avec profil imbriqué passants.
QUOTA: Relevé 2026-10-29 : 25 % disponibles sur 5 h et 50 % semaine ; réserve utilisateur 5 %. Objectif global actif.
NEXT_ACTION: Snapshot 0.56 puis SORT-PROTECTED-005 : protéger des zones à leurs positions actuelles et permettre le remplissage inversé, indices visuels prouvés et moteur partagé. Garder l’inconnu GP ; essais projection/Macro Chain différés, sans les redemander.
DEFINITION_OF_DONE: Tranche intégrée compilée, tests/package verts, limites documentées et sauvegarde source ; aucun domaine global promu complet sans preuve.
