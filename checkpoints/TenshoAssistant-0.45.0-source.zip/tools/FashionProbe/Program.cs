using Lumina;
using Lumina.Data;
using Lumina.Excel.Sheets;
using TenshoAssistant.Fashion;
using TenshoAssistant.Items;

if(args.Length is <1 or >2 || args.Length==2 && args[1]!="--fetch") throw new ArgumentException("Supply sqpack directory, optionally --fetch for the two fixed public dataset requests.");
using var data=new GameData(args[0],new LuminaOptions {DefaultExcelLanguage=Language.French});
var hints=new FashionHintCatalog(data.Excel.GetSheet<FashionCheckThemeCategory>().Select(row=>new FashionHint(row.RowId,row.Name.ExtractText())));
var sheet=data.Excel.GetSheet<Item>(); var copied=new List<ItemDefinition>(); var blocked=0;
foreach(var row in sheet)
{
    var name=row.Name.ExtractText(); if(row.RowId==0 || string.IsNullOrWhiteSpace(name)) continue;
    var slots=row.EquipSlotCategory.Value;
    var mask=row.EquipSlotCategory.RowId==0 ? EquipmentSlots.None:EquipmentSlotMap.FromNative(slots.Head,slots.Body,slots.Gloves,slots.Legs,slots.Feet,slots.Ears,slots.Neck,slots.Wrists,slots.FingerL,slots.FingerR);
    if(slots.Head<0 && slots.Body>0)
    { if((mask&EquipmentSlots.Head)!=0 || (mask&EquipmentSlots.Body)==0) throw new InvalidOperationException("Blocked head slot was treated as wearable head."); blocked++; }
    copied.Add(new(row.RowId,name,row.CanBeHq,row.Icon,Equipment:mask));
}
var items=ItemCatalog.Build(copied,new("installed-game","French","probe",1));
if(hints.Hints.Count<100 || blocked==0 || copied.Count(item=>item.Equipment!=EquipmentSlots.None)<1000) throw new InvalidOperationException("Native fashion metadata incomplete.");
Console.WriteLine($"PASS native fashion metadata: {hints.Hints.Count} named hints, {copied.Count(item=>item.Equipment!=EquipmentSlots.None)} wearable items, {blocked} body items block rather than equip the head slot.");
if(args.Length==2)
{
    using var source=new FashionDataService(); await source.RequestAsync();
    var dataset=source.State.Dataset ?? throw new InvalidOperationException(source.State.Error ?? "No fashion dataset.");
    var knownHints=hints.Hints.Select(hint=>hint.Id).ToHashSet();
    var references=dataset.HintIds.SelectMany(dataset.ForHint).ToArray();
    var hintId=dataset.HintIds.First(id=>knownHints.Contains(id) && dataset.Filter(id,EquipmentSlots.Body,items,"").Count>0);
    var candidates=dataset.Filter(hintId,EquipmentSlots.Body,items,"");
    if(candidates.Any(candidate=>candidate.Item is null || (candidate.Item.Equipment&EquipmentSlots.Body)==0)) throw new InvalidOperationException("Fashion body filter accepted an incompatible reference.");
    Console.WriteLine($"PASS explicit fashion source: {dataset.HintIds.Count} categories, {references.Length} hint/item links, {dataset.HintIds.Count(id=>!knownHints.Contains(id))} unknown hint IDs, {references.Count(match=>items.Find(match.ItemId) is null)} unresolved item references; providerDate={dataset.ProviderUpdatedAt:O}, dateStatus={dataset.DateStatus}.");
    Console.WriteLine($"PASS native fashion body filtering: hint {hintId} {hints.Hints.First(hint=>hint.Id==hintId).Name}, {candidates.Count} candidates; sample {candidates[0].Match.ItemId} {candidates[0].Item!.Name}, raw observations={candidates[0].Match.Reports}. No current-week or score inference.");
}
