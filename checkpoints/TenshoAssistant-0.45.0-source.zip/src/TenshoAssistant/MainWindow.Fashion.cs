using System.Globalization;
using System.Numerics;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.Fashion;
using TenshoAssistant.Items;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private string fashionHintQuery="",fashionItemQuery="";
    private uint fashionHintId;
    private EquipmentSlots fashionSlot;
    private bool fashionShowItems;
    private FashionHintCatalog? fashionNativeView;
    private FashionDataset? fashionHintDataView,fashionItemDataView;
    private string fashionHintQueryView="",fashionItemQueryView="";
    private uint fashionItemHintView;
    private EquipmentSlots fashionSlotView;
    private ItemCatalog? fashionItemsView;
    private FashionHint[] fashionAllHints=[],fashionHintMatches=[];
    private IReadOnlyList<FashionCandidate> fashionCandidates=[];
    private bool fashionHintsNeedFilter=true;
    private static readonly (EquipmentSlots Slot,string Name)[] FashionSlots=
    [ (EquipmentSlots.None,"Tous les emplacements"),(EquipmentSlots.Head,"Tête"),(EquipmentSlots.Body,"Torse"),
      (EquipmentSlots.Hands,"Mains"),(EquipmentSlots.Legs,"Jambes"),(EquipmentSlots.Feet,"Pieds"),
      (EquipmentSlots.Ears,"Boucles d'oreilles"),(EquipmentSlots.Neck,"Collier"),(EquipmentSlots.Wrists,"Bracelets"),(EquipmentSlots.Ring,"Bague") ];
    private void DrawFashion()
    {
        Heading("Revue de mode","Répertoire d'indices · équipements signalés par la communauté");
        ImGui.TextWrapped("Choisissez l'indice affiché dans votre Revue de mode et son emplacement. Ce répertoire ne sélectionne pas automatiquement la semaine et ne calcule ni score ni teinture.");
        var native=fashionHints.State;
        if(native.Catalog is not { } catalog) { ImGui.TextWrapped(native.Error ?? "Lecture des indices du jeu…"); return; }
        var state=fashionData.State; var dataset=state.Dataset;
        if(state.Loading) { if(ImGui.Button("Annuler la lecture du répertoire")) fashionData.Cancel(); ImGui.SameLine(); ImGui.TextDisabled("Lecture en cours…"); }
        else
        {
            if(ImGui.Button("Consulter les associations communautaires")) _=fashionData.RequestAsync();
            if(dataset is not null) { ImGui.SameLine(); if(ImGui.SmallButton("Actualiser à la source##Fashion")) _=fashionData.RequestAsync(true); }
        }
        if(state.Error is { } error) ImGui.TextWrapped(error);
        if(dataset is not null)
        {
            ImGui.TextDisabled($"Récupéré : {dataset.FetchedAt:yyyy-MM-dd HH:mm:ss} UTC");
            if(dataset.ProviderUpdatedAt is { } date) ImGui.TextDisabled($"Mise à jour annoncée par la source : {date:yyyy-MM-dd HH:mm:ss} UTC");
            if(dataset.DateStatus!=FashionDateStatus.Parsed) ImGui.TextWrapped(dataset.DateStatus==FashionDateStatus.Future
                ? "La date annoncée est future et ne permet pas de confirmer la fraîcheur des données."
                : "Date de mise à jour inconnue ou non interprétable ; la récupération ne la remplace pas.");
            if(DateTimeOffset.UtcNow-dataset.FetchedAt>=FashionDataService.FreshFor) ImGui.TextColored(Accent,"Répertoire ancien en cache ; actualisez si nécessaire.");
        }
        ImGui.TextDisabled("Source : FFXIVGachaSpreadsheet · observations historiques partielles, sans garantie de médaille ou de score");
        if(!ReferenceEquals(fashionNativeView,catalog) || !ReferenceEquals(fashionHintDataView,dataset))
        {
            var known=catalog.Hints.ToDictionary(hint=>hint.Id);
            fashionAllHints=catalog.Hints.Concat((dataset?.HintIds ?? []).Where(id=>!known.ContainsKey(id)).Select(id=>new FashionHint(id,$"Indice non résolu {id}")))
                .OrderBy(hint=>hint.Name,StringComparer.CurrentCultureIgnoreCase).ThenBy(hint=>hint.Id).ToArray();
            fashionNativeView=catalog; fashionHintDataView=dataset; fashionHintsNeedFilter=true;
        }
        if(fashionShowItems && fashionHintId!=0)
        {
            if(ImGui.SmallButton("Retour aux indices")) fashionShowItems=false;
            DrawFashionItems(dataset); return;
        }
        ImGui.SetNextItemWidth(-1); ImGui.InputTextWithHint("##FashionHintSearch","Nom français de l'indice ou identifiant…",ref fashionHintQuery,128);
        if(fashionHintsNeedFilter || fashionHintQueryView!=fashionHintQuery)
        {
            var query=fashionHintQuery.Trim();
            fashionHintMatches=fashionAllHints.Where(hint=>query.Length==0 || hint.Id.ToString(CultureInfo.InvariantCulture)==query
                || CultureInfo.CurrentCulture.CompareInfo.IndexOf(hint.Name,query,CompareOptions.IgnoreCase|CompareOptions.IgnoreNonSpace)>=0).ToArray();
            fashionNativeView=catalog; fashionHintDataView=dataset; fashionHintQueryView=fashionHintQuery;
            fashionHintsNeedFilter=false;
        }
        ImGui.TextDisabled($"{fashionHintMatches.Length} indices · catalogue du jeu et références conservées de la source");
        if(!ImGui.BeginTable("FashionHints",2,ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingStretchProp)) return;
        try
        {
            ImGui.TableSetupColumn("Indice",ImGuiTableColumnFlags.WidthStretch,3); ImGui.TableSetupColumn("Objets signalés"); ImGui.TableHeadersRow();
            var clipper=ImGui.ImGuiListClipper();
            try
            {
                clipper.Begin(fashionHintMatches.Length);
                while(clipper.Step())
                for(var index=clipper.DisplayStart;index<clipper.DisplayEnd;index++)
                {
                    var hint=fashionHintMatches[index]; ImGui.TableNextRow(); ImGui.TableNextColumn();
                    if(ImGui.Selectable($"{hint.Name}##FashionHint{hint.Id}",fashionHintId==hint.Id)) { fashionHintId=hint.Id; fashionShowItems=true; fashionItemQuery=""; }
                    if(ImGui.IsItemHovered()) ImGui.SetTooltip($"ID d'indice : {hint.Id}");
                    ImGui.TableNextColumn(); ImGui.TextUnformatted(dataset is null ? "Non consulté" : dataset.ForHint(hint.Id).Count.ToString(CultureInfo.InvariantCulture));
                }
            }
            finally { clipper.End(); clipper.Destroy(); }
        }
        finally { ImGui.EndTable(); }
    }
    private void DrawFashionItems(FashionDataset? dataset)
    {
        var hint=fashionAllHints.FirstOrDefault(entry=>entry.Id==fashionHintId);
        ImGui.TextColored(Accent,hint?.Name ?? $"Indice {fashionHintId}");
        ImGui.SetNextItemWidth(240);
        if(ImGui.BeginCombo("Emplacement##Fashion",FashionSlots.First(pair=>pair.Slot==fashionSlot).Name))
        {
            try { foreach(var pair in FashionSlots) if(ImGui.Selectable(pair.Name,pair.Slot==fashionSlot)) fashionSlot=pair.Slot; }
            finally { ImGui.EndCombo(); }
        }
        ImGui.SetNextItemWidth(-1); ImGui.InputTextWithHint("##FashionItemSearch","Nom ou identifiant d'équipement…",ref fashionItemQuery,128);
        if(dataset is null) { ImGui.TextWrapped("Consultez les associations communautaires pour cet indice."); return; }
        var items=itemCatalog.State.Catalog;
        if(items is null) { DrawCatalogStatus(); return; }
        if(!ReferenceEquals(fashionItemDataView,dataset) || !ReferenceEquals(fashionItemsView,items) || fashionItemHintView!=fashionHintId
            || fashionItemQueryView!=fashionItemQuery || fashionSlotView!=fashionSlot)
        {
            fashionCandidates=dataset.Filter(fashionHintId,fashionSlot,items,fashionItemQuery);
            fashionItemDataView=dataset; fashionItemsView=items; fashionItemHintView=fashionHintId; fashionItemQueryView=fashionItemQuery; fashionSlotView=fashionSlot;
        }
        ImGui.TextDisabled($"{fashionCandidates.Count} résultats · {dataset.ForHint(fashionHintId).Count} références dans la source");
        if(fashionSlot!=EquipmentSlots.None) ImGui.TextWrapped("Le filtre utilise les emplacements positifs du jeu ; une référence sans emplacement local confirmé reste visible avec Tous les emplacements.");
        ImGui.TextWrapped("Les observations ne sont pas une probabilité de réussite. Métier, niveau, sexe et autres restrictions d'équipement restent à vérifier ; posséder l'objet ne prouve pas qu'il peut être équipé.");
        if(itemId>0)
        {
            ImGui.TextDisabled($"En contexte : {SelectedItem?.Name ?? $"Objet {itemId}"}");
            if(ImGui.SmallButton("Stocks##Fashion")) { page=Page.Items; focusStocksTab=true; }
            ImGui.SameLine(); if(ImGui.SmallButton("Recettes##Fashion")) OpenContextTool("Craftimizer");
            ImGui.SameLine(); if(ImGui.SmallButton("Prix##Fashion")) OpenContextTool("Price Insight");
        }
        if(fashionCandidates.Count==0) { ImGui.TextWrapped("Aucune association renseignée pour ces filtres ; cela ne prouve pas qu'aucun équipement ne convient."); return; }
        RefreshRecipeHoldingsCache();
        if(!ImGui.BeginTable("FashionCandidates",3,ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingStretchProp)) return;
        try
        {
            ImGui.TableSetupColumn("Équipement",ImGuiTableColumnFlags.WidthStretch,3); ImGui.TableSetupColumn("Observations"); ImGui.TableSetupColumn("Stock recensé"); ImGui.TableHeadersRow();
            var clipper=ImGui.ImGuiListClipper();
            try
            {
                clipper.Begin(fashionCandidates.Count);
                while(clipper.Step())
                for(var index=clipper.DisplayStart;index<clipper.DisplayEnd;index++)
                {
                    var entry=fashionCandidates[index]; var id=entry.Match.ItemId; var item=entry.Item;
                    ImGui.TableNextRow(); ImGui.TableNextColumn(); DrawItemIcon(item,new Vector2(28)); var clicked=ImGui.IsItemClicked(); ImGui.SameLine();
                    var selectable=item is not null && id<=int.MaxValue;
                    ImGui.BeginDisabled(!selectable);
                    try { if((ImGui.Selectable($"{item?.Name ?? $"Objet {id}"}##FashionItem{id}",itemId==id,ImGuiSelectableFlags.None,new Vector2(0,28)) || clicked) && selectable) SelectItem(id); }
                    finally { ImGui.EndDisabled(); }
                    if(ImGui.IsItemHovered(ImGuiHoveredFlags.AllowWhenDisabled)) ImGui.SetTooltip($"{item?.Name ?? "Référence non résolue"}\nID {id}\nEmplacement local : {(item is null ? "inconnu":FashionSlotNames(item.Equipment))}");
                    ImGui.TableNextColumn(); ImGui.TextUnformatted(entry.Match.Reports.ToString("N0"));
                    ImGui.TableNextColumn();
                    var stock=GetRecipeHoldings(id);
                    ImGui.TextUnformatted(!stock.HasObservation ? "Inconnu" : $"{stock.Total:N0}{(stock.HasCached ? " · cache":"")}{(stock.HasUnknown ? " · partiel":"")}");
                    if(ImGui.IsItemHovered()) ImGui.SetTooltip("Somme des observations des sacs et rangements importés. Réimportez les caches après transfert ; les rangements jamais observés restent inconnus.");
                }
            }
            finally { clipper.End(); clipper.Destroy(); }
        }
        finally { ImGui.EndTable(); }
    }
    private static string FashionSlotNames(EquipmentSlots slots)=>slots==EquipmentSlots.None ? "Aucun emplacement pris en charge"
        : string.Join(", ",FashionSlots.Skip(1).Where(pair=>(slots&pair.Slot)!=0).Select(pair=>pair.Name));
}
