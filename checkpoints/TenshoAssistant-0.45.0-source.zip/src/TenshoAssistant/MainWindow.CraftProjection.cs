using System.Numerics;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.Craft;
using TenshoAssistant.Items;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private CraftLiveFrame? projectionFrame;private CraftActionCatalog? projectionCatalog;private CraftProjectionResult? projectionResult;
    private uint projectionRecipe;private int projectionTarget,projectionSort;
    private void DrawCraftProjection(CraftLiveState state)
    {
        if(!ImGui.CollapsingHeader("Comparer les prochains coups · expérimental",ImGuiTreeNodeFlags.DefaultOpen))return;
        ImGui.TextWrapped("Projection d'une seule action en condition Normale, parmi les actions admissibles selon le client hors vérification de recharge. Les intervalles conservent les combos encore possibles. Aucun calcul de rotation complète, aucune action lancée, aucune garantie HQ.");
        if(state.Frame is not { } frame || craftActions.State.Catalog is not { } catalog)return;
        var now=DateTimeOffset.UtcNow;
        if(!ReferenceEquals(projectionFrame,frame) || !ReferenceEquals(projectionCatalog,catalog))
        {projectionFrame=frame;projectionCatalog=catalog;projectionResult=CraftLiveProjection.Build(state,catalog,now);}
        if(state.ObservedAt is not { } date || now<date || now-date>TimeSpan.FromSeconds(2))
        {ImGui.TextWrapped("Observation trop ancienne pour afficher une projection.");return;}
        if(projectionResult is not { } result)return;
        if(frame.Recipe is { } recipe && projectionRecipe!=recipe.RecipeId)
        {projectionRecipe=recipe.RecipeId;projectionTarget=recipe.Simulation?.Quality ?? 0;}
        ImGui.SetNextItemWidth(110);ImGui.InputInt("Cible de qualité pour signaler une fin prématurée",ref projectionTarget,0);
        if(projectionTarget<0 || projectionTarget>(frame.Recipe?.Simulation?.Quality ?? 0)){ImGui.TextWrapped("La cible doit être comprise entre zéro et la qualité maximale de cette recette.");return;}
        if(ImGui.RadioButton("Gain qualité immédiat",projectionSort==0))projectionSort=0;ImGui.SameLine();
        if(ImGui.RadioButton("Gain progression immédiat",projectionSort==1))projectionSort=1;ImGui.SameLine();
        if(ImGui.RadioButton("Solidité restante",projectionSort==2))projectionSort=2;
        foreach(var issue in result.Issues)ImGui.TextWrapped(issue);
        if(result.Actions.Count==0){ImGui.TextDisabled("Aucune action projetable avec cette observation et ce modèle.");return;}
        ImGui.TextDisabled("Le tri porte sur un gain immédiat ; il ne choisit pas un plan de craft viable.");
        if(ImGui.BeginTable("LiveCraftProjection",7,ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingStretchProp))
        {
            try
            {
                ImGui.TableSetupColumn("Action",ImGuiTableColumnFlags.WidthStretch,2);
                foreach(var title in new[]{"Progression après","Qualité après","Solidité après","Coût PS","Calme intérieur après","Résultat immédiat"})ImGui.TableSetupColumn(title);
                ImGui.TableHeadersRow();
                var rows=result.Actions.OrderBy(row=>row.Broken).ThenByDescending(row=>projectionSort==0 ? row.Quality.Min:projectionSort==1 ? row.Progress.Min:row.Durability.Min).ThenBy(row=>row.CpCost.Max);
                foreach(var row in rows)
                {
                    ImGui.TableNextRow();ImGui.TableNextColumn();DrawItemIcon(new ItemDefinition(0,row.Metadata.Name,false,row.Metadata.Icon),new Vector2(24));ImGui.SameLine();ImGui.TextWrapped(row.Metadata.Name);
                    if(ImGui.IsItemHovered())ImGui.SetTooltip($"{row.Metadata.Description}\n{row.Alternatives} état(s) de combo/historique compatible(s) dans le modèle.");
                    ImGui.TableNextColumn();ImGui.TextUnformatted(row.Progress.ToString());ImGui.TableNextColumn();ImGui.TextUnformatted(row.Quality.ToString());
                    ImGui.TableNextColumn();ImGui.TextUnformatted(row.Durability.ToString());ImGui.TableNextColumn();ImGui.TextUnformatted(row.CpCost.ToString());
                    ImGui.TableNextColumn();ImGui.TextUnformatted(row.InnerQuiet.ToString());ImGui.TableNextColumn();
                    var text=row.Broken ? "Casse la synthèse":row.Completed ? row.Quality.Min>=projectionTarget ? "Termine avec cible atteinte":"Termine sous la cible":"Continue";
                    ImGui.TextColored(row.Broken || row.Completed && row.Quality.Min<projectionTarget ? Accent:row.Completed ? Success:Muted,text);
                }
            }
            finally{ImGui.EndTable();}
        }
    }
}
