using System.Numerics;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.MiniGames;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private readonly int[] cactpotBoard = new int[9];
    private CancellationTokenSource? cactpotCancellation;
    private Task<(MiniCactpotResult? Result, string? Error)>? cactpotTask;
    private MiniCactpotResult? cactpotResult;
    private string? cactpotError;
    private int cactpotGeneration;
    private int cactpotTaskGeneration;
    private bool windowDisposed;

    private void DrawMiniCactpot()
    {
        Heading("Mini Cactpot", "Saisissez les chiffres révélés du ticket · 0 représente une case cachée");
        if (windowDisposed) return;
        if (cactpotTask?.IsCompleted == true)
        {
            var completed = cactpotTask.GetAwaiter().GetResult();
            cactpotTask = null;
            if (cactpotTaskGeneration == cactpotGeneration) { cactpotResult = completed.Result; cactpotError = completed.Error; }
        }
        if (ImGui.BeginTable("CactpotBoard", 3, ImGuiTableFlags.SizingFixedFit))
        {
            try
            {
                for (var index = 0; index < 9; index++)
                {
                    ImGui.TableNextColumn();
                    ImGui.SetNextItemWidth(55);
                    if (ImGui.InputInt($"##Cactpot{index}", ref cactpotBoard[index], 0, 0))
                    {
                        cactpotGeneration++; cactpotResult = null; cactpotError = null;
                        cactpotCancellation?.Cancel();
                    }
                }
            }
            finally { ImGui.EndTable(); }
        }
        if (ImGui.Button("Effacer le ticket"))
        {
            Array.Clear(cactpotBoard); cactpotGeneration++; cactpotResult = null; cactpotError = null;
            cactpotCancellation?.Cancel();
        }
        ImGui.SameLine();
        ImGui.BeginDisabled(cactpotTask is not null);
        try
        {
            if (ImGui.Button("Calculer le meilleur choix"))
            {
                cactpotCancellation?.Dispose();
                cactpotCancellation = new CancellationTokenSource();
                var copied = cactpotBoard.ToArray();
                var token = cactpotCancellation.Token;
                cactpotTaskGeneration = cactpotGeneration;
                cactpotTask = Task.Run<(MiniCactpotResult?, string?)>(() =>
                {
                    try { return (MiniCactpotSolver.Solve(copied, token), null); }
                    catch (OperationCanceledException) { return (null, null); }
                    catch (Exception error) { return (null, error.Message); }
                });
            }
        }
        finally { ImGui.EndDisabled(); }
        ImGui.TextDisabled($"{cactpotBoard.Count(value => value != 0)}/4 chiffres révélés · lignes et colonnes comptées depuis le coin supérieur gauche");
        if (cactpotTask is not null) ImGui.TextDisabled("Calcul en cours…");
        if (cactpotError is { } error) ImGui.TextWrapped(error);
        if (cactpotResult is not { } result) return;
        ImGui.TextColored(Accent, result.ChooseLine ? "Choisissez une ligne" : "Prochaine case à révéler");
        ImGui.TextUnformatted($"Récompense espérée avec les choix suivants optimaux : {result.ExpectedReward:N2} PGS");
        var lines = new[] { "Ligne du haut", "Ligne centrale", "Ligne du bas", "Colonne gauche", "Colonne centrale", "Colonne droite", "Diagonale ↘", "Diagonale ↙" };
        for (var index = 0; index < result.Choices.Count; index++)
        {
            if (result.Choices[index] is not { } value) continue;
            var label = result.ChooseLine ? lines[index] : $"Ligne {index / 3 + 1}, colonne {index % 3 + 1}";
            var best = Math.Abs(value - result.ExpectedReward) < 0.000001;
            ImGui.TextColored(best ? Success : Muted, $"{(best ? "★ " : "")}{label} : {value:N2} PGS");
        }
        ImGui.TextWrapped("Espérance mathématique sur les chiffres cachés ; le gain d'un ticket individuel reste aléatoire. Saisie et choix dans le jeu restent manuels.");
    }
    public void Dispose()
    {
        if (windowDisposed) return;
        windowDisposed = true; cactpotGeneration++;
        craftChain.Dispose();
        craftSolve.Dispose();
        triadSolve.Dispose();
        preparationPrices.Dispose();
        cactpotCancellation?.Cancel(); cactpotCancellation?.Dispose();
        cactpotResult = null;
    }
}
