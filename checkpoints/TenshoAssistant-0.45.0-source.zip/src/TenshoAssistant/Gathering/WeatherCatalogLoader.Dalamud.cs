using System.Diagnostics;
using Dalamud.Plugin.Services;
using Lumina.Excel.Sheets;

namespace TenshoAssistant.Gathering;

internal sealed class WeatherCatalogLoader : IDisposable
{
    private readonly object gate=new();private readonly WeatherCatalogService service;private readonly IDataManager data;private readonly IFramework framework;private readonly IPluginLog log;
    private readonly List<ZoneWeather> zones=[];private readonly Dictionary<uint,WeatherDefinition> weathers=[];private int position;private bool stopped;
    public WeatherCatalogLoader(WeatherCatalogService service,IDataManager data,IFramework framework,IPluginLog log)
    {this.service=service;this.data=data;this.framework=framework;this.log=log;framework.Update+=Update;}
    private void Update(IFramework unused)
    {
        lock(gate)
        {
            if(stopped || !framework.IsInFrameworkUpdateThread || framework.IsFrameworkUnloading)return;
            try
            {
                var sheet=data.GetExcelSheet<TerritoryType>();var rates=data.GetExcelSheet<WeatherRate>();var weatherSheet=data.GetExcelSheet<Weather>();
                var end=Math.Min(position+32,sheet.Count);var started=Stopwatch.GetTimestamp();
                while(position<end)
                {
                    var row=sheet.GetRowAt(position++);if(row.RowId==0)continue;var shares=new List<WeatherShare>();
                    if(row.WeatherRate.RowId!=0 && rates.TryGetRow(row.WeatherRate.RowId,out var rate))
                    {
                        for(var index=0;index<rate.Rate.Count && index<rate.Weather.Count;index++)
                        {
                            if(rate.Rate[index]==0)continue;var id=rate.Weather[index].RowId;shares.Add(new(id,rate.Rate[index]));
                            if(id!=0 && !weathers.ContainsKey(id) && weatherSheet.TryGetRow(id,out var weather))
                                weathers[id]=new(id,weather.Name.ExtractText(),weather.Icon>0 ? (uint)weather.Icon:0);
                        }
                    }
                    zones.Add(new(row.RowId,row.WeatherRate.RowId,shares,row.IndividualWeather.RowId!=0));
                    if(Stopwatch.GetElapsedTime(started)>=TimeSpan.FromMilliseconds(2))break;
                }
                if(position!=sheet.Count)return;
                var version=string.Join(";",data.GameData.Repositories.Values.OrderBy(row=>row.Name).Select(row=>$"{row.Name}={row.Version}"));
                service.Publish(new(weathers.Values,zones,version));Stop();
            }
            catch(Exception error){service.Fail(error);log.Warning(error,"Weather catalog unavailable.");Stop();}
        }
    }
    private void Stop(){stopped=true;framework.Update-=Update;zones.Clear();weathers.Clear();}
    public void Dispose(){lock(gate){if(!stopped)Stop();service.Clear();}}
}
