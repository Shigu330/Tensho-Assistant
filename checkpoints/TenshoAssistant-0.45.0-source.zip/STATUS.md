# État courant

CURRENT_GOAL: CRAFT-LIVE-003 — IMPLEMENTED / TESTED ; comparaison immédiate expérimentale de coups normaux, voir docs/CRAFT-LIVE-003.md
CURRENT_MODEL_CLASS: HEAVY — adaptateur natif et projections à états incomplets
RECOMMENDED_MODEL: HEAVY pour les déductions natives/conditions ; LIGHT pour les tâches mécaniques ; continuation autorisée
MODEL_ESCALATION: None
QUOTA: Relevé 2026-10-29 : 11 % consommés sur 5 h, 33 % semaine (89 % / 67 % disponibles). Réserve utilisateur 5 % sur la fenêtre limitante ; objectif global actif.
LAST_READ: RULES/STATUS/GOAL et sources/docs ciblés relus le 2026-10-29 ; audit 0.44 conservé et documents courants mis à jour.
BUILD: COMPILED Release 0.45.0.0 ; sortie canonique bin/x64/Release
TESTS: TESTED — 290/290 tests ; versions/ZIP/exclusion hôte verts ; projections par intervalles, conditions distinctes 0/1, gates et probes natifs passants
RUNTIME: Banque, stocks, carnet et préparation jusqu'à 0.5.27 confirmés par l'utilisateur. Fonctions 0.6–0.45 non validées en jeu. Tests projection et Macro Chain différés explicitement ; ne pas les redemander.
WORK_COMPLETED: Dix-sept domaines PARTIAL ; copie native typée et admissibilité, comparaison d'un coup normal via modèle partagé, intervalles de combos/historique sans fait inventé, cible et risques immédiats affichés. 290 tests ; aucune exécution ou validation native revendiquée.
BLOCKER: Aucun blocage global. L'utilisateur a différé les tests de projection et Macro Chain ; validation runtime conservée sans redemande. Conditions ordinaires/bonus d'outil peuvent être étudiés indépendamment.
RESUME_FROM: GOAL.md ; TESTING.md pour le protocole de la base.
NEXT_ACTION: Snapshot 0.45.0 puis CRAFT-CONDITIONS-004 : conditions ordinaires et bonus d'outil en condition favorable, avec identification native vérifiée et inconnus explicites. Rotation adaptative complète reste au périmètre ; garder les 17 domaines, réserve de quota 5 %.

| Plugin | Coverage |
|---|---|
| Avant-Garde | PARTIAL — répertoire manuel d'indices natifs, équipements signalés, emplacements/stock/contexte et source datée ; thème courant/teintures/score/attache non déduits |
| Blue Mage Helper | PARTIAL — grimoire, numéros, descriptions, lieux renseignés et acquisition confirmée |
| Character Panel Refined | PARTIAL — attributs natifs, sans formules dérivées |
| Collections | PARTIAL — montures, mascottes, emotes et cartes Triple Triade ; inconnu distinct d'absent |
| Craftimizer | PARTIAL — simulation/recherche/export/séquences, observation et projection d'un coup normal ; conditions/rotation native/recettes spéciales et runtime à compléter |
| Duty Loot Preview | PARTIAL — consultation manuelle par contenu, coffres/récompenses, icônes/contexte, provenance et cache ; drops directs non interprétés, données externes partielles |
| ezMiniCactpot | PARTIAL — solveur optimal manuel ; adaptation native à développer |
| GatherBuddy | PARTIAL — sources récolte/pêche, cartes, météo de zone, horloge ET et prochaines plages UTC ; présence/prérequis météo/accès/harpon non couverts |
| Item Use | PARTIAL — usages du catalogue de recettes |
| LazyGatherer | PARTIAL — optimiseur de scénario manuel MIN/BTN, espérances/seuils et copie des PR courants ; régénération/procs/collectionnables et adaptation du point natif non couverts |
| Macro Chain | PARTIAL — séquences à marqueur final, lancement explicite, arrêt, persistance ; natif à confirmer |
| Mappy | PARTIAL — navigateur natif, repères favoris persistants, ressources de zone et prévisions météo statiques ; météo forcée non observée |
| Monster Loot Hunter | PARTIAL — associations matériau/monstre, fiches/niveaux/lieux et carte de zone, transport/cadence partagés, contexte ; données communautaires partielles |
| Price Insight | PARTIAL — prix manuels/survol, coût direct et terminal des chaînes, cache/cadence/priorités communs, dates NQ/HQ par monde |
| QuestTracker | PARTIAL — états natifs, séquence, fiche et liens de prérequis/suivantes ; disponibilité non calculée |
| SortaKinda | PARTIAL — aperçu de règles sauvegardées, sans déplacement natif |
| TriadBuddy | PARTIAL — carnet/deck/solveur manuel, observation des faces opt-in expérimentale ; identités/règles/trait natifs et autres règles non établis |

