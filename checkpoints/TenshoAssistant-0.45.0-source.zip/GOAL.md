# GOAL sélectionné

ID: CRAFT-LIVE-003
OBJECTIVE: Comparer un coup depuis une observation native cohérente, avec intervalles d'états inconnus, puis poursuivre le périmètre complet jusqu'à la réserve de quota de 5 %.
CURRENT_STATE: IMPLEMENTED / TESTED en 0.45.0, 290 tests/package verts ; valeurs typées et admissibilités copiées, projection immédiate normale, coûts/IQ par intervalles et cible explicite. Conventions condition handler1/addon0 établies dans les sources ; aucune capture en jeu. Tests projection/Macro Chain reportés par l'utilisateur.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: CraftLiveProjection/Raw/Reader, MainWindow.CraftProjection/Live/Tools ; Plugin/DI ; CraftProjectionTests, probes et documents.
IN_SCOPE: Projection d'une seule action parmi admissibilités natives hors recharge, modèle partagé et ressources concordantes, ambiguïtés gardées en intervalles, état périmé/incompatible refusé ; aucune exécution ou rotation complète inventée.
OUT_OF_SCOPE: Revendiquer remplacement intégral ou validation native sans preuve ; commander une action depuis cette comparaison.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: Relevé 2026-10-29 : 89 % disponibles sur 5 h et 67 % semaine ; réserve utilisateur 5 % sur la fenêtre limitante. Objectif global actif.
NEXT_ACTION: Snapshot 0.45.0 puis CRAFT-CONDITIONS-004 : étendre conditions ordinaires et établir le bonus d'outil favorable depuis données natives vérifiées, bloquer l'inconnu au lieu d'un bonus supposé absent. Rotation native et autres fonctions des 17 domaines restent PARTIAL ; tests projection/Macro Chain différés, ne pas redemander.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
