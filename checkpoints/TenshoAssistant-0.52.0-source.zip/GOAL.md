# GOAL sélectionné

ID: USE-HOVER-003
OBJECTIVE: Réunir le survol des usages et des prix autour d’un contexte commun sans réseau implicite, puis poursuivre les 17 outils jusqu’à la réserve de quota de 5 %.
CURRENT_STATE: IMPLEMENTED / TESTED en 0.52.0, 343 tests/package verts ; contexte normalisé owner/âge/stabilité et panneau commun, usages seuls sans HTTP, garde de scope des prix et priorité manuelle testées. Survol/rendu réels non validés.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: Items/ItemHover/Reader ; Market/MarketHover/ItemHoverCoordinator/MarketService ; Configuration/Settings ; MainWindow.MarketHover ; Plugin ; ItemHoverTests ; ConfigSerializationProbe/GatheringProbe ; docs.
IN_SCOPE: Option locale d’usages au survol, indépendante des prix et du monde ; objet de base/qualité explicites, un lecteur et un panneau ; pas de requête de prix si seulement usages. Cache, délai et priorité du marché conservés.
OUT_OF_SCOPE: Inférer demande GC/disponibilité/acceptation réelles, afficher comme courant un contexte périmé, tarifer un objet spécial ou collectionnable, revendiquer validation native. Autres fonctions des 17 domaines toujours au périmètre.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: Relevé 2026-10-29 : 54 % disponibles sur 5 h et 55 % semaine ; réserve utilisateur 5 %. Objectif global actif.
NEXT_ACTION: USE-CONTEXT-004 : vérifier les signatures locales et source officielle IContextMenu pour une action explicite d’ouverture des usages/outils depuis un objet, avec identité normalisée copiée et garde de propriétaire. Pas de nouveau lecteur de survol ou de réseau. Conserver l’étude du tri natif (priorité A) et l’inconnu GP ; tests craft/Macro Chain différés.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
