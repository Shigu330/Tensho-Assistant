using Newtonsoft.Json;
using TenshoAssistant;
using TenshoAssistant.Craft;

var recipe=new RecipeDefinition(2819,12892,3,"Cuisine",59,[],7);
var preset=CraftPresets.Create(recipe,"Essai JSON local",[CraftActionKind.Reflect,CraftActionKind.TrainedPerfection,CraftActionKind.BasicSynthesis]);
var configuration=new Configuration{CraftPresets=[preset],ItemUsagesOnHover=true,MarketPricesOnHover=true};
foreach(var handling in new[]{TypeNameHandling.None,TypeNameHandling.Auto,TypeNameHandling.Objects})
{
    // Local generated fixture only; never deserialize external JSON with type names enabled.
    var settings=new JsonSerializerSettings{TypeNameHandling=handling};
    var encoded=JsonConvert.SerializeObject(configuration,settings);
    var decoded=JsonConvert.DeserializeObject<Configuration>(encoded,settings) ?? throw new Exception("Missing configuration");
    var restored=decoded.CraftPresets?.Single() ?? throw new Exception("Missing sequence");
    if(decoded.Version!=1 || !CraftPresets.Valid(restored) || restored.Id!=preset.Id || restored.RecipeId!=2819 || restored.CraftTypeId!=7
        || !restored.Actions.SequenceEqual(preset.Actions) || restored.SavedAt!=preset.SavedAt || !decoded.ItemUsagesOnHover || !decoded.MarketPricesOnHover)throw new Exception("Serialization mismatch");
    var legacy=JsonConvert.DeserializeObject<Configuration>("{\"Version\":1}",settings) ?? throw new Exception("Missing legacy configuration");
    if(legacy.ItemUsagesOnHover || legacy.MarketPricesOnHover)throw new Exception("Missing fields enabled hover unexpectedly.");
    Console.WriteLine($"PASS Newtonsoft.Json {typeof(JsonConvert).Assembly.GetName().Version}, mode {handling}: configuration v1, recipe ids, immutable actions and UTC date roundtrip");
}
