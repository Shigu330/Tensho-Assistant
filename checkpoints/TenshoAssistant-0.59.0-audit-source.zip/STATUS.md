# État courant

CURRENT_GOAL: BASE-AUDIT-002 — audit de périmètre/livraison effectué ; base 0.59.0.0 compilée/testée, voir docs/BASE-AUDIT-002.md
CURRENT_MODEL_CLASS: HEAVY — configuration/règles partagées
RECOMMENDED_MODEL: HEAVY pour l’intégration native des menus/tri ; LIGHT pour les tâches mécaniques ; continuation autorisée
MODEL_ESCALATION: None
QUOTA: Relevé final 2026-10-29 : 95 % consommés sur 5 h, 53 % semaine (5 % / 47 % disponibles). Réserve utilisateur atteinte : pause conditionnelle demandée à ce seuil. Objectif global non achevé ; reprise après instruction utilisateur et contrôle du compteur.
LAST_READ: RULES/STATUS/GOAL, règles/configuration/éditeur relus ; sortie canonique, copies de DLL et paquet ZIP inspectés. Snapshot 0.58 sauvegardé.
BUILD: COMPILED Release 0.59.0.0 ; sortie canonique bin/x64/Release
TESTS: TESTED — 385/385 tests ; package/versions/exclusion hôte verts, zéro avertissement/erreur. Six groupes de modèles, Newtonsoft trois modes et nouveaux contrôles SHA-256 ZIP/canonique passants.
RUNTIME: Banque, stocks, carnet et préparation jusqu’à 0.5.27 confirmés par l’utilisateur. Fonctions 0.6–0.59 non validées en jeu. Tests projection et Macro Chain explicitement différés ; ne pas les redemander.
WORK_COMPLETED: Dix-sept domaines PARTIAL ; bibliothèque de 64 modèles sans observation/owner, noms uniques, copies, géométrie strictement compatible et rebind au scope courant en brouillon. Profils conservés séparément, aucune application/capture implicite. Livraison x64/Release 0.59 contrôlée contre ZIP par SHA-256 ; archive legacy 0.5.22 intacte.
BLOCKER: Aucun blocage global. Le bonus natif d’Abondance reste inconnu : sources divergentes et aucun getter nommé confirmé dans les bindings étudiés. Ne pas inventer une formule ; travaux indépendants poursuivis.
RESUME_FROM: GOAL.md ; TESTING.md pour le protocole de la base.
NEXT_ACTION: Vérifier le compteur avant toute reprise, réserve 5 %. Puis étude GatherBuddy/pêche sur catalogue et feuilles/source primaire, appâts/prérequis non déduits sans preuve. Audit 17 outils/71 liens/DLL-ZIP terminé. GP inconnu et essais craft/Macro Chain différés conservés.

| Plugin | Coverage |
|---|---|
| Avant-Garde | PARTIAL — répertoire manuel d'indices natifs, équipements signalés, emplacements/stock/contexte et source datée ; thème courant/teintures/score/attache non déduits |
| Blue Mage Helper | PARTIAL — grimoire, numéros, descriptions, lieux renseignés et acquisition confirmée |
| Character Panel Refined | PARTIAL — attributs natifs, sans formules dérivées |
| Collections | PARTIAL — montures, mascottes, emotes et cartes Triple Triade ; inconnu distinct d'absent |
| Craftimizer | PARTIAL — simulation/recherche/export/séquences, observation et projection d'un coup normal ; conditions/rotation native/recettes spéciales et runtime à compléter |
| Duty Loot Preview | PARTIAL — consultation manuelle par contenu, coffres/récompenses, icônes/contexte, provenance et cache ; drops directs non interprétés, données externes partielles |
| ezMiniCactpot | PARTIAL — solveur exact manuel et mode observé opt-in LotteryDaily ; conseil actualisé, aucune commande ; adaptation/rendu natifs non validés en jeu |
| GatherBuddy | PARTIAL — sources/maps/horaires/météo statiques et point courant observé opt-in (objets/icônes/taux affichés, contexte) ; présence/prérequis/harpon et validation native non couverts |
| Item Use | PARTIAL — recettes, mandats, candidats GC/aquarium, survol et menu Inventory opt-in ; autres usages/disponibilité, liens de discussion et runtime à compléter |
| LazyGatherer | PARTIAL — optimiseur manuel avec effets explicitement déclarés, observation du point et copie de ressources ; décodeur natif/bonus/régénération/procs/collectionnables et validation runtime à compléter |
| Macro Chain | PARTIAL — séquences à marqueur final, lancement explicite, arrêt, persistance ; natif à confirmer |
| Mappy | PARTIAL — navigateur natif, repères favoris persistants, ressources de zone et prévisions météo statiques ; météo forcée non observée |
| Monster Loot Hunter | PARTIAL — associations matériau/monstre, fiches/niveaux/lieux et carte de zone, transport/cadence partagés, contexte ; données communautaires partielles |
| Price Insight | PARTIAL — consultation manuelle et prix au survol opt-in, NQ/HQ/monde, cache/cadence/priorités partagés ; contexte mutualisé et scope owner/monde, runtime à confirmer |
| QuestTracker | PARTIAL — états natifs, séquence, fiche et liens de prérequis/suivantes ; disponibilité non calculée |
| SortaKinda | PARTIAL — profils/modèles, critères, zones protégées/filtrées et inversion, application visuelle après capture directe ; autres filtres/automatisations choisies et validation runtime à compléter |
| TriadBuddy | PARTIAL — carnet/deck/solveur manuel, observation des faces opt-in expérimentale ; identités/règles/trait natifs et autres règles non établis |

