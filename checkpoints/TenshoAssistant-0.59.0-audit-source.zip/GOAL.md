# GOAL sélectionné

ID: BASE-AUDIT-002
OBJECTIVE: Vérifier livraison et périmètre de la base, puis poursuivre les 17 domaines jusqu’à la réserve de quota de 5 %.
CURRENT_STATE: Audit ciblé effectué : 17 références présentes/PARTIAL, liens locaux et chemins vérifiés ; 0.59.0.0, 385 tests/package, Newtonsoft et SHA-256 verts. Objectif global non achevé ; rendu/application/persistance natifs non observés.
FILES: Inventory/InventorySortTemplates et validation partagée ; Configuration ; MainWindow.SortTemplates/SortRules/Tools ; InventorySortTemplateTests ; ConfigSerializationProbe ; scripts/Verify.ps1 ; docs/SORT-TEMPLATES-007.md.
IN_SCOPE: 64 modèles nommés, GUID/version, géométrie compatible, listes copiées, create/update/delete avec rollback, rebind au scope courant et aucune capture/application implicite. Configuration v1 compatible.
OUT_OF_SCOPE: Copier propriétaire/observation, rogner des zones pour une autre géométrie, mise à jour silencieuse de géométrie, tri automatique. Les 17 domaines restent PARTIAL.
VALIDATION: Verify.ps1 385/385, package/versions/ZIP/SHA-256/exclusion hôte verts, zéro avertissement/erreur ; six groupes bibliothèque et chaîne vers permutation d’une autre sacoche. Newtonsoft None/Auto/Objects avec bibliothèque imbriquée passants.
QUOTA: Relevé final 2026-10-29 : 5 % disponibles sur 5 h et 47 % semaine. Seuil d’arrêt utilisateur atteint ; pause conditionnelle, objectif global non achevé. Sauvegarde de reprise conservée ; attendre instruction utilisateur avant continuation.
NEXT_ACTION: Contrôler le quota et garder 5 % avant tout travail lourd. Audit effectué : 17 noms/17 PARTIAL, 71 liens locaux dans 61 Markdown, paquet canonique 0.59.0.0 et 385 tests. Reprise indépendante : étude du catalogue GatherBuddy/pêche et des feuilles/sources d’appâts/prérequis, sans inventer d’informations. GP inconnu et essais projection/Macro Chain différés conservés.
DEFINITION_OF_DONE: Tranche intégrée compilée, tests/package verts, limites documentées et sauvegarde source ; aucun domaine global promu complet sans preuve.
