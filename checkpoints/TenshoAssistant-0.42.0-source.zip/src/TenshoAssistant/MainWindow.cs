using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Windowing;
using Dalamud.Plugin.Services;
using TenshoAssistant.Inventory;
using TenshoAssistant.Items;
using TenshoAssistant.Craft;
using TenshoAssistant.Gathering;
using TenshoAssistant.Collections;
using TenshoAssistant.Market;
using TenshoAssistant.Quests;
using TenshoAssistant.Character;
using TenshoAssistant.Maps;
using TenshoAssistant.Macros;
using TenshoAssistant.MiniGames;
using TenshoAssistant.Duties;
using TenshoAssistant.Monsters;
using TenshoAssistant.Fashion;

namespace TenshoAssistant;

internal sealed partial class MainWindow : Window, IDisposable
{
    private enum Page { Home, Items, Gathering, Maps, MacroChain, SortPreview, Collections, BlueMagic, TripleTriad, Market, Quests, Character, MiniCactpot, Settings, Diagnostics, DutyLoot, MonsterLoot, GatheringGp, Fashion, CraftSimulation, CraftLive, Weather }
    private static readonly Vector4 Accent = new(0.94f, 0.77f, 0.46f, 1);
    private static readonly Vector4 Success = new(0.52f, 0.85f, 0.66f, 1);
    private static readonly Vector4 Muted = new(0.65f, 0.69f, 0.75f, 1);
    private static readonly string BuildVersion = typeof(Plugin).Assembly.GetName().Version?.ToString(3) ?? "?";
    private readonly Configuration configuration;
    private readonly Action save;
    private readonly IPluginLog log;
    private readonly InventoryService inventory;
    private readonly ItemCatalogService itemCatalog;
    private readonly RecipeCatalogService recipeCatalog;
    private readonly CraftActionCatalogService craftActions;
    private readonly CraftLiveService craftLive;
    private readonly WeatherCatalogService weather;
    private readonly GatheringCatalogService gatheringCatalog;
    private readonly CollectionService collections;
    private readonly MarketService market;
    private readonly MarketHoverService marketHover;
    private readonly QuestService quests;
    private readonly CharacterStatsService characterStats;
    private readonly MapCatalogService maps;
    private readonly MacroObservationService macroObservations;
    private readonly MacroChainService macroChain;
    private readonly TriadObservationService triadObservation;
    private readonly DutyCatalogService duties;
    private readonly DutyLootService dutyLoot;
    private readonly MonsterLootService monsterLoot;
    private readonly GpCatalogService gpActions;
    private readonly FashionHintService fashionHints;
    private readonly FashionDataService fashionData;
    private string questQuery = string.Empty;
    private string questCategory = string.Empty;
    private int questFilter = 1;
    private CollectionKind collectionKind;
    private string collectionQuery = string.Empty;
    private int collectionFilter;
    private uint selectedBlueSpell;
    private bool focusGatherTab;
    private uint? gatheringTypeFilter;
    private BankKey? sortPreviewOrigin;
    private int sortPreviewField = -1;
    private bool sortPreviewDescending;
    private readonly InventoryBankService bank;
    private readonly BankInventoryBridge bankBridge;
    private readonly ITextureProvider textures;
    private readonly IGameGui gameGui;
    private Page page;
    private string? saveError;
    private int itemId;
    private string itemQuery = string.Empty;
    private string toolQuery = string.Empty;
    private string bankQuery = string.Empty;
    private BankKey? bankOriginFilter;
    private bool bankPersonalFilter;
    private string bankCategoryFilter = string.Empty;
    private int bankQualityFilter;
    private bool focusCraftTab;
    private bool focusStocksTab;
    private bool focusBankTab;
    private ItemCatalog? searchedCatalog;
    private IReadOnlyList<ItemDefinition> searchResults = [];
    private readonly Stack<uint> craftHistory = [];
    private string craftBookFilter = string.Empty;
    private string craftBookQuery = string.Empty;
    private uint craftBookRecipe;
    private int craftPlanTarget = 1;
    private readonly Dictionary<uint, ItemHoldingsSummary> recipeHoldingsCache = [];
    private InventorySnapshot? recipeHoldingsLive;
    private BankState? recipeHoldingsBank;
    private ulong recipeHoldingsCharacter;

    public MainWindow(Configuration configuration, Action save, IPluginLog log,
        InventoryService inventory, ItemCatalogService itemCatalog, RecipeCatalogService recipeCatalog, GatheringCatalogService gatheringCatalog, CollectionService collections, MarketService market, MarketHoverService marketHover, QuestService quests, CharacterStatsService characterStats, MapCatalogService maps, MacroObservationService macroObservations, MacroChainService macroChain, TriadObservationService triadObservation, InventoryBankService bank,
        BankInventoryBridge bankBridge, ITextureProvider textures, IGameGui gameGui, DutyCatalogService duties, DutyLootService dutyLoot, MonsterLootService monsterLoot,GpCatalogService gpActions,FashionHintService fashionHints,FashionDataService fashionData,CraftActionCatalogService craftActions,CraftLiveService craftLive,WeatherCatalogService weather) : base("Tensho--Assistant###TenshoMain")
    {
        this.configuration = configuration;
        this.save = save;
        this.log = log;
        this.inventory = inventory;
        this.itemCatalog = itemCatalog;
        this.recipeCatalog = recipeCatalog;
        this.craftActions = craftActions;
        this.craftLive = craftLive;
        this.weather = weather;
        this.gatheringCatalog = gatheringCatalog;
        this.collections = collections;
        this.market = market;
        this.marketHover = marketHover;
        this.quests = quests;
        this.characterStats = characterStats;
        this.maps = maps;
        this.macroObservations = macroObservations;
        this.macroChain = macroChain;
        this.triadObservation = triadObservation;
        this.duties = duties;
        this.dutyLoot = dutyLoot;
        this.monsterLoot = monsterLoot;
        this.gpActions=gpActions;
        this.fashionHints=fashionHints; this.fashionData=fashionData;
        this.bank = bank;
        this.bankBridge = bankBridge;
        this.textures = textures;
        this.gameGui = gameGui;
        Size = new Vector2(1040, 700);
        SizeCondition = ImGuiCond.FirstUseEver;
        SizeConstraints = new WindowSizeConstraints
        {
            MinimumSize = new Vector2(760, 480),
            MaximumSize = new Vector2(float.MaxValue, float.MaxValue),
        };
    }

    public override void Draw()
    {
        monsterLoot.SelectItem((uint)Math.Max(0,itemId));
        ValidateGpCopy();
        ValidateCraftCopy();
        ValidateCraftSearch();
        craftChain.ValidateContext(bankBridge.State.CharacterId, (uint)Math.Max(0, itemId), craftPlanTarget, recipeCatalog.State.Catalog);
        triadSolve.ValidateContext(bankBridge.State.CharacterId, triadRevision);
        preparationPrices.ValidateContext(bankBridge.State.CharacterId,market.State.WorldId,(uint)Math.Max(0,itemId),craftPlanTarget,costBasisIndex,costQualityIndex,craftChainChoiceRevision);
        ImGui.TextColored(Accent, "TENSHO  /  ASSISTANT");
        ImGui.SameLine();
        ImGui.TextDisabled($"v{BuildVersion}");
        ImGui.TextDisabled("Vos objets, vos activités et vos outils dans un espace commun.");
        ImGui.Separator();

        var height = Math.Max(260, ImGui.GetContentRegionAvail().Y - ImGui.GetFrameHeightWithSpacing());
        if (ImGui.BeginTable("Workspace", 2, ImGuiTableFlags.SizingStretchProp))
        {
            try
            {
                ImGui.TableSetupColumn("Navigation", ImGuiTableColumnFlags.WidthFixed, 200);
                ImGui.TableSetupColumn("Contenu", ImGuiTableColumnFlags.WidthStretch);
                ImGui.TableNextRow();
                ImGui.TableSetColumnIndex(0);
                var showNavigation = ImGui.BeginChild("NavigationPane", new Vector2(0, height), true);
                try { if (showNavigation) DrawNavigation(); }
                finally { ImGui.EndChild(); }

                ImGui.TableSetColumnIndex(1);
                var showContent = ImGui.BeginChild("ContentPane", new Vector2(0, height), true);
                try
                {
                    if (showContent)
                    {
                        switch (page)
                        {
                            case Page.Home: DrawHome(); break;
                            case Page.Items: DrawItems(); break;
                            case Page.Gathering: DrawGatheringBrowser(); break;
                            case Page.Maps: DrawMaps(); break;
                            case Page.DutyLoot: DrawDutyLoot(); break;
                            case Page.MonsterLoot: DrawMonsterLoot(); break;
                            case Page.GatheringGp: DrawGatheringGp(); break;
                            case Page.Fashion: DrawFashion(); break;
                            case Page.CraftSimulation: DrawCraftSimulation(); break;
                            case Page.CraftLive: DrawCraftLive(); break;
                            case Page.Weather: DrawWeather(); break;
                            case Page.MacroChain: DrawMacroChain(); break;
                            case Page.SortPreview: DrawSortPreview(); break;
                            case Page.Collections: DrawCollections(); break;
                            case Page.BlueMagic: DrawCollections(true); break;
                            case Page.TripleTriad: DrawTripleTriad(); break;
                            case Page.Market: DrawMarket(); break;
                            case Page.Quests: DrawQuests(); break;
                            case Page.Character: DrawCharacterStats(); break;
                            case Page.MiniCactpot: DrawMiniCactpot(); break;
                            case Page.Settings: DrawSettings(); break;
                            case Page.Diagnostics: DrawDiagnostics(); break;
                        }
                    }
                }
                finally { ImGui.EndChild(); }
            }
            finally { ImGui.EndTable(); }
        }
        ImGui.Separator();
        ImGui.TextDisabled("/tensho");
        ImGui.SameLine();
        ImGui.TextDisabled("Sacs en direct · Servants et chocobo : imports manuels datés");
    }

    private void DrawNavigation()
    {
        ImGui.TextDisabled("ESPACE DE TRAVAIL");
        Navigation("Accueil & outils", Page.Home);
        Navigation("Objets & rangements", Page.Items);
        ImGui.Spacing();
        ImGui.Separator();
        ImGui.TextDisabled("PRÉFÉRENCES");
        Navigation("Réglages", Page.Settings);
        Navigation("Diagnostics", Page.Diagnostics);
        ImGui.Spacing();
        ImGui.Separator();
        ImGui.TextDisabled("OBJET EN CONTEXTE");
        if (SelectedItem is { } selected)
        {
            DrawItemIcon(selected, new Vector2(32));
            ImGui.TextWrapped(selected.Name);
            ImGui.TextDisabled($"ID {selected.Id}");
            if (ImGui.SmallButton("Voir les quantités")) { page = Page.Items; focusStocksTab = true; }
            DrawContextTools();
        }
        else if (itemId > 0) ImGui.TextWrapped($"Objet ID {itemId}");
        else ImGui.TextWrapped("Sélectionnez un objet pour le conserver entre les outils.");
    }

    private void Navigation(string label, Page destination)
    {
        if (ImGui.Selectable(label, page == destination, ImGuiSelectableFlags.None, new Vector2(0, 30)))
            page = destination;
    }

    private ItemDefinition? SelectedItem => itemId > 0 ? itemCatalog.State.Catalog?.Find((uint)itemId) : null;

    private static void Heading(string title, string description)
    {
        ImGui.TextColored(Accent, title);
        ImGui.TextWrapped(description);
        ImGui.Spacing();
        ImGui.Separator();
        ImGui.Spacing();
    }

    private void DrawHome()
    {
        DrawTools();
    }

    private void DrawCatalogStatus()
    {
        var state = itemCatalog.State;
        if (state.Catalog is { } catalog)
            ImGui.TextColored(Success, $"Catalogue prêt : {catalog.Count:N0} objets · {catalog.Metadata.Language}");
        else ImGui.TextWrapped(state.Error ?? (state.TotalRows > 0
            ? $"Catalogue en cours : {state.RowsCopied:N0}/{state.TotalRows:N0} lignes copiées."
            : "Préparation du catalogue…"));
    }
}
