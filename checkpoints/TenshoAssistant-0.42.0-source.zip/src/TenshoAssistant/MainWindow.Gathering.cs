using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Game.Text.SeStringHandling.Payloads;
using TenshoAssistant.Items;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private void OpenGathering(uint id)
    {
        SelectItem(id);
        page = Page.Items;
        gatheringTypeFilter = null;
        focusGatherTab = true;
    }

    private void DrawGathering()
    {
        Heading("Lieux de récolte", "Sources connues dans les données du jeu pour l'objet en contexte.");
        if (itemId <= 0)
        {
            ImGui.TextWrapped("Sélectionnez un objet dans Recherche ou dans la Banque, ou un ingrédient de recette.");
            return;
        }
        DrawItemIcon(SelectedItem, new Vector2(40));
        ImGui.SameLine();
        ImGui.TextColored(Accent, SelectedItem?.Name ?? $"ID {itemId}");
        var state = gatheringCatalog.State;
        if (state.Catalog is not { } catalog)
        {
            ImGui.TextWrapped(state.Error ?? $"Préparation des lieux de récolte : {state.Copied:N0}/{state.Total:N0}");
            return;
        }
        var sources = catalog.ForItem((uint)itemId);
        if (sources.Count == 0)
        {
            ImGui.TextWrapped("Aucun lieu trouvé dans le catalogue de points de récolte. Cet objet peut avoir d'autres sources.");
            ImGui.TextDisabled("Monstres, boutiques, échanges et pêche sous-marine ne sont pas couverts ici.");
            return;
        }
        if (gatheringTypeFilter is { } filter && !sources.Any(source => source.TypeId == filter)) gatheringTypeFilter = null;
        if (ImGui.SmallButton("Tous les types")) gatheringTypeFilter = null;
        foreach (var type in sources.DistinctBy(source => source.TypeId))
        {
            ImGui.SameLine();
            ImGui.PushID((int)type.TypeId);
            try
            {
                DrawItemIcon(new ItemDefinition(0, type.TypeName, false, type.IconId), new Vector2(30));
                if (ImGui.IsItemClicked()) gatheringTypeFilter = type.TypeId;
                if (ImGui.IsItemHovered()) ImGui.SetTooltip(type.TypeName);
            }
            finally { ImGui.PopID(); }
        }
        ImGui.Spacing();
        ImGui.TextColored(Accent, gatheringTypeFilter is { } selected ? sources.First(source => source.TypeId == selected).TypeName : "Tous les types de récolte");
        if (ImGui.BeginTable("GatheringSources", 6, ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingStretchProp))
        {
            try
            {
                ImGui.TableSetupColumn("Type de récolte");
                ImGui.TableSetupColumn("Niveau du point");
                ImGui.TableSetupColumn("Zone");
                ImGui.TableSetupColumn("Lieu");
                ImGui.TableSetupColumn("Horaires ET");
                ImGui.TableSetupColumn("Carte");
                ImGui.TableHeadersRow();
                foreach (var source in sources.Where(source => gatheringTypeFilter is null || source.TypeId == gatheringTypeFilter))
                {
                    ImGui.TableNextRow();
                    ImGui.TableNextColumn(); ImGui.TextWrapped(source.IsHidden ? $"{source.TypeName} · objet caché" : source.TypeName);
                    ImGui.TableNextColumn(); ImGui.TextUnformatted(source.Level.ToString());
                    ImGui.TableNextColumn(); ImGui.TextWrapped(source.Zone);
                    ImGui.TableNextColumn(); ImGui.TextWrapped(string.IsNullOrWhiteSpace(source.Place) ? "Lieu non renseigné" : source.Place);
                    ImGui.TableNextColumn(); ImGui.TextWrapped(source.Timing.Label);
                    ImGui.TableNextColumn();
                    ImGui.PushID($"{source.IsFishing}/{source.PointId}/{source.ItemId}");
                    try
                    {
                        ImGui.BeginDisabled(source.MapId == 0);
                        try
                        {
                            if (ImGui.SmallButton("Carte de zone"))
                                gameGui.OpenMapWithMapLink(new MapLinkPayload(source.TerritoryId, source.MapId, 20.5f, 20.5f));
                        }
                        finally { ImGui.EndDisabled(); }
                        if (ImGui.IsItemHovered()) ImGui.SetTooltip("Ouvrir le centre de la zone ; ce repère n'est pas la position exacte du point.");
                        if(ImGui.SmallButton("Météo de zone")) OpenWeather(source.TerritoryId,source.Zone);
                    }
                    finally { ImGui.PopID(); }
                }
            }
            finally { ImGui.EndTable(); }
        }
        ImGui.Spacing();
        ImGui.TextWrapped("Horaires statiques en heure d'Éorzéa (ET). Météo, déblocages et présence actuelle non vérifiés. Les horaires de pêche et des points nuageux ne sont pas couverts.");
        if (ImGui.Button("Copier les lieux"))
            ImGui.SetClipboardText(string.Join(Environment.NewLine,
                sources.Where(source => gatheringTypeFilter is null || source.TypeId == gatheringTypeFilter)
                    .Select(source => $"{SelectedItem?.Name ?? itemId.ToString()} — {source.TypeName}, niv. {source.Level} — {source.Zone} / {source.Place} — {source.Timing.Label}")));
    }
}
