# GOAL sélectionné

ID: GATHER-WEATHER-001
OBJECTIVE: Prévisions météo natives partagées Mappy/GatherBuddy avec dates UTC/ET et couverture ; poursuivre les 17 domaines.
CURRENT_STATE: IMPLEMENTED / TESTED en 0.42.0, 275 tests/package verts ; 1290 territoires/72 météos/24 zones individuelles vérifiés, cas Empyrée90 conservé partiel. Liens depuis cartes/sources et six périodes avec icônes ; aucun météo forcée ou prérequis de ressource inventé. Aucune validation runtime.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: Gathering/WeatherForecast/Loader ; MainWindow.Weather/Maps/Gathering ; Plugin/DI ; WeatherForecastTests, WeatherProbe et documents.
IN_SCOPE: Tables natives et tirage déterministe, périodes UTC/ET, poids partiels/inconnus, données immuables et accès partagés ; pas d'observation des événements ou conditions de ressource.
OUT_OF_SCOPE: Déclarer les 17 plugins remplacés ; prétendre une validation en jeu sans observation.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: 2026-10-28, 13 % disponibles sur 5 h et 71 % semaine au dernier relevé ; continuer selon instruction utilisateur.
NEXT_ACTION: Snapshot 0.42.0 puis GATHER-WINDOWS-003 : horloge ET et fenêtres horaires à venir en UTC depuis les horaires natifs déjà copiés. Préserver limites météo/prérequis et conseils natifs de craft non achevés ; les 17 domaines restent PARTIAL et le goal global actif.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
