# GOAL sélectionné

ID: GATHER-WINDOWS-003
OBJECTIVE: Horloge ET et prochaines fenêtres horaires UTC depuis les horaires natifs ; poursuivre les fonctions utiles des 17 domaines.
CURRENT_STATE: IMPLEMENTED / TESTED en 0.43.0, 280 tests/package verts ; conversions rationnelles, frontières inclusives/exclusives, fusion de minuit et oracle deux jours ET. Probe point30999 passant ; aucun runtime ni disponibilité de point certifiée.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: GatheringTimeline ; MainWindow.GatheringTime/Gathering/GatheringBrowser ; GatheringTimelineTests ; GatheringProbe et documents.
IN_SCOPE: Horloge ET calculée, trois prochaines plages UTC et survol, identité des états inconnus/non limités, cache borné et dates explicites ; pas de présence native ou prérequis.
OUT_OF_SCOPE: Déclarer les 17 plugins remplacés ; prétendre une validation en jeu sans observation.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: 2026-10-28, 7 % disponibles sur 5 h et 70 % semaine au dernier relevé ; continuer selon instruction utilisateur.
NEXT_ACTION: Snapshot 0.43.0 puis CRAFT-PRESETS-001 : conserver/recharger les séquences d'artisanat via actions manuelles explicites, recette identifiée et bornes/invalidation ; aucune activation native. Les conseils de craft/prérequis météo restent à compléter ; goal global actif et 17 domaines PARTIAL.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
