# GOAL sélectionné

ID: QUEST-ITEM-SEARCH-006 — DONE côté code/tests
OBJECTIVE: Rendre les sources de quête d’un objet consultables par nom, catégorie native et identifiant, sans perdre variantes ni couverture ; poursuivre l’objectif global jusqu’à la réserve quota.
CURRENT_STATE: Version 0.70.0 compilée, 435/435 tests et paquet verts ; recherche combinée et copie readonly vérifiées. Aucun runtime revendiqué.
REFERENCES: RULES.md ; ROADMAP.md ; docs/QUEST-ITEM-SOURCES-004.md ; docs/QUEST-ITEM-SEARCH-006.md.
FILES: QuestRewardIndex.cs ; MainWindow.QuestItemSources.cs ; tests QuestRewardIndex ; manifests et documents.
IN_SCOPE: Filtre par mots combinés nom/catégorie, ID entier exact, restauration et compte filtré/total ; catégorie et ID en tooltip, index partagé et navigation existante.
OUT_OF_SCOPE: Disponibilité/obtention de récompenses, nouvelles lectures natives ou réseau, validation en jeu. Dix-sept domaines PARTIAL.
VALIDATION: Verify.ps1 : 435/435 tests, zéro avertissement/erreur ; API/versions/SHA-256/exclusion hôte verts. Nouvel essai de filtre vérifiant identités et isolation Item/readonly.
QUOTA: Relevé 2026-10-29 : 6 % disponibles sur 5 h, 32 % semaine ; réserve 5 %.
NEXT_ACTION: Contrôler le quota réel et poursuivre seulement avec marge suffisante. Prochaine tranche READY : docs/QUEST-ITEM-PROGRESS-007-PLAN.md ; lier les sources de quête à la progression du même snapshot, avec filtres et inconnus explicites, sans disponibilité déduite. Aucun essai craft/Macro Chain à redemander. L’objectif global n’est pas déclaré achevé.
DEFINITION_OF_DONE: Tranche compilée/testée/documentée et source sauvegardée ; recherche sans changement de variantes ou interprétation de disponibilité.
