# État courant

CURRENT_GOAL: CACT-LIVE-002 — IMPLEMENTED / TESTED ; plateau Mini Cactpot observé et conseil actualisé, voir docs/CACT-LIVE-002.md
CURRENT_MODEL_CLASS: HEAVY — adaptateur natif et isolation des workers
RECOMMENDED_MODEL: HEAVY pour l’étude native ; LIGHT pour tâches mécaniques ; continuation autorisée
MODEL_ESCALATION: None
QUOTA: Relevé 2026-10-29 : 34 % consommés sur 5 h, 37 % semaine (66 % / 63 % disponibles). Réserve utilisateur 5 % ; objectif global actif.
LAST_READ: RULES/STATUS/GOAL relus le 2026-10-29 ; docs courants, sources ciblées Cactpot, métadonnées locales et dépôt primaire consultés.
BUILD: COMPILED Release 0.48.0.0 ; sortie canonique bin/x64/Release
TESTS: TESTED — 311/311 tests ; package/versions/ZIP/exclusion hôte verts, zéro avertissement/erreur ; observation Cactpot et workers à succès/erreurs tardifs couverts.
RUNTIME: Banque, stocks, carnet et préparation jusqu'à 0.5.27 confirmés par l'utilisateur. Fonctions 0.6–0.48 non validées en jeu. Tests projection et Macro Chain différés explicitement ; ne pas les redemander.
WORK_COMPLETED: Dix-sept domaines PARTIAL ; mode Mini Cactpot observé activable, copie stable bornée de neuf chiffres, recalcul après révélation, conseil retiré si observation périmée/injouable ; session commune manuelle/native et refus des résultats tardifs. Craft 0.46/0.47 conservé.
BLOCKER: Aucun blocage global. Tests projection et Macro Chain différés ; les travaux indépendants continuent.
RESUME_FROM: GOAL.md ; TESTING.md pour le protocole de la base.
NEXT_ACTION: Snapshot 0.48.0 puis GATHER-NATIVE-004 : étudier l’observation du point de récolte et des taux affichés pour alimenter le scénario PR commun sans inventer rendement/bonus de base ni commander de récolte. Preuve primaire/métadonnées avant implémentation ; réserve 5 % et 17 domaines conservés.

| Plugin | Coverage |
|---|---|
| Avant-Garde | PARTIAL — répertoire manuel d'indices natifs, équipements signalés, emplacements/stock/contexte et source datée ; thème courant/teintures/score/attache non déduits |
| Blue Mage Helper | PARTIAL — grimoire, numéros, descriptions, lieux renseignés et acquisition confirmée |
| Character Panel Refined | PARTIAL — attributs natifs, sans formules dérivées |
| Collections | PARTIAL — montures, mascottes, emotes et cartes Triple Triade ; inconnu distinct d'absent |
| Craftimizer | PARTIAL — simulation/recherche/export/séquences, observation et projection d'un coup normal ; conditions/rotation native/recettes spéciales et runtime à compléter |
| Duty Loot Preview | PARTIAL — consultation manuelle par contenu, coffres/récompenses, icônes/contexte, provenance et cache ; drops directs non interprétés, données externes partielles |
| ezMiniCactpot | PARTIAL — solveur exact manuel et mode observé opt-in LotteryDaily ; conseil actualisé, aucune commande ; adaptation/rendu natifs non validés en jeu |
| GatherBuddy | PARTIAL — sources récolte/pêche, cartes, météo de zone, horloge ET et prochaines plages UTC ; présence/prérequis météo/accès/harpon non couverts |
| Item Use | PARTIAL — usages du catalogue de recettes |
| LazyGatherer | PARTIAL — optimiseur de scénario manuel MIN/BTN, espérances/seuils et copie des PR courants ; régénération/procs/collectionnables et adaptation du point natif non couverts |
| Macro Chain | PARTIAL — séquences à marqueur final, lancement explicite, arrêt, persistance ; natif à confirmer |
| Mappy | PARTIAL — navigateur natif, repères favoris persistants, ressources de zone et prévisions météo statiques ; météo forcée non observée |
| Monster Loot Hunter | PARTIAL — associations matériau/monstre, fiches/niveaux/lieux et carte de zone, transport/cadence partagés, contexte ; données communautaires partielles |
| Price Insight | PARTIAL — prix manuels/survol, coût direct et terminal des chaînes, cache/cadence/priorités communs, dates NQ/HQ par monde |
| QuestTracker | PARTIAL — états natifs, séquence, fiche et liens de prérequis/suivantes ; disponibilité non calculée |
| SortaKinda | PARTIAL — aperçu de règles sauvegardées, sans déplacement natif |
| TriadBuddy | PARTIAL — carnet/deck/solveur manuel, observation des faces opt-in expérimentale ; identités/règles/trait natifs et autres règles non établis |

