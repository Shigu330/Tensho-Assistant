# GOAL sélectionné

ID: CACT-LIVE-002
OBJECTIVE: Alimenter le solveur Mini Cactpot commun depuis un plateau natif observé cohérent, puis poursuivre les outils jusqu’à la réserve de quota de 5 %.
CURRENT_STATE: IMPLEMENTED / TESTED en 0.48.0, 311 tests/package verts ; neuf chiffres copiés sur framework, mode observé opt-in et recalcul UI après révélation, retrait des conseils périmés ; résultats tardifs isolés. Aucun essai natif ou rendu nouveau déclaré.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: MiniCactpotObservation/Reader/SolveSession ; MainWindow.MiniCactpot/Settings/Tools ; DI Plugin/MainWindow ; MiniCactpotObservationTests ; docs.
IN_SCOPE: Observation LotteryDaily activable, copie managée/readonly, plateau jouable de un à quatre chiffres, âge maximal deux secondes, même solveur exact que saisie manuelle. Aucun callback, clic, dépense ou choix dans le jeu.
OUT_OF_SCOPE: Revendiquer validation native ou remplacement intégral sans preuve ; exécuter un choix de jeu depuis l’observation.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: Relevé 2026-10-29 : 66 % disponibles sur 5 h et 63 % semaine ; réserve utilisateur 5 % sur la fenêtre limitante. Objectif global actif.
NEXT_ACTION: GATHER-NATIVE-004 : étude d’une observation du point de récolte et de ses taux affichés pour le scénario PR partagé. Vérifier source primaire et métadonnées, ne pas confondre taux modifiés et valeurs de base. Tests projection/Macro Chain toujours différés.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
