# État courant

CURRENT_GOAL: GP-ACTIVE-005 — IMPLEMENTED_CORE / TESTED ; effets manuellement déclarés, décodeur natif restant à établir, voir docs/GP-ACTIVE-005.md
CURRENT_MODEL_CLASS: HEAVY — sémantique des influences et oracle indépendant
RECOMMENDED_MODEL: HEAVY pour les influences natives ; LIGHT pour tâches mécaniques ; continuation autorisée
MODEL_ESCALATION: None
QUOTA: Relevé 2026-10-29 :11 % consommés sur 5 h,40 % semaine (89 % /60 % disponibles). Réserve utilisateur5 % sur la fenêtre limitante ; objectif global actif.
LAST_READ: RULES/STATUS/GOAL et fin de GATHER-NATIVE-004 relus ; règles des familles/effets vérifiées dans la source primaire ciblée, preuves statiques conservées.
BUILD: COMPILED Release 0.50.0.0 ; sortie canonique bin/x64/Release
TESTS: TESTED —327/327 tests ; package/versions/ZIP/exclusion hôte verts, zéro avertissement/erreur. Oracle indépendant128 scénarios, probes MIN/BTN historiques et effets déclarés passants.
RUNTIME: Banque, stocks, carnet et préparation jusqu’à 0.5.27 confirmés par l’utilisateur. Fonctions0.6–0.50 non validées en jeu. Tests projection et Macro Chain différés explicitement ; ne pas les redemander.
WORK_COMPLETED: Dix-sept domaines PARTIAL ; noyau PR partagé et UI pour familles déjà payées, Évangile et bonus de première tentative, dépenses nouvelles seulement, inconnus déclarés refusés. Observation0.49 conservée ; aucun effet ou compteur natif supposé absent.
BLOCKER: Aucun blocage global. Tests projection et Macro Chain différés ; les travaux indépendants continuent.
RESUME_FROM: GOAL.md ; TESTING.md pour le protocole de la base.
NEXT_ACTION: Snapshot 0.50 puis GP-METADATA-006 : vérifier GatheringItem/GatheringItemLevel→ItemLevel.Gathering et la formule de bonus d’Abondance dans les sources/fichiers du jeu ; copier les faits utiles dans le catalogue commun avec ambiguïtés inconnues avant aide au scénario. Décodeur d’effets et optimisation native complète toujours requis.

| Plugin | Coverage |
|---|---|
| Avant-Garde | PARTIAL — répertoire manuel d'indices natifs, équipements signalés, emplacements/stock/contexte et source datée ; thème courant/teintures/score/attache non déduits |
| Blue Mage Helper | PARTIAL — grimoire, numéros, descriptions, lieux renseignés et acquisition confirmée |
| Character Panel Refined | PARTIAL — attributs natifs, sans formules dérivées |
| Collections | PARTIAL — montures, mascottes, emotes et cartes Triple Triade ; inconnu distinct d'absent |
| Craftimizer | PARTIAL — simulation/recherche/export/séquences, observation et projection d'un coup normal ; conditions/rotation native/recettes spéciales et runtime à compléter |
| Duty Loot Preview | PARTIAL — consultation manuelle par contenu, coffres/récompenses, icônes/contexte, provenance et cache ; drops directs non interprétés, données externes partielles |
| ezMiniCactpot | PARTIAL — solveur exact manuel et mode observé opt-in LotteryDaily ; conseil actualisé, aucune commande ; adaptation/rendu natifs non validés en jeu |
| GatherBuddy | PARTIAL — sources/maps/horaires/météo statiques et point courant observé opt-in (objets/icônes/taux affichés, contexte) ; présence/prérequis/harpon et validation native non couverts |
| Item Use | PARTIAL — usages du catalogue de recettes |
| LazyGatherer | PARTIAL — optimiseur manuel avec effets explicitement déclarés, observation du point et copie de ressources ; décodeur natif/bonus/régénération/procs/collectionnables et validation runtime à compléter |
| Macro Chain | PARTIAL — séquences à marqueur final, lancement explicite, arrêt, persistance ; natif à confirmer |
| Mappy | PARTIAL — navigateur natif, repères favoris persistants, ressources de zone et prévisions météo statiques ; météo forcée non observée |
| Monster Loot Hunter | PARTIAL — associations matériau/monstre, fiches/niveaux/lieux et carte de zone, transport/cadence partagés, contexte ; données communautaires partielles |
| Price Insight | PARTIAL — prix manuels/survol, coût direct et terminal des chaînes, cache/cadence/priorités communs, dates NQ/HQ par monde |
| QuestTracker | PARTIAL — états natifs, séquence, fiche et liens de prérequis/suivantes ; disponibilité non calculée |
| SortaKinda | PARTIAL — aperçu de règles sauvegardées, sans déplacement natif |
| TriadBuddy | PARTIAL — carnet/deck/solveur manuel, observation des faces opt-in expérimentale ; identités/règles/trait natifs et autres règles non établis |

