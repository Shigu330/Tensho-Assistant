# GOAL sélectionné

ID: QUEST-CURRENCIES-005-STUDY
OBJECTIVE: Étudier puis résoudre sur preuve les monnaies de quête sans Item direct, en préservant conditions et quantités ; poursuivre les 17 domaines jusqu’à la réserve quota de 5 %.
CURRENT_STATE: QUEST-ITEM-SOURCES-004 IMPLEMENTED / TESTED en 0.68.0, 434 tests/package/SHA-256 et probe natif verts. Index de 3 496 Items/8 288 associations, variantes exactes ; quinze monnaies et quatre quantités non résolues explicitement.
WHY_NOW: Réduire un manque de couverture précis de la chaîne quête → récompense → objet → stocks, sans inventer l’identité de monnaie ou la compagnie du personnage.
REFERENCES: docs/QUEST-REWARDS-003.md ; docs/QUEST-ITEM-SOURCES-004.md ; métadonnées GC/currency locales et consommateur primaire ciblé.
FILES: Quests/QuestRewardCopy/Rewards/Index ; QuestRewardsProbe ; API/feuilles locales ; tests et rendu conditionnel si preuve.
IN_SCOPE: Examiner les quinze lignes et leurs clés GCTypeReward/CurrencyReward, relations natives GrandCompany/currency ; variantes statiques explicites, quantités/provenance, intégration au modèle et index existants.
OUT_OF_SCOPE: Choisir compagnie/rang actuel sans observation, hardcoder un ItemId à partir d’une convention, récompense réellement reçue, réseau ou commande natifs. Les 17 restent PARTIAL.
VALIDATION: Dernière tranche Verify.ps1 434/434, zéro avertissement/erreur, package/API/versions/SHA-256/exclusion hôte verts ; toutes les associations/variantes de l’index comparées à la projection native. Nouvelle identité/condition à prouver et tester avant intégration.
QUOTA: Relevé 2026-10-29 : 21 % disponibles sur 5 h et 34 % semaine ; réserve 5 %, objectif global actif.
NEXT_ACTION: Checkpoint 0.68 puis census ciblé des quinze monnaies et signatures/relations GrandCompany ; conserver les inconnus si la preuve manque. GP et essais projection/Macro Chain différés, sans les redemander.
DEFINITION_OF_DONE: Étude sourcée et tranche utile compilée/testée ou inconnu précisément documenté, preuves/docs/sauvegarde à jour ; aucun domaine global promu complet sans preuve.
