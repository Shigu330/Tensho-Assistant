# GOAL sélectionné

ID: DUTY-001
OBJECTIVE: Aperçu des butins par contenu avec identités et provenance fiables ; poursuivre la couverture du projet.
CURRENT_STATE: CORE_PARTIAL — modèle/parser original implémenté en 0.31.1, 181 tests/package verts. Identité, catégories, provenance, limites, annulation et immutabilité testées. Duty Loot reste non disponible tant que service réseau/UI non intégrés ; aucune validation en jeu. Macro Chain reporté.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: Domaines Gathering, Inventory, Collections, Market, Quests, Character, MiniGames ; MainWindow.* ; Plugin.cs ; tests et documents.
IN_SCOPE: Modèle original et consultation explicite des butins, identités contenu/instance/territoire, source et couverture, cache/annulation, icônes et contexte commun. QUEST-002 conservé sans interpréter l'éligibilité.
OUT_OF_SCOPE: Déclarer les 17 plugins remplacés ; prétendre une validation en jeu sans observation.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: 2026-10-28, 2 % disponibles sur 5 h et 85 % semaine au dernier relevé ; continuer selon instruction utilisateur, sauvegarde avant épuisement.
NEXT_ACTION: DUTY-001 : parser disponible dans Duties/DutyLootDocument.cs. Ajouter service HTTP possédé, cache borné et annulation/révision, puis UI par contenu avec icônes/contexte et tests avant exposition. Voir docs/DUTY-001-STUDY.md ; conserver les 17 domaines et l'objectif global actif, aucun test Macro Chain redemandé.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
