using System.Numerics;
using Dalamud.Plugin.Services;
using FFXIVClientStructs.FFXIV.Client.Game.UI;
using FFXIVClientStructs.FFXIV.Client.UI.Agent;
using Lumina.Excel.Sheets;

namespace TenshoAssistant.Maps;

// Aether currents of one territory: Total 0 means flying is not governed by aether currents there (or unknown).
public sealed record MapFlightState(uint TerritoryId,int Total,int Unlocked,bool Complete,bool MountAllowed);

// Player position, the game's map flag and the flight state of the watched territory, copied on the framework thread.
// Flag is a world X/Z position on FlagMapId, or null when no flag is set.
// Game event marker (quest objectives and similar) copied from AgentMap.EventMarkers: world position, optional area radius.
public sealed record MapEventMarker(uint MapId,uint Icon,Vector3 Position,float Radius,string Tooltip);

// Flights: every territory that has aether currents, refreshed every two seconds (menu wings and the header symbol).
// Events: the game's quest/event markers, refreshed every half second. InCombat/InDuty drive the « hide » settings.
public sealed record MapLiveState(uint TerritoryId,uint MapId,Vector3 Position,float Rotation,DateTimeOffset ObservedAt,uint FlagMapId=0,Vector2? Flag=null,
    IReadOnlyDictionary<uint,MapFlightState>? Flights=null,IReadOnlyList<MapEventMarker>? Events=null,bool InCombat=false,bool InDuty=false);

internal sealed class MapLiveReader : IDisposable
{
    private readonly IFramework framework;private readonly IClientState client;private readonly IObjectTable objects;private readonly IPluginLog log;
    private readonly Dictionary<uint,(uint Set,uint[] Currents)> currents=[];
    private readonly Dictionary<uint,bool> mounts=[];
    private MapLiveState? state;private bool disposed;private DateTimeOffset retryAt;private DateTimeOffset flightAt;
    private IReadOnlyDictionary<uint,MapFlightState>? flights;private int removeFlag;
    private IReadOnlyList<MapEventMarker> events=[];private DateTimeOffset eventsAt;
    private readonly ICondition condition;
    public MapLiveState? State=>Volatile.Read(ref state);
    /// <summary>Queues the flag removal; it is written on the next framework tick, never from the UI thread.</summary>
    public void RemoveFlag()=>Interlocked.Exchange(ref removeFlag,1);

    public MapLiveReader(IFramework framework,IClientState client,IObjectTable objects,IDataManager data,ICondition condition,IPluginLog log)
    {
        this.framework=framework;this.client=client;this.objects=objects;this.log=log;this.condition=condition;
        try
        {
            foreach(var set in data.GetExcelSheet<AetherCurrentCompFlgSet>())
                if(set.Territory.RowId!=0)currents.TryAdd(set.Territory.RowId,(set.RowId,set.AetherCurrents.Select(current=>current.RowId).Where(id=>id!=0).ToArray()));
            foreach(var territory in data.GetExcelSheet<TerritoryType>())mounts[territory.RowId]=territory.Mount;
        }
        catch(Exception error){log.Warning(error,"Aether current data unavailable; flight state stays unknown.");}
        framework.Update+=Update;
    }
    private void Update(IFramework _)
    {
        if(disposed || !framework.IsInFrameworkUpdateThread || framework.IsFrameworkUnloading)return;
        var now=DateTimeOffset.UtcNow;if(now<retryAt)return;
        try
        {
            if(Interlocked.Exchange(ref removeFlag,0)==1)ClearFlag();
            var player=client.IsLoggedIn ? objects.LocalPlayer:null;
            if(player is null){Volatile.Write(ref state,null);return;}
            var (flagMap,flag)=ReadFlag();
            if(flights is null || now>=flightAt){flights=ReadFlights();flightAt=now.AddSeconds(2);}
            if(now>=eventsAt){events=ReadEvents();eventsAt=now.AddMilliseconds(500);}
            var inCombat=condition[Dalamud.Game.ClientState.Conditions.ConditionFlag.InCombat];
            var inDuty=condition[Dalamud.Game.ClientState.Conditions.ConditionFlag.BoundByDuty] || condition[Dalamud.Game.ClientState.Conditions.ConditionFlag.BoundByDuty56];
            Volatile.Write(ref state,new MapLiveState(client.TerritoryType,client.MapId,player.Position,player.Rotation,now,flagMap,flag,flights,events,inCombat,inDuty));
        }
        catch(Exception error){Volatile.Write(ref state,null);retryAt=now.AddSeconds(5);log.Warning(error,"Map position unavailable; retry in five seconds.");}
    }
    private unsafe IReadOnlyDictionary<uint,MapFlightState> ReadFlights()
    {
        var player=PlayerState.Instance();var result=new Dictionary<uint,MapFlightState>();
        if(player==null)return result;
        foreach(var (territory,set) in currents)
            result[territory]=new(territory,set.Currents.Length,set.Currents.Count(id=>player->IsAetherCurrentUnlocked(id)),
                player->IsAetherCurrentZoneComplete(set.Set),mounts.GetValueOrDefault(territory));
        return result;
    }
    // Quest and event markers of the game map, copied (strings included); at most 256 to bound the work per refresh.
    private static unsafe IReadOnlyList<MapEventMarker> ReadEvents()
    {
        var agent=AgentMap.Instance();
        if(agent==null)return [];
        var result=new List<MapEventMarker>();
        foreach(var marker in agent->EventMarkers)
        {
            if(result.Count>=256)break;
            if(marker.IconId==0 || marker.MapId==0 || !float.IsFinite(marker.Position.X) || !float.IsFinite(marker.Position.Z))continue;
            var tooltip=marker.TooltipString!=null ? marker.TooltipString->ToString():"";
            result.Add(new(marker.MapId,marker.IconId,marker.Position,float.IsFinite(marker.Radius) ? Math.Max(0,marker.Radius):0,tooltip));
        }
        return result.AsReadOnly();
    }
    // Values are copied out of the agent here; no pointer survives this call.
    private static unsafe (uint MapId,Vector2? Flag) ReadFlag()
    {
        var agent=AgentMap.Instance();
        if(agent==null || agent->FlagMarkerCount==0)return (0,null);
        var marker=agent->FlagMapMarkers[0];
        return marker.MapId==0 || !float.IsFinite(marker.XFloat) || !float.IsFinite(marker.YFloat) ? (0,null):(marker.MapId,new Vector2(marker.XFloat,marker.YFloat));
    }
    // The game shows the flag while FlagMarkerCount is non-zero; resetting it removes the flag from the map and minimap.
    private static unsafe void ClearFlag()
    {
        var agent=AgentMap.Instance();
        if(agent!=null)agent->FlagMarkerCount=0;
    }
    public void Dispose(){if(disposed)return;disposed=true;framework.Update-=Update;Volatile.Write(ref state,null);}
}
