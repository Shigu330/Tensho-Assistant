# GOAL sélectionné

ID: DUTY-001
OBJECTIVE: Aperçu des butins par contenu avec identités et provenance fiables ; poursuivre la couverture du projet.
CURRENT_STATE: IMPLEMENTED / TESTED — modèle, catalogue, service et UI intégrés en 0.32.0, 192 tests/package verts. Probe natif 672 contenus ; consultations réelles Sastasha/Praetorium réussies. Couverture externe partielle, drops directs signalés hors périmètre ; aucune validation en jeu. Macro Chain reporté.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: Domaines Duties, Gathering, Inventory, Collections, Market, Quests, Character, MiniGames ; MainWindow.* ; Plugin.cs ; tests, probe et documents.
IN_SCOPE: Modèle original et consultation explicite des butins, identités contenu/instance/territoire, source et couverture, cache/annulation, icônes et contexte commun. QUEST-002 conservé sans interpréter l'éligibilité.
OUT_OF_SCOPE: Déclarer les 17 plugins remplacés ; prétendre une validation en jeu sans observation.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: 2026-10-28 après réinitialisation, 94 % disponibles sur 5 h et 83 % semaine au dernier relevé ; continuer selon instruction utilisateur.
NEXT_ACTION: Snapshot 0.32.0 puis étudier LOOT-001 (sources de matériaux sur monstres) et les identités des drops directs ; aucune jointure par simple nom traduit inventée. Conserver les 17 domaines et l'objectif global actif, aucun test Macro Chain redemandé.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
