using System.Net.Http;
using System.Text;

namespace TenshoAssistant.Duties;

public sealed record DutyLootState(DutyDefinition? Duty, DutyLootDocument? Document, bool Loading, string? Error);

/// <summary>Only explicit RequestAsync performs network I/O; selection and cache reads are local.</summary>
public sealed class DutyLootService : IDisposable
{
    public const int CacheCapacity = 32;
    public static readonly TimeSpan FreshFor = TimeSpan.FromMinutes(30);
    public static readonly TimeSpan RequestInterval = TimeSpan.FromSeconds(3);
    private readonly object gate = new();
    private readonly HttpClient client;
    private readonly bool ownsClient;
    private readonly TimeProvider clock;
    private readonly Dictionary<uint, DutyLootDocument> cache = [];
    private CancellationTokenSource? request;
    private DutyLootState state = new(null,null,false,null);
    private long generation;
    private long? lastRequest;
    private bool disposed;
    public DutyLootState State => Volatile.Read(ref state);
    public DutyLootService(HttpClient? client = null, TimeProvider? clock = null)
    {
        ownsClient = client is null;
        this.client = client ?? new HttpClient { Timeout = TimeSpan.FromSeconds(15) };
        this.clock = clock ?? TimeProvider.System;
    }
    public void Select(DutyDefinition? duty)
    {
        lock (gate)
        {
            if (disposed || Equals(state.Duty,duty)) return;
            if (duty is not null && (duty.DutyId == 0 || duty.InstanceId == 0 || duty.TerritoryId == 0))
                throw new ArgumentException("Invalid duty identity.",nameof(duty));
            generation++; request?.Cancel();
            state = new(duty,duty is null ? null : cache.GetValueOrDefault(duty.InstanceId),false,null);
        }
    }
    public void Cancel()
    {
        lock (gate)
        {
            if (disposed || !state.Loading) return;
            generation++; request?.Cancel();
            state = state with { Loading = false, Error = "Consultation annulée." };
        }
    }
    public async Task RequestAsync(bool force = false, CancellationToken cancellation = default)
    {
        DutyDefinition duty;
        long ticket;
        CancellationTokenSource source;
        lock (gate)
        {
            if (disposed || state.Duty is null || state.Loading || cancellation.IsCancellationRequested) return;
            duty = state.Duty;
            if (!force && cache.TryGetValue(duty.InstanceId,out var saved) && clock.GetUtcNow() - saved.FetchedAt is var age && age >= TimeSpan.Zero && age < FreshFor)
            { state = state with { Document = saved, Error = null }; return; }
            if (lastRequest is { } last && clock.GetElapsedTime(last) < RequestInterval)
            { state = state with { Error = "Patientez trois secondes entre deux consultations." }; return; }
            lastRequest = clock.GetTimestamp();
            source = CancellationTokenSource.CreateLinkedTokenSource(cancellation);
            source.CancelAfter(TimeSpan.FromSeconds(12));
            request = source; ticket = ++generation;
            state = state with { Loading = true, Error = null };
        }
        try
        {
            using var message = new HttpRequestMessage(HttpMethod.Get,$"https://www.garlandtools.org/db/doc/instance/en/2/{duty.InstanceId}.json");
            message.Headers.UserAgent.ParseAdd($"TenshoAssistant/{typeof(DutyLootService).Assembly.GetName().Version?.ToString(3) ?? "1.0.0"}");
            using var response = await client.SendAsync(message,HttpCompletionOption.ResponseHeadersRead,source.Token).ConfigureAwait(false);
            response.EnsureSuccessStatusCode();
            if (response.Content.Headers.ContentLength > DutyLootParser.MaximumBytes) throw new InvalidDataException("Réponse de butin trop volumineuse.");
            await using var stream = await response.Content.ReadAsStreamAsync(source.Token).ConfigureAwait(false);
            using var buffer = new MemoryStream();
            var bytes = new byte[8192];
            int read;
            while ((read = await stream.ReadAsync(bytes,source.Token).ConfigureAwait(false)) > 0)
            {
                if (buffer.Length + read > DutyLootParser.MaximumBytes) throw new InvalidDataException("Réponse de butin trop volumineuse.");
                buffer.Write(bytes,0,read);
            }
            source.Token.ThrowIfCancellationRequested();
            var json = new UTF8Encoding(false,true).GetString(buffer.GetBuffer(),0,(int)buffer.Length);
            var parsed = DutyLootParser.Parse(json,duty.InstanceId,clock.GetUtcNow(),source.Token);
            lock (gate)
            {
                if (disposed || ticket != generation || source.IsCancellationRequested) return;
                if (!cache.ContainsKey(duty.InstanceId) && cache.Count >= CacheCapacity)
                    cache.Remove(cache.MinBy(pair => pair.Value.FetchedAt).Key);
                cache[duty.InstanceId] = parsed;
                state = new(duty,parsed,false,null);
            }
        }
        catch (Exception error)
        {
            lock (gate)
            {
                if (disposed || ticket != generation) return;
                state = state with { Loading = false, Error = error is OperationCanceledException
                    ? "Consultation annulée ou délai dépassé." : $"Lecture du butin impossible : {error.Message}" };
            }
        }
        finally
        {
            lock (gate)
            {
                if (ReferenceEquals(request,source))
                {
                    request = null;
                    // A borrowed handler may ignore cancellation and return late without throwing.
                    if (!disposed && ticket == generation && state.Loading)
                        state = state with { Loading = false, Error = "Consultation annulée ou délai dépassé." };
                }
                source.Dispose();
            }
        }
    }
    public void Dispose()
    {
        lock (gate)
        {
            if (disposed) return;
            disposed = true; generation++; request?.Cancel(); cache.Clear();
            state = new(null,null,false,null);
            if (ownsClient) client.Dispose();
        }
    }
}
