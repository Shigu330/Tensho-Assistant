using Dalamud.Game.Command;
using Dalamud.Interface.Windowing;
using Dalamud.Plugin;
using Dalamud.Plugin.Services;
using TenshoAssistant.Inventory;
using TenshoAssistant.Items;
using TenshoAssistant.Craft;
using TenshoAssistant.Gathering;
using TenshoAssistant.Collections;
using TenshoAssistant.Market;
using TenshoAssistant.Quests;
using TenshoAssistant.Character;
using TenshoAssistant.Maps;
using TenshoAssistant.Macros;
using TenshoAssistant.MiniGames;
using TenshoAssistant.Duties;

namespace TenshoAssistant;

public sealed class Plugin : IDalamudPlugin
{
    private const string Command = "/tensho";
    private readonly RegistrationScope registrations = new();
    private readonly IPluginLog log;
    private readonly MainWindow mainWindow;
    private readonly WindowSystem windows = new("TenshoAssistant");
    private readonly InventoryService inventoryService = new();
    private readonly ItemCatalogService itemCatalog = new();
    private readonly RecipeCatalogService recipeCatalog = new();
    private readonly GatheringCatalogService gatheringCatalog = new();
    private readonly CollectionService collections = new();
    private readonly MarketService market = new();
    private readonly MarketHoverService marketHover = new();
    private readonly QuestService quests = new();
    private readonly CharacterStatsService characterStats = new();
    private readonly MapCatalogService maps = new();
    private readonly MacroObservationService macroObservations = new();
    private readonly MacroChainService macroChain = new();
    private readonly TriadObservationService triadObservation = new();
    private readonly DutyCatalogService duties = new();
    private readonly DutyLootService dutyLoot = new();
    private readonly BankImportOverlay bankOverlay;

    public Plugin(IDalamudPluginInterface pluginInterface, ICommandManager commands, IPluginLog log,
        IGameInventory inventory, IPlayerState player, IClientState client, IFramework framework, IDataManager data, IGameGui gameGui,
        ITextureProvider textures, IUnlockState unlocks, IGameInteropProvider interop)
    {
        this.log = log;
        var configuration = pluginInterface.GetPluginConfig() as Configuration ?? new Configuration();
        if (configuration.Version != 1)
            throw new NotSupportedException($"Unsupported configuration version: {configuration.Version}");

        try
        {
            registrations.Register(() => { }, market.Dispose);
            registrations.Register(() => { }, dutyLoot.Dispose);
            MarketWorldReader? marketReader = null;
            registrations.Register(() => marketReader = new MarketWorldReader(market, framework, player, client, log), () => marketReader?.Dispose());
            var bank = new InventoryBankService(new FileInventoryBankStore(
                Path.Combine(pluginInterface.GetPluginConfigDirectory(), "InventoryBank.json")));
            registrations.Register(() => { }, bank.Dispose);
            var bankBridge = new BankInventoryBridge(bank, inventory, gameGui, player, client, framework, log);
            registrations.Register(() => { }, bankBridge.Dispose);
            bankOverlay = new BankImportOverlay(bank, bankBridge);
            mainWindow = new MainWindow(configuration, () => pluginInterface.SavePluginConfig(configuration), log,
                inventoryService, itemCatalog, recipeCatalog, gatheringCatalog, collections, market, marketHover, quests, characterStats, maps, macroObservations, macroChain, triadObservation, bank, bankBridge, textures, gameGui, duties, dutyLoot) { IsOpen = configuration.OpenOnLoad };
            registrations.Register(() => { }, mainWindow.Dispose);
            MacroChainBridge? macroBridge = null;
            registrations.Register(() => macroBridge = new MacroChainBridge(macroChain, framework, player, client, commands, interop, log), () => macroBridge?.Dispose());
            MacroObservationReader? macroObserver = null;
            registrations.Register(() => macroObserver = new MacroObservationReader(macroObservations, framework, player, client, log), () => macroObserver?.Dispose());
            MarketHoverReader? hoverReader = null;
            registrations.Register(() => hoverReader = new MarketHoverReader(configuration, market, marketHover, itemCatalog, gameGui, player, client, framework, log),
                () => hoverReader?.Dispose());
            MapCatalogLoader? mapLoader = null;
            registrations.Register(() => mapLoader = new MapCatalogLoader(maps, data, framework, log), () => mapLoader?.Dispose());
            DutyCatalogLoader? dutyLoader = null;
            registrations.Register(() => dutyLoader = new DutyCatalogLoader(duties, data, framework, log), () => dutyLoader?.Dispose());
            CharacterStatsReader? statsReader = null;
            registrations.Register(() => statsReader = new CharacterStatsReader(characterStats, framework, player, client, log), () => statsReader?.Dispose());
            QuestReader? questReader = null;
            registrations.Register(() => questReader = new QuestReader(quests, data, framework, player, client, unlocks, log),
                () => questReader?.Dispose());
            CollectionReader? collectionReader = null;
            registrations.Register(() => collectionReader = new CollectionReader(collections, data, framework, player, client, unlocks, log),
                () => collectionReader?.Dispose());
            TriadObservationReader? triadReader = null;
            registrations.Register(() => triadReader = new TriadObservationReader(triadObservation, framework, player, client, gameGui, log),
                () => triadReader?.Dispose());
            ItemCatalogLoader? catalogLoader = null;
            registrations.Register(() => catalogLoader = new ItemCatalogLoader(itemCatalog, data, framework, log),
                () => catalogLoader?.Dispose());
            RecipeCatalogLoader? recipeLoader = null;
            registrations.Register(() => recipeLoader = new RecipeCatalogLoader(recipeCatalog, data, framework, log),
                () => recipeLoader?.Dispose());
            GatheringCatalogLoader? gatheringLoader = null;
            registrations.Register(() => gatheringLoader = new GatheringCatalogLoader(gatheringCatalog, data, framework, log),
                () => gatheringLoader?.Dispose());
            DalamudInventoryReader? inventoryReader = null;
            registrations.Register(() => inventoryReader = new DalamudInventoryReader(inventoryService, inventory, player, client, framework, log),
                () => inventoryReader?.Dispose());
            registrations.Register(() => windows.AddWindow(mainWindow), () => windows.RemoveWindow(mainWindow));
            registrations.Register(() =>
            {
                if (!commands.AddHandler(Command, new CommandInfo(OnCommand)
                    { HelpMessage = "Ouvrir Tensho--Assistant." }))
                    throw new InvalidOperationException($"Command already registered: {Command}");
            }, () => commands.RemoveHandler(Command));
            registrations.Register(() => pluginInterface.UiBuilder.Draw += Draw,
                () => pluginInterface.UiBuilder.Draw -= Draw);
            registrations.Register(() => pluginInterface.UiBuilder.OpenMainUi += Open,
                () => pluginInterface.UiBuilder.OpenMainUi -= Open);
            registrations.Register(() => pluginInterface.UiBuilder.OpenConfigUi += Open,
                () => pluginInterface.UiBuilder.OpenConfigUi -= Open);
            Action openOnLogin = () =>
            {
                if (configuration.OpenOnLogin) Open();
            };
            registrations.Register(() => client.Login += openOnLogin,
                () => client.Login -= openOnLogin);
        }
        catch
        {
            Dispose();
            throw;
        }
    }

    private void OnCommand(string command, string arguments) => Open();
    private void Open() => mainWindow.IsOpen = true;
    private void Draw()
    {
        windows.Draw();
        bankOverlay.Draw();
        mainWindow.DrawMarketHover();
    }

    public void Dispose()
    {
        try { registrations.Dispose(); }
        catch (AggregateException error) { log.Error(error, "Failed to release some Tensho registrations."); }
    }
}
