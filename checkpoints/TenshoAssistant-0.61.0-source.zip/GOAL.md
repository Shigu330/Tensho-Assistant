# GOAL sélectionné

ID: GATHER-FISH-WINDOWS-008-STUDY
OBJECTIVE: Étudier puis intégrer les conditions communautaires de pêche sur des preuves explicites, en poursuivant les 17 domaines jusqu’à la réserve de quota de 5 %.
CURRENT_STATE: Tranche précédente GATHER-FISH-SOURCES-007 IMPLEMENTED / TESTED en 0.61.0, 396 tests/package/SHA-256 et probe réel 4869 verts. Appâts et chaînes partagent le cache d’objet existant. Rendu en jeu non observé.
WHY_NOW: Les chaînes d’appâts sont consultables ; les horaires et conditions doivent être compris avant toute projection de fenêtre.
REFERENCES: docs/GATHER-FISH-SOURCES-007.md ; docs/GATHER-WINDOWS-003.md ; docs/GATHER-WEATHER-001.md ; REF-GATHER-FISH-SOURCES-007.
FILES: Community/FishingSources ; Gathering/GatheringTime et Weather ; MainWindow.FishingSources ; tests/probes ciblés.
IN_SCOPE: Schéma et unités des horaires, météo et transitions depuis sources primaires ; réutilisation des modèles/catalogues natifs et cache/transport communs ; état inconnu conservé.
OUT_OF_SCOPE: Inventer la signification du code météo natif 2, présence/déblocage/prise du personnage ou disponibilité certaine ; aucun automatisme de pêche. Les 17 domaines restent PARTIAL.
VALIDATION: Dernière tranche : Verify.ps1 396/396, zéro avertissement/erreur, package/versions/SHA-256/exclusion hôte verts ; Gobie de Merlthor 19 variantes/19 liens natifs/deux appâts résolus. Nouvelles conditions à prouver/tester avant livraison.
QUOTA: Relevé 2026-10-29 : 78 % disponibles sur 5 h et 43 % semaine ; réserve 5 %, objectif global actif.
NEXT_ACTION: Finaliser le checkpoint 0.61 puis lire le générateur et exemples d’horaires/conditions. GP et essais projection/Macro Chain différés, sans les redemander.
DEFINITION_OF_DONE: Étude sourcée et limites explicites ; toute tranche intégrée compilée et testée, documents/sauvegarde à jour ; aucun domaine global promu complet sans preuve.
