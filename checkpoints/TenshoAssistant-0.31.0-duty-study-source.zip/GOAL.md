# GOAL sélectionné

ID: DUTY-001
OBJECTIVE: Aperçu des butins par contenu avec identités et provenance fiables ; poursuivre la couverture du projet.
CURRENT_STATE: STUDIED — sources examinées et réponse Garland Tools Sastasha rapprochée des IDs locaux. Produit actuel 0.31.0, 177 tests/package valides ; QUEST-002 implémenté/testé, non observé en jeu. Duty Loot reste non disponible tant que service/UI/tests non intégrés. Macro Chain reporté.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: Domaines Gathering, Inventory, Collections, Market, Quests, Character, MiniGames ; MainWindow.* ; Plugin.cs ; tests et documents.
IN_SCOPE: Modèle original et consultation explicite des butins, identités contenu/instance/territoire, source et couverture, cache/annulation, icônes et contexte commun. QUEST-002 conservé sans interpréter l'éligibilité.
OUT_OF_SCOPE: Déclarer les 17 plugins remplacés ; prétendre une validation en jeu sans observation.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: 2026-10-28, 2 % disponibles sur 5 h et 85 % semaine au dernier relevé ; continuer selon instruction utilisateur, sauvegarde avant épuisement.
NEXT_ACTION: DUTY-001 : étude des sources achevée, voir docs/DUTY-001-STUDY.md. Implémenter un parser/service de consultation explicite Garland Tools avec identités, provenance et limites, puis UI intégrée et tests ; aucune table de drops native inventée. Conserver les 17 domaines et l'objectif global actif ; aucun test Macro Chain redemandé.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
