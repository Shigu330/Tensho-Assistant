# DUTY-001 — Étude des sources, 2026-10-28

État : STUDIED, implémentation de l'outil non commencée. Le plugin produit reste 0.31.0.0 / 177 tests ; cette étude ne rend aucun outil disponible dans l'interface.

## Preuve locale

Les métadonnées Lumina installées exposent `InstanceContent.InstanceContentRewardItem`. La feuille correspondante ne contient que `Unknown0` et `Unknown1` (sbyte), sans référence Item interprétée. `Treasure` expose des textes/champs inconnus et un modèle SGB, pas une liste typée d'objets. Ce constat porte sur les feuilles examinées ; il ne prouve pas l'absence de toute information de butin dans tous les fichiers du client.

GatheringProbe vérifie maintenant l'identité de Sastasha depuis le sqpack installé : InstanceContent 4 → ContentFinderCondition 4 → territoire 1036, ContentLinkType 1. Le retour ContentFinderCondition.Content doit correspondre à la ligne InstanceContent. Ce contrôle est passé le 2026-10-28. Ne jamais appliquer aveuglément Content.RowId à tous les types de contenu (roulettes, contenus publics, etc.).

## Sources primaires consultées

- [DutyLootPreview, DutyInfoService](https://github.com/grittyfrog/DutyLootPreview/blob/1ea0e9fd49b4b843d513a29eae0336de7a05228e/DutyLootPreview/Data/DutyInfoService.cs) : index des objets par contenu à partir des feuilles supplémentaires DungeonBossDrop, DungeonBossChest et DungeonChestItem. Auteur/dépôt identifiés ; aucune implémentation copiée. Aucune licence de dépôt n'a été trouvée dans l'arbre examiné, donc pas de réutilisation du code présumée autorisée.
- [LuminaSupplemental, génération des objets des coffres](https://github.com/Critical-Impact/LuminaSupplemental/blob/bd265c2b39868387937ae5b0c038593af997e0f9/src/LuminaSupplemental.SpaghettiGenerator/Steps/DungeonChestItemStep.cs) : import ChestDropsV2, généré hors client ; [génération des drops de boss](https://github.com/Critical-Impact/LuminaSupplemental/blob/bd265c2b39868387937ae5b0c038593af997e0f9/src/LuminaSupplemental.SpaghettiGenerator/Steps/DungeonBossDropStep.cs) : GTParser. Dépôt déclaré GPL-3.0 par GitHub ; aucun paquet, fichier CSV ou code intégré au projet.
- [Réponse Garland Tools Sastasha](https://www.garlandtools.org/db/doc/instance/en/2/4.json) : requête manuelle de lecture réussie, `instance.id=4`, `name=Sastasha`, champs rewards/fights/coffers. Exemples du premier coffre de combat : IDs 2684, 2683 ; du premier coffre de zone : 3781, 3786. `rewards` est une catégorie distincte, pas assimilée sans vérification aux coffres. Les noms des objets resteront ceux du catalogue français local.

Le document externe ne fournit pas de date d'observation ni de garantie d'exhaustivité. La date de téléchargement ne doit pas devenir une date de mise à jour de la source. Une entrée absente ne signifie pas « aucun butin ». Aucun taux de drop ne peut être inventé à partir d'une simple liste.

## Prochaine tranche d'implémentation

Modèle managé original : identité InstanceContent / ContentFinderCondition / territoire distincte, source Garland Tools, date de récupération et couverture explicitement partielle. Parser JSON borné et validant l'ID demandé ; coffres de combat, coffres de zone et récompenses séparés, identifiants Item résolus par le catalogue commun et inconnus conservés. Pas d'inclusion aveugle de tous les `partials` comme drops.

Service HTTP possédé, consultation explicite, cache borné et horodaté, annulation/révision, erreurs conservées distinctes de listes vides ; aucun accès réseau implicite par survol. Interface par contenu avec icônes et sélection vers le contexte commun. Pas de modification native du journal ou du menu de mission nécessaire pour la première tranche.

Tests à couvrir avant exposition : mauvais ID/provider, champs absents/mal formés, doublons multi-sources conservant leur provenance, Item inconnu, annulation/changement de sélection/réponse tardive, taille bornée, cache et erreur réseau. Compiler/versionner avant tout essai en jeu. Ne pas déclarer Duty Loot Preview remplacé sur cette seule tranche.
