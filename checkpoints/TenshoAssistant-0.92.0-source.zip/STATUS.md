# État courant

REFONTE_UI_2026_10_30: COMPLETE — périmètre UI accepté par l’utilisateur après
confirmation des vérifications en jeu. Derniers contrôles techniques : Release
0.75.0, 471/471 tests, langues et paquet vérifiés. Validation runtime rapportée
par l’utilisateur, non exécutée par l’agent. Voir docs/UI-LOCALIZATION-MIGRATION.md.
Cette clôture ne change pas la couverture métier PARTIAL des domaines ci-dessous.

CURRENT_GOAL: NPC-VENDORS-014 (0.88 outil ; 0.89 liens FateShop ; 0.90 mise en page du survol, X/Y ; 0.91 entrée « PNJ vendeurs » dans le clic droit de l'inventaire) — TESTED (DLL 0.91.0.0, 509/509). Liste PNJ au survol vue en jeu (capture 0.89, mise en page à corriger → 0.90). HOVER-TOOLTIP-013 : accroche, stock, moins cher, monstres wiki (0.87, « Lâché par : Rroneek (niv. 96) · Shaaloani ») et icône Gil VALIDATED_IN_GAME (captures utilisateur 2026-10-30). Également à valider en jeu : SORT-ITEM-PROPS-008 (0.84), CATALOG-CACHE-012 récolte/pêche (0.83). Cache objets VALIDATED_IN_GAME (0.81) ; recettes (0.82) non encore confirmées en jeu. SORT-ZONE-SELECT-011 (0.77–0.80) VALIDATED_IN_GAME (même rapport). ; multi-catégories et priorité vues en jeu (0.77/0.78), reste du protocole à faire. Clos le 2026-10-30 : QUEST-ITEM-PROGRESS-007 et SORT-RUNTIME-VALIDATION (tri natif validé en jeu, rapport utilisateur).
CURRENT_MODEL_CLASS: LIGHT — jointure managée, aucune API native nouvelle
RECOMMENDED_MODEL: LIGHT pour cette tranche ; HEAVY pour l’intégration native des menus/tri
MODEL_ESCALATION: None
QUOTA: Relevé utilisateur 2026-10-30 ~20:45 : 86 % session (réinit. 23:20), 12 % semaine (réinit. jeudi 23:00). Réserve abaissée par l'utilisateur à 1 % (5 h et semaine) vers 20:55 ; diagnostic assignats fait, arrêt avant tout code (question en jeu ouverte). Point de reprise : checkpoints/0.89.0-quota.md. Réserves : arrêt à 5 % restants (5 h) OU 1 % restant (semaine).
LAST_READ: 2026-10-30 — pilotage complet, QuestService/QuestReader/QuestRewardIndex/MainWindow.QuestItemSources relus pour QUEST-ITEM-PROGRESS-007.
BUILD: COMPILED Release 2026-10-30 20:39 — Verify.ps1 exécuté par l’agent sur le PC ; bin\x64\Release\TenshoAssistant.dll FileVersion 0.91.0.0 ; 0 avertissement, 0 erreur.
TESTS: TESTED — Verify.ps1 509/509 (dont 4 NpcVendorTests et WikiMonsterTests redirections/candidats) ; détail antérieur 504/504 (477 + 6 InventorySortSelection + 3 ItemCatalogCache + 3 RecipeCatalogCache + 3 GatheringCatalogCache + 4 InventorySortProps + 4 MarketHoverDetails + 4 MonsterHoverSources), langues et paquet/SHA-256 verts (agent).
RUNTIME: Captures utilisateur 2026-10-30 18:43 (objet « Pièce d’argent allagoise ») : colonne Progression, compteurs 1 en cours · 173 terminées · 127 non confirmées (301/301), filtres Toutes et En cours, séquence affichée ; relevé issu du cache disque daté 29-10-26 21:40. 2026-10-30 ~19:00 : utilisateur rapporte « v76 ok » (DLL 0.76.0.0 chargée en jeu) ; libellés « séquence finale (255) » / « 1 variante » et « Non confirmée » après déconnexion rapportés OK (« tout est OK »). Antérieur : jusqu’à 0.5.27 confirmé ; refonte UI 0.75 confirmée par l’utilisateur.
WORK_COMPLETED: CACHE-001 : instantanés JSON persistants bornés, écritures ordonnées atomiques hors framework, portée/version/langue/propriétaire et dates conservées. Durées par domaine dans Réglages ; force dans les outils ; péremption indicative des imports ; calculs du carnet mis en cache et rejoués avant restitution. Catalogue statique partagé en mémoire et observations vivantes conservés. Correctifs qualité/temps 0.74 conservés.
BLOCKER: Aucun blocage global. Le bonus natif d’Abondance reste inconnu : sources divergentes et aucun getter nommé confirmé dans les bindings étudiés. Ne pas inventer une formule ; travaux indépendants poursuivis.
RESUME_FROM: GOAL.md ; docs/QUEST-ITEM-PROGRESS-007.md ; CLAUDE.md pour les contraintes de la session cloud.
NEXT_ACTION: Reprise après 23:20 : assignats d'artisanat/récolte dans l'outil PNJ (InclusionShop + monnaie codée prouvée, voir docs/NPC-VENDORS-014.md « Piste de reprise »). Outil PNJ 0.91 validé en jeu pour gils/espoilles/sceaux (capture). Restent à confirmer : clic droit inventaire → PNJ vendeurs, survol PNJ 0.90 ; outil PNJ vendeurs (Épaule de rroneek → marchand de gemmes bicolores, drapeau au clic droit ; docs/NPC-VENDORS-014.md) (Épaule de rroneek → Rroneek 96 Shaaloani), aucune recherche sur équipement/objets fabriqués/récoltés, fenêtre Matériaux des monstres (docs/HOVER-TOOLTIP-013.md), critères/filtres de tri (docs/SORT-ITEM-PROPS-008.md), recettes et récolte/pêche après rechargement. Puis SORT-ARMOURY-009 (HEAVY) ou autre domaine PARTIAL ; puis SORT-ITEM-PROPS-008. Tri natif 0.54–0.59 VALIDATED_IN_GAME (rapport utilisateur 2026-10-30) (docs/SORT-GAP-008-STUDY.md) avant SORT-ITEM-PROPS-008. Les 17 outils restent PARTIAL.

| Plugin | Coverage |
|---|---|
| Avant-Garde | PARTIAL — répertoire manuel d'indices natifs, équipements signalés, emplacements/stock/contexte et source datée ; thème courant/teintures/score/attache non déduits |
| Blue Mage Helper | PARTIAL — grimoire, numéros, descriptions, lieux renseignés et acquisition confirmée |
| Character Panel Refined | PARTIAL — attributs natifs, sans formules dérivées |
| Collections | PARTIAL — montures, mascottes, emotes, cartes, orchestrion, titres et succès ; preuve de chargement, catégories/fiches/récompenses, runtime à confirmer |
| Craftimizer | PARTIAL — carnet natif, collectionnables ordinaires, qualité initiale et recherche orientée attentes ; optimum global, rotation adaptative et recettes spéciales à compléter |
| Duty Loot Preview | PARTIAL — consultation manuelle par contenu, coffres/récompenses, icônes/contexte, provenance et cache ; drops directs non interprétés, données externes partielles |
| ezMiniCactpot | PARTIAL — solveur exact manuel et mode observé opt-in LotteryDaily ; conseil actualisé, aucune commande ; adaptation/rendu natifs non validés en jeu |
| GatherBuddy | PARTIAL — sources/maps/horaires/météo statiques, point courant MIN/BTN opt-in, carnet natif pêche, appâts/conditions explicites et plages ET/UTC et météo localisée ; plages des critères renseignés, présence/prérequis/harpon et runtime à compléter |
| Item Use | PARTIAL — recettes, mandats, candidats GC/aquarium, orchestrion et sources de quête, survol et menu Inventory opt-in ; autres usages/disponibilité, liens de discussion et runtime à compléter |
| LazyGatherer | PARTIAL — optimiseur manuel avec effets explicitement déclarés, observation du point et copie de ressources ; décodeur natif/bonus/régénération/procs/collectionnables et validation runtime à compléter |
| Macro Chain | PARTIAL — séquences à marqueur final, lancement explicite, arrêt, persistance ; natif à confirmer |
| Mappy | PARTIAL — navigateur natif, repères favoris persistants, ressources de zone et prévisions météo statiques ; météo forcée non observée |
| Monster Loot Hunter | PARTIAL — associations matériau/monstre, fiches/niveaux/lieux et carte de zone, transport/cadence partagés, contexte ; données communautaires partielles |
| Price Insight | PARTIAL — consultation manuelle et prix au survol opt-in, NQ/HQ/monde, cache/cadence/priorités partagés ; contexte mutualisé et scope owner/monde, runtime à confirmer |
| QuestTracker | PARTIAL — états natifs, séquence, fiches/liens et récompenses conditionnelles vers Item ; sources inverses managées, couverture/inconnus et disponibilité non calculée |
| SortaKinda | PARTIAL — profils/modèles, critères, zones protégées/filtrées et inversion, application visuelle après capture directe ; autres filtres/automatisations choisies et validation runtime à compléter |
| TriadBuddy | PARTIAL — carnet/deck/solveur manuel, observation des faces opt-in expérimentale ; identités/règles/trait natifs et autres règles non établis |

