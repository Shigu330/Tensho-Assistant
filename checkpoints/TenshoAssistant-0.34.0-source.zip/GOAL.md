# GOAL sélectionné

ID: GP-001
OBJECTIVE: Aide aux PR avec scénario explicite et actions/coûts vérifiés ; poursuivre la couverture du projet.
CURRENT_STATE: IMPLEMENTED / TESTED — optimiseur manuel MIN/BTN et PR observés intégrés en 0.34.0, 214 tests/package verts. Probe 20 actions et scénario contrôlé, 64 cas contre oracle indépendant passants. Hypothèses et couverture partielle explicites ; aucune validation en jeu. Macro Chain reporté.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: Domaines Community, Monsters, Duties, Maps, Gathering, Inventory, Collections, Market, Quests, Character, MiniGames ; MainWindow.* ; Plugin.cs ; tests, probe et documents.
IN_SCOPE: Catalogue de 20 actions PR vérifiées, scénario manuel ordinaire MIN/BTN, optimisation coût/espérance et seuils ; copie explicite des PR courants/niveau avec identité et date, sans exécution d'action.
OUT_OF_SCOPE: Déclarer les 17 plugins remplacés ; prétendre une validation en jeu sans observation.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: 2026-10-28, 72 % disponibles sur 5 h et 80 % semaine au dernier relevé ; continuer selon instruction utilisateur.
NEXT_ACTION: Snapshot 0.34.0 puis FASHION-001 (Avant-Garde) : vérifier indices/équipements et validité hebdomadaire des sources avant recommandations. Conserver les 17 domaines et le goal global, Macro Chain différé ; adaptations GP/Triad natives restent des extensions.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
