# Backlog ciblé

État courant 0.50.0 (2026-10-29) : [effets PR déjà payés](docs/GP-ACTIVE-005.md), déclarations manuelles avec icônes, coût supplémentaire et bonus limité à la première tentative ; observation du point conservée sans décodeur d’effets inventé. 327/327 tests et package vérifiés ; oracle indépendant sur 128 scénarios et probes avec actions du jeu passants. Les 17 domaines restent PARTIAL, fonctions 0.6+ non validées en jeu. Tests projection/Macro Chain différés ; réserve de quota 5 %.

MISE À JOUR 2026-10-27 / 0.5.27 : les anciens états READY/TODO de CRAFT-001A ci-dessous sont dépassés. Catalogue, carnet et préparation implémentés, 63 tests réussis et confirmation utilisateur reçue. Cet ancien checkpoint est clos ; GOAL.md décrit la tranche actuelle. Les scénarios runtime non observés restent conservés dans TESTING.md.

- CORE-001 DONE : snapshot managé et InventoryService avec portée propriétaire/conteneurs/NQ-HQ, couverture et observations ; huit tests inventaire passent.
- INV-001 DONE (implémentation/tests) : adaptateur des quatre sacs intégré, lecture framework, invalidation et snapshots Partial/Unknown. Aucun Complete supposé.
- INV-002 DONE (implémentation/tests, 0.1.1) : preuve de chargement/stabilité et lecture complète, affichage d'un total exact des quatre sacs si complet ; nouvel essai live requis.
- RUNTIME-001 : protocole utilisateur courant accepté ; cas avancés de déchargement/erreur/second personnage conservés dans TESTING.md, sans réussite supposée.
- ITEM-001 DONE côté code/tests : catalogue Item partagé, métadonnées de génération et recherche par nom/ID reliée au diagnostic des sacs.
- ITEM-001-RUNTIME DONE : catalogue français 50 880 objets, recherche/sélection et NQ/HQ/total confirmés par capture et retour utilisateur.
- CRAFT-001A READY : catalogue Recipe + RecipeLevelTable + ingrédients ; première tranche recette → ingrédients, basée sur le même catalogue Item.
- UI-003 DONE côté code/tests : espace commun avec navigation, répertoire des 17 outils, réglages et diagnostics séparés. UI-003-RUNTIME ACTIVE : contrôle visuel 0.2.0 avant reprise de CRAFT-001A.
- UI-004 DONE côté code/tests : répertoire remplacé par une grille d'icônes natives ; détails seulement dans une fiche après clic. L'essai UI-003-RUNTIME doit utiliser la nouvelle DLL 0.2.1.
- BANK-001 DONE côté code/tests : cache persistant par personnage/servant/sacoche, imports manuels attachés aux menus et résultats de recherche datés. BANK-001-RUNTIME ACTIVE : vérifier ancrage/import/réimport/persistance en 0.3.0 avant reprise des recettes.
- Banque : équipements/cristaux/marché des servants et éventuelle suppression manuelle d'un ancien relevé restent des extensions séparées, sans prétendre être inclus dans le relevé des sept pages.
- UI-005 DONE côté code/tests : icônes réelles et regroupement unifié Personnage/Chocobo/Servants. UI-005-RUNTIME ACTIVE : vérifier visuellement 0.4.0. La capture 0.3.0 prouve un cache chocobo consultable mais ne valide pas encore les imports servant ou leur attache/persistance.
- CRAFT-001 TODO après ITEM-001 : catalogue Recipe + RecipeLevelTable + ingrédients ; chemin recette → besoins.
- Runtime CORE-000 à effectuer : chargement, commande, préférence, rechargement/déchargement et logs dans un client FFXIV approprié.
- Les phases suivantes de chaque plugin restent dans ROADMAP.md. Les dépôts non fournis doivent être identifiés et leurs licences vérifiées au moment de leur étude ciblée (NEEDS_STUDY).
- Combat/ACT/IINACT : complément séparé, aucune priorité devant les 17 plugins.
