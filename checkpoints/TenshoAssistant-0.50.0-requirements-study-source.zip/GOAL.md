# GOAL sélectionné

ID: GP-ACTIVE-005
OBJECTIVE: Prendre en compte les effets déjà payés dans le modèle PR partagé sans double comptage, puis établir les données et le décodeur nécessaires à sa liaison native ; poursuivre le périmètre complet jusqu’à 5 % de quota.
CURRENT_STATE: IMPLEMENTED_CORE / TESTED en 0.50.0,327 tests/package verts ; UI de déclarations manuelles, base et coût supplémentaire, bonus limité consommé une fois ;128 scénarios contre oracle indépendant. Décodeur natif/magnitudes non établis, aucun essai runtime nouveau déclaré.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: GpOptimizer/GpActiveEffects ; MainWindow.GatheringGp/Observation/Tools ; GpActiveEffectsTests ; GatheringActionsProbe ; docs.
IN_SCOPE: État d’effets explicitement fourni, familles déjà actives exclues des nouveaux achats, supplément Évangile et bonus payé sur première tentative. Moteur partagé conservant scénario historique ; inconnus déclarés refusés.
OUT_OF_SCOPE: Déduire absence ou magnitude native depuis StatusGainSelf=0, annoncer remplacement intégral/validation native sans preuve. Régénération, procs, restauration, cristaux/collectionnables et effets hors modèle restent à développer.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: Relevé2026-10-29 :89 % disponibles sur 5 h et60 % semaine ; réserve utilisateur5 %. Objectif global actif.
NEXT_ACTION: Lire docs/GP-METADATA-006-STUDY.md : nouveau probe exécuté,61/131 clés divergent entre ItemLevel et table externe,51 objets ont plusieurs exigences ; frontières et déblocage diffèrent aussi. Résoudre origine et contexte exacts avant toute aide automatique. Garder le scénario manuel actuel et progresser sur les travaux indépendants si cette donnée reste inconnue. Tests projection/Macro Chain différés ;17 domaines et objectif global conservés.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
