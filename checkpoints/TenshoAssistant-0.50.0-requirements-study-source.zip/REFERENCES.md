# Références

## REF-GP-ACTIVE-005

STATUS: CURRENT_VERIFIED / LOCAL_VERIFIED —2026-10-29. [Preuves et limites](docs/GP-ACTIVE-005.md).
SOURCE: LazyGatherer0bb8ec9a47dc4521411c705221cdeda361015d75, familles Yield/Gift/Tidings et tentatives Abondance ; faits ciblés uniquement, AGPL, aucune implémentation importée. Actions/ActionTransient installées et probe commun ; StatusGainSelf vide reste une association inconnue.
FACTS: familles permanentes déjà actives non sélectionnées à nouveau ; supplément Évangile2, bonus limité appliqué une fois. Modèle déclaré et oracle originaux ; aucun état natif inventé.
VALIDATION:327/327 tests/package, oracle128 scénarios et probes MIN/BTN avec actions du jeu passants. Rendu et effets réels non validés.

## REF-GATHER-NATIVE-004

STATUS: LOCAL_VERIFIED / CURRENT_VERIFIED — 2026-10-29. [Preuves et limites](docs/GATHER-NATIVE-004.md).
SOURCE: signatures GUI installées ; FFXIVClientStructs AddonGathering/AtkResNode 385b0821bc4573b77fbde84c930774eeca8283ec ; LazyGatherer GatheringItemComponent/GatheringController 0bb8ec9a47dc4521411c705221cdeda361015d75 pour faits de lecture seulement (AGPL, aucune implémentation importée).
FACTS: Gathering.uld installé contient 8 lignes CheckBox composant1010, textes10/16 et icône31→composant1005, texte quantité7. Probe utilise GatheringUiLayout de production ; 35/12 nœuds, borne256. Textes vides/tirets/malformés restent inconnus ; taux affichés pas déduits comme bases.
VALIDATION: 320/320 tests/package verts et GatheringUiProbe passant ; aucune capture ou validation visuelle native.

## REF-CACT-LIVE-002

Voir aussi [CACT-LIVE-002](docs/CACT-LIVE-002.md) : métadonnées locales AddonLotteryDaily et source FFXIVClientStructs 385b0821bc4573b77fbde84c930774eeca8283ec vérifiées ; indexeurs neuf entiers en ordre ligne/colonne. Référence historique MidoriKami/EzMiniCactpot 63173afb3eff69aa64a3edc613a377c4053d26fa pour GameNumbers et retrait en fin de ticket ; aucune implémentation importée, pas de fichier LICENSE trouvé dans cet arbre. Ancienne URL daemitus 404. API compilée et 311 tests/package verts ; native runtime non validé. Statuts LOCAL_VERIFIED / HISTORICAL_VERIFIED, 2026-10-29.

## REF-CRAFT-CONDITIONS-004 / RANGE-005

STATUS: CURRENT_VERIFIED / LOCAL_VERIFIED — 2026-10-29. Sources et limites dans [CRAFT-CONDITIONS-004](docs/CRAFT-CONDITIONS-004.md) et [CRAFT-CONDITION-RANGE-005](docs/CRAFT-CONDITION-RANGE-005.md).
SOURCE: Craftimizer commit 1d4a2c67ea47a25d68701e8e69c8744dbbd56d86, Gearsets et Simulator (StepCondition, facteurs qualité), lus depuis le dépôt primaire ; métadonnées et sqpack locaux.
FACTS: description anglaise connue des outils × 1,75 ; 136 marqueurs dans 928 outils principaux, aucun ailleurs. Favorable/Mauvaise → Normale ; Excellente → Mauvaise ; à partir de Normale, enveloppe conservatrice Normale/Favorable/Excellente sans probabilité. Bornes par condition comparées à une énumération exhaustive sur petits scénarios.
VALIDATION: 302/302 tests/package verts. L’observation de l’outil réellement équipé et le rendu en jeu restent non validés ; tests projection et Macro Chain différés.

## REF-CRAFT-LIVE-003

DOMAIN: Craft ; projection immédiate native expérimentale.
NAME: Valeurs Synthesis typées et admissibilité des actions.
REPOSITORY: WorkingRobot/Craftimizer ; aers/FFXIVClientStructs ; assemblies locales API 15.
COMMIT_OR_VERSION: 1d4a2c67ea47a25d68701e8e69c8744dbbd56d86 ; ActionManager 385b0821bc4573b77fbde84c930774eeca8283ec.
LICENSE: Sources étudiées pour les faits ; implémentation originale, aucun hook ou offset repris.
VERIFIED_AT: 2026-10-29.
STATUS: CURRENT_VERIFIED pour schéma/conventions étudiés ; LOCAL_VERIFIED pour signatures ; runtime UNKNOWN, test différé par l'utilisateur.
SOURCE: [preuves et limites](docs/CRAFT-LIVE-003.md).
FILES_READ: SynthesisValues, Condition, SynthHelper, Hooks ; ActionManager et métadonnées AtkValue/ActionType/CraftCondition.
TECHNICAL_FACTS: Normale addon0 et handler1, étape UI moins un ; GetActionStatus sans contrôle de recharge ; GetActionCost non utilisé faute de sens établi des quatre paramètres additionnels. Projection d'états possibles, sans rotation complète.
LOCAL_COMPATIBILITY: Verify.ps1 0.45.0.0, 290/290 tests/package verts ; GatheringProbe et CraftSimulationProbe passant.
NOTES: Le test de projection et Macro Chain sont différés par l'utilisateur ; pas de nouvelle demande. Réserve de quota utilisateur 5 %.

## REF-GATHER-WEATHER-001

DOMAIN: Gathering / Maps ; météo de zones.
NAME: Poids météo natifs et prévisions des périodes ET.
REPOSITORY: FFXIV-CombatReborn/GatherBuddyReborn ; feuilles natives installées.
COMMIT_OR_VERSION: a204f2f45cb98302dbe938921255c3a6d617c775 ; Lumina locale API 15.
LICENSE: Apache-2.0 pour la référence ; faits étudiés, implémentation originale.
VERIFIED_AT: 2026-10-28.
STATUS: CURRENT_VERIFIED pour calcul/taux ; LOCAL_VERIFIED pour jointures et icônes ; runtime UNKNOWN.
SOURCE: [preuves et limites](docs/GATHER-WEATHER-001.md).
FILES_READ: WeatherManager.Computation.cs, CumulativeWeatherRates.cs ; WeatherRate, Weather, TerritoryType via ApiProbe et sqpack.
TECHNICAL_FACTS: Période huit heures ET, mélange 32 bits et taux cumulés ; 1290 territoires/72 météos, 24 zones individuelles ; Empyrée total90 conservé inconnu pour la masse manquante.
LOCAL_COMPATIBILITY: Verify.ps1 0.42.0.0, 275/275 tests/package verts ; WeatherProbe passant sans avertissement.
NOTES: Prévision calculée, pas météo native observée ; événement et prérequis de ressources hors couverture.

## REF-CRAFT-LIVE-002

DOMAIN: Craft ; effets observés.
NAME: Identités de statuts, Param, compteurs et historique unique.
REPOSITORY: WorkingRobot/Craftimizer ; feuilles natives et assemblies installées.
COMMIT_OR_VERSION: 1d4a2c67ea47a25d68701e8e69c8744dbbd56d86 ; API 15 locale.
LICENSE: MIT pour la source étudiée ; faits utilisés, aucun hook/code repris.
VERIFIED_AT: 2026-10-28.
STATUS: CURRENT_VERIFIED pour Param/IDs/convention étudiée ; LOCAL_VERIFIED pour douze statuts/icônes ; runtime UNKNOWN.
SOURCE: [preuves et limites](docs/CRAFT-LIVE-002.md).
FILES_READ: SynthHelper, SimulatorUtils, SynthesisValues ; StatusList.Length, Status.Param et feuilles Status du jeu.
TECHNICAL_FACTS: Compteurs via Param, douze IDs reconnus et icônes natives, présence de Main suprême distincte de son historique. Le lecteur primaire suit ses ActionStates via actions ; les procs natifs ne sont pas convertis sans preuve.
LOCAL_COMPATIBILITY: Verify.ps1 0.41.0.0, 270/270 tests et package verts ; probe douze statuts et 208 actions passant.
NOTES: Aucun état complet de conseil reconstruit ; test runtime différé, autres domaines peuvent avancer.

## REF-CRAFT-LIVE-001

DOMAIN: Craft ; observation native.
NAME: CraftEventHandler, AddonSynthesis et PS courants.
REPOSITORY: Assemblies locales Dalamud/FFXIVClientStructs installées ; aucune copie de code externe.
COMMIT_OR_VERSION: API 15 ; signatures et champs vérifiés via ApiProbe.
LICENSE: Métadonnées inspectées, pas d'assembly hôte redistribuée.
VERIFIED_AT: 2026-10-28.
STATUS: LOCAL_VERIFIED pour disponibilité des accès ; runtime UNKNOWN.
SOURCE: [preuves et protocole](docs/CRAFT-LIVE-001.md).
FILES_READ: Types EventFramework/CraftEventHandler/CraftCondition/CraftFlags, AddonSynthesis/CraftEffect, AtkTextNode/AtkResNode/Utf8String, IObjectTable/ICharacter/IBattleChara et statuts ; lecteur expérimental existant comme convention lifecycle.
TECHNICAL_FACTS: Handler présent contrairement au CraftingManager supposé ; champs nommés recette/étape/condition, textes et effets UI, CurrentCp/MaxCp. Paramètres temporels/charges de statuts non interprétés.
LOCAL_COMPATIBILITY: Verify.ps1 0.40.0.0, 265/265 tests et package verts ; aucune capture du client en cours réalisée.
NOTES: Lecture seule temporaire désactivée par défaut ; aucun conseil ou état natif complet revendiqué.

## REF-CRAFT-ACTIONS-002

DOMAIN: Craft ; actions normales avancées.
NAME: Neuf actions, traits, Calme intérieur et protection de solidité.
REPOSITORY: WorkingRobot/Craftimizer.
COMMIT_OR_VERSION: 1d4a2c67ea47a25d68701e8e69c8744dbbd56d86 ; feuilles natives installées API 15.
LICENSE: MIT ; faits étudiés, implémentation originale.
VERIFIED_AT: 2026-10-28.
STATUS: LOCAL_VERIFIED pour 208 métadonnées/icônes ; CURRENT_VERIFIED pour contraintes/traits du modèle ; runtime UNKNOWN.
SOURCE: [table d'actions, preuves et limites](docs/CRAFT-ACTIONS-002.md).
FILES_READ: DelicateSynthesis, PreparatoryTouch, PrudentSynthesis/Touch, RefinedTouch, TrainedEye/Finesse/Perfection, ImmaculateMend ; Simulator et Effects.
TECHNICAL_FACTS: Trait 94 séparé, deux charges/combo, interdiction Parcimonie, ouverture/niveau et dix charges, restauration totale, protection persistante consommée une seule fois.
LOCAL_COMPATIBILITY: Verify.ps1 0.39.0.0, 260/260 tests et package verts ; probe 208 variantes, recette niveau100 et replay passant.
NOTES: Proposition niveau100 sous cible explicitement rapportée ; ne prouve ni impossibilité ni capacité du personnage connecté. Pas de lecture native de synthèse.

## REF-CRAFT-MACRO-001

DOMAIN: Craft ; export manuel.
NAME: Commandes localisées, capacité et attentes proposées.
REPOSITORY: WorkingRobot/Craftimizer.
COMMIT_OR_VERSION: 1d4a2c67ea47a25d68701e8e69c8744dbbd56d86.
LICENSE: MIT ; faits étudiés, implémentation originale.
VERIFIED_AT: 2026-10-28.
STATUS: CURRENT_VERIFIED ; métadonnées d'actions LOCAL_VERIFIED ; activation en jeu UNKNOWN.
SOURCE: [preuves et limites](docs/CRAFT-MACRO-001.md).
FILES_READ: MacroCopy.cs, BaseAction.cs, BaseBuffAction.cs, Observe.cs, MastersMend.cs, MuscleMemory.cs, Reflect.cs ; lecteur natif de macros existant.
TECHNICAL_FACTS: 15 lignes, /ac avec nom natif et attente ; effets 2s, autres actions modélisées 3s. Convention d'export, pas garantie de latence.
LOCAL_COMPATIBILITY: Release 0.37.0.0, 243/243 tests et package verts ; probe des huit métiers passant.
NOTES: Copie texte par bloc uniquement ; aucune exécution ou écriture native.

## REF-CRAFT-SIM-001

DOMAIN: Craft ; simulation manuelle normale.
NAME: Paramètres Recipe et actions déterministes.
REPOSITORY: WorkingRobot/Craftimizer ; ffxiv-teamcraft/simulator.
COMMIT_OR_VERSION: 1d4a2c67ea47a25d68701e8e69c8744dbbd56d86 ; 74e167a05ba279526d2ddd457a048e234bedbad9 ; assemblies locales API 15.
LICENSE: Craftimizer MIT ; sources étudiées pour les faits, aucun code externe embarqué.
VERIFIED_AT: 2026-10-28.
STATUS: LOCAL_VERIFIED pour champs/jointures/actions/icônes ; CURRENT_VERIFIED pour comparaison des formules de ces commits ; runtime UNKNOWN.
SOURCE: [dossier et preuves](docs/CRAFT-SIM-001.md).
FILES_READ: Craftimizer SimulationInput et actions/effets ; Teamcraft quality-action, progress-action, AdvancedTouch ; Lumina Recipe/RecipeLevelTable/CraftAction/Action/ActionTransient du jeu installé.
TECHNICAL_FACTS: Bases tronquées avant action, buffs additifs, combos conditionnels, durées et arrêts ; 136 variantes natives vérifiées ; 11 361 recettes acceptées / 2 531 explicitement exclues du modèle initial.
LOCAL_COMPATIBILITY: Release 0.36.0.0, Verify.ps1 239/239 et package verts ; CraftSimulationProbe passant.
NOTES: Condition normale uniquement, attributs manuels/copiés, pas de taux HQ ni de synthèse commandée ; voir périmètre exact et test différé.

État courant 0.19.0 (2026-10-28) : [base multi-outils](docs/BASE-TOOLS-001.md), [sous-recettes](docs/CRAFT-CHAIN-001.md), [cartes](docs/MAP-001A.md), [favoris de cartes](docs/MAP-002.md), [prix au survol](docs/MARKET-HOVER-001.md) et [séquences de macros](docs/MACRO-001A.md). 119/119 tests et package vérifiés. L'utilisateur testera Macro Chain plus tard ; validation native différée, sans acceptation supposée.

REF-ID: REF-GATHER-LOCAL-20261027
DOMAIN: Récolte/pêche
SOURCE: Assemblies Lumina installées, sqpack du jeu installé lu par tools/GatheringProbe.
STATUS: LOCAL_VERIFIED — compilation API ; LOCAL_DATA_VERIFIED — jointures exécutées sur fichiers du jeu.
VERIFIED_AT: 2026-10-27 Europe/Brussels
FILES_READ: Métadonnées GatheringItem, GatheringItemPoint (subrows), GatheringPointBase, GatheringPoint, GatheringType, TerritoryType, PlaceName, FishingSpot et Map ; données locales des mêmes feuilles.
TECHNICAL_FACTS: Les RowRef non typées sont contrôlées par RowType. GatheringItemPoint.RowId identifie GatheringItem et ses subrows référencent GatheringPoint ; cette liaison fournit les sources des objets cachés absents de GatheringPointBase.Item. FishingSpot.Item est directement typé Item.
NOTES: Pas de code de plugin externe copié. Carte ouverte au centre de zone uniquement ; aucune position exacte ou disponibilité déduite. Preuves de comptage dans TESTING.md.

REF-ID: INVENTORY-VISUAL-ORDER-20261027
DOMAIN: Inventory
NAME: ItemOrderModule et ItemOrderModuleSorter
SOURCE: https://github.com/aers/FFXIVClientStructs/blob/main/FFXIVClientStructs/FFXIV/Client/UI/Misc/ItemOrderModule.cs
VERIFIED_AT: 2026-10-27 Europe/Brussels
STATUS: LOCAL_VERIFIED — champs présents dans l'assembly installé et accès compilé ; runtime à confirmer.
TECHNICAL_FACTS: InventorySorter, SaddleBagSorter, PremiumSaddleBagSorter et GetActiveRetainerSorter exposent Items ; chaque entrée référence Page et Slot physiques. Cette permutation est distincte de l'ordre physique IGameInventory.
NOTES: L'affirmation précédente selon laquelle changer ligne/colonne suffisait était incorrecte. La projection consomme désormais cette table ; aucune écriture native.


## REF-MACRO-BRIDGE-20261028

REF-ID: REF-MACRO-BRIDGE-20261028
DOMAIN: Macro Chain
NAME: Adaptateur local à marqueur final et appel possédé
REPOSITORY: Sources originales Tensho ; références primaires https://github.com/Caraxi/MacroChain et https://github.com/aers/FFXIVClientStructs
COMMIT_OR_VERSION: Assemblies locales API 15 compilées en 0.18.0 ; lectures externes du 2026-10-27 conservées dans docs/MACRO-001A.md
LICENSE: Aucune implémentation externe copiée ; SDK/assemblies hôte non redistribués
VERIFIED_AT: 2026-10-28 Europe/Brussels
STATUS: LOCAL_VERIFIED pour signatures/compilation ; NATIVE_BEHAVIOR_UNVERIFIED
SOURCE: ApiProbe, Dalamud.xml local et sources de l'adaptateur
FILES_READ: RaptureMacroModule.Macro/GetMacro, Utf8String, RaptureShellModule.ExecuteMacro/MacroLines/MacroName/MacroCurrentLine, IGameInteropProvider.HookFromAddress, IFramework.IsInFrameworkUpdateThread
TECHNICAL_FACTS: Macro est un type natif avec 15 lignes ; livres 0/1 et index 0–99. Hook à adresse fournie par les membres typés, aucun offset/signature ajouté. Les noms/lignes copiés au framework sont managés. IsInFrameworkUpdateThread vérifie le thread du jeu, pas seulement la portée du callback Update.
LOCAL_COMPATIBILITY: 0.18.0 compilée et 114 tests/package vérifiés ; scopes, commandes et hook possédés. Aucun appel au jeu effectué pendant ces tests.
NOTES: Indice de ligne au callback du marqueur encore à confirmer. Le protocole accepte la ligne du pied ou sa consommation immédiate ; tout désaccord arrête la suite. Aucune réussite d'action de macro n'est déduite du marqueur.

BASELINE_REFERENCE_DATE: 2026-10-27

Les onze blocs historiques ci-dessous sont transcrits du prompt maître, et non revérifiés sur leurs dépôts. Les licences sont celles rapportées par cette source. Aucune source de plugin externe n'a été copiée. FILES_READ distingue ce qui a réellement été lu ici des concepts rapportés historiquement.

## REF-DALAMUD

REF-ID: REF-DALAMUD
DOMAIN: Socle
NAME: Dalamud
REPOSITORY: https://github.com/goatcorp/Dalamud
COMMIT_OR_VERSION: 1e514694497ae448fca8e8a46f7b63642ad1e5ad
LICENSE: AGPL v3 (observation historique fournie)
VERIFIED_AT: 2026-10-27
STATUS: HISTORICAL_VERIFIED
SOURCE: docs/PROMPT-MAITRE.md
FILES_READ: Prompt maître seulement dans cette session ; fichiers/concepts rapportés : IFramework ; IUnlockState ; IGameInventory ; IAddonLifecycle ; WindowSystem ; GameInventory.
TECHNICAL_FACTS: IFramework expose IsInFrameworkUpdateThread, RunOnTick, RunOnFrameworkThread. Copier ReadOnlySpan<GameInventoryItem> avant traitement différé. Indicateurs de chargement unlocks : false peut rester inconnu. InventoryChanged invalide, ne prouve pas la complétude.
LOCAL_COMPATIBILITY: UNKNOWN pour ces commits historiques ; le build du bootstrap est consigné séparément.
NOTES: Conserver uniquement les faits techniques. Pas de conclusion produit issue d'un autre projet.

## REF-SAMPLE

REF-ID: REF-SAMPLE
DOMAIN: Bootstrap
NAME: SamplePlugin
REPOSITORY: https://github.com/goatcorp/SamplePlugin
COMMIT_OR_VERSION: b8477daaa678a5dd72cdcd4a32bc249d3c23a598
LICENSE: AGPL v3 (observation historique fournie)
VERIFIED_AT: 2026-10-27
STATUS: HISTORICAL_VERIFIED
SOURCE: docs/PROMPT-MAITRE.md
FILES_READ: Prompt maître seulement dans cette session ; fichiers/concepts rapportés : Plugin ; configuration ; fenêtres.
TECHNICAL_FACTS: IDalamudPlugin, PluginService, ICommandManager, WindowSystem, UiBuilder.Draw/OpenConfigUi/OpenMainUi, IPluginConfiguration/SavePluginConfig, Dispose. SDK observé 15.0.0, sans présumer de sa validité actuelle.
LOCAL_COMPATIBILITY: UNKNOWN pour ces commits historiques ; le build du bootstrap est consigné séparément.
NOTES: Conserver uniquement les faits techniques. Pas de conclusion produit issue d'un autre projet.

## REF-CRAFT

REF-ID: REF-CRAFT
DOMAIN: Craftimizer #5
NAME: Craftimizer
REPOSITORY: https://github.com/WorkingRobot/Craftimizer
COMMIT_OR_VERSION: 1d4a2c67ea47a25d68701e8e69c8744dbbd56d86
LICENSE: MIT (observation historique fournie)
VERIFIED_AT: 2026-10-27
STATUS: HISTORICAL_VERIFIED
SOURCE: docs/PROMPT-MAITRE.md
FILES_READ: Prompt maître seulement dans cette session ; fichiers/concepts rapportés : RecipeData ; RecipeNote ; WKSRecipeNotebook ; simulateur ; solver.
TECHNICAL_FACTS: Joindre Recipe/RecipeLevelTable/Item/seuils collectables. Qualité initiale selon HQ, niveaux objets et MaterialQualityFactor. Byregot/Inner Quiet, Innovation/Great Strides, étapes et aléatoire. Solver annulable avec parallélisme borné, génétique/MCTS/Raphael ; pas d'exhaustivité universelle démontrée. Offsets à revérifier avant usage.
LOCAL_COMPATIBILITY: UNKNOWN pour ces commits historiques ; le build du bootstrap est consigné séparément.
NOTES: Conserver uniquement les faits techniques. Pas de conclusion produit issue d'un autre projet.

## REF-ARTISAN

REF-ID: REF-ARTISAN
DOMAIN: Craft secondaire
NAME: Artisan
REPOSITORY: https://github.com/PunishXIV/Artisan
COMMIT_OR_VERSION: 247c2df1fad7eb83fa7af584e8340f4f987b12de
LICENSE: BSD-3-Clause (observation historique fournie)
VERIFIED_AT: 2026-10-27
STATUS: HISTORICAL_VERIFIED
SOURCE: docs/PROMPT-MAITRE.md
FILES_READ: Prompt maître seulement dans cette session ; fichiers/concepts rapportés : CraftState ; StepState ; Simulator ; Calculations ; ISolver ; TrackConditions ; RecipeWindowUI.
TECHNICAL_FACTS: Calculs selon facteurs/diviseurs RecipeLevelTable. Séparer simulation et sélection d'action. Référence secondaire, pas un plugin supplémentaire.
LOCAL_COMPATIBILITY: UNKNOWN pour ces commits historiques ; le build du bootstrap est consigné séparément.
NOTES: Conserver uniquement les faits techniques. Pas de conclusion produit issue d'un autre projet.

## REF-GATHER

REF-ID: REF-GATHER
DOMAIN: GatherBuddy #8
NAME: GatherBuddyReborn
REPOSITORY: https://github.com/FFXIV-CombatReborn/GatherBuddyReborn
COMMIT_OR_VERSION: a204f2f45cb98302dbe938921255c3a6d617c775
LICENSE: Apache-2.0 (observation historique fournie)
VERIFIED_AT: 2026-10-27
STATUS: HISTORICAL_VERIFIED
SOURCE: docs/PROMPT-MAITRE.md
FILES_READ: Prompt maître seulement dans cette session ; fichiers/concepts rapportés : GameData ; Gatherable ; TimeInterval ; BitfieldUptime ; UptimeManager ; WeatherManager.
TECHNICAL_FACTS: Feuilles Item, GatheringItem, GatheringItemPoint, GatheringPoint, GatheringPointBase, Aetheryte, TerritoryType, Weather, WeatherRate, FishingSpot. MIN/BTN, niveau, étoiles, lieu. Distinguer Item/Gathering/GatheringPoint IDs et Always/Never/Invalid. Existence statique ne prouve pas les prérequis personnage.
LOCAL_COMPATIBILITY: UNKNOWN pour ces commits historiques ; le build du bootstrap est consigné séparément.
NOTES: Conserver uniquement les faits techniques. Pas de conclusion produit issue d'un autre projet.

## REF-SORT

REF-ID: REF-SORT
DOMAIN: SortaKinda #16
NAME: SortaKinda
REPOSITORY: https://github.com/MidoriKami/SortaKinda
COMMIT_OR_VERSION: 95a1bf9161f4bc595c21094eeaae9fda556f4b4b
LICENSE: AGPL v3+ (observation historique fournie)
VERIFIED_AT: 2026-10-27
STATUS: HISTORICAL_VERIFIED
SOURCE: docs/PROMPT-MAITRE.md
FILES_READ: Prompt maître seulement dans cette session ; fichiers/concepts rapportés : Règles ; slot sets ; configuration ; InventoryRenderer ; preview.
TECHNICAL_FACTS: Filtrage, ordre, slot sets, configuration globale/personnage, aperçu. Ne pas coupler sauvegarde et action de tri native. Étudier le comportement actuel lors de l'intégration.
LOCAL_COMPATIBILITY: UNKNOWN pour ces commits historiques ; le build du bootstrap est consigné séparément.
NOTES: Conserver uniquement les faits techniques. Pas de conclusion produit issue d'un autre projet.

## REF-INVENTORY

REF-ID: REF-INVENTORY
DOMAIN: Inventaire secondaire
NAME: InventoryTools
REPOSITORY: https://github.com/Critical-Impact/InventoryTools
COMMIT_OR_VERSION: 70a9f410d9a8ab97bef6bcf795415ea2d7c75097
LICENSE: GPL v3 (observation historique fournie)
VERIFIED_AT: 2026-10-27
STATUS: HISTORICAL_VERIFIED
SOURCE: docs/PROMPT-MAITRE.md
FILES_READ: Prompt maître seulement dans cette session ; fichiers/concepts rapportés : ItemSearchService ; ItemObtainabilityService ; CraftListTrackingService ; ListFilterService.
TECHNICAL_FACTS: Portée propriétaire/servant/conteneur/NQ-HQ. Absence dans snapshot incomplet ne signifie pas quantité zéro. Service d'inventaire commun.
LOCAL_COMPATIBILITY: UNKNOWN pour ces commits historiques ; le build du bootstrap est consigné séparément.
NOTES: Conserver uniquement les faits techniques. Pas de conclusion produit issue d'un autre projet.

## REF-SHINIES

REF-ID: REF-SHINIES
DOMAIN: Collections secondaire
NAME: XIV-Shinies
REPOSITORY: https://github.com/XIV-Shinies/xiv-shinies-plugin
COMMIT_OR_VERSION: e6f4341200f11db6d1bc827eee7fa16ad7aec55a
LICENSE: MIT (observation historique fournie)
VERIFIED_AT: 2026-10-27
STATUS: HISTORICAL_VERIFIED
SOURCE: docs/PROMPT-MAITRE.md
FILES_READ: Prompt maître seulement dans cette session ; fichiers/concepts rapportés : CollectorRegistry ; CollectResult ; CollectorRunner ; ExcelUnlockCollector ; GameThread ; QuestSequenceCollector ; CollectionStatusMemory.
TECHNICAL_FACTS: Collectors par domaine, raisons de skip, couverture explicite, erreurs isolées et thread approprié. Vide ne signifie pas complet.
LOCAL_COMPATIBILITY: UNKNOWN pour ces commits historiques ; le build du bootstrap est consigné séparément.
NOTES: Conserver uniquement les faits techniques. Pas de conclusion produit issue d'un autre projet.

## REF-TOMESTONE

REF-ID: REF-TOMESTONE
DOMAIN: Collections secondaire
NAME: Tomestone
REPOSITORY: https://github.com/TomestoneGG/Dalamud.Tomestone
COMMIT_OR_VERSION: d9e69687d4453899d8d419ab3964383afa6e58a5
LICENSE: AGPL v3 (observation historique fournie)
VERIFIED_AT: 2026-10-27
STATUS: HISTORICAL_VERIFIED
SOURCE: docs/PROMPT-MAITRE.md
FILES_READ: Prompt maître seulement dans cette session ; fichiers/concepts rapportés : BuddyEquip ; Achievement ; Companion ; Mount ; Orchestrion ; TripleTriadCard ; CharaMakeCustomize ; Item ; AozAction.
TECHNICAL_FACTS: Domaines candidats de collection. Candidat de collection ne prouve jamais la possession.
LOCAL_COMPATIBILITY: UNKNOWN pour ces commits historiques ; le build du bootstrap est consigné séparément.
NOTES: Conserver uniquement les faits techniques. Pas de conclusion produit issue d'un autre projet.

## REF-QUEST

REF-ID: REF-QUEST
DOMAIN: Quêtes secondaire
NAME: ffxiv-todo
REPOSITORY: https://github.com/datamachine/ffxiv-todo
COMMIT_OR_VERSION: ef5f5bab3b0b2c601a14d6c00d2088f1a40f1894
LICENSE: MIT (observation historique fournie)
VERIFIED_AT: 2026-10-27
STATUS: HISTORICAL_VERIFIED
SOURCE: docs/PROMPT-MAITRE.md
FILES_READ: Prompt maître seulement dans cette session ; fichiers/concepts rapportés : Catalogue ; unlock resolver ; PreviousQuest ; overrides.
TECHNICAL_FACTS: Préserver Unknown. Prérequis ALL/ANY et AND/OR à distinguer selon preuve ; ne pas simplifier arbitrairement.
LOCAL_COMPATIBILITY: UNKNOWN pour ces commits historiques ; le build du bootstrap est consigné séparément.
NOTES: Conserver uniquement les faits techniques. Pas de conclusion produit issue d'un autre projet.

## REF-SNAPSHOT

REF-ID: REF-SNAPSHOT
DOMAIN: Snapshots secondaire
NAME: Tsukimichi
REPOSITORY: https://github.com/xenofei/Tsukimichi
COMMIT_OR_VERSION: a82116abee83a0fbf0356f3eaa29d5bb9fd800c1
LICENSE: MIT (observation historique fournie)
VERIFIED_AT: 2026-10-27
STATUS: HISTORICAL_VERIFIED
SOURCE: docs/PROMPT-MAITRE.md
FILES_READ: Prompt maître seulement dans cette session ; fichiers/concepts rapportés : GameStateReader ; SnapshotService ; CharacterSnapshot ; QuestRecord ; QuestQuery ; SnapshotDiff ; DailyOfferBook ; GameResets ; JsonSnapshotStore.
TECHNICAL_FACTS: Toute donnée dynamique importante doit exprimer fraîcheur et portée ; séparer observation, acquisition réseau, calcul et mise à jour.
LOCAL_COMPATIBILITY: UNKNOWN pour ces commits historiques ; le build du bootstrap est consigné séparément.
NOTES: Conserver uniquement les faits techniques. Pas de conclusion produit issue d'un autre projet.

## REF-SCOPE

REF-ID: REF-SCOPE
DOMAIN: Périmètre
NAME: Liste autoritaire des 17 plugins
REPOSITORY: N/A — prompt utilisateur
COMMIT_OR_VERSION: SHA256 76B22632FEDCCA6D127FBDFE848AC87C9BC75663D0C36B238F985B23F2B38B9C
LICENSE: N/A — instructions utilisateur ; aucune licence de redistribution supposée
VERIFIED_AT: 2026-10-27
STATUS: LOCAL_VERIFIED
SOURCE: Deux pièces jointes utilisateur identiques, copie docs/PROMPT-MAITRE.md
FILES_READ: Prompt maître complet ; empreintes des deux fichiers vérifiées
TECHNICAL_FACTS: 17 plugins prioritaires ; CORE-000 limité au bootstrap ; contexte et checkpoints persistants.
LOCAL_COMPATIBILITY: Appliqué à ROADMAP.md ; tous les plugins restent NOT_STARTED après le socle.
NOTES: Sources actuelles des autres plugins : NEEDS_STUDY lors de leur GOAL, sans étude globale initiale.

## REF-LOCAL-001

REF-ID: REF-LOCAL-001
DOMAIN: Toolchain et bootstrap
NAME: Environnement local compilé
REPOSITORY: N/A — assemblies installées
COMMIT_OR_VERSION: Dalamud 15.0.3.9 ; commit 30509c3b4fd00edd9a3d65b7bbf16433d84be03b ; SDK Dalamud 15.0.0 ; .NET SDK 10.0.403 / runtime 10.0.14
LICENSE: Licences de l'installation dans Hooks/15.0.3.9/licenses.txt ; non réauditées
VERIFIED_AT: 2026-10-27 Europe/Brussels
STATUS: LOCAL_VERIFIED
SOURCE: dotnet --info ; cache NuGet ; Hooks/dev et Hooks/15.0.3.9 ; build Release et tests
FILES_READ: Sdk/Sdk.props, Sdk/Sdk.targets, Sdk/SdkPackageVersions.props ; Dalamud.xml (sections interfaces/commande/UI) ; Dalamud.runtimeconfig.json ; version.json du dossier stable ; commit_hash.txt dev/stable ; cibles DalamudPackager
TECHNICAL_FACTS: SDK Dalamud cible net10.0-windows/C#14/x64, résout Hooks/dev par défaut et autorise DALAMUD_HOME. .NET du PATH est 9.0.302 ; SDK 10.0.403 disponible dans C:/ia-code/.tools/dotnet10. Stable et dev rapportent le même commit. version.json stable rapporte jeu 2026.10.16.0000.0000 et runtime 10.0.14. Le plugin compile avec injection constructeur, IDalamudPlugin, AddHandler, UiBuilder et WindowSystem.
LOCAL_COMPATIBILITY: COMPILED Release sans avertissement ni erreur ; 5/5 tests managés. Aucun test d'exécution Dalamud/FFXIV.
NOTES: Aucune hypothèse de compatibilité d'offsets, d'inventaire ou d'unlocks. Ne pas recopier d'assemblies hôte dans le paquet.

## REF-DOTNET-DOCS

REF-ID: REF-DOTNET-DOCS
DOMAIN: Outillage
NAME: Documentation Microsoft installation Windows
REPOSITORY: https://learn.microsoft.com/en-us/dotnet/core/install/windows
COMMIT_OR_VERSION: Page consultée le 2026-10-27
LICENSE: Documentation Microsoft ; pas de code repris
VERIFIED_AT: 2026-10-27
STATUS: CURRENT_VERIFIED
SOURCE: Recherche web ciblée pendant la localisation du SDK
FILES_READ: Section installation Windows (résultat de recherche)
TECHNICAL_FACTS: Les SDK peuvent être installés ou extraits dans un dossier explicite.
LOCAL_COMPATIBILITY: Installation devenue inutile : SDK existant trouvé localement.
NOTES: La preuve locale, et non la version citée par la page, détermine global.json.

## REF-INV-MODEL

REF-ID: REF-INV-MODEL
DOMAIN: Fondation d'inventaire partagée
NAME: Sémantique du snapshot managé CORE-001
REPOSITORY: N/A — sources originales locales Tensho--Assistant
COMMIT_OR_VERSION: CORE-001
LICENSE: Code original local ; aucune source externe copiée
VERIFIED_AT: 2026-10-27 Europe/Brussels
STATUS: LOCAL_VERIFIED
SOURCE: Sources managées et Verify.ps1 exécuté avec succès
FILES_READ: src/TenshoAssistant/Inventory/InventorySnapshot.cs ; InventoryService.cs ; tests/TenshoAssistant.Tests/InventoryTests.cs
TECHNICAL_FACTS: Snapshots figés, types d'identifiants distincts, requêtes à portée explicite, borne minimale et exactitude nullable, couverture par conteneur, publication atomique du dernier lot et invalidation totale. Huit tests inventaire passent, 13/13 avec le socle.
LOCAL_COMPATIBILITY: Compilation Release .NET 10.0.403 et SDK Dalamud 15.0.0 ; aucune lecture native ni validation en jeu.
NOTES: Vérification du code original, pas de nouvelle validation des références historiques. Les garanties de lecture/complétude de IGameInventory restent à étudier dans INV-001.

## REF-INV-API

REF-ID: REF-INV-API
DOMAIN: Acquisition des sacs et lifecycle
NAME: Contrat public local IGameInventory / identité / framework
REPOSITORY: N/A — assemblies installées ; dépôt associé https://github.com/goatcorp/Dalamud
COMMIT_OR_VERSION: Hooks/dev, commit 30509c3b4fd00edd9a3d65b7bbf16433d84be03b (installation consignée REF-LOCAL-001)
LICENSE: Assemblies de l'installation existante ; aucun code de Dalamud copié
VERIFIED_AT: 2026-10-27 Europe/Brussels
STATUS: LOCAL_VERIFIED
SOURCE: Dalamud.xml installé ; inspection de métadonnées via tools/ApiProbe ; compilation du nouvel adaptateur
FILES_READ: Dalamud.xml sections IGameInventory, IPlayerState ; métadonnées Dalamud.dll : GameInventoryType, GameInventoryItem, IGameInventory et InventoryChangelogDelegate, IFramework et OnUpdateDelegate, IClientState et LogoutDelegate ; sources locales de l'adaptateur et du coordinateur
TECHNICAL_FACTS: GetInventoryItems(GameInventoryType) retourne ReadOnlySpan<GameInventoryItem>. Inventory1–4 valent 0–3. Les slots exposent IsEmpty, ContainerType, BaseItemId, IsHq et Quantity (Int32). InventoryChanged reçoit IReadOnlyCollection<InventoryEventArgs>. Update reçoit IFramework ; Logout reçoit deux Int32. IPlayerState expose IsLoaded et ContentId ; IsLoaded peut être vrai sans objet LocalPlayer. Aucun indicateur public de complétude/chargement de conteneur dans IGameInventory inspecté.
LOCAL_COMPATIBILITY: Adaptateur compilé avec injection des services ; coordinateur managé testé, 20/20 tests au total. Runtime inconnu ; aucun Complete émis. Le contrat public seul ne justifie pas une preuve d'absence à partir d'un span vide.
NOTES: XML et métadonnées ne prouvent pas le comportement live. Span vide classé Unknown, non vide Partial. Les événements ne sont utilisés que pour invalider ; les données d'événement ne sont pas conservées. La source historique reste inchangée.

## REF-INV-LOAD

REF-ID: REF-INV-LOAD
DOMAIN: Chargement des sacs et preuve de complétude
NAME: InventoryManager / InventoryContainer locaux
REPOSITORY: N/A — assembly installée FFXIVClientStructs.dll
COMMIT_OR_VERSION: SHA256 F5A2C68CCECD3E199BDA572050E98902B2E7594066C95DC7826C2D4297CD0564
LICENSE: Assembly de l'installation existante ; aucun code externe copié
VERIFIED_AT: 2026-10-27 Europe/Brussels
STATUS: LOCAL_VERIFIED
SOURCE: Métadonnées de Hooks/dev/FFXIVClientStructs.dll via ApiProbe ; compilation de l'adaptateur contre cette assembly
FILES_READ: Métadonnées de InventoryManager et InventoryContainer ; XML installé ; InventoryReadEvidence.cs et tests associés
TECHNICAL_FACTS: InventoryManager.Instance() retourne InventoryManager* ; GetInventoryContainer(InventoryType) retourne InventoryContainer*. InventoryContainer expose Items (InventoryItem*), Type, Size (Int32) et IsLoaded (Boolean). Ces membres typés permettent de croiser chargement, identité du conteneur, stabilité du buffer et nombre de slots lus. Aucun offset numérique nouveau n'est utilisé.
LOCAL_COMPATIBILITY: Build Release 0.1.1.0 réussi ; 25/25 tests managés et paquet vérifiés. Appels natifs ajoutés non encore validés en jeu.
NOTES: Complète REF-INV-API, qui reste correct sur l'absence d'indicateur dans IGameInventory seul. La sémantique native est celle des membres installés ; sa confirmation live reste RUNTIME-001.

PREVIOUS: L'adaptateur 0.1.0 émet uniquement Partial/Unknown faute de preuve de chargement via IGameInventory.
PREVIOUS_VERIFIED_AT: 2026-10-27
CURRENT: 0.1.1 émet Complete pour un sac uniquement si en-têtes chargés valides avant/après, buffer stable et slots lus égaux à Size ; sinon Partial/Unknown.
CURRENT_VERIFIED_AT: 2026-10-27 Europe/Brussels
EVIDENCE: Membres de l'assembly installée, code compilé et tests InventoryReadEvidenceTests.
DECISION: Utiliser cette preuve supplémentaire pour un total exact des quatre sacs ; aucun total global de tous les rangements.
REASON: Corriger le libellé toujours inconnu sans transformer un span vide en preuve de quantité zéro.

## REF-ITEM-API

REF-ID: REF-ITEM-API
DOMAIN: Catalogue Item partagé
NAME: Source Lumina Item et métadonnées de génération
REPOSITORY: N/A — assemblies Dalamud/Lumina/Lumina.Excel installées
COMMIT_OR_VERSION: Installation REF-LOCAL-001 ; schéma Lumina.Excel et versions repositories capturés dans chaque ItemCatalogMetadata lors du chargement
LICENSE: Assemblies existantes ; aucun code externe repris, catalogue construit depuis les données locales du jeu
VERIFIED_AT: 2026-10-27 Europe/Brussels
STATUS: LOCAL_VERIFIED
SOURCE: Métadonnées via tools/ApiProbe, documentation XML locale et compilation Release 0.1.4
FILES_READ: Item.RowId/Name/CanBeHq dans Lumina.Excel.dll ; Lumina.GameData.Repositories et Lumina.Data.Repository.Name/Version dans Lumina.dll ; XML IDataManager.GetExcelSheet et ExcelSheet.Count/GetRowAt/Language ; ReadOnlySeString.ExtractText
TECHNICAL_FACTS: GetRowAt utilise un index séquentiel distinct de RowId. Name est une ReadOnlySeString extraite immédiatement en string. La feuille expose sa langue ; les repositories exposent des versions copiables. Les définitions/index publiés ne contiennent ni feuille, ligne Lumina ni pointeur natif. La construction peut donc travailler uniquement sur les données managées copiées.
LOCAL_COMPATIBILITY: Plugin 0.1.4 compilé, 31/31 tests managés et paquet verts. Aucun chargement réel de cette nouvelle source dans le client n'a encore été observé.
NOTES: Le budget de copie framework est souple ; ni latence réelle ni compatibilité d'une future version du jeu ne sont revendiquées. La langue/génération du catalogue ne doit pas être confondue avec la possession d'un objet dans l'inventaire.

RUNTIME_EVIDENCE_AT: 2026-10-27 Europe/Brussels
RUNTIME_EVIDENCE: Capture utilisateur codex-clipboard-e454bd2e-7f41-4788-87bf-0ced362301f8.png et retour « tous est OK ». Catalogue chargé : 50 880 objets, French ; recherche sirop, sélection du résultat 12892 et diagnostic 0 NQ/156 HQ/total 156 visibles. Source réelle et rendu confirmés dans ce périmètre ; ne pas extrapoler aux performances ou scénarios d'erreur. Détails dans TESTING.md.

## REF-UI-ICONS

REF-ID: REF-UI-ICONS
DOMAIN: Interface / répertoire des outils
NAME: IconButton et FontAwesome natifs Dalamud
REPOSITORY: N/A — installation locale Dalamud, voir REF-LOCAL-001
COMMIT_OR_VERSION: Assembly installée utilisée par le build 0.2.1 ; commit Dalamud consigné dans REF-LOCAL-001
LICENSE: Ressources déjà fournies par l'hôte ; aucun asset externe copié ou redistribué
VERIFIED_AT: 2026-10-27 Europe/Brussels
STATUS: LOCAL_VERIFIED
SOURCE: Documentation XML Dalamud et métadonnées de FontAwesomeIcon via ApiProbe
FILES_READ: Dalamud.xml, ImGuiComponents.IconButton(string, FontAwesomeIcon, Vector2) ; champs utilisés de FontAwesomeIcon ; MainWindow.Tools.cs
TECHNICAL_FACTS: Un bouton icône peut être créé à partir d'un identifiant, d'un glyphe FontAwesome et d'une taille Vector2. Les 17 glyphes des modules futurs et BoxOpen existent localement. La police est gérée par l'hôte.
LOCAL_COMPATIBILITY: Compilation Release 0.2.1 sans avertissement ; 31/31 tests et paquet verts. Rendu et clics dans le client encore à valider.
NOTES: L'ouverture et le rendu d'une popup ImGui doivent utiliser le même niveau de pile ID ; le code ouvre la fiche hors de la portée de la table.

## REF-BANK-API

REF-ID: REF-BANK-API
DOMAIN: Inventaires servant/chocobo et import manuel
NAME: Contextes, identités et positions des menus d'inventaire
REPOSITORY: N/A — assemblies locales Dalamud et FFXIVClientStructs, installation REF-LOCAL-001
COMMIT_OR_VERSION: Assemblies installées contre lesquelles 0.3.0 compile ; FFXIVClientStructs SHA256 consigné dans REF-INV-LOAD
LICENSE: Assemblies existantes ; aucun code externe ou asset copié
VERIFIED_AT: 2026-10-27 Europe/Brussels
STATUS: LOCAL_VERIFIED
SOURCE: Métadonnées via ApiProbe, documentation XML locale et compilation du nouvel adaptateur
FILES_READ: RetainerManager et Retainer (RetainerId, NameString, IsReady), XML GetActiveRetainer/LastSelectedRetainerId ; IGameGui.GetAddonByName ; AtkUnitBasePtr.IsNull/IsReady/IsVisible/Position/ScaledWidth ; types AddonInventoryRetainer, AddonInventoryRetainerLarge, AddonInventoryBuddy ; groupes GameInventoryType déjà inspectés
TECHNICAL_FACTS: GetActiveRetainer retourne le servant référencé par LastSelectedRetainerId, pas une preuve autonome de menu ouvert. RetainerPage1–7 correspondent aux IDs 10000–10006 ; sacoches 4000/4001 et premium 4100/4101. Le wrapper d'addon fournit visibilité et coordonnées copiables. Le lecteur natif commun réutilise IsLoaded/type/taille/buffer stables avant de publier un groupe complet.
LOCAL_COMPATIBILITY: Build 0.3.0 réussi, 43/43 tests managés et paquet vérifiés. Banque/save/recherche managés testés ; menus, identités réelles et conteneurs servant/chocobo non encore validés dans le client.
NOTES: Les noms runtime InventoryRetainer/InventoryRetainerLarge/InventoryBuddy sont choisis à partir des types locaux ; InventoryBuddy2 est un candidat de repli. Cette correspondance et l'ancrage restent UNKNOWN côté observation runtime, à confirmer par BANK-001-RUNTIME. Aucun attribut de nom d'addon exploitable n'a été observé sur ces types lors du sondage. Aucun offset numérique ajouté, aucune requête serveur ou action de déplacement d'objet exécutée.

RUNTIME_EVIDENCE_AT: 2026-10-27 Europe/Brussels
RUNTIME_EVIDENCE: Capture 55b7452f-db39-4732-aca5-13ee28923f23 : v0.3.0, cache Sacoche chocobo affiché avec 26 HQ et date UTC, sacs avec 182 NQ, cumul recensé 208. Cela confirme la consultation d'un import chocobo dans la recherche, pas l'ancrage, les servants ou la conservation après reload. Détails dans TESTING.md.

## REF-ITEM-TEXTURES

REF-ID: REF-ITEM-TEXTURES
DOMAIN: Catalogue Item et icônes UI
NAME: Item.Icon / ITextureProvider / ISharedImmediateTexture
REPOSITORY: N/A — assemblies locales Lumina.Excel et Dalamud
COMMIT_OR_VERSION: Installation REF-LOCAL-001, API compilée en 0.4.0 ; catalogue garde les versions de données/schema dans ses métadonnées
LICENSE: Assets du jeu chargés par l'hôte existant ; aucun fichier d'image copié ou redistribué
VERIFIED_AT: 2026-10-27 Europe/Brussels
STATUS: LOCAL_VERIFIED
SOURCE: Métadonnées Item et interfaces textures, documentation XML locale, compilation et tests du catalogue
FILES_READ: Item.Icon ; GameIconLookup (IconId/ItemHq/HiRes), ITextureProvider.TryGetFromGameIcon, ISharedImmediateTexture.TryGetWrap, IDalamudTextureWrap.Handle/Size ; documentation des durées de vie et usage au thread UI
TECHNICAL_FACTS: L'icône de base est un identifiant distinct d'Item.RowId. Lookup demandé haute résolution, sans variante HQ imposée. TryGetWrap fournit un wrap valide pour la frame seulement, sans attente ; ne pas le conserver entre frames. Propriété de la ressource conservée par l'hôte. Le code transmet Handle à ImGui.Image et réserve la taille si la texture n'est pas encore disponible.
LOCAL_COMPATIBILITY: Release 0.4.0 compilée sans avertissement ; 55/55 tests et paquet verts. IconId est préservé par recherche/lookup dans les tests. Aucun rendu d'icône de cette version encore observé en jeu.
NOTES: Les fixtures de tests vérifient la transmission d'un numéro d'icône, pas l'existence ou l'apparence d'un asset. Aucune texture n'est chargée dans le worker du catalogue.

## REF-CRAFT-LOCAL-API

REF-ID: REF-CRAFT-LOCAL-API
DOMAIN: Catalogue de recettes
STATUS: LOCAL_VERIFIED / 2026-10-27 Europe/Brussels
SOURCE: ApiProbe sur les assemblies Dalamud/Lumina locales, puis compilation de l'adaptateur 0.5.0
TECHNICAL_FACTS: Recipe fournit ItemResult, Ingredient, AmountResult, AmountIngredient, CraftType et RecipeLevelTable. CraftType fournit Name ; RecipeLevelTable fournit ClassJobLevel. Les RowRef sont résolus par RowId via les feuilles correspondantes.
LIMITS: Les valeurs et IDs sont copiés en données managées ; aucune validation de l'apparence ou de la complétude du catalogue n'est revendiquée avant l'essai en jeu.

