using System.Numerics;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.Gathering;
using TenshoAssistant.Monsters;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private void DrawFishingSources(GatheringCatalog catalog)
    {
        if(catalog.Fishing.ForItem((uint)itemId).Count==0 || !ImGui.CollapsingHeader("Appâts & conditions · Garland Tools###FishingCommunity"))return;
        ImGui.TextWrapped("Consultation manuelle de données communautaires, distinctes du carnet du jeu. Seul l’identifiant public d’objet est envoyé. Cache et cadence partagés avec les sources sur monstres ; aucune action de pêche.");
        var state=monsterLoot.State;
        if(state.ItemId!=(uint)itemId)return;
        ImGui.BeginDisabled(state.Loading);
        try
        {
            if(ImGui.Button(state.Item is null ? "Consulter les lieux et conditions":"Actualiser les lieux et conditions"))_ = monsterLoot.RequestItemAsync(state.Item is not null);
        }
        finally{ImGui.EndDisabled();}
        if(state.Loading)ImGui.TextDisabled("Consultation en cours…");
        if(state.Error is { } error)ImGui.TextWrapped(error);
        if(state.Item is not { } document)return;
        ImGui.TextDisabled($"Garland Tools · consultation {document.FetchedAt:yyyy-MM-dd HH:mm:ss} UTC");
        var age=DateTimeOffset.UtcNow-document.FetchedAt;
        if(age<TimeSpan.Zero)ImGui.TextDisabled("Date de consultation future : fraîcheur inconnue.");
        else if(age>=MonsterLootService.FreshFor)ImGui.TextColored(Accent,"Données anciennes en cache ; actualisation manuelle disponible.");
        if(document.FishingError is not null){ImGui.TextWrapped("Données de pêche non interprétables ; les autres références d’objet restent disponibles.");return;}
        if(document.Fishing is not {SpotsKnown:true} fishing){ImGui.TextWrapped("Lieux et appâts non renseignés dans cette réponse ; aucune absence n’est déduite.");return;}
        if(fishing.Spots.Count==0)ImGui.TextWrapped("Aucun lieu listé par cette source. Le catalogue peut être incomplet.");
        for(var index=0;index<fishing.Spots.Count;index++)
        {
            var spot=fishing.Spots[index];ImGui.PushID(index);
            try
            {
                var native=spot.SpotId is { } id ? catalog.ForFishingSpot(id):null;
                var title=native is null ? "Lieu externe non relié au catalogue local":$"{native.Zone} · {native.Place}";
                if(!ImGui.CollapsingHeader($"{title} · variante {index+1}###FishingSource"))continue;
                if(spot.Conditions is { } conditions)
                {
                    ImGui.TextColored(Accent,"HORAIRES RENSEIGNÉS · ET");
                    if(conditions.Error is not null)ImGui.TextWrapped("Conditions non interprétables ; appâts conservés, horaires et météos inconnus.");
                    else
                    {
                        DrawGatheringTime(conditions.Timing);
                        DrawFishingWeatherNames("Météo requise",conditions.Weather,native?.TerritoryId);
                        DrawFishingWeatherNames("Météo précédente",conditions.PreviousWeather,native?.TerritoryId);
                    }
                    if(native is not null && ImGui.SmallButton("Prévisions de la zone"))OpenWeather(native.TerritoryId,native.Zone);
                    ImGui.TextWrapped("Horaire calculé seul ; météo, prises préalables, accès et autres conditions non vérifiés.");
                    ImGui.Separator();
                }
                ImGui.TextColored(Accent,"APPÂTS & PÊCHE AU VIF");
                if(spot.BaitChains is null)ImGui.TextDisabled("Appâts non renseignés pour ce lieu.");
                else if(spot.BaitChains.Count==0)ImGui.TextDisabled("Aucune chaîne listée ; cela ne signifie pas qu’aucun appât est nécessaire.");
                else for(var route=0;route<spot.BaitChains.Count;route++)
                {
                    ImGui.PushID(route);
                    try
                    {
                        if(spot.BaitChains.Count>1)ImGui.TextDisabled($"Possibilité {route+1}");
                        var chain=spot.BaitChains[route];
                        for(var step=0;step<chain.Count;step++)
                        {
                            var item=itemCatalog.State.Catalog?.Find(chain[step]);ImGui.PushID(step);
                            try
                            {
                                if(step>0)ImGui.TextDisabled("↓ pêche au vif");
                                DrawItemIcon(item,new Vector2(28));var clicked=ImGui.IsItemClicked();ImGui.SameLine();
                                ImGui.BeginDisabled(item is null);
                                try{clicked|=ImGui.SmallButton(item?.Name ?? "Objet non résolu dans le catalogue local");}
                                finally{ImGui.EndDisabled();}
                                if(clicked && item is not null)SelectItem(item.Id);
                            }
                            finally{ImGui.PopID();}
                        }
                    }
                    finally{ImGui.PopID();}
                }
                ImGui.Separator();
            }
            finally{ImGui.PopID();}
        }
        ImGui.TextWrapped("Chaînes dans l’ordre indiqué par la source, appât initial puis poissons intermédiaires éventuels. Conditions communautaires possiblement incomplètes ; aucune disponibilité actuelle garantie.");
    }

    private void DrawFishingWeatherNames(string title,IReadOnlyList<string>? names,uint? territory)
    {
        if(names is null)ImGui.TextDisabled($"{title} : non renseignée");
        else if(names.Count==0)ImGui.TextDisabled($"{title} : liste vide, aucune absence de restriction déduite");
        else
        {
            ImGui.TextDisabled(title+" · alternatives");
            foreach(var name in names)
            {
                var matched=territory is { } id ? weather.State.Catalog?.WeatherBySourceName(name,id):null;
                if(matched is null)ImGui.TextWrapped($"{name} · correspondance locale inconnue");
                else
                {
                    DrawItemIcon(new TenshoAssistant.Items.ItemDefinition(0,matched.Name,false,matched.Icon),new Vector2(24));
                    if(ImGui.IsItemHovered())ImGui.SetTooltip($"Source : {name} · météo du jeu {matched.Id}. Correspondance de nom, pas une observation du ciel.");
                    ImGui.SameLine();ImGui.TextUnformatted(matched.Name);
                }
            }
        }
    }
}
