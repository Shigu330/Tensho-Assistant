using System.Numerics;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.Items;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private bool focusUsesTab;
    private void DrawItemUses()
    {
        Heading("Usages de l’objet","Recettes, mandats et références dans les catalogues du jeu");
        if(itemId<=0){ImGui.TextWrapped("Sélectionnez un objet dans Recherche, Banque ou une recette pour consulter ses usages.");return;}
        DrawRecipeResultHeader();var id=(uint)itemId;
        if(recipeCatalog.State.Catalog is { } recipes)
        {
            var count=recipes.ForIngredient(id).Count;
            if(ImGui.SmallButton($"Voir les recettes utilisant cet objet ({count})"))focusCraftTab=true;
        }
        else ImGui.TextDisabled("Catalogue de recettes en préparation…");
        var state=itemUses.State;
        if(state.Catalog is not { } catalog)
        {
            ImGui.TextWrapped(state.Error is null ? $"Lecture du catalogue des autres usages… {state.Copied}/{state.Total}":"Catalogue des autres usages indisponible ; consultez Diagnostics.");return;
        }
        ImGui.Separator();
        if(catalog.IsSupplyCandidate(id))
        {ImGui.TextColored(Accent,"Livraisons de grande compagnie");ImGui.TextWrapped("Cet objet figure parmi les livraisons potentielles du catalogue. La demande de votre compagnie aujourd’hui n’a pas été observée.");}
        if(catalog.IsAquariumFish(id))
        {ImGui.TextColored(Accent,"Aquarium");ImGui.TextWrapped("Ce poisson figure dans le catalogue des poissons d’aquarium. Le bassin et les conditions de placement restent à vérifier dans le jeu.");}
        if(!catalog.IsSupplyCandidate(id) && !catalog.IsAquariumFish(id))ImGui.TextDisabled("Aucune référence dans les catalogues de livraisons GC et de poissons d’aquarium.");
        var leves=catalog.LevesFor(id);ImGui.Spacing();ImGui.TextColored(Accent,$"Mandats d’artisanat ({leves.Count})");
        ImGui.TextWrapped("Remises renseignées dans les données du jeu. Acceptation, déblocages, droits disponibles et bonus HQ ne sont pas déduits.");
        if(leves.Count==0)ImGui.TextDisabled("Aucun mandat indexé pour cet objet.");
        foreach(var leve in leves)
        {
            ImGui.PushID((int)leve.RowId);
            try
            {
                DrawItemIcon(new ItemDefinition(0,leve.Name,false,leve.IconId),new Vector2(24));ImGui.SameLine();
                var job=string.IsNullOrWhiteSpace(leve.Job) ? "Métier non renseigné":leve.Job;
                var level=leve.Level>0 ? $"niveau {leve.Level}":"Niveau non renseigné";
                if(!ImGui.CollapsingHeader($"{leve.Name} · {job} · {level}"))continue;
                if(!string.IsNullOrWhiteSpace(leve.Place))ImGui.TextWrapped($"Lieu d’émission renseigné : {leve.Place}");
                ImGui.TextDisabled("Objets et quantités renseignés pour ce mandat");
                for(var index=0;index<leve.Requests.Count;index++)
                {
                    var request=leve.Requests[index];var item=itemCatalog.State.Catalog?.Find(request.ItemId);ImGui.PushID(index);
                    try
                    {
                        DrawItemIcon(item,new Vector2(28));var click=ImGui.IsItemClicked();ImGui.SameLine();
                        click|=ImGui.SmallButton(item?.Name ?? $"Objet {request.ItemId}");
                        ImGui.SameLine();ImGui.TextUnformatted(request.Quantity is { } quantity ? $"× {quantity}":"Quantité non renseignée");
                        if(click){SelectItem(request.ItemId);focusUsesTab=true;}
                    }
                    finally{ImGui.PopID();}
                }
            }
            finally{ImGui.PopID();}
        }
        if(catalog.UnresolvedLeveRows>0)ImGui.TextWrapped($"Catalogue partiel : {catalog.UnresolvedLeveRows} référence(s) de mandat non résolue(s).");
        ImGui.TextDisabled($"Données du jeu · {catalog.Language} · autres usages possibles hors de ces catalogues");
    }
}
