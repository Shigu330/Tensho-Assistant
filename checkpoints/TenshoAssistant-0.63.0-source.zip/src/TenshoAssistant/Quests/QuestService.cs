namespace TenshoAssistant.Quests;

public enum QuestProgress { Unconfirmed, Active, Complete }
public sealed record QuestEntry(uint Id, string Name, string Category, uint Icon, QuestProgress Progress, byte? Sequence)
{
    public IReadOnlyList<uint> PreviousQuestIds { get; init; } = Array.Empty<uint>();
    public byte PreviousQuestJoin { get; init; }
    // Unknown7 in the installed schema: retained raw; no step-satisfaction inference.
    public byte PreviousQuestStep { get; init; }
    public bool IsRepeatable { get; init; }
    public ushort Level { get; init; }
    public ushort AdditionalLevel { get; init; }
    public string Zone { get; init; } = "";
    public uint IssuerId { get; init; }
    public uint IssuerMapId { get; init; }
    public uint IssuerTerritoryId { get; init; }
}
public sealed record QuestState(ulong CharacterId, DateTimeOffset? ObservedAt, IReadOnlyList<QuestEntry> Entries, bool Loading, string? Error);

/// <summary>One immutable, direct-link index per published observation. No recursive traversal.</summary>
public sealed class QuestLinks
{
    private readonly IReadOnlyDictionary<uint, QuestEntry> entries;
    private readonly IReadOnlyDictionary<uint, IReadOnlyList<QuestEntry>> next;
    public QuestLinks(IEnumerable<QuestEntry> source)
    {
        var copied = source.Select(entry => entry with
        {
            PreviousQuestIds = Array.AsReadOnly(entry.PreviousQuestIds.Where(id => id != 0).Distinct().ToArray())
        }).ToArray();
        entries = copied.ToDictionary(entry => entry.Id);
        next = copied.SelectMany(entry => entry.PreviousQuestIds.Select(id => (Id: id, Entry: entry)))
            .GroupBy(link => link.Id).ToDictionary(group => group.Key,
                group => (IReadOnlyList<QuestEntry>)Array.AsReadOnly(group.Select(link => link.Entry)
                    .OrderBy(entry => entry.Name, StringComparer.OrdinalIgnoreCase).ThenBy(entry => entry.Id).ToArray()));
    }
    public QuestEntry? Find(uint id) => entries.GetValueOrDefault(id);
    public IReadOnlyList<QuestEntry> Following(uint id) => next.GetValueOrDefault(id) ?? Array.Empty<QuestEntry>();
    public static string JoinLabel(byte mode) => mode switch
    { 1 => "Toutes les quêtes liées", 2 => "Au moins une des quêtes liées", _ => $"Condition non interprétée (mode {mode})" };
    public bool CompletionEvidence(QuestEntry entry) => entry.PreviousQuestIds.Count > 0 && entry.PreviousQuestJoin switch
    {
        1 => entry.PreviousQuestIds.All(id => Find(id)?.Progress == QuestProgress.Complete),
        2 => entry.PreviousQuestIds.Any(id => Find(id)?.Progress == QuestProgress.Complete),
        _ => false
    };
}

public sealed class QuestService
{
    private QuestState state = new(0, null, Array.Empty<QuestEntry>(), true, null);
    private int refresh;
    public QuestState State => Volatile.Read(ref state);
    public void RequestRefresh() => Interlocked.Exchange(ref refresh, 1);
    internal bool ConsumeRefresh() => Interlocked.Exchange(ref refresh, 0) == 1;
    internal void Publish(ulong character, IEnumerable<QuestEntry> entries) => Interlocked.Exchange(ref state,
        new(character, character == 0 ? null : DateTimeOffset.UtcNow,
            Array.AsReadOnly(entries.Select(entry => entry with
                {
                    Progress = character == 0 ? QuestProgress.Unconfirmed : entry.Progress,
                    Sequence = character == 0 ? null : entry.Sequence,
                    PreviousQuestIds = Array.AsReadOnly(entry.PreviousQuestIds.Where(id => id != 0).Distinct().ToArray())
                })
                .OrderBy(entry => entry.Name, StringComparer.OrdinalIgnoreCase).ThenBy(entry => entry.Id).ToArray()), false, null));
    internal void Invalidate() => Interlocked.Exchange(ref state,
        new(0, null, Array.AsReadOnly(State.Entries.Select(entry => entry with { Progress = QuestProgress.Unconfirmed, Sequence = null }).ToArray()), true, null));
    internal void Fail(Exception error) { Invalidate(); Interlocked.Exchange(ref state, State with { Loading = false, Error = error.Message }); }
    internal void Clear() => Interlocked.Exchange(ref state, new(0, null, Array.Empty<QuestEntry>(), false, null));
}
