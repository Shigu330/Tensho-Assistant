using System.Diagnostics;
using Dalamud.Plugin.Services;
using Lumina.Excel;
using Lumina.Excel.Sheets;

namespace TenshoAssistant.Items;

/// <summary>Copies bounded batches on framework, indexes only managed data on a cancellable worker.</summary>
internal sealed class ItemCatalogLoader : IDisposable
{
    private readonly object gate = new();
    private readonly ItemCatalogService service;
    private readonly IDataManager data;
    private readonly IFramework framework;
    private readonly IPluginLog log;
    private readonly CancellationTokenSource cancellation = new();
    private readonly List<ItemDefinition> rows = [];
    private ExcelSheet<Item>? sheet;
    private ExcelSheet<Item>? englishItems;
    private bool englishUnavailable;
    private ItemCatalogMetadata? metadata;
    private Task<(ItemCatalog? Catalog, Exception? Error)>? build;
    private int position;
    private bool stopped;
    private bool disposed;

    public ItemCatalogLoader(ItemCatalogService service, IDataManager data, IFramework framework, IPluginLog log)
    {
        this.service = service;
        this.data = data;
        this.framework = framework;
        this.log = log;
        try { framework.Update += OnUpdate; }
        catch { cancellation.Dispose(); throw; }
    }

    private void OnUpdate(IFramework _)
    {
        if (!framework.IsInFrameworkUpdateThread || framework.IsFrameworkUnloading) return;
        lock (gate)
        {
            if (stopped) return;
            try
            {
                if (build is not null)
                {
                    if (!build.IsCompleted) return;
                    var result = build.GetAwaiter().GetResult(); // Completion already established; never waits.
                    if (result.Error is not null) throw result.Error;
                    service.Publish(result.Catalog!);
                    Stop();
                    return;
                }

                if (sheet is null)
                {
                    sheet = data.GetExcelSheet<Item>();
                    var versions = string.Join(";", data.GameData.Repositories.Values.OrderBy(r => r.Name)
                        .Select(r => $"{r.Name}={r.Version}"));
                    metadata = new ItemCatalogMetadata("Lumina.Excel/Item", sheet.Language.ToString(),
                        $"{versions};schema={typeof(Item).Assembly.GetName().Version}", 1);
                }

                var started = Stopwatch.GetTimestamp();
                var batchEnd = Math.Min(position + 128, sheet.Count);
                while (position < batchEnd)
                {
                    var row = sheet.GetRowAt(position++);
                    var name = row.Name.ExtractText();
                    if (row.RowId != 0 && !string.IsNullOrWhiteSpace(name))
                    {
                        var uiCategory = row.ItemUICategory.Value;
                        var slots=row.EquipSlotCategory.Value;
                        CraftToolDefinition? tool=null;
                        if(slots.MainHand>0 && row.ClassJobUse.RowId is >=8 and <=15)
                        {
                            string? description=null;
                            if(!englishUnavailable)
                            {
                                try
                                {
                                    englishItems ??= data.GetExcelSheet<Item>(Dalamud.Game.ClientLanguage.English);
                                    if(englishItems.TryGetRow(row.RowId,out var english))description=english.Description.ExtractText();
                                }
                                catch(Exception error){englishUnavailable=true;englishItems=null;log.Warning(error,"English tool metadata unavailable; Good-condition bonus remains unknown.");}
                            }
                            tool=new(row.ClassJobUse.RowId,CraftToolBonuses.FromDeclaredMetadata(description,row.ItemSpecialBonus.RowId,row.ItemSpecialBonusParam));
                        }
                        var equipment=row.EquipSlotCategory.RowId==0 ? EquipmentSlots.None : EquipmentSlotMap.FromNative(
                            slots.Head,slots.Body,slots.Gloves,slots.Legs,slots.Feet,slots.Ears,slots.Neck,slots.Wrists,slots.FingerL,slots.FingerR,slots.MainHand,slots.OffHand,slots.SoulCrystal);
                        rows.Add(new ItemDefinition(row.RowId, name, row.CanBeHq, row.Icon,
                            uiCategory.RowId, uiCategory.Name.ExtractText(), !row.IsUntradable && row.ItemSearchCategory.RowId != 0,
                            row.AdditionalData.RowType == typeof(TripleTriadCard) ? row.AdditionalData.RowId : 0,equipment,tool));
                    }
                    if (Stopwatch.GetElapsedTime(started) >= TimeSpan.FromMilliseconds(2)) break;
                }
                service.Progress(position, sheet.Count);
                if (position != sheet.Count) return;

                var managed = rows.ToArray();
                var context = metadata!;
                var token = cancellation.Token;
                sheet = null;englishItems=null;
                rows.Clear();
                build = Task.Run<(ItemCatalog? Catalog, Exception? Error)>(() =>
                {
                    try { return (ItemCatalog.Build(managed, context, token), null); }
                    catch (Exception error) { return (null, error); }
                });
            }
            catch (Exception error)
            {
                log.Error(error, "Tensho item catalog could not be built.");
                service.Fail();
                Stop();
            }
        }
    }

    private void Stop()
    {
        stopped = true;
        framework.Update -= OnUpdate;
        sheet = null;
        englishItems=null;
        rows.Clear();
    }

    public void Dispose()
    {
        lock (gate)
        {
            if (disposed) return;
            disposed = true;
            cancellation.Cancel();
            Stop();
            service.Clear();
            // No worker can publish: publication occurs only through the now-removed Update callback.
            cancellation.Dispose();
        }
    }
}
