namespace TenshoAssistant.Gathering;

public sealed record GatheringOpening(DateTimeOffset StartsAt,DateTimeOffset EndsAt,bool Current);
public sealed record GatheringTimeline(GatheringScheduleKind Kind,int EtMinute,DateTimeOffset CalculatedAt,IReadOnlyList<GatheringOpening> Openings);
public static class GatheringTime
{
    private const long DayTicks=4200L*TimeSpan.TicksPerSecond;
    public static int MinuteOfDay(DateTimeOffset date)
    {
        var ticks=date.UtcTicks-DateTimeOffset.UnixEpoch.UtcTicks;
        if(ticks<0)throw new ArgumentOutOfRangeException(nameof(date));
        return (int)(ticks%DayTicks*12/(35L*TimeSpan.TicksPerSecond));
    }
    public static GatheringTimeline Next(GatheringSchedule schedule,DateTimeOffset date,int count=3)
    {
        ArgumentNullException.ThrowIfNull(schedule);
        if(count is <1 or >12 || date<DateTimeOffset.UnixEpoch || date>DateTimeOffset.MaxValue.AddSeconds(-(count+3)*4200))throw new ArgumentOutOfRangeException(nameof(date));
        var minute=MinuteOfDay(date);
        if(schedule.Kind!=GatheringScheduleKind.Limited)return new(schedule.Kind,minute,date.ToUniversalTime(),Array.AsReadOnly(Array.Empty<GatheringOpening>()));
        var day=(date.UtcTicks-DateTimeOffset.UnixEpoch.UtcTicks)/DayTicks*DayTicks;
        var candidates=new List<(long Start,long End)>();
        for(var offset=-1;offset<=count+1;offset++)
        foreach(var window in schedule.Windows)
        {
            // First representable tick at the exact rational ET minute boundary (35/12 real seconds).
            long Boundary(int value)=>day+offset*DayTicks+(value*35L*TimeSpan.TicksPerSecond+11)/12;
            candidates.Add((Boundary(window.StartMinute),Boundary(window.EndMinute)));
        }
        var merged=new List<(long Start,long End)>();
        foreach(var candidate in candidates.OrderBy(value=>value.Start).ThenBy(value=>value.End))
        {
            if(merged.Count>0 && candidate.Start<=merged[^1].End)merged[^1]=(merged[^1].Start,Math.Max(merged[^1].End,candidate.End));
            else merged.Add(candidate);
        }
        var now=date.UtcTicks-DateTimeOffset.UnixEpoch.UtcTicks;
        var result=merged.Where(window=>window.End>now).Take(count).Select(window=>new GatheringOpening(DateTimeOffset.UnixEpoch.AddTicks(window.Start),DateTimeOffset.UnixEpoch.AddTicks(window.End),window.Start<=now)).ToArray();
        return new(schedule.Kind,minute,date.ToUniversalTime(),Array.AsReadOnly(result));
    }
}
