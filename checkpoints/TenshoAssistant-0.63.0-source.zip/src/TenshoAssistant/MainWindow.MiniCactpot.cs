using System.Numerics;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.MiniGames;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private readonly int[] cactpotBoard=new int[9];
    private readonly MiniCactpotSolveSession cactpotSolve=new();
    private int cactpotGeneration;
    private ulong cactpotObservedOwner;
    private bool windowDisposed;
    private void InvalidateCactpot()
    {cactpotGeneration++;cactpotSolve.Cancel();}
    private void SyncCactpot(MiniCactpotObservationState observation)
    {
        if(!observation.Enabled)return;
        if(!observation.CanSolve(DateTimeOffset.UtcNow))
        {
            if(cactpotObservedOwner!=0 || cactpotBoard.Any(value=>value!=0))
            {Array.Clear(cactpotBoard);cactpotObservedOwner=0;InvalidateCactpot();}
            return;
        }
        if(cactpotObservedOwner==observation.Owner && cactpotBoard.SequenceEqual(observation.Frame!.Board))return;
        InvalidateCactpot();cactpotObservedOwner=observation.Owner;
        for(var index=0;index<9;index++)cactpotBoard[index]=observation.Frame!.Board[index];
        _=cactpotSolve.StartAsync(cactpotBoard,cactpotObservedOwner,cactpotGeneration);
    }
    private void DrawMiniCactpot()
    {
        Heading("Mini Cactpot","Ticket manuel ou observé · conseils de révélation et de ligne");
        if(windowDisposed)return;
        var observation=cactpotObservation.State;var enabled=observation.Enabled;
        if(ImGui.Checkbox("Observer le ticket du jeu et actualiser les conseils · expérimental",ref enabled))
        {
            cactpotObservation.SetEnabled(enabled);observation=cactpotObservation.State;
            Array.Clear(cactpotBoard);cactpotObservedOwner=0;InvalidateCactpot();
        }
        SyncCactpot(observation);
        cactpotSolve.ValidateContext(enabled ? cactpotObservedOwner:0,cactpotGeneration);
        if(enabled)
        {
            ImGui.TextWrapped(observation.Status switch
            {
                MiniCactpotObservationStatus.Offline=>"Connectez un personnage.",
                MiniCactpotObservationStatus.AddonAbsent=>"Ouvrez un ticket Mini Cactpot dans le jeu.",
                MiniCactpotObservationStatus.NotReady=>"Fenêtre masquée ou en transition.",
                MiniCactpotObservationStatus.Error=>"Lecture indisponible.",
                MiniCactpotObservationStatus.Observed when observation.Frame is {Revealed:0}=>"En attente du premier chiffre révélé.",
                MiniCactpotObservationStatus.Observed when observation.Frame is {Revealed:>4}=>"Ticket terminé ou en transition ; aucun conseil conservé.",
                _=>observation.CanSolve(DateTimeOffset.UtcNow) ? "Ticket observé : conseils recalculés après chaque révélation.":"En attente d’une observation récente."
            });
            if(observation.Error is { } error)ImGui.TextWrapped(error);
            if(observation.ObservedAt is { } observed)ImGui.TextDisabled($"Observation {observed:HH:mm:ss} UTC · copie à 5 Hz, aucun clic automatique");
        }
        else ImGui.TextWrapped("Saisissez entre un et quatre chiffres révélés ; 0 représente une case cachée.");
        if(ImGui.BeginTable("CactpotBoard",3,ImGuiTableFlags.SizingFixedFit))
        {
            try
            {
                for(var index=0;index<9;index++)
                {
                    ImGui.TableNextColumn();ImGui.SetNextItemWidth(55);
                    if(enabled)ImGui.Button($"{(cactpotBoard[index]==0 ? "?":cactpotBoard[index].ToString())}##Cactpot{index}",new Vector2(52));
                    else if(ImGui.InputInt($"##Cactpot{index}",ref cactpotBoard[index],0,0))InvalidateCactpot();
                }
            }
            finally{ImGui.EndTable();}
        }
        if(!enabled)
        {
            if(ImGui.Button("Effacer le ticket")){Array.Clear(cactpotBoard);InvalidateCactpot();}
            ImGui.SameLine();ImGui.BeginDisabled(cactpotSolve.State.Loading);
            try{if(ImGui.Button("Calculer le meilleur choix"))_=cactpotSolve.StartAsync(cactpotBoard,0,cactpotGeneration);}
            finally{ImGui.EndDisabled();}
        }
        var state=cactpotSolve.State;
        ImGui.TextDisabled($"{cactpotBoard.Count(value=>value!=0)}/4 chiffres révélés · lignes et colonnes depuis le coin supérieur gauche");
        if(state.Loading)ImGui.TextDisabled("Calcul en cours…");
        if(state.Error is { } errorText)ImGui.TextWrapped(errorText);
        if(state.Result is not { } result)return;
        ImGui.TextColored(Accent,result.ChooseLine ? "Choisissez une ligne":"Prochaine case à révéler");
        ImGui.TextUnformatted($"Récompense espérée avec les choix suivants optimaux : {result.ExpectedReward:N2} PGS");
        var lines=new[]{"Ligne du haut","Ligne centrale","Ligne du bas","Colonne gauche","Colonne centrale","Colonne droite","Diagonale ↘","Diagonale ↙"};
        for(var index=0;index<result.Choices.Count;index++)
        {
            if(result.Choices[index] is not { } value)continue;
            var label=result.ChooseLine ? lines[index]:$"Ligne {index/3+1}, colonne {index%3+1}";
            var best=Math.Abs(value-result.ExpectedReward)<0.000001;
            ImGui.TextColored(best ? Success:Muted,$"{(best ? "★ ":"")}{label} : {value:N2} PGS");
        }
        ImGui.TextWrapped("Espérance mathématique sur les chiffres cachés ; le gain d’un ticket individuel reste aléatoire. Révélez les cases et choisissez la ligne vous-même dans le jeu.");
    }
    public void Dispose()
    {
        if (windowDisposed) return;
        windowDisposed = true; cactpotGeneration++;
        craftChain.Dispose();
        craftSolve.Dispose();
        triadSolve.Dispose();
        preparationPrices.Dispose();
        cactpotSolve.Dispose();
    }
}
