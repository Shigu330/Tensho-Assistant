# GOAL sélectionné

ID: GATHER-FISH-FORECAST-010
OBJECTIVE: Croiser les conditions de pêche explicitement renseignées aux prévisions natives avec horizon borné et inconnus conservés ; poursuivre les 17 domaines jusqu’à la réserve quota de 5 %.
CURRENT_STATE: GATHER-FISH-WEATHER-009 IMPLEMENTED / TESTED en 0.63.0, 405 tests/package/SHA-256 et probes Weather/8753 verts. Météos source reliées aux noms/icônes natifs par territoire, sans choix arbitraire parmi les doublons. Rendu en jeu non observé.
WHY_NOW: Horaires, conditions et correspondances d’identité sont disponibles ; réutiliser les prévisions et l’horloge communes pour des plages compatibles, sans les présenter comme une capture possible certaine.
REFERENCES: docs/GATHER-FISH-WEATHER-009.md ; docs/GATHER-FISH-WINDOWS-008.md ; docs/GATHER-WEATHER-001.md.
FILES: Community/FishingConditions ; Gathering/WeatherForecast, GatheringTimeline ; MainWindow.FishingSources ; tests/probes ciblés.
IN_SCOPE: Intersection bornée horaire ET/météo courante/précédente, états incomplets/inconnus distincts de non-correspondance, tables individuelles/partielles et horodatage CalculatedAt ; copie/cache partagés.
OUT_OF_SCOPE: Déduire météo native code 2, intuition/prises préalables, personnage débloqué, présence/capture certaine ou météo forcée réelle ; aucune action de pêche. Les 17 domaines restent PARTIAL.
VALIDATION: Dernière tranche : Verify.ps1 405/405, zéro avertissement/erreur, package/API/versions/SHA-256/exclusion hôte verts. WeatherProbe 214 lignes/43 noms globalement ambigus ; probe réel 8753 et alias territoire 137 vérifiés. Nouvelle projection à tester avec oracle/bornes avant livraison.
QUOTA: Relevé 2026-10-29 : 68 % disponibles sur 5 h et 42 % semaine ; réserve 5 %, objectif global actif.
NEXT_ACTION: Checkpoint 0.63 puis contrat d’inconnus et intersection bornée, réutilisant les périodes et fenêtres UTC existantes. GP et essais projection/Macro Chain différés, sans les redemander.
DEFINITION_OF_DONE: Tranche intégrée compilée/testée, preuves/limites/docs/sauvegarde à jour ; aucun domaine global promu complet sans preuve.
