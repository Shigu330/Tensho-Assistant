# GOAL sélectionné

ID: CRAFT-PRESETS-001
OBJECTIVE: Conserver et recharger explicitement les séquences manuelles de craft, puis poursuivre les 17 domaines.
CURRENT_STATE: IMPLEMENTED / TESTED en 0.44.0, 283 tests/package verts ; sauvegarde nommée et bornée, résolution recette exacte, chargement sans résultat/attributs enregistrés et rollback en cas d'échec. Roundtrip JSON managé testé ; persistance native à confirmer.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: CraftPresets, Configuration v1, MainWindow.CraftPresets/Simulation/Tools/navigation ; CraftPresetTests et documents.
IN_SCOPE: Recette/actions/nom/date conservés dans la configuration, chargement/retrait explicites, bornes et conservation des entrées non résolues ; aucune exécution native.
OUT_OF_SCOPE: Déclarer les 17 plugins remplacés ; prétendre une validation en jeu sans observation.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: 2026-10-28, 3 % disponibles sur 5 h et 69 % semaine au dernier relevé ; continuer selon instruction utilisateur.
NEXT_ACTION: Snapshot 0.44.0 puis audit borné chemins/versions/documents et sérialisation compatible hôte. Préserver l'objectif global et les 17 domaines PARTIAL ; conseils natifs et prérequis météo restent à compléter, Macro Chain différé. Reprise de grosses tranches après renouvellement du quota.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
