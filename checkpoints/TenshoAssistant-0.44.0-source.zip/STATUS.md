# État courant

CURRENT_GOAL: CRAFT-PRESETS-001 — IMPLEMENTED / TESTED ; séquences sauvegardées, voir docs/CRAFT-PRESETS-001.md
CURRENT_MODEL_CLASS: HEAVY (GPT-6.1 Sol)
RECOMMENDED_MODEL: LIGHT pour les adaptations bornées ; continuation du modèle actuel autorisée par l'utilisateur
MODEL_ESCALATION: None
QUOTA: Vérifié le 2026-10-28 : 97 % consommés sur 5 h, 31 % semaine (3 % / 69 % disponibles). Continuation autorisée ; objectif global actif.
LAST_READ: Tous les Markdown du projet et la note de checkpoint relus le 2026-10-28 avant modification ; prompt maître, historique et états récents distingués.
BUILD: COMPILED Release 0.44.0.0 ; sortie canonique bin/x64/Release
TESTS: TESTED — 283/283 tests ; versions/ZIP/exclusion hôte verts ; copie/résolution/roundtrip JSON managé et rollback des séquences passants
RUNTIME: Banque, stocks, carnet et préparation jusqu'à 0.5.27 confirmés par l'utilisateur. Nouvelles fonctions 0.6–0.44 non validées en jeu.
WORK_COMPLETED: Dix-sept domaines PARTIAL ; séquences de craft persistantes avec recette exacte, validation/bornes/rollback et chargement invalidant les résultats, météo/horaires UTC et autres outils conservés. 283 tests ; aucun lancement natif ou succès runtime inventé.
BLOCKER: Aucun blocage global. L'utilisateur a répondu « Je testerai plus tard » pour Macro Chain ; sa validation native reste différée, sans redemande. Cartes et horaires ET statiques intégrés.
RESUME_FROM: GOAL.md ; TESTING.md pour le protocole de la base.
NEXT_ACTION: Snapshot 0.44.0 puis audit borné de cohérence des chemins/versions/docs et compatibilité de sérialisation des séquences avec l'hôte. Ne pas ouvrir une grosse tranche avant renouvellement du quota ; scope des 17 domaines inchangé, Macro Chain différé.

| Plugin | Coverage |
|---|---|
| Avant-Garde | PARTIAL — répertoire manuel d'indices natifs, équipements signalés, emplacements/stock/contexte et source datée ; thème courant/teintures/score/attache non déduits |
| Blue Mage Helper | PARTIAL — grimoire, numéros, descriptions, lieux renseignés et acquisition confirmée |
| Character Panel Refined | PARTIAL — attributs natifs, sans formules dérivées |
| Collections | PARTIAL — montures, mascottes, emotes et cartes Triple Triade ; inconnu distinct d'absent |
| Craftimizer | PARTIAL — recettes/préparation, 26 actions, export/recherche, séquences sauvegardées et observation partielle ; conseils natifs/recettes spéciales à développer |
| Duty Loot Preview | PARTIAL — consultation manuelle par contenu, coffres/récompenses, icônes/contexte, provenance et cache ; drops directs non interprétés, données externes partielles |
| ezMiniCactpot | PARTIAL — solveur optimal manuel ; adaptation native à développer |
| GatherBuddy | PARTIAL — sources récolte/pêche, cartes, météo de zone, horloge ET et prochaines plages UTC ; présence/prérequis météo/accès/harpon non couverts |
| Item Use | PARTIAL — usages du catalogue de recettes |
| LazyGatherer | PARTIAL — optimiseur de scénario manuel MIN/BTN, espérances/seuils et copie des PR courants ; régénération/procs/collectionnables et adaptation du point natif non couverts |
| Macro Chain | PARTIAL — séquences à marqueur final, lancement explicite, arrêt, persistance ; natif à confirmer |
| Mappy | PARTIAL — navigateur natif, repères favoris persistants, ressources de zone et prévisions météo statiques ; météo forcée non observée |
| Monster Loot Hunter | PARTIAL — associations matériau/monstre, fiches/niveaux/lieux et carte de zone, transport/cadence partagés, contexte ; données communautaires partielles |
| Price Insight | PARTIAL — prix manuels/survol, coût direct et terminal des chaînes, cache/cadence/priorités communs, dates NQ/HQ par monde |
| QuestTracker | PARTIAL — états natifs, séquence, fiche et liens de prérequis/suivantes ; disponibilité non calculée |
| SortaKinda | PARTIAL — aperçu de règles sauvegardées, sans déplacement natif |
| TriadBuddy | PARTIAL — carnet/deck/solveur manuel, observation des faces opt-in expérimentale ; identités/règles/trait natifs et autres règles non établis |

