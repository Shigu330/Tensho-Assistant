# GOAL sélectionné

ID: CRAFT-CONDITIONS-004
OBJECTIVE: Établir les conditions ordinaires et le bonus d'outil favorable sans transformer l'inconnu en absence, puis poursuivre les outils jusqu'à la réserve de quota de 5 %.
CURRENT_STATE: IMPLEMENTED / TESTED en 0.46.0, 295 tests/package verts ; quatre conditions ordinaires, bonus principal vérifié dans les fichiers du jeu, qualité inconnue explicite. Ni bonus équipé ni projections validés en jeu ; tests reportés par l'utilisateur.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: CraftSimulation/CraftLiveProjection/Reader ; ItemCatalog/Loader ; MainWindow.CraftProjection/Live ; CraftConditionTests ; ToolBonusProbe ; documentation.
IN_SCOPE: Projection d'une action parmi les quatre conditions ordinaires, copie native bornée de l'outil et classification des métadonnées ; bonus ambigu conserve qualité inconnue. Simulation/recherche de rotations reste normale.
OUT_OF_SCOPE: Revendiquer remplacement intégral ou validation native sans preuve ; commander une action depuis cette comparaison.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: Relevé 2026-10-29 : 73 % disponibles sur 5 h et 65 % semaine ; réserve utilisateur 5 % sur la fenêtre limitante. Objectif global actif.
NEXT_ACTION: CRAFT-CONDITION-RANGE-005 : enveloppe de qualité d'une séquence fixe sur les transitions ordinaires, après preuve primaire des transitions. Ne pas confondre enveloppe du modèle, probabilité HQ et garantie runtime. Tests projection/Macro Chain différés, ne pas redemander.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
