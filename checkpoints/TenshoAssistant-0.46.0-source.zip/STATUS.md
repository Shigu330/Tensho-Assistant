# État courant

CURRENT_GOAL: CRAFT-CONDITIONS-004 — IMPLEMENTED / TESTED ; quatre conditions ordinaires et bonus favorable explicite, voir docs/CRAFT-CONDITIONS-004.md
CURRENT_MODEL_CLASS: HEAVY — adaptateur natif et projections à états incomplets
RECOMMENDED_MODEL: HEAVY pour les déductions natives/conditions ; LIGHT pour les tâches mécaniques ; continuation autorisée
MODEL_ESCALATION: None
QUOTA: Relevé 2026-10-29 : 27 % consommés sur 5 h, 35 % semaine (73 % / 65 % disponibles). Réserve utilisateur 5 % ; objectif global actif.
LAST_READ: RULES/STATUS/GOAL et sources/docs ciblés relus le 2026-10-29 ; audit 0.44 conservé et documents courants mis à jour.
BUILD: COMPILED Release 0.46.0.0 ; sortie canonique bin/x64/Release
TESTS: TESTED — 295/295 tests ; package/versions/ZIP/exclusion hôte verts, zéro avertissement/erreur ; ToolBonusProbe 928 outils, 136 bonus favorables identifiés.
RUNTIME: Banque, stocks, carnet et préparation jusqu'à 0.5.27 confirmés par l'utilisateur. Fonctions 0.6–0.46 non validées en jeu. Tests projection et Macro Chain différés explicitement ; ne pas les redemander.
WORK_COMPLETED: Dix-sept domaines PARTIAL ; projection immédiate Normale/Favorable/Excellente/Mauvaise, métadonnées anglaises partagées des outils principaux, qualité nullable pour bonus inconnu. Transition commune, copie native bornée et SeString décodé ; aucune exécution ou validation runtime revendiquée.
BLOCKER: Aucun blocage global. Tests projection et Macro Chain différés ; les travaux indépendants continuent.
RESUME_FROM: GOAL.md ; TESTING.md pour le protocole de la base.
NEXT_ACTION: Sauvegarde 0.46.0 puis CRAFT-CONDITION-RANGE-005 : évaluer une séquence fixe sur les transitions ordinaires pour distinguer qualité normale et enveloppe conservatrice ; preuve primaire des transitions avant implémentation. Rotation native et 17 domaines conservés.

| Plugin | Coverage |
|---|---|
| Avant-Garde | PARTIAL — répertoire manuel d'indices natifs, équipements signalés, emplacements/stock/contexte et source datée ; thème courant/teintures/score/attache non déduits |
| Blue Mage Helper | PARTIAL — grimoire, numéros, descriptions, lieux renseignés et acquisition confirmée |
| Character Panel Refined | PARTIAL — attributs natifs, sans formules dérivées |
| Collections | PARTIAL — montures, mascottes, emotes et cartes Triple Triade ; inconnu distinct d'absent |
| Craftimizer | PARTIAL — simulation/recherche/export/séquences, observation et projection d'un coup normal ; conditions/rotation native/recettes spéciales et runtime à compléter |
| Duty Loot Preview | PARTIAL — consultation manuelle par contenu, coffres/récompenses, icônes/contexte, provenance et cache ; drops directs non interprétés, données externes partielles |
| ezMiniCactpot | PARTIAL — solveur optimal manuel ; adaptation native à développer |
| GatherBuddy | PARTIAL — sources récolte/pêche, cartes, météo de zone, horloge ET et prochaines plages UTC ; présence/prérequis météo/accès/harpon non couverts |
| Item Use | PARTIAL — usages du catalogue de recettes |
| LazyGatherer | PARTIAL — optimiseur de scénario manuel MIN/BTN, espérances/seuils et copie des PR courants ; régénération/procs/collectionnables et adaptation du point natif non couverts |
| Macro Chain | PARTIAL — séquences à marqueur final, lancement explicite, arrêt, persistance ; natif à confirmer |
| Mappy | PARTIAL — navigateur natif, repères favoris persistants, ressources de zone et prévisions météo statiques ; météo forcée non observée |
| Monster Loot Hunter | PARTIAL — associations matériau/monstre, fiches/niveaux/lieux et carte de zone, transport/cadence partagés, contexte ; données communautaires partielles |
| Price Insight | PARTIAL — prix manuels/survol, coût direct et terminal des chaînes, cache/cadence/priorités communs, dates NQ/HQ par monde |
| QuestTracker | PARTIAL — états natifs, séquence, fiche et liens de prérequis/suivantes ; disponibilité non calculée |
| SortaKinda | PARTIAL — aperçu de règles sauvegardées, sans déplacement natif |
| TriadBuddy | PARTIAL — carnet/deck/solveur manuel, observation des faces opt-in expérimentale ; identités/règles/trait natifs et autres règles non établis |

