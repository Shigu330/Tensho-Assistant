# GOAL sélectionné

ID: TRIAD-002
OBJECTIVE: Étudier et intégrer une observation passive bornée des faces et couleurs du match, en conservant explicites les informations non établies ; poursuivre la couverture du projet.
CURRENT_STATE: IMPLEMENTED / TESTED — observation expérimentale opt-in intégrée en 0.26.0, 154 tests/package valides ; API/structures locales inspectées. Pas de validation en jeu ni de liaison automatique au solveur. Macro Chain attend un essai reporté par l'utilisateur, sans bloquer les travaux indépendants.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: Domaines Gathering, Inventory, Collections, Market, Quests, Character, MiniGames ; MainWindow.* ; Plugin.cs ; tests et documents.
IN_SCOPE: Copies framework de 19 emplacements, états vide/masqué/connu/incomplet, couleurs/phase UI et provenance, activation volontaire, invalidation et arrêt possédés ; informations non observées laissées inconnues.
OUT_OF_SCOPE: Déclarer les 17 plugins remplacés ; prétendre une validation en jeu sans observation.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: 2026-10-28, 36 % disponibles sur 5 h et 90 % semaine au dernier relevé ; continuer selon instruction utilisateur.
NEXT_ACTION: Sauvegarder 0.26.0. Lier l'observation au solveur demande d'abord validation runtime et preuves des identités/règles/trait ; poursuivre indépendamment MARKET-002, estimation du coût d'une préparation avec les services existants et prix inconnus explicites. Les autres domaines de la roadmap restent dans le goal global.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
