using Lumina;
using Lumina.Data;
using Lumina.Excel.Sheets;
using TenshoAssistant.Gathering;
using TenshoAssistant.Craft;
using TenshoAssistant.Inventory;
using TenshoAssistant.Maps;
using TenshoAssistant.Items;
using TenshoAssistant.Market;
using TenshoAssistant.MiniGames;

if (args.Length != 1) throw new ArgumentException("Supply the installed game's sqpack directory.");
using var data = new GameData(args[0], new LuminaOptions { DefaultExcelLanguage = Language.French });
var points = data.Excel.GetSheet<GatheringPoint>();
var items = data.Excel.GetSheet<GatheringItem>();
var fishing = data.Excel.GetSheet<FishingSpot>();
var transientPoints = data.Excel.GetSheet<GatheringPointTransient>();
var rareTimes = data.Excel.GetSheet<GatheringRarePopTimeTable>();
GatheringSchedule ReadSchedule(GatheringPoint point)
{
    if (point.Type == 8 || !transientPoints.TryGetRow(point.RowId, out var timing)) return GatheringSchedule.Unknown;
    if (timing.GatheringRarePopTimeTable.RowId == 0)
        return GatheringSchedule.FromEphemeral(timing.EphemeralStartTime, timing.EphemeralEndTime);
    if (!rareTimes.TryGetRow(timing.GatheringRarePopTimeTable.RowId, out var rare)) return GatheringSchedule.Unknown;
    var slots = new List<(ushort, ushort)>();
    for (var index = 0; index < rare.StartTime.Count; index++) slots.Add((rare.StartTime[index], rare.Duration[index]));
    return GatheringSchedule.FromRare(slots);
}
var count = 0;
var fishingCount = 0;
var examples = new HashSet<uint>();
var managed = new List<GatheringSource>();
void Add(GatheringPoint point, uint id, bool hidden = false)
{
    if (point.GatheringPointBase.RowId == 0 || point.TerritoryType.RowId == 0) return;
    var basis = point.GatheringPointBase.Value;
    var type = basis.GatheringType.Value;
    var territory = point.TerritoryType.Value;
    managed.Add(new(id, point.RowId, basis.RowId, type.RowId, type.Name.ExtractText(),
        (uint)Math.Max(0, type.IconMain), basis.GatheringLevel, territory.RowId,
        territory.PlaceName.Value.Name.ExtractText(), point.PlaceName.Value.Name.ExtractText(), territory.Map.RowId, false, hidden, ReadSchedule(point)));
}
var links = data.Excel.GetSubrowSheet<GatheringItemPoint>();
foreach (var item in items)
{
    if (item.Item.RowId == 0 || item.Item.RowType != typeof(Item)) continue;
    if (links.TryGetRow(item.RowId, out var nodeLinks))
        foreach (var link in nodeLinks)
            if (link.GatheringPoint.RowId != 0) Add(link.GatheringPoint.Value, item.Item.RowId, item.IsHidden);
}
foreach (var point in points)
{
    if (point.GatheringPointBase.RowId == 0 || point.TerritoryType.RowId == 0) continue;
    var basis = point.GatheringPointBase.Value;
    foreach (var reference in basis.Item)
    {
        if (reference.RowId == 0 || reference.RowType != typeof(GatheringItem)) continue;
        var gatheringItem = items.GetRow(reference.RowId);
        var item = gatheringItem.Item;
        if (item.RowId == 0 || item.RowType != typeof(Item)) continue;
        count++;
        Add(point, item.RowId, gatheringItem.IsHidden);
        if (item.RowId is 12893 or 12891 or 8 && examples.Add(item.RowId))
            Console.WriteLine($"Item {item.RowId}: {basis.GatheringType.Value.Name.ExtractText()} / {point.TerritoryType.Value.PlaceName.Value.Name.ExtractText()} / {point.PlaceName.Value.Name.ExtractText()}");
    }
}
foreach (var spot in fishing)
    if (spot.TerritoryType.RowId != 0)
    {
        fishingCount += spot.Item.Count(item => item.RowId != 0);
        foreach (var item in spot.Item)
            if (item.RowId != 0)
                managed.Add(new(item.RowId, spot.RowId, spot.RowId, 100, "Pêche", 62118, spot.GatheringLevel,
                    spot.TerritoryType.RowId, spot.TerritoryType.Value.PlaceName.Value.Name.ExtractText(),
                    spot.PlaceName.Value.Name.ExtractText(), spot.TerritoryType.Value.Map.RowId, true));
    }
var catalog = new GatheringCatalog(managed, "installed-game");
Console.WriteLine($"Deduplicated sources: {catalog.Count}");
var chestnut = catalog.ForItem(12893).FirstOrDefault() ?? throw new InvalidOperationException("Missing hidden chestnut source.");
Console.WriteLine($"Marron sombre: {chestnut.TypeName}, level {chestnut.Level}, {chestnut.Zone}, {chestnut.Place}, hidden={chestnut.IsHidden}");
Console.WriteLine($"Gathering links: {count}; fishing links: {fishingCount}; points: {points.Count}");
if (count == 0 || fishingCount == 0) throw new InvalidOperationException("Real data join produced an empty domain.");
var blue = data.Excel.GetSheet<AozAction>();
var blueDetails = data.Excel.GetSheet<AozActionTransient>();
foreach (var spell in blue.Where(row => row.RowId != 0 && row.Action.RowId != 0).Take(5))
{
    var details = blueDetails.GetRow(spell.RowId);
    Console.WriteLine($"Blue {spell.RowId}: {spell.Action.Value.Name.ExtractText()}, number={details.Number}, rank={spell.Rank}, location={details.Location.RowType?.Name}:{details.Location.RowId}");
}
Console.WriteLine($"Static catalog rows: mounts={data.Excel.GetSheet<Mount>().Count}, companions={data.Excel.GetSheet<Companion>().Count}, emotes={data.Excel.GetSheet<Emote>().Count}, quests={data.Excel.GetSheet<Quest>().Count}");
var recipeRows = new List<RecipeDefinition>();
foreach (var row in data.Excel.GetSheet<Recipe>())
{
    if (row.RowId == 0 || row.ItemResult.RowId == 0 || row.AmountResult == 0) continue;
    var ingredients = new List<RecipeIngredient>();
    for (var index = 0; index < row.Ingredient.Count; index++)
        if (row.Ingredient[index].RowId != 0 && row.AmountIngredient[index] > 0)
            ingredients.Add(new(row.Ingredient[index].RowId, row.AmountIngredient[index]));
    recipeRows.Add(new(row.RowId, row.ItemResult.RowId, row.AmountResult, row.CraftType.Value.Name.ExtractText(),
        row.RecipeLevelTable.Value.ClassJobLevel, ingredients, row.CraftType.RowId));
}
var recipes = RecipeCatalog.Build(recipeRows, "installed-game");
var itemSheet = data.Excel.GetSheet<Item>();
foreach (var recipe in recipes.ForResult(12892))
{
    var plan = CraftChain.Build(recipe, 7, recipes, _ => new([], 0, 0, false, true, false, false));
    Console.WriteLine($"Real craft chain {itemSheet.GetRow(recipe.ResultItemId).Name.ExtractText()}: {plan.Requested} requested, {plan.Produced} produced, {plan.Steps.Count} steps, unresolved={plan.HasUnresolved}");
    foreach (var material in plan.Materials)
        Console.WriteLine($"  {itemSheet.GetRow(material.ItemId).Name.ExtractText()}: {material.Amount}, {material.Reason}");
    if (plan.Produced != 9 || plan.Materials.Single(material => material.ItemId == 12891).Amount != 9)
        throw new InvalidOperationException("Real birch syrup yield or ingredient join does not match expected quantities.");
}
if (recipes.ForResult(12892).Count == 0) throw new InvalidOperationException("Real birch syrup recipe missing.");
var maps = new MapCatalog(data.Excel.GetSheet<Map>().Where(row => row.RowId != 0 && row.TerritoryType.RowId != 0)
    .Select(row => new MapDefinition(row.RowId, row.TerritoryType.RowId, row.PlaceNameRegion.Value.Name.ExtractText(),
        row.PlaceName.Value.Name.ExtractText(), row.PlaceNameSub.Value.Name.ExtractText(), row.MapIndex, row.SizeFactor)));
var sampleSource = catalog.ForItem(8).First(source => source.MapId != 0);
var sampleMap = maps.Find(sampleSource.MapId) ?? throw new InvalidOperationException("Gathering source references a missing map.");
if (sampleMap.TerritoryId != sampleSource.TerritoryId) throw new InvalidOperationException("Map and gathering territory mismatch.");
Console.WriteLine($"Native map catalog: {maps.Entries.Count} maps; sample {sampleMap.Zone}, map={sampleMap.MapId}, territory={sampleMap.TerritoryId}");
var hoverExamples = new uint[] { 12892, 4551, 1 }.Select(id => itemSheet.GetRow(id)).Select(row =>
    new ItemDefinition(row.RowId, row.Name.ExtractText(), row.CanBeHq, row.Icon,
        row.ItemUICategory.RowId, row.ItemUICategory.Value.Name.ExtractText(), !row.IsUntradable && row.ItemSearchCategory.RowId != 0)).ToArray();
var hoverCatalog = ItemCatalog.Build(hoverExamples, new("installed-game", "French", "local-probe", 1));
foreach (var example in hoverExamples)
    Console.WriteLine($"Hover eligibility {example.Id} {example.Name}: marketable={example.IsMarketable}, HQ={example.CanBeHq}");
if (MarketHoverTracker.Normalize(1012892, hoverCatalog) != new MarketHoverItem(12892, true)
    || MarketHoverTracker.Normalize(1, hoverCatalog) is not null || MarketHoverTracker.Normalize(2012892, hoverCatalog) is not null)
    throw new InvalidOperationException("Native market eligibility or HQ normalization did not match the copied game data.");
var bases = data.Excel.GetSheet<GatheringPointBase>();
Console.WriteLine($"Schedule sheet counts: points={points.Count}, bases={bases.Count}, transient={transientPoints.Count}, rare={rareTimes.Count}");
foreach (var timing in transientPoints.Where(row => row.GatheringRarePopTimeTable.RowId != 0 || row.EphemeralStartTime != row.EphemeralEndTime).Take(8))
{
    var pointFound = points.TryGetRow(timing.RowId, out var nativePoint);
    var baseFound = bases.TryGetRow(timing.RowId, out _);
    var rare = timing.GatheringRarePopTimeTable.Value;
    Console.WriteLine($"Schedule sample key={timing.RowId}, point={pointFound}, baseSameId={baseFound}, nativeBase={(pointFound ? nativePoint.GatheringPointBase.RowId : 0)}, rare={rare.RowId}, starts={string.Join(',', rare.StartTime)}, durations={string.Join(',', rare.Duration)}, ephemeral={timing.EphemeralStartTime}-{timing.EphemeralEndTime}");
}
Console.WriteLine($"Native rare durations: {string.Join(',', rareTimes.SelectMany(row => row.Duration).Distinct().Order())}");
Console.WriteLine($"Ephemeral examples: {string.Join(';', transientPoints.Where(row => row.EphemeralStartTime != row.EphemeralEndTime).Take(8).Select(row => $"{row.RowId}:{row.EphemeralStartTime}-{row.EphemeralEndTime}"))}");
if (ReadSchedule(points.GetRow(30999)).Windows.Single() != new GatheringWindow(540, 720)
    || ReadSchedule(points.GetRow(31436)).Windows.Single() != new GatheringWindow(1200, 1440))
    throw new InvalidOperationException("Real rare or ephemeral schedule mismatch.");
foreach (var group in catalog.Sources.GroupBy(source => source.Timing.Kind))
    Console.WriteLine($"Interpreted schedule {group.Key}: {group.Count()}");
if (catalog.Sources.Any(source => source.Timing.Kind == GatheringScheduleKind.Invalid))
    throw new InvalidOperationException("Unexpected native schedule encoding: inspect before release.");
Console.WriteLine("PASS installed-game schedule joins and minute conversion");
var triadCards = data.Excel.GetSheet<TripleTriadCard>();
var triadResidents = data.Excel.GetSheet<TripleTriadCardResident>();
Console.WriteLine($"Triad sheets: names={triadCards.Count}, resident={triadResidents.Count}");
foreach (var card in triadCards.Where(row => row.RowId != 0 && !string.IsNullOrWhiteSpace(row.Name.ExtractText())).Take(3))
{
    var resident = triadResidents.GetRow(card.RowId);
    Console.WriteLine($"Triad {card.RowId}: {card.Name.ExtractText()}, order={resident.Order}, stars={resident.TripleTriadCardRarity.Value.Stars}, top={resident.Top}, right={resident.Right}, bottom={resident.Bottom}, left={resident.Left}, type={resident.TripleTriadCardType.Value.Name.ExtractText()}");
}
foreach (var item in itemSheet.Where(row => row.AdditionalData.RowType == typeof(TripleTriadCard)).Take(3))
    Console.WriteLine($"Triad item {item.RowId} {item.Name.ExtractText()}, card={item.AdditionalData.RowId}, icon={item.Icon}");
Console.WriteLine($"Triad icon 88001 exists={data.FileExists("ui/icon/088000/088001.tex")}");
var triadValid = triadCards.Where(row => row.RowId != 0 && !string.IsNullOrWhiteSpace(row.Name.ExtractText()))
    .Select(row => triadResidents.GetRow(row.RowId)).Where(row => row.Top > 0).ToArray();
var missingTriadIcons = triadValid.Where(row => !data.FileExists($"ui/icon/{(88000 + row.RowId) / 1000 * 1000:000000}/{88000 + row.RowId:000000}.tex")).ToArray();
Console.WriteLine($"Triad valid cards={triadValid.Length}, missing icons={missingTriadIcons.Length}, invalid values={triadValid.Count(row => row.Top > 10 || row.Bottom is < 1 or > 10 || row.Right is < 1 or > 10 || row.Left is < 1 or > 10)}, stars={string.Join(',', triadValid.Select(row => row.TripleTriadCardRarity.Value.Stars).Distinct().Order())}");
var managedTriad = triadValid.Select(row => new TriadCardDefinition(row.RowId, row.Order,
    row.TripleTriadCardRarity.Value.Stars, row.Top, row.Right, row.Bottom, row.Left,
    row.TripleTriadCardType.RowId, row.TripleTriadCardType.Value.Name.ExtractText(), triadCards.GetRow(row.RowId).Description.ExtractText())).ToArray();
var triadItems = ItemCatalog.Build(itemSheet.Where(row => row.AdditionalData.RowType == typeof(TripleTriadCard))
    .Select(row => new ItemDefinition(row.RowId, row.Name.ExtractText(), row.CanBeHq, row.Icon,
        TripleTriadCardId: row.AdditionalData.RowId)), new("Item/AdditionalData", "French", "installed-game", 1));
var nativeDodo = managedTriad.Single(card => card.Id == 1);
if (managedTriad.Length != 475 || managedTriad.Any(card => !card.IsValid) || missingTriadIcons.Length != 0
    || nativeDodo.Top != 4 || nativeDodo.Right != 2 || nativeDodo.Bottom != 3 || nativeDodo.Left != 4
    || triadItems.ForTriadCard(1).Single().Id != 9772 || !managedTriad.Any(card => card.Id != card.Number))
    throw new InvalidOperationException("Native Triad catalog, artwork, orientation or typed item join mismatch.");
Console.WriteLine($"PASS installed-game Triad values, 475 icons, native/display identities and item join; {triadItems.Count} card items");
var triadMatch = TriadPosition.Create(managedTriad.Where(card => card.Id <= 5),
    managedTriad.Where(card => card.Id is >= 6 and <= 10), TriadPlayer.Blue);
var triadOpening = TripleTriadSolver.Solve(triadMatch);
Console.WriteLine($"Native Triad opening: completedDepth={triadOpening.CompletedDepth}, exact={triadOpening.Exact}, nodes={triadOpening.Nodes}, moves={triadOpening.Moves.Count}");
for (var step = 0; step < 6; step++) triadMatch = triadMatch.Play(triadMatch.LegalMoves()[0]);
var triadEndgame = TripleTriadSolver.Solve(triadMatch);
if (!triadEndgame.Exact || triadEndgame.CompletedDepth != 3 || triadEndgame.Moves.Count != 6
    || triadEndgame.Best(triadMatch.Turn).Count == 0 || triadMatch.BlueScore + triadMatch.RedScore != 10)
    throw new InvalidOperationException("Native Triad endgame integration failed.");
Console.WriteLine("PASS native-card Triad simulation and exact three-ply advice");
var typedTriad = managedTriad.Where(card => card.TypeId != 0).GroupBy(card => card.TypeId)
    .OrderByDescending(group => group.Count()).First().Take(10).ToArray();
if (typedTriad.Length != 10) throw new InvalidOperationException("Need ten native cards of a shared family for rule integration.");
var triadRuleCases = 0;
for (var family = 0; family < 3; family++)
for (var ordered = 0; ordered < 2; ordered++)
for (var mask = 0; mask < 16; mask++)
{
    var rules = (TriadRules)mask | (ordered == 1 ? TriadRules.Order : 0)
        | (family == 1 ? TriadRules.Ascension : family == 2 ? TriadRules.Descension : 0);
    var match = TriadPosition.Create(typedTriad.Take(5),typedTriad.Skip(5),TriadPlayer.Blue,rules);
    for (var step = 0; step < 6; step++) match = match.Play(match.LegalMoves()[0]);
    var advice = TripleTriadSolver.Solve(match);
    if (!advice.Exact || advice.CompletedDepth != 3 || advice.Moves.Count != (ordered == 1 ? 3 : 6) || match.Rules != rules)
        throw new InvalidOperationException("Native Triad rule-aware integration failed.");
    var modifier = family == 1 ? 6 : family == 2 ? -6 : 0;
    for (var index = 0; index < 10; index++)
        if (match.FamilyModifier(index) != modifier || match.EffectiveSide(index,0) != Math.Clamp(typedTriad[index].Top + modifier,1,10))
            throw new InvalidOperationException("Native Triad family display rank mismatch.");
    triadRuleCases++;
}
Console.WriteLine($"PASS native-card Triad exact endgames and effective ranks: {triadRuleCases} rule combinations, family={typedTriad[0].TypeId}");
