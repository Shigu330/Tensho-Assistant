# GOAL sélectionné

ID: TRIAD-001D
OBJECTIVE: Ajouter Identique/Plus et les chaînes de captures à Triple Triade, en préservant les autres règles, l'annulation et la distinction exact/estimé ; poursuivre la couverture du projet.
CURRENT_STATE: IMPLEMENTED / TESTED — Identique/Plus/combos intégrés en 0.24.0, 144 tests/package valides ; 192 fins de partie supplémentaires sur seize combinaisons comparées au moteur indépendant, probe cartes natives passant. Macro Chain attend un essai reporté par l'utilisateur, sans bloquer ce travail indépendant.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: Domaines Gathering, Inventory, Collections, Market, Quests, Character, MiniGames ; MainWindow.* ; Plugin.cs ; tests et documents.
IN_SCOPE: Captures simultanées Identique/Plus, partenaires alliés, chaînes bornées, interactions avec Inversion/Tueur d'as ; règles immutables et solveur borné conservés.
OUT_OF_SCOPE: Déclarer les 17 plugins remplacés ; prétendre une validation en jeu sans observation.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: 2026-10-28, 52 % disponibles sur 5 h et 92 % semaine au dernier relevé ; continuer selon instruction utilisateur.
NEXT_ACTION: Sauvegarder 0.24.0 puis TRIAD-001E : Ordre et Bonus/Malus, sources primaires et tests indépendants des interactions avant activation. Ne pas annoncer une lecture du plateau non implémentée. Les autres domaines de la roadmap restent dans le goal global.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
