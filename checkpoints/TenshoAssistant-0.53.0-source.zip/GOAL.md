# GOAL sélectionné

ID: USE-CONTEXT-004
OBJECTIVE: Ouvrir les outils avec l’objet choisi au clic droit natif, puis poursuivre les 17 domaines jusqu’à la réserve de quota de 5 %.
CURRENT_STATE: IMPLEMENTED / TESTED en 0.53.0, 349 tests/package verts ; menu Inventory opt-in et cinq routes communes, identité/qualité/propriétaire/révision/âge revalidés. Callback et rendu natifs non observés.
FILES: Items/ItemContextMenuSession/Bridge ; MainWindow.ItemContextMenu ; Plugin/Configuration/Settings ; ItemContextMenuTests ; ConfigSerializationProbe ; docs/USE-CONTEXT-004.md.
IN_SCOPE: Cibles Inventory, copie managée à l’ouverture, navigation au clic explicite vers Usages/Stocks/Craft/Récolte/Tous les outils, aucune requête réseau par le menu. SelectItem, historique et onglets existants conservés.
OUT_OF_SCOPE: Pointeurs au Draw, conversion de menus Default ou liens par heuristique, exécution craft/récolte ou prix implicites, revendication de validation native. Les 17 domaines restent PARTIAL dans l’objectif global.
VALIDATION: Verify.ps1 349/349 ; package/versions/ZIP/exclusion hôte verts, zéro avertissement/erreur ; Newtonsoft None/Auto/Objects. Source primaire Dalamud et SDK installés inspectés ; protocole runtime dans le document.
QUOTA: Relevé 2026-10-29 : 47 % disponibles sur 5 h et 54 % semaine ; réserve utilisateur 5 %. Objectif global actif.
NEXT_ACTION: Snapshot 0.53 puis SORT-NATIVE-002-STUDY : source SortaKinda et API locale avant application explicite des règles. Distinguer aperçu, ordre visuel et positions physiques. Garder l’inconnu GP ; essais projection/Macro Chain différés, ne pas les redemander.
DEFINITION_OF_DONE: Tranche intégrée compilée, tests/package verts, limites documentées et sauvegarde source ; aucun domaine global promu complet sans preuve.
