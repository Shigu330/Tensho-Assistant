# État courant

CURRENT_GOAL: USE-CONTEXT-004 — IMPLEMENTED / TESTED ; menu d’inventaire et cinq routes communes, voir docs/USE-CONTEXT-004.md
CURRENT_MODEL_CLASS: HEAVY — mutualisation du contexte et isolation des requêtes
RECOMMENDED_MODEL: HEAVY pour l’intégration native des menus/tri ; LIGHT pour les tâches mécaniques ; continuation autorisée
MODEL_ESCALATION: None
QUOTA: Relevé 2026-10-29 : 53 % consommés sur 5 h, 46 % semaine (47 % / 54 % disponibles). Réserve utilisateur 5 % ; objectif global actif.
LAST_READ: RULES/STATUS/GOAL et documents racine relus ; signatures locales et source officielle des menus inspectées. Tranche 0.52 documentée et sauvegardée.
BUILD: COMPILED Release 0.53.0.0 ; sortie canonique bin/x64/Release
TESTS: TESTED — 349/349 tests ; package/versions/ZIP/exclusion hôte verts, zéro avertissement/erreur. Six groupes menu et Newtonsoft v1 trois modes passants ; preuves des probes précédents conservées.
RUNTIME: Banque, stocks, carnet et préparation jusqu’à 0.5.27 confirmés par l’utilisateur. Fonctions 0.6–0.53 non validées en jeu. Tests projection et Macro Chain explicitement différés ; ne pas les redemander.
WORK_COMPLETED: Dix-sept domaines PARTIAL ; menu Inventory opt-in, objet/qualité copiés, cinq routes Usages/Stocks/Craft/Récolte/Tous les outils. Remplacement/logout/désactivation/âge/catalogue et Dispose contrôlés avant remise unique au Draw. Aucun nouveau poller natif ou réseau par le menu.
BLOCKER: Aucun blocage global. Le bonus natif d’Abondance reste inconnu : sources divergentes et aucun getter nommé confirmé dans les bindings étudiés. Ne pas inventer une formule ; travaux indépendants poursuivis.
RESUME_FROM: GOAL.md ; TESTING.md pour le protocole de la base.
NEXT_ACTION: Snapshot 0.53 puis SORT-NATIVE-002-STUDY : vérifier source SortaKinda et API locale avant application native explicite des règles. Distinguer aperçu sauvegardé, ordre visuel et positions physiques. GP inconnu et essais différés conservés.

| Plugin | Coverage |
|---|---|
| Avant-Garde | PARTIAL — répertoire manuel d'indices natifs, équipements signalés, emplacements/stock/contexte et source datée ; thème courant/teintures/score/attache non déduits |
| Blue Mage Helper | PARTIAL — grimoire, numéros, descriptions, lieux renseignés et acquisition confirmée |
| Character Panel Refined | PARTIAL — attributs natifs, sans formules dérivées |
| Collections | PARTIAL — montures, mascottes, emotes et cartes Triple Triade ; inconnu distinct d'absent |
| Craftimizer | PARTIAL — simulation/recherche/export/séquences, observation et projection d'un coup normal ; conditions/rotation native/recettes spéciales et runtime à compléter |
| Duty Loot Preview | PARTIAL — consultation manuelle par contenu, coffres/récompenses, icônes/contexte, provenance et cache ; drops directs non interprétés, données externes partielles |
| ezMiniCactpot | PARTIAL — solveur exact manuel et mode observé opt-in LotteryDaily ; conseil actualisé, aucune commande ; adaptation/rendu natifs non validés en jeu |
| GatherBuddy | PARTIAL — sources/maps/horaires/météo statiques et point courant observé opt-in (objets/icônes/taux affichés, contexte) ; présence/prérequis/harpon et validation native non couverts |
| Item Use | PARTIAL — recettes, mandats, candidats GC/aquarium, survol et menu Inventory opt-in ; autres usages/disponibilité, liens de discussion et runtime à compléter |
| LazyGatherer | PARTIAL — optimiseur manuel avec effets explicitement déclarés, observation du point et copie de ressources ; décodeur natif/bonus/régénération/procs/collectionnables et validation runtime à compléter |
| Macro Chain | PARTIAL — séquences à marqueur final, lancement explicite, arrêt, persistance ; natif à confirmer |
| Mappy | PARTIAL — navigateur natif, repères favoris persistants, ressources de zone et prévisions météo statiques ; météo forcée non observée |
| Monster Loot Hunter | PARTIAL — associations matériau/monstre, fiches/niveaux/lieux et carte de zone, transport/cadence partagés, contexte ; données communautaires partielles |
| Price Insight | PARTIAL — consultation manuelle et prix au survol opt-in, NQ/HQ/monde, cache/cadence/priorités partagés ; contexte mutualisé et scope owner/monde, runtime à confirmer |
| QuestTracker | PARTIAL — états natifs, séquence, fiche et liens de prérequis/suivantes ; disponibilité non calculée |
| SortaKinda | PARTIAL — aperçu de règles sauvegardées, sans déplacement natif |
| TriadBuddy | PARTIAL — carnet/deck/solveur manuel, observation des faces opt-in expérimentale ; identités/règles/trait natifs et autres règles non établis |

