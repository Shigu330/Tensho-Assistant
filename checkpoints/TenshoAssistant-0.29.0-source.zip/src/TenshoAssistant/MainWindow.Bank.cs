using System.Numerics;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.Inventory;
using TenshoAssistant.Items;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private sealed record BankItemRow(uint ItemId, long Nq, long Hq, string Locations);

    private static readonly StorageCategory[] StorageGroups =
        [StorageCategory.PlayerBags, StorageCategory.Chocobo, StorageCategory.Retainer];

    private static void DrawStorageGroups(ItemHoldingsSummary summary)
    {
        foreach (var category in StorageGroups)
        {
            var rows = summary.Rows.Where(row => row.Category == category).OrderBy(row => row.Name, StringComparer.Ordinal).ToArray();
            if (rows.Length == 0) continue;
            var label = category switch
            {
                StorageCategory.PlayerBags => "Personnage",
                StorageCategory.Chocobo => "Chocobo",
                _ => "Servants",
            };
            if (!ImGui.CollapsingHeader(label, ImGuiTreeNodeFlags.DefaultOpen)) continue;
            if (!ImGui.BeginTable($"StorageGroup{category}", 5,
                    ImGuiTableFlags.SizingStretchProp | ImGuiTableFlags.BordersInnerH | ImGuiTableFlags.RowBg)) continue;
            try
            {
                ImGui.TableSetupColumn("Rangement", ImGuiTableColumnFlags.WidthStretch, 2.2f);
                ImGui.TableSetupColumn("NQ", ImGuiTableColumnFlags.WidthStretch, 0.6f);
                ImGui.TableSetupColumn("HQ", ImGuiTableColumnFlags.WidthStretch, 0.6f);
                ImGui.TableSetupColumn("Total", ImGuiTableColumnFlags.WidthStretch, 0.8f);
                ImGui.TableSetupColumn("État / date UTC", ImGuiTableColumnFlags.WidthStretch, 1.8f);
                ImGui.TableHeadersRow();
                foreach (var row in rows)
                {
                    string Count(long count) => row.Coverage == InventoryCoverage.Unknown ? "—"
                        : row.Coverage == InventoryCoverage.Partial ? $"≥ {count:N0}" : count.ToString("N0");
                    ImGui.TableNextRow();
                    ImGui.TableNextColumn(); ImGui.TextWrapped(row.Name);
                    ImGui.TableNextColumn(); ImGui.TextUnformatted(Count(row.Nq));
                    ImGui.TableNextColumn(); ImGui.TextUnformatted(Count(row.Hq));
                    ImGui.TableNextColumn(); ImGui.TextUnformatted(Count(checked(row.Nq + row.Hq)));
                    ImGui.TableNextColumn();
                    if (row.Coverage == InventoryCoverage.Unknown) ImGui.TextWrapped("Non observé / non importé");
                    else
                    {
                        ImGui.TextColored(row.IsCached ? Accent : Success, row.IsCached ? "Cache manuel" : "En direct");
                        if (row.ObservedAt is { } observed) ImGui.TextWrapped(observed.ToString("yyyy-MM-dd HH:mm:ss"));
                    }
                }
            }
            finally { ImGui.EndTable(); }
            ImGui.Spacing();
        }
    }

    private void DrawImportManager()
    {
        if (!ImGui.CollapsingHeader("Imports & rangements enregistrés")) return;
        var state = bank.State;
        var menus = bankBridge.State;
        ImGui.TextWrapped("Ouvrez l'inventaire d'un servant ou la sacoche chocobo puis utilisez son panneau Tensho pour importer ou actualiser. Les boutons ci-dessous sont aussi disponibles tant que le rangement est ouvert.");
        DrawMenuImport(menus.Retainer);
        DrawMenuImport(menus.Saddlebag);
        if (menus.Premium?.Loaded == true) DrawMenuImport(menus.Premium);
        if (menus.Retainer is null && menus.Saddlebag is null)
            ImGui.TextDisabled("Aucun inventaire servant/chocobo ouvert actuellement.");
        if (menus.Message is { } message) ImGui.TextWrapped(message);
        if (state.Loading) ImGui.TextWrapped("Chargement des relevés sauvegardés…");
        if (state.Error is { } error) ImGui.TextWrapped(error);
        if (menus.CharacterId == 0)
        {
            ImGui.TextWrapped("Connectez un personnage pour retrouver ses relevés.");
            return;
        }
        var entries = state.Entries.Where(entry => entry.Key.CharacterId == menus.CharacterId)
            .OrderBy(entry => entry.Key.Kind).ThenBy(entry => entry.Name, StringComparer.Ordinal).ToArray();
        ImGui.TextUnformatted($"{entries.Length} rangement(s) importé(s) pour ce personnage");
        foreach (var entry in entries)
        {
            ImGui.BulletText(entry.Key.Kind == BankStorageKind.Retainer ? $"Servant : {entry.Name}" : entry.Name);
            ImGui.TextDisabled($"Dernier relevé : {entry.Snapshot.ObservedAt:yyyy-MM-dd HH:mm:ss} UTC");
        }
        ImGui.TextWrapped("Portée : sept pages servant et sacoches standard/supplémentaire importées. Équipement, cristaux et ventes du servant exclus. Chaque réimport remplace le relevé précédent.");
    }

    private void DrawBankBrowser()
    {
        ImGui.TextColored(Accent, "BANQUE D'OBJETS");
        ImGui.TextDisabled("Inventaire personnel, servants et sacoches importés · cliquez sur une ligne pour la mettre en contexte");
        ImGui.Separator();

        if (bank.State.Loading) ImGui.TextDisabled("Chargement des relevés sauvegardés…");
        if (bank.State.Error is { } bankError) ImGui.TextWrapped(bankError);
        ImGui.TextDisabled(bankPersonalFilter
            ? "Personnage en direct · actualisation automatique"
            : "Personnage en direct · autres rangements : relevés manuels, à réimporter après un transfert");

        var characterId = bankBridge.State.CharacterId;
        if (characterId == 0)
        {
            ImGui.TextWrapped("Connectez un personnage pour consulter sa banque importée.");
            return;
        }

        var entries = bank.State.Entries
            .Where(entry => entry.Key.CharacterId == characterId)
            .OrderBy(entry => entry.Key.Kind)
            .ThenBy(entry => entry.Name, StringComparer.Ordinal)
            .ToArray();
        if (ImGui.BeginTabBar("BankOriginTabs"))
        {
            try
            {
                if (ImGui.BeginTabItem("Global"))
                {
                    bankPersonalFilter = false;
                    bankOriginFilter = null;
                    ImGui.EndTabItem();
                }
                if (ImGui.BeginTabItem("Personnage"))
                {
                    bankPersonalFilter = true;
                    bankOriginFilter = null;
                    ImGui.EndTabItem();
                }
                for (var index = 0; index < entries.Length; index++)
                {
                    var entry = entries[index];
                    var label = entry.Key.Kind == BankStorageKind.Retainer ? $"Servant : {entry.Name}" : entry.Name;
                    if (ImGui.BeginTabItem($"{label}##BankOrigin{index}"))
                    {
                        bankPersonalFilter = false;
                        bankOriginFilter = entry.Key;
                        ImGui.EndTabItem();
                    }
                }
            }
            finally { ImGui.EndTabBar(); }
        }
        var selectedEntries = bankOriginFilter is { } origin
            ? entries.Where(entry => entry.Key == origin).ToArray()
            : entries;

        var rows = new Dictionary<uint, (long Nq, long Hq, HashSet<string> Locations)>();
        var personalSnapshot = inventory.Current;
        var personalContainers = bankOriginFilter is null && personalSnapshot is not null
            ? personalSnapshot.Containers.Values.Where(container =>
                container.Location.Owner.Value == characterId && container.Location.Container.Value is >= 0 and <= 3)
                .OrderBy(container => container.Location.Container.Value).ToArray()
            : [];
        var sources = personalContainers.Select(container => (Name: "Inventaire personnel", Container: container))
            .Concat(bankPersonalFilter ? [] : selectedEntries.SelectMany(entry => entry.Snapshot.Containers.Values
                .Select(container => (Name: entry.Name, Container: container))));
        foreach (var source in sources)
        foreach (var quantity in source.Container.Quantities)
        {
            var row = rows.GetValueOrDefault(quantity.Key.Id.Value);
            row.Locations ??= new(StringComparer.Ordinal);
            row.Locations.Add(source.Name);
            if (quantity.Key.IsHighQuality) row.Hq = checked(row.Hq + quantity.Value);
            else row.Nq = checked(row.Nq + quantity.Value);
            rows[quantity.Key.Id.Value] = row;
        }

        ImGui.SetNextItemWidth(180);
        var nativeCategories = rows.Keys
            .Select(id => itemCatalog.State.Catalog?.Find(id)?.UiCategoryName)
            .Where(name => !string.IsNullOrWhiteSpace(name))
            .Select(name => name!)
            .Distinct(StringComparer.Ordinal)
            .OrderBy(name => name, StringComparer.Ordinal)
            .ToArray();
        var categoryLabel = string.IsNullOrWhiteSpace(bankCategoryFilter) ? "Toutes les catégories" : bankCategoryFilter;
        if (ImGui.BeginCombo("Catégorie##BankCategory", categoryLabel))
        {
            try
            {
                if (ImGui.Selectable("Toutes les catégories", string.IsNullOrWhiteSpace(bankCategoryFilter)))
                    bankCategoryFilter = string.Empty;
                foreach (var category in nativeCategories)
                    if (ImGui.Selectable(category, bankCategoryFilter == category)) bankCategoryFilter = category;
            }
            finally { ImGui.EndCombo(); }
        }
        ImGui.SameLine();
        ImGui.SetNextItemWidth(140);
        var qualityLabel = bankQualityFilter switch { 1 => "NQ uniquement", 2 => "HQ uniquement", _ => "NQ + HQ" };
        if (ImGui.BeginCombo("Qualité##BankQuality", qualityLabel))
        {
            try
            {
                foreach (var option in new[] { (0, "NQ + HQ"), (1, "NQ uniquement"), (2, "HQ uniquement") })
                    if (ImGui.Selectable(option.Item2, bankQualityFilter == option.Item1)) bankQualityFilter = option.Item1;
            }
            finally { ImGui.EndCombo(); }
        }
        ImGui.SameLine();
        if (ImGui.SmallButton("Réinitialiser##BankFilters"))
        {
            bankCategoryFilter = string.Empty;
            bankQualityFilter = 0;
            bankQuery = string.Empty;
        }
        ImGui.SameLine();
        ImGui.SetNextItemWidth(-1);
        ImGui.InputTextWithHint("##BankQuery", "Rechercher dans la banque…", ref bankQuery, 128);

        var allVisible = rows.Select(pair =>
            {
                var item = itemCatalog.State.Catalog?.Find(pair.Key);
                return new BankItemRow(pair.Key, pair.Value.Nq, pair.Value.Hq, string.Join(", ", pair.Value.Locations));
            })
            .Where(MatchesBankFilters)
            .OrderBy(row => itemCatalog.State.Catalog?.Find(row.ItemId)?.Name ?? $"Objet {row.ItemId}", StringComparer.Ordinal)
            .ToArray();

        if (allVisible.Length == 0)
        {
            ImGui.TextDisabled("Aucun objet ne correspond à cette recherche.");
            return;
        }
        var sourceGroups = new List<(string Name, InventoryContainerSnapshot Container)>();
        if (bankOriginFilter is null) AddDisplayFrames("Personnage", personalContainers, sourceGroups);
        if (!bankPersonalFilter)
            foreach (var entry in selectedEntries)
                AddDisplayFrames($"{entry.Name} ({entry.Snapshot.ObservedAt:HH:mm} UTC)", entry.Snapshot.Containers.Values, sourceGroups);
        DrawInventoryFrames(sourceGroups);
        return;

    }

    private void AddDisplayFrames(string name, IEnumerable<InventoryContainerSnapshot> containers,
        List<(string Name, InventoryContainerSnapshot Container)> frames)
    {
        var copied = containers.ToArray();
        if (copied.Length == 0) return;
        try
        {
            var pages = InventoryDisplayLayout.Build(copied);
            for (var page = 0; page < pages.Count; page++)
            {
                var positioned = pages[page].Select((stack, index) => (stack, index))
                    .Where(pair => pair.stack.HasValue)
                    .Select(pair => pair.stack!.Value with { Slot = pair.index });
                frames.Add(($"{name} · Sac {page + 1}", new InventoryContainerSnapshot(
                    copied[0].Location, copied.All(c => c.Coverage == InventoryCoverage.Complete)
                        ? InventoryCoverage.Complete : InventoryCoverage.Partial, positioned)));
            }
        }
        catch (InvalidOperationException)
        {
            ImGui.TextWrapped($"{name} : ordre visuel indisponible. Réimportez le rangement ouvert.");
        }
    }

    private void DrawInventoryFrames(IReadOnlyList<(string Name, InventoryContainerSnapshot Container)> groups)
    {
        if (groups.Count == 0)
        {
            ImGui.TextDisabled("Inventaire personnel indisponible ou pas encore observé.");
            return;
        }
        const int columns = 5;
        const int rows = 7;
        const float slotSize = 42;
        const float frameWidth = columns * 46 + 12;
        const float frameHeight = rows * 46 + 48;
        var filtering = !string.IsNullOrWhiteSpace(bankCategoryFilter)
            || bankQualityFilter != 0 || !string.IsNullOrWhiteSpace(bankQuery);
        var displayedFrames = 0;
        for (var groupIndex = 0; groupIndex < groups.Count; groupIndex++)
        {
            var group = groups[groupIndex];
            var items = GetContainerRows(group.Container, rows * columns);
            if (filtering && !items.Any(item => item is not null)) continue;
            // FFXIV lays out the four personal bags as a 2 x 2 set of 5 x 7 frames.
            if (displayedFrames % 2 != 0) ImGui.SameLine();
            displayedFrames++;
            if (!ImGui.BeginChild($"BankFrame{groupIndex}", new Vector2(frameWidth, frameHeight), true,
                    ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoScrollWithMouse))
            {
                ImGui.EndChild();
                continue;
            }
            try
            {
                ImGui.TextColored(Accent, group.Name);
                ImGui.PushStyleVar(ImGuiStyleVar.CellPadding, new Vector2(2, 2));
                if (ImGui.BeginTable($"BankFrameGrid{groupIndex}", columns, ImGuiTableFlags.SizingFixedFit))
                {
                    try
                    {
                        for (var rowIndex = 0; rowIndex < rows; rowIndex++)
                        {
                            for (var columnIndex = 0; columnIndex < columns; columnIndex++)
                            {
                                ImGui.TableNextColumn();
                                var itemIndex = rowIndex * columns + columnIndex;
                                ImGui.PushID(itemIndex);
                                try
                                {
                                if (itemIndex < items.Length && items[itemIndex] is { } item)
                                    DrawBankSlot(item, slotSize);
                                else
                                {
                                    var corner = ImGui.GetCursorScreenPos();
                                    ImGui.GetWindowDrawList().AddRectFilled(corner, corner + new Vector2(slotSize),
                                        ImGui.GetColorU32(ImGuiCol.FrameBg), 4);
                                    ImGui.Dummy(new Vector2(slotSize));
                                }
                                }
                                finally { ImGui.PopID(); }
                            }
                        }
                    }
                    finally { ImGui.EndTable(); }
                }
                ImGui.PopStyleVar();
            }
            finally { ImGui.EndChild(); }
        }
        if (filtering && displayedFrames == 0) ImGui.TextDisabled("Aucun sac ne contient d'objet correspondant aux filtres.");
    }

    private BankItemRow?[] GetContainerRows(InventoryContainerSnapshot container, int capacity)
    {
        var result = new BankItemRow?[capacity];
        foreach (var stack in container.Stacks)
        {
            var row = new BankItemRow(stack.Item.Id.Value,
                stack.Item.IsHighQuality ? 0 : stack.Quantity,
                stack.Item.IsHighQuality ? stack.Quantity : 0, "");
            if (stack.Slot >= 0 && stack.Slot < capacity && MatchesBankFilters(row)) result[stack.Slot] = row;
        }
        return result;
    }

    private bool MatchesBankFilters(BankItemRow row)
    {
        var item = itemCatalog.State.Catalog?.Find(row.ItemId);
        var categoryMatch = string.IsNullOrWhiteSpace(bankCategoryFilter)
            || string.Equals(item?.UiCategoryName, bankCategoryFilter, StringComparison.Ordinal);
        var qualityMatch = bankQualityFilter switch
        {
            1 => row.Nq > 0,
            2 => row.Hq > 0,
            _ => true,
        };
        var query = bankQuery.Trim();
        return categoryMatch && qualityMatch && (string.IsNullOrWhiteSpace(query)
            || (item?.Name?.Contains(query, StringComparison.OrdinalIgnoreCase) ?? false)
            || row.ItemId.ToString().Contains(query, StringComparison.OrdinalIgnoreCase));
    }

    private void DrawBankSlot(BankItemRow row, float slotSize)
    {
        var item = itemCatalog.State.Catalog?.Find(row.ItemId);
        ImGui.PushID((int)row.ItemId);
        try
        {
            var slotMin = ImGui.GetCursorScreenPos();
            var slotMax = slotMin + new Vector2(slotSize);
            var drawList = ImGui.GetWindowDrawList();
            drawList.AddRectFilled(slotMin, slotMax, ImGui.GetColorU32(itemId == (int)row.ItemId ? ImGuiCol.FrameBgActive : ImGuiCol.FrameBg), 4);
            ImGui.SetCursorScreenPos(slotMin + new Vector2(3));
            DrawItemIcon(item, new Vector2(slotSize - 6));
            if (ImGui.IsItemClicked()) SelectItem(row.ItemId);
            if (ImGui.IsItemHovered())
                ImGui.SetTooltip($"{item?.Name ?? $"Objet {row.ItemId}"}\nNQ : {row.Nq:N0} · HQ : {row.Hq:N0}\nCliquer pour sélectionner");
            var count = checked(row.Nq + row.Hq).ToString("N0");
            var countSize = ImGui.CalcTextSize(count);
            var countPosition = new Vector2(slotMax.X - countSize.X - 3, slotMax.Y - countSize.Y - 2);
            drawList.AddRectFilled(countPosition - new Vector2(2, 1), slotMax - new Vector2(1, 1), ImGui.GetColorU32(ImGuiCol.PopupBg));
            drawList.AddText(countPosition, ImGui.GetColorU32(ImGuiCol.Text), count);
        }
        finally { ImGui.PopID(); }
    }

    private void DrawMenuImport(BankMenuContext? context)
    {
        if (context is null) return;
        var disabled = !context.Loaded || bank.State.Loading || bank.State.Importing || bank.State.Error is not null;
        ImGui.BeginDisabled(disabled);
        try
        {
            if (ImGui.Button($"Actualiser : {context.Name}##{context.Key.Kind}", new Vector2(-1, 28)))
                bankBridge.RequestImport(context.Key);
        }
        finally { ImGui.EndDisabled(); }
        if (!context.Loaded) ImGui.TextDisabled("Attente du chargement complet de ce rangement.");
    }
}
