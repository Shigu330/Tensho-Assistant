using System.Numerics;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.Macros;
using TenshoAssistant.Items;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private readonly List<MacroSlot> macroPlan = [];
    private bool macroPlanLoaded;
    private int macroBook;
    private bool macroPlanSaved;
    private string? macroPlanError;
    private void DrawMacroChain()
    {
        Heading("Enchaînement de macros", "Choisissez des macros du jeu, puis lancez explicitement leur séquence");
        if (!macroPlanLoaded)
        {
            macroPlan.AddRange((configuration.MacroChainPlan ?? []).Where(slot => slot is not null && slot.Book <= 1 && slot.Index < 100).Take(32));
            macroPlanLoaded = true; macroChain.RequestRefresh();
        }
        var state = macroChain.State;
        var active = state.Sequence.Status is MacroSequenceStatus.Ready or MacroSequenceStatus.AwaitingStart or MacroSequenceStatus.Running;
        ImGui.TextWrapped("Chaque macro doit finir par /tenshonext sur une ligne séparée. Ajoutez cette ligne vous-même dans le menu Macros du jeu ; Tensho ne modifie pas les macros enregistrées. Ce marqueur déclenche la suite, sans garantir le succès des actions du jeu.");
        if (ImGui.SmallButton("Copier /tenshonext")) ImGui.SetClipboardText(MacroDefinition.Marker);
        ImGui.SameLine();
        if (ImGui.SmallButton("Actualiser les macros")) macroChain.RequestRefresh();
        if (state.Loading) ImGui.TextDisabled("Lecture des macros en cours…");
        if (state.CharacterId == 0) ImGui.TextDisabled("Connectez un personnage pour consulter ses macros.");
        if (state.Error is { } error) DrawMacroWrappedText(error);
        ImGui.TextColored(active ? Accent : Muted, $"{MacroStatus(state.Sequence.Status)} · {state.Sequence.Completed}/{state.Sequence.Plan.Count} étape(s)");
        if (state.Sequence.Message is { } message) DrawMacroWrappedText(message);
        ImGui.TextDisabled("Version expérimentale : fonctionnement natif à confirmer en jeu.");
        ImGui.BeginDisabled(active);
        try
        {
            if (ImGui.RadioButton("Personnelles", macroBook == 0)) macroBook = 0;
            ImGui.SameLine(); if (ImGui.RadioButton("Partagées", macroBook == 1)) macroBook = 1;
            var visible = ImGui.BeginChild("MacroCatalog", new Vector2(0, 190), true);
            try
            {
                if (visible)
                foreach (var macro in state.Catalog.Where(row => row.Slot.Book == macroBook))
                {
                    ImGui.PushID($"Macro{macro.Slot.Book}/{macro.Slot.Index}");
                    try
                    {
                        DrawItemIcon(new ItemDefinition(0, macro.Slot.Name, false, macro.IconId), new Vector2(24));
                        ImGui.SameLine();
                        if (ImGui.SmallButton($"Ajouter##{macro.Slot.Index}") && macroPlan.Count < 32)
                        { macroPlan.Add(macro.Slot); macroPlanSaved = false; }
                        ImGui.SameLine(); ImGui.TextUnformatted($"{macro.Slot.Index} · {macro.Slot.Name}");
                        if (macro.ValidationError() is { } validation)
                        { ImGui.SameLine(); ImGui.TextColored(Accent, "Marqueur requis"); if (ImGui.IsItemHovered()) ImGui.SetTooltip(validation); }
                    }
                    finally { ImGui.PopID(); }
                }
            }
            finally { ImGui.EndChild(); }
            ImGui.TextColored(Accent, $"Séquence ({macroPlan.Count}/32)");
            var showPlan = ImGui.BeginChild("MacroPlan", new Vector2(0, 160), true);
            try
            {
                if (showPlan)
                for (var index = 0; index < macroPlan.Count; index++)
                {
                    var slot = macroPlan[index];
                    ImGui.PushID(index);
                    var remove = false;
                    try
                    {
                        if (ImGui.SmallButton("Retirer")) remove = true;
                        ImGui.SameLine();
                        if (index > 0 && ImGui.SmallButton("↑"))
                        { (macroPlan[index - 1], macroPlan[index]) = (macroPlan[index], macroPlan[index - 1]); macroPlanSaved = false; }
                        ImGui.SameLine(); ImGui.TextUnformatted($"{index + 1}. {(slot.Book == 0 ? "Personnel" : "Partagé")} {slot.Index} · {slot.Name}");
                    }
                    finally { ImGui.PopID(); }
                    if (remove) { macroPlan.RemoveAt(index); index--; macroPlanSaved = false; }
                }
            }
            finally { ImGui.EndChild(); }
            if (ImGui.Button("Enregistrer la séquence"))
            {
                var previous = configuration.MacroChainPlan ?? [];
                configuration.MacroChainPlan = macroPlan.ToList();
                try { save(); macroPlanSaved = true; macroPlanError = null; }
                catch (Exception exception)
                { configuration.MacroChainPlan = previous; macroPlanError = "Échec de sauvegarde de la séquence."; log.Warning(exception, "Could not save macro chain plan."); }
            }
            ImGui.SameLine();
            ImGui.BeginDisabled(macroPlan.Count == 0 || state.CharacterId == 0 || state.Loading);
            try { if (ImGui.Button("Lancer la séquence")) macroChain.RequestStart(macroPlan); }
            finally { ImGui.EndDisabled(); }
        }
        finally { ImGui.EndDisabled(); }
        if (active && ImGui.Button("Arrêter l'enchaînement")) macroChain.RequestCancel();
        ImGui.TextWrapped("Arrêter l'enchaînement supprime les étapes suivantes ; la macro courante peut finir dans le jeu. Aucune reprise automatique après interruption ou changement de personnage.");
        if (macroPlanSaved) ImGui.TextColored(Success, "Séquence enregistrée.");
        if (macroPlanError is { } saveMessage) ImGui.TextWrapped(saveMessage);
    }
    private static string MacroStatus(MacroSequenceStatus status) => status switch
    {
        MacroSequenceStatus.Ready => "Prêt à lancer l'étape suivante",
        MacroSequenceStatus.AwaitingStart => "Étape lancée · attente du marqueur de fin",
        MacroSequenceStatus.Running => "Étape en cours",
        MacroSequenceStatus.Complete => "Tous les marqueurs ont été reçus",
        MacroSequenceStatus.Cancelled => "Enchaînement arrêté",
        MacroSequenceStatus.Failed => "Enchaînement interrompu",
        _ => "Au repos",
    };
    private static void DrawMacroWrappedText(string text)
    {
        ImGui.PushTextWrapPos(0);
        try { ImGui.TextUnformatted(text); }
        finally { ImGui.PopTextWrapPos(); }
    }
}
