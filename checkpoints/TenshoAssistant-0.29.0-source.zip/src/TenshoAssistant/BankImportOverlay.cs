using System.Numerics;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.Inventory;

namespace TenshoAssistant;

/// <summary>Companion panels attached to visible game menus; native pointers never enter Draw.</summary>
internal sealed class BankImportOverlay(InventoryBankService bank, BankInventoryBridge bridge)
{
    public void Draw()
    {
        var menus = bridge.State;
        if (menus.Retainer is { } retainer) DrawPanel("Retainer", retainer, null, menus.Message);
        if (menus.Saddlebag is { } saddle) DrawPanel("Chocobo", saddle, menus.Premium, menus.Message);
    }

    private void DrawPanel(string id, BankMenuContext context, BankMenuContext? premium, string? message)
    {
        var viewport = ImGui.GetMainViewport();
        var position = viewport.Pos + context.Anchor;
        var minimum = viewport.WorkPos;
        var maximum = Vector2.Max(minimum, viewport.WorkPos + viewport.WorkSize - new Vector2(330, premium is null ? 170 : 240));
        position = Vector2.Clamp(position, minimum, maximum);
        ImGui.SetNextWindowPos(position, ImGuiCond.Always);
        ImGui.SetNextWindowSize(new Vector2(330, 0), ImGuiCond.Always);
        var visible = ImGui.Begin($"Banque d'objets###TenshoBankImport{id}",
            ImGuiWindowFlags.NoDecoration | ImGuiWindowFlags.NoMove | ImGuiWindowFlags.NoSavedSettings
            | ImGuiWindowFlags.AlwaysAutoResize | ImGuiWindowFlags.NoFocusOnAppearing);
        try
        {
            if (!visible) return;
            ImGui.TextUnformatted("TENSHO · Banque d'objets");
            DrawSource(context);
            if (premium is not null && premium.Loaded)
            {
                ImGui.Separator();
                DrawSource(premium);
            }
            if (message is not null) ImGui.TextWrapped(message);
            if (bank.State.Error is { } error) ImGui.TextWrapped(error);
        }
        finally { ImGui.End(); }
    }

    private void DrawSource(BankMenuContext context)
    {
        ImGui.TextWrapped(context.Name);
        var existing = bank.State.Entries.FirstOrDefault(entry => entry.Key == context.Key);
        ImGui.TextDisabled(existing is null ? "Jamais importé" : $"Cache : {existing.Snapshot.ObservedAt:yyyy-MM-dd HH:mm:ss} UTC");
        var disabled = !context.Loaded || bank.State.Loading || bank.State.Importing || bank.State.Error is not null;
        ImGui.BeginDisabled(disabled);
        try
        {
            if (ImGui.Button($"Importer / actualiser##{context.Key.Kind}", new Vector2(-1, 28))) bridge.RequestImport(context.Key);
        }
        finally { ImGui.EndDisabled(); }
        if (!context.Loaded) ImGui.TextWrapped("Attente du chargement complet de l'inventaire…");
    }
}
