using Dalamud.Bindings.ImGui;
using TenshoAssistant.Inventory;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private void DrawSettings()
    {
        Heading("Réglages", "Choisissez quand la fenêtre s'ouvre. Les deux options sont indépendantes et sauvegardées immédiatement.");
        var openOnLoad = configuration.OpenOnLoad;
        var openOnLogin = configuration.OpenOnLogin;
        var loadChanged = ImGui.Checkbox("Ouvrir au chargement du plugin", ref openOnLoad);
        ImGui.TextDisabled("À l'activation ou au rechargement de Tensho--Assistant.");
        ImGui.Spacing();
        var loginChanged = ImGui.Checkbox("Ouvrir à la connexion du personnage", ref openOnLogin);
        ImGui.TextDisabled("À chaque connexion ou reconnexion d'un personnage.");
        if (loadChanged || loginChanged)
        {
            var previous = configuration.OpenOnLoad;
            var previousLogin = configuration.OpenOnLogin;
            configuration.OpenOnLoad = openOnLoad;
            configuration.OpenOnLogin = openOnLogin;
            try
            {
                save();
                saveError = null;
            }
            catch (Exception error)
            {
                configuration.OpenOnLoad = previous;
                configuration.OpenOnLogin = previousLogin;
                saveError = "Échec de sauvegarde. Réessayez ; les détails sont dans le journal Dalamud.";
                log.Error(error, "Could not persist Tensho configuration.");
            }
        }
        if (saveError is not null) ImGui.TextWrapped(saveError);
        ImGui.Spacing(); ImGui.Separator();
        var hoverPrices = configuration.MarketPricesOnHover;
        if (ImGui.Checkbox("Afficher les prix au survol des objets en jeu", ref hoverPrices))
        {
            var previous = configuration.MarketPricesOnHover;
            configuration.MarketPricesOnHover = hoverPrices;
            try { save(); saveError = null; if (!hoverPrices) market.CancelBackground(); }
            catch (Exception error)
            { configuration.MarketPricesOnHover = previous; saveError = "Échec de sauvegarde de l'option de prix."; log.Warning(error, "Could not save market hover preference."); }
        }
        ImGui.TextWrapped("Désactivé par défaut. Après un survol stable, consulte Universalis avec les seuls identifiants publics d'objet et de monde. Cache partagé de cinq minutes ; au plus une requête réseau toutes les trois secondes pour les prix manuels et au survol réunis.");
        ImGui.Spacing();
        ImGui.Separator();
        ImGui.TextWrapped("Vous pouvez toujours ouvrir la fenêtre avec /tensho. Les autres outils seront ajoutés progressivement.");
    }

    private void DrawDiagnostics()
    {
        Heading("Diagnostics", "État et provenance des données communes. Ces informations facilitent les vérifications en jeu.");
        ImGui.TextUnformatted($"Plugin : {BuildVersion} · Configuration : v{configuration.Version}");
        DrawMacroObservation();
        ImGui.Spacing();
        ImGui.TextColored(Accent, "Catalogue d'objets");
        DrawCatalogStatus();
        if (itemCatalog.State.Catalog is { } catalog)
        {
            ImGui.TextUnformatted($"Génération : {catalog.Metadata.Generation}");
            ImGui.TextWrapped($"Source : {catalog.Metadata.Source}");
            ImGui.TextWrapped($"Version des données : {catalog.Metadata.DataVersion}");
        }
        ImGui.Spacing();
        ImGui.TextColored(Accent, "Catalogue de recettes");
        var recipeState = recipeCatalog.State;
        if (recipeState.Catalog is { } recipes)
            ImGui.TextColored(Success, $"Catalogue prêt : {recipes.Count:N0} recettes · source {recipes.Source}");
        else if (recipeState.Error is { } recipeError)
            ImGui.TextWrapped($"Erreur : {recipeError}");
        else if (recipeState.TotalRows > 0)
            ImGui.TextWrapped($"Chargement : {recipeState.RowsCopied:N0}/{recipeState.TotalRows:N0} lignes copiées.");
        else
            ImGui.TextDisabled("Catalogue de recettes en préparation…");
        ImGui.Spacing();
        ImGui.Separator();
        var gathering = gatheringCatalog.State;
        ImGui.TextColored(Accent, "Catalogue de récolte");
        var mapState = maps.State;
        ImGui.TextDisabled(mapState.Catalog is { } mapCatalog ? $"Cartes : {mapCatalog.Entries.Count:N0} entrées natives"
            : mapState.Error ?? $"Cartes : {mapState.Copied:N0}/{mapState.Total:N0}");
        if (gathering.Catalog is { } gathered)
        {
            ImGui.TextColored(Success, $"Catalogue prêt : {gathered.Count:N0} liens objet/lieu");
            ImGui.TextWrapped($"Source : GatheringItem → GatheringPointBase → GatheringPoint + FishingSpot ; {gathered.Source}");
        }
        else ImGui.TextWrapped(gathering.Error ?? $"Chargement : {gathering.Copied:N0}/{gathering.Total:N0} points");
        ImGui.Spacing();
        ImGui.TextColored(Accent, "Collections, quêtes et services consultatifs");
        ImGui.TextDisabled($"Collections : {collections.State.Entries.Count:N0} entrées · personnage {collections.State.CharacterId} · lecture {collections.State.Loading}");
        if (collections.State.Error is { } collectionError) ImGui.TextWrapped(collectionError);
        ImGui.TextDisabled($"Quêtes : {quests.State.Entries.Count:N0} entrées · personnage {quests.State.CharacterId} · lecture {quests.State.Loading}");
        if (quests.State.Error is { } questError) ImGui.TextWrapped(questError);
        ImGui.TextDisabled($"Marché : monde {market.State.WorldName} · survol {(configuration.MarketPricesOnHover ? "activé" : "désactivé")}");
        if (market.State.Error is { } marketError) ImGui.TextWrapped(marketError);
        var stats = characterStats.State;
        ImGui.TextDisabled(stats.CharacterId == 0 ? "Attributs : aucune observation" : $"Attributs : {stats.Values.Count} valeurs · {stats.ObservedAt:HH:mm:ss} UTC");
        ImGui.TextDisabled(cactpotTask is { IsCompleted: false } ? "Mini Cactpot : calcul en cours" : "Mini Cactpot : calcul manuel, sans lecture native du ticket");
        var chain = craftChain.State;
        ImGui.TextDisabled(chain.Loading ? "Sous-recettes : calcul en cours" : chain.Result is { } chainResult
            ? $"Sous-recettes : {chainResult.Steps.Count} étapes · calcul {chain.CalculatedAt:HH:mm:ss} UTC"
            : "Sous-recettes : calcul manuel sur observations capturées");
        if (chain.Error is { } chainError) ImGui.TextWrapped(chainError);
        ImGui.Spacing();
        ImGui.TextColored(Accent, "Banque d'objets");
        var bankState = bank.State;
        ImGui.TextWrapped(bankState.Loading ? "Chargement du fichier…"
            : bankState.Error ?? $"{bankState.Entries.Count} relevés sauvegardés, tous personnages confondus.");
        ImGui.TextUnformatted(bankState.Importing ? "Écriture d'un import en cours." : "Actualisation manuelle uniquement.");
        var menus = bankBridge.State;
        ImGui.TextWrapped($"Fenêtre servant détectée : {menus.Retainer?.AddonName ?? "aucune"}");
        ImGui.TextWrapped($"Fenêtre chocobo détectée : {menus.Saddlebag?.AddonName ?? "aucune"}");
        if (menus.Message is { } message) ImGui.TextWrapped(message);
        ImGui.Spacing();
        ImGui.Separator();
        ImGui.TextColored(Accent, "Inventaire du personnage");
        var snapshot = inventory.Current;
        if (snapshot is null)
        {
            ImGui.TextWrapped("Inconnu : aucune observation valide actuellement publiée.");
            return;
        }
        ImGui.TextUnformatted($"Observation : {snapshot.ObservedAt:yyyy-MM-dd HH:mm:ss} UTC");
        ImGui.TextWrapped($"Source : {snapshot.Source}");
        foreach (var container in snapshot.Containers.Values.OrderBy(c => c.Location.Container.Value))
        {
            var state = container.Coverage switch
            {
                InventoryCoverage.Complete => "complet",
                InventoryCoverage.Partial => "partiel",
                _ => "inconnu",
            };
            var name = container.Location.Container.Value == 2001
                ? "Cristaux"
                : $"Sac {container.Location.Container.Value + 1}";
            ImGui.TextUnformatted($"{name} : {state}");
        }
        ImGui.TextWrapped("Cette observation couvre les quatre sacs et le rangement des cristaux, pas tous les autres rangements du personnage.");
    }
}
