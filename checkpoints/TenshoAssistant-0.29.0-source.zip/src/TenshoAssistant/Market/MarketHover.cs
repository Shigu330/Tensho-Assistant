using TenshoAssistant.Items;

namespace TenshoAssistant.Market;

public sealed record MarketHoverItem(uint ItemId, bool Hq);
public sealed class MarketHoverTracker
{
    private ulong owner;
    private uint world;
    private DateTimeOffset stableSince;
    private DateTimeOffset nextAttempt;
    public MarketHoverItem? Current { get; private set; }
    public static MarketHoverItem? Normalize(ulong raw, ItemCatalog? catalog)
    {
        if (raw == 0 || catalog is null) return null;
        var hq = raw > 1000000;
        var id = hq ? raw - 1000000 : raw;
        if (id > uint.MaxValue || catalog.Find((uint)id) is not { IsMarketable: true } item || (hq && !item.CanBeHq)) return null;
        return new(item.Id, hq);
    }
    public bool Observe(bool enabled, ulong character, uint worldId, ulong raw, ItemCatalog? catalog, DateTimeOffset now)
    {
        var item = enabled && character != 0 && worldId != 0 ? Normalize(raw, catalog) : null;
        var changed = owner != character || world != worldId || item != Current;
        if (changed) { owner = character; world = worldId; Current = item; stableSince = now; nextAttempt = now; }
        return changed;
    }
    public bool TakeRequest(DateTimeOffset now)
    {
        if (Current is null || now - stableSince < TimeSpan.FromMilliseconds(600) || now < nextAttempt) return false;
        nextAttempt = now.AddSeconds(5); return true;
    }
}

public sealed class MarketHoverService
{
    private MarketHoverItem? current;
    public MarketHoverItem? Current => Volatile.Read(ref current);
    internal void Publish(MarketHoverItem? item) => Interlocked.Exchange(ref current, item);
}
