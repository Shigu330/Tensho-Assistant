using Dalamud.Plugin.Services;
using TenshoAssistant.Items;

namespace TenshoAssistant.Market;

internal sealed class MarketHoverReader : IDisposable
{
    private readonly object gate = new();
    private readonly Configuration configuration;
    private readonly MarketService market;
    private readonly MarketHoverService service;
    private readonly ItemCatalogService items;
    private readonly IGameGui gameGui;
    private readonly IPlayerState player;
    private readonly IClientState client;
    private readonly IFramework framework;
    private readonly IPluginLog log;
    private readonly MarketHoverTracker tracker = new();
    private bool disposed;
    private DateTimeOffset retryAt;
    public MarketHoverReader(Configuration configuration, MarketService market, MarketHoverService service, ItemCatalogService items,
        IGameGui gameGui, IPlayerState player, IClientState client, IFramework framework, IPluginLog log)
    {
        this.configuration = configuration; this.market = market; this.service = service; this.items = items;
        this.gameGui = gameGui; this.player = player; this.client = client; this.framework = framework; this.log = log;
        framework.Update += Update;
    }
    private void Update(IFramework unusedFramework)
    {
        lock (gate)
        {
            if (disposed || !framework.IsInFrameworkUpdateThread || framework.IsFrameworkUnloading) return;
            var now = DateTimeOffset.UtcNow;
            if (now < retryAt) return;
            try
            {
                var character = client.IsLoggedIn && player.IsLoaded ? player.ContentId : 0;
                var world = market.State.WorldId;
                var raw = configuration.MarketPricesOnHover && character != 0 ? gameGui.HoveredItem : 0;
                if (tracker.Observe(configuration.MarketPricesOnHover, character, world, raw, items.State.Catalog, now)) market.CancelBackground();
                service.Publish(tracker.Current);
                var pending = market.BackgroundState;
                if (pending is { RetryAt: { } retry } && tracker.Current is { } current
                    && pending.ItemId == current.ItemId && pending.WorldId == world && retry > now) return;
                if (tracker.TakeRequest(now) && tracker.Current is { } item)
                {
                    var cached = market.GetCached(world, item.ItemId);
                    if (cached is null || now - cached.FetchedAt >= TimeSpan.FromMinutes(5)) _ = market.RequestAsync(item.ItemId, background: true);
                }
            }
            catch (Exception error)
            {
                service.Publish(null); market.CancelBackground(); retryAt = now.AddSeconds(5);
                log.Warning(error, "Tensho hovered market item unavailable; retry in five seconds.");
            }
        }
    }
    public void Dispose()
    {
        lock (gate)
        {
            if (disposed) return;
            disposed = true; framework.Update -= Update; service.Publish(null); market.CancelBackground();
        }
    }
}
