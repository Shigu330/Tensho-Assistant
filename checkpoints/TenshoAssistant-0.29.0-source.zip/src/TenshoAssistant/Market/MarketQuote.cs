using System.Text.Json;

namespace TenshoAssistant.Market;

public sealed record MarketQualityPrice(decimal? Minimum, decimal? RecentSale, DateTimeOffset? SaleAt);
public sealed record MarketQuote(uint WorldId, uint ItemId, DateTimeOffset FetchedAt, DateTimeOffset? UploadedAt,
    MarketQualityPrice Nq, MarketQualityPrice Hq)
{
    public bool HasRecentUpload(DateTimeOffset now) => UploadedAt is { } date
        && date <= now.AddMinutes(5) && now - date <= TimeSpan.FromHours(24);

    public static MarketQuote Parse(string json, uint worldId, uint itemId, DateTimeOffset fetchedAt)
    {
        using var document = JsonDocument.Parse(json, new JsonDocumentOptions { MaxDepth = 32 });
        var root = document.RootElement;
        if (!root.TryGetProperty("results", out var results) || results.ValueKind != JsonValueKind.Array)
            throw new InvalidDataException("Réponse Universalis invalide.");
        foreach (var row in results.EnumerateArray())
        {
            if (!row.TryGetProperty("itemId", out var id) || id.GetUInt32() != itemId) continue;
            DateTimeOffset? upload = null;
            if (row.TryGetProperty("worldUploadTimes", out var times))
                foreach (var time in times.EnumerateArray())
                    if (time.GetProperty("worldId").GetUInt32() == worldId) upload = Timestamp(time, "timestamp");
            return new(worldId, itemId, fetchedAt.ToUniversalTime(), upload, ReadQuality(row, "nq"), ReadQuality(row, "hq"));
        }
        throw new InvalidDataException("Objet non résolu par Universalis pour ce monde.");
    }
    private static MarketQualityPrice ReadQuality(JsonElement row, string quality)
    {
        if (!row.TryGetProperty(quality, out var value)) return new(null, null, null);
        var min = World(value, "minListing");
        var sale = World(value, "recentPurchase");
        return new(Price(min), Price(sale), sale is { } entry ? Timestamp(entry, "timestamp") : null);
    }
    private static JsonElement? World(JsonElement value, string field) =>
        value.TryGetProperty(field, out var group) && group.ValueKind == JsonValueKind.Object
        && group.TryGetProperty("world", out var world) && world.ValueKind == JsonValueKind.Object ? world : null;
    private static decimal? Price(JsonElement? value) => value is { } row && row.TryGetProperty("price", out var price)
        && price.TryGetDecimal(out var amount) && amount > 0 ? amount : null;
    private static DateTimeOffset? Timestamp(JsonElement value, string field) =>
        value.TryGetProperty(field, out var timestamp) && timestamp.TryGetInt64(out var milliseconds) && milliseconds > 0
            ? DateTimeOffset.FromUnixTimeMilliseconds(milliseconds) : null;
}
