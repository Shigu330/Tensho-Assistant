using System.Diagnostics;
using Dalamud.Plugin.Services;

namespace TenshoAssistant.Market;

internal sealed class MarketWorldReader : IDisposable
{
    private readonly MarketService service;
    private readonly IFramework framework;
    private readonly IPlayerState player;
    private readonly IClientState client;
    private readonly IPluginLog log;
    private readonly object gate = new();
    private bool disposed;
    private long retryAt;
    private uint worldId;
    private ulong character;
    public MarketWorldReader(MarketService service, IFramework framework, IPlayerState player, IClientState client, IPluginLog log)
    {
        this.service = service; this.framework = framework; this.player = player; this.client = client; this.log = log;
        framework.Update += Update;
    }
    private void Update(IFramework _)
    {
        lock (gate)
        {
            if (disposed || !framework.IsInFrameworkUpdateThread || framework.IsFrameworkUnloading) return;
            if (!client.IsLoggedIn || !player.IsLoaded || player.ContentId == 0)
            { Clear(); return; }
            if (Stopwatch.GetTimestamp() < retryAt) return;
            try
            {
                var owner = player.ContentId;
                var world = player.CurrentWorld;
                if (world.RowId == 0) { Clear(); return; }
                if (character == owner && worldId == world.RowId) return;
                var name = world.Value.Name.ExtractText();
                if (!client.IsLoggedIn || !player.IsLoaded || player.ContentId != owner || player.CurrentWorld.RowId != world.RowId)
                { Clear(); return; }
                service.SetWorld(owner, world.RowId, name);
                character = owner;
                worldId = world.RowId;
            }
            catch (Exception error)
            {
                Clear();
                retryAt = Stopwatch.GetTimestamp() + 5 * Stopwatch.Frequency;
                log.Warning(error, "Tensho current market world unavailable; retry in five seconds.");
            }
        }
    }
    private void Clear()
    {
        character = 0; worldId = 0;
        service.SetWorld(0, 0, "");
    }
    public void Dispose()
    {
        lock (gate)
        {
            if (disposed) return;
            disposed = true;
            framework.Update -= Update;
            Clear();
        }
    }
}
