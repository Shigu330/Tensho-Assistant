using System.Numerics;
using Dalamud.Bindings.ImGui;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    public void DrawMarketHover()
    {
        if (windowDisposed || !configuration.MarketPricesOnHover || marketHover.Current is not { } hovered) return;
        var state = market.State;
        if (state.WorldId == 0) return;
        var quote = market.GetCached(state.WorldId, hovered.ItemId);
        var background = market.BackgroundState;
        var position = ImGui.GetMousePos() + new Vector2(24, 24);
        var viewport = ImGui.GetMainViewport();
        position.X = Math.Clamp(position.X, viewport.WorkPos.X, Math.Max(viewport.WorkPos.X, viewport.WorkPos.X + viewport.WorkSize.X - 380));
        position.Y = Math.Clamp(position.Y, viewport.WorkPos.Y, Math.Max(viewport.WorkPos.Y, viewport.WorkPos.Y + viewport.WorkSize.Y - 200));
        ImGui.SetNextWindowPos(position, ImGuiCond.Always);
        ImGui.SetNextWindowBgAlpha(0.94f);
        var visible = ImGui.Begin("Prix au survol###TenshoMarketHover", ImGuiWindowFlags.NoDecoration | ImGuiWindowFlags.AlwaysAutoResize
            | ImGuiWindowFlags.NoSavedSettings | ImGuiWindowFlags.NoInputs | ImGuiWindowFlags.NoFocusOnAppearing | ImGuiWindowFlags.NoNav);
        try
        {
            if (!visible) return;
            var item = itemCatalog.State.Catalog?.Find(hovered.ItemId);
            DrawItemIcon(item, new Vector2(28)); ImGui.SameLine();
            ImGui.PushTextWrapPos(350);
            try { ImGui.TextColored(Accent, item?.Name ?? $"Objet {hovered.ItemId}"); }
            finally { ImGui.PopTextWrapPos(); }
            ImGui.TextDisabled($"{state.WorldName} · {(hovered.Hq ? "objet HQ" : "objet NQ")}");
            if (quote is { } prices)
            {
                ImGui.TextUnformatted($"Minimum NQ : {prices.Nq.Minimum?.ToString("N0") ?? "Non renseigné"} gils");
                ImGui.TextUnformatted($"Minimum HQ : {prices.Hq.Minimum?.ToString("N0") ?? "Non renseigné"} gils");
                ImGui.TextDisabled($"Consulté {prices.FetchedAt:HH:mm:ss} UTC");
                ImGui.TextDisabled(prices.UploadedAt is { } date ? $"Relevé {date:yyyy-MM-dd HH:mm} UTC" : "Date du relevé inconnue");
                if (!prices.HasRecentUpload(DateTimeOffset.UtcNow))
                    ImGui.TextColored(Accent, "Relevé ancien, non daté ou date incohérente");
                if (DateTimeOffset.UtcNow - prices.FetchedAt >= TimeSpan.FromMinutes(5)) ImGui.TextDisabled("Cache expiré · actualisation en attente");
            }
            else ImGui.TextDisabled(background?.ItemId == hovered.ItemId && background.WorldId == state.WorldId
                ? background.Loading ? "Consultation en cours…" : background.Error ?? "Aucun prix renseigné"
                : "Consultation après un survol stable…");
            ImGui.TextDisabled("Universalis · données communautaires");
        }
        finally { ImGui.End(); }
    }
}
