using System.Text;
using Dalamud.Bindings.ImGui;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private void DrawMacroObservation()
    {
        if (!ImGui.CollapsingHeader("Observation des macros · lecture seule")) return;
        var state = macroObservations.State;
        var enabled = state.Enabled;
        if (ImGui.Checkbox("Observer les transitions natives", ref enabled)) { macroObservations.SetEnabled(enabled); return; }
        ImGui.TextWrapped("Désactivé par défaut. Lecture seule, sans exécution ni annulation de macro. Les macros très courtes peuvent échapper aux observations entre deux images ; cette trace ne prouve pas leur absence ou leur succès.");
        if (state.Error is { } error) ImGui.TextWrapped(error);
        if (state.Current is not { } current) return;
        ImGui.TextDisabled(current.Available ? $"Ligne native {current.Line} · verrou {current.Locked} · attente {current.WaitMs} ms" : "État natif indisponible");
        foreach (var row in state.Trace.TakeLast(10))
            ImGui.TextUnformatted($"{row.ObservedAt:HH:mm:ss.fff} · ligne {row.Line} · verrou {row.Locked} · attente {row.WaitMs} · {row.Name}");
        if (ImGui.Button("Copier les transitions observées"))
        {
            var text = new StringBuilder($"Tensho {BuildVersion} — observation passive UTC, sans preuve d'exécution complète\n");
            foreach (var row in state.Trace)
                text.AppendLine($"{row.ObservedAt:O} | disponible={row.Available} | ligne={row.Line} | verrou={row.Locked} | attenteMs={row.WaitMs} | {row.Name}");
            ImGui.SetClipboardText(text.ToString());
        }
    }
}
