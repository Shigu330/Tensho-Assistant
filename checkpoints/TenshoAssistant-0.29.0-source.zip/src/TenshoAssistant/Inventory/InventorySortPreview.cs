namespace TenshoAssistant.Inventory;

public enum InventorySortField { Name, Category, Quantity, Quality }
public sealed record InventoryPreviewStack(InventoryLocation Origin, InventoryStack Stack);
public sealed record InventorySortResult(int Capacity, IReadOnlyList<InventoryPreviewStack> Stacks);

public static class InventorySortPreview
{
    public static InventorySortResult Build(IEnumerable<InventoryContainerSnapshot> containers, int capacity,
        InventorySortField field, bool descending, Func<uint, (string Name, uint Category)> describe)
    {
        ArgumentNullException.ThrowIfNull(containers);
        ArgumentNullException.ThrowIfNull(describe);
        if (!Enum.IsDefined(field) || capacity < 0) throw new ArgumentOutOfRangeException(nameof(field));
        var source = containers.OrderBy(container => container.Location.Container.Value).ToArray();
        if (source.Any(container => container.Coverage != InventoryCoverage.Complete)
            || source.Select(container => container.Location.Owner).Distinct().Count() > 1
            || source.Select(container => container.Location).Distinct().Count() != source.Length)
            throw new InvalidOperationException("A complete, single-owner, nonduplicate source is required.");
        var values = source.SelectMany(container => container.Stacks.Select(stack => new InventoryPreviewStack(container.Location, stack))).ToArray();
        if (values.Length > capacity) throw new InvalidOperationException("Stacks exceed preview capacity.");
        var ordered = values.Select((value, index) => (Value: value, Index: index, Label: describe(value.Stack.Item.Id.Value))).ToArray();
        IOrderedEnumerable<(InventoryPreviewStack Value, int Index, (string Name, uint Category) Label)> sorted = field switch
        {
            InventorySortField.Quantity => descending ? ordered.OrderByDescending(row => row.Value.Stack.Quantity) : ordered.OrderBy(row => row.Value.Stack.Quantity),
            InventorySortField.Quality => descending ? ordered.OrderByDescending(row => row.Value.Stack.Item.IsHighQuality) : ordered.OrderBy(row => row.Value.Stack.Item.IsHighQuality),
            InventorySortField.Category => descending ? ordered.OrderByDescending(row => row.Label.Category) : ordered.OrderBy(row => row.Label.Category),
            _ => descending ? ordered.OrderByDescending(row => row.Label.Name, StringComparer.OrdinalIgnoreCase) : ordered.OrderBy(row => row.Label.Name, StringComparer.OrdinalIgnoreCase),
        };
        return new(capacity, Array.AsReadOnly(sorted.ThenBy(row => row.Value.Stack.Item.Id.Value)
            .ThenBy(row => row.Value.Stack.Item.IsHighQuality).ThenBy(row => row.Index).Select(row => row.Value).ToArray()));
    }
}
