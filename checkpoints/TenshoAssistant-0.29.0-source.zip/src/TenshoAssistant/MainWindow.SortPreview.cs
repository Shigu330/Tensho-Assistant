using System.Numerics;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.Inventory;
using TenshoAssistant.Items;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private InventorySnapshot? sortingViewSnapshot;
    private ItemCatalog? sortingViewCatalog;
    private InventorySortResult? sortingViewResult;
    private int sortingViewField;
    private bool sortingViewDescending;
    private void DrawSortPreview()
    {
        Heading("Organisation de l'inventaire", "Aperçu des règles de tri. Cet outil ne déplace aucun objet dans le jeu.");
        if (sortPreviewField < 0)
        {
            sortPreviewField = Math.Clamp(configuration.SortPreviewField, 0, 3);
            sortPreviewDescending = configuration.SortPreviewDescending;
        }
        var character = bankBridge.State.CharacterId;
        if (character == 0) { ImGui.TextDisabled("Connectez un personnage pour préparer son inventaire."); return; }
        var entries = bank.State.Entries.Where(entry => entry.Key.CharacterId == character).ToArray();
        if (sortPreviewOrigin is { } selected && !entries.Any(entry => entry.Key == selected)) sortPreviewOrigin = null;
        var chosen = entries.FirstOrDefault(entry => entry.Key == sortPreviewOrigin);
        ImGui.SetNextItemWidth(260);
        if (ImGui.BeginCombo("Rangement", chosen?.Name ?? "Inventaire personnel"))
        {
            try
            {
                if (ImGui.Selectable("Inventaire personnel", sortPreviewOrigin is null)) sortPreviewOrigin = null;
                foreach (var entry in entries)
                    if (ImGui.Selectable($"{entry.Name}##{entry.Key}", sortPreviewOrigin == entry.Key)) sortPreviewOrigin = entry.Key;
            }
            finally { ImGui.EndCombo(); }
        }
        chosen = entries.FirstOrDefault(entry => entry.Key == sortPreviewOrigin);
        var snapshot = chosen?.Snapshot ?? inventory.Current;
        var containers = snapshot?.Containers.Values.Where(container => chosen is not null
                || (container.Location.Owner.Value == character && container.Location.Container.Value is >= 0 and <= 3)).ToArray() ?? [];
        var expected = chosen is null ? 4 : BankStorageScope.ContainerIds(chosen.Key.Kind).Count;
        if (containers.Length != expected || containers.Any(container => container.Coverage != InventoryCoverage.Complete))
        {
            ImGui.TextWrapped("Le rangement doit être entièrement observé pour calculer l'aperçu.");
            return;
        }
        if (itemCatalog.State.Catalog is not { } catalog) { DrawCatalogStatus(); return; }
        var labels = new[] { "Nom", "Catégorie du jeu", "Quantité", "Qualité NQ/HQ" };
        ImGui.SetNextItemWidth(210);
        if (ImGui.BeginCombo("Trier par", labels[sortPreviewField]))
        {
            try
            {
                for (var index = 0; index < labels.Length; index++)
                    if (ImGui.Selectable(labels[index], sortPreviewField == index)) sortPreviewField = index;
            }
            finally { ImGui.EndCombo(); }
        }
        ImGui.SameLine();
        ImGui.Checkbox("Décroissant", ref sortPreviewDescending);
        if (ImGui.Button("Enregistrer cette règle"))
        {
            var oldField = configuration.SortPreviewField;
            var oldDescending = configuration.SortPreviewDescending;
            configuration.SortPreviewField = sortPreviewField;
            configuration.SortPreviewDescending = sortPreviewDescending;
            try { save(); saveError = null; }
            catch (Exception error)
            {
                configuration.SortPreviewField = oldField;
                configuration.SortPreviewDescending = oldDescending;
                saveError = "La règle n'a pas pu être sauvegardée.";
                log.Error(error, "Could not save sort preview rule.");
            }
        }
        if (saveError is not null) ImGui.TextWrapped(saveError);
        var capacity = chosen is null ? 140 : chosen.Key.Kind == BankStorageKind.Retainer ? 175 : 70;
        if (sortingViewResult is null || !ReferenceEquals(sortingViewSnapshot, snapshot) || !ReferenceEquals(sortingViewCatalog, catalog)
            || sortingViewField != sortPreviewField || sortingViewDescending != sortPreviewDescending)
        {
            sortingViewResult = InventorySortPreview.Build(containers, capacity, (InventorySortField)sortPreviewField,
                sortPreviewDescending, id => (catalog.Find(id)?.Name ?? $"ID {id}", catalog.Find(id)?.UiCategoryId ?? 0));
            sortingViewSnapshot = snapshot; sortingViewCatalog = catalog;
            sortingViewField = sortPreviewField; sortingViewDescending = sortPreviewDescending;
        }
        var preview = sortingViewResult;
        ImGui.TextDisabled($"{preview.Stacks.Count}/{capacity} cases occupées · piles et qualités conservées");
        if (chosen is not null) ImGui.TextDisabled($"Cache manuel : {chosen.Snapshot.ObservedAt:yyyy-MM-dd HH:mm:ss} UTC");
        const float slot = 34;
        var framesPerRow = Math.Max(1, (int)(ImGui.GetContentRegionAvail().X / 200));
        for (var bag = 0; bag < capacity / 35; bag++)
        {
            if (bag % framesPerRow != 0) ImGui.SameLine();
            var visible = ImGui.BeginChild($"SortPreviewBag{bag}", new Vector2(194, 300), true);
            try
            {
                if (!visible) continue;
                ImGui.TextColored(Accent, $"Aperçu · Sac {bag + 1}");
                if (!ImGui.BeginTable("Slots", 5, ImGuiTableFlags.SizingFixedFit)) continue;
                try
                {
                    for (var index = 0; index < 35; index++)
                    {
                        ImGui.TableNextColumn();
                        ImGui.PushID(index);
                        try
                        {
                            var target = bag * 35 + index;
                            if (target < preview.Stacks.Count)
                            {
                                var stack = preview.Stacks[target].Stack;
                                DrawBankSlot(new(stack.Item.Id.Value, stack.Item.IsHighQuality ? 0 : stack.Quantity,
                                    stack.Item.IsHighQuality ? stack.Quantity : 0, ""), slot);
                            }
                            else ImGui.Dummy(new Vector2(slot));
                        }
                        finally { ImGui.PopID(); }
                    }
                }
                finally { ImGui.EndTable(); }
            }
            finally { ImGui.EndChild(); }
        }
    }
}
