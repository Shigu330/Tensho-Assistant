using Dalamud.Bindings.ImGui;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private void DrawCharacterStats()
    {
        Heading("Statistiques du personnage", "Attributs lus directement dans le jeu · actualisation chaque seconde");
        var state = characterStats.State;
        if (state.CharacterId == 0) { ImGui.TextWrapped("Statistiques inconnues : aucun personnage chargé."); return; }
        ImGui.TextColored(Accent, $"{state.Name} · {state.Job} · niveau {state.Level}");
        ImGui.TextDisabled($"Observation : {state.ObservedAt:HH:mm:ss} UTC");
        var groups = new[]
        {
            ("Attributs", new[] { ("Strength", "Force"), ("Dexterity", "Dextérité"), ("Vitality", "Vitalité"), ("Intelligence", "Intelligence"), ("Mind", "Esprit"), ("HealthPoints", "PV (attribut)"), ("MagicPoints", "PM (attribut)") }),
            ("Combat", new[] { ("CriticalHit", "Critique"), ("DirectHitRate", "Coups nets"), ("Determination", "Détermination"), ("Tenacity", "Ténacité"), ("Piety", "Piété"), ("SkillSpeed", "Vivacité"), ("SpellSpeed", "Célérité"), ("Defense", "Défense"), ("MagicDefense", "Défense magique") }),
            ("Artisanat", new[] { ("Craftsmanship", "Habileté"), ("Control", "Contrôle"), ("CraftingPoints", "PS (attribut CP)") }),
            ("Récolte", new[] { ("Gathering", "Collecte"), ("Perception", "Discernement"), ("GatheringPoints", "PR (attribut GP)") }),
        };
        foreach (var group in groups)
        {
            if (!ImGui.CollapsingHeader(group.Item1, ImGuiTreeNodeFlags.DefaultOpen)) continue;
            if (!ImGui.BeginTable($"Character{group.Item1}", 2, ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingStretchProp)) continue;
            try
            {
                foreach (var (key, label) in group.Item2)
                {
                    ImGui.TableNextRow(); ImGui.TableNextColumn(); ImGui.TextUnformatted(label);
                    ImGui.TableNextColumn(); ImGui.TextUnformatted(state.Values.TryGetValue(key, out var value) ? value.ToString("N0") : "Inconnu");
                }
            }
            finally { ImGui.EndTable(); }
        }
        ImGui.TextWrapped("Ces valeurs ne constituent pas une estimation de dégâts, de taux critique ou de réussite de fabrication.");
    }
}
