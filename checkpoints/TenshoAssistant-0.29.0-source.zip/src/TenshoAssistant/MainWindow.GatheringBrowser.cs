using System.Numerics;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.Gathering;
using TenshoAssistant.Items;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private GatheringCatalog? sourceViewCatalog;
    private ItemCatalog? sourceViewItems;
    private string sourceQuery = "";
    private string sourceZoneQuery = "";
    private string sourceViewQuery = "";
    private string sourceViewZoneQuery = "";
    private uint? sourceTypeFilter;
    private uint? sourceViewTypeFilter;
    private ItemDefinition[] sourceMatches = [];
    private GatheringSource[] sourceTypes = [];

    private void DrawGatheringBrowser()
    {
        Heading("Récolte & pêche", "Recherchez une ressource ou une zone, puis sélectionnez un objet pour consulter ses lieux.");
        if (gatheringCatalog.State.Catalog is not { } sources)
        {
            var state = gatheringCatalog.State;
            ImGui.TextWrapped(state.Error ?? $"Chargement des sources : {state.Copied:N0}/{state.Total:N0}");
            return;
        }
        if (itemCatalog.State.Catalog is not { } items) { DrawCatalogStatus(); return; }
        if (!ReferenceEquals(sourceViewCatalog, sources))
            sourceTypes = sources.Sources.DistinctBy(source => source.TypeId).OrderBy(source => source.TypeId).ToArray();
        ImGui.SetNextItemWidth(-1);
        ImGui.InputTextWithHint("##SourceSearch", "Rechercher une ressource…", ref sourceQuery, 128);
        ImGui.SetNextItemWidth(-1);
        ImGui.InputTextWithHint("##SourceZoneSearch", "Filtrer une zone ou un lieu…", ref sourceZoneQuery, 128);
        if (ImGui.SmallButton("Tous les métiers##SourceBrowser")) sourceTypeFilter = null;
        foreach (var type in sourceTypes)
        {
            ImGui.SameLine();
            ImGui.PushID($"SourceType{type.TypeId}");
            try
            {
                DrawItemIcon(new ItemDefinition(0, type.TypeName, false, type.IconId), new Vector2(28));
                if (ImGui.IsItemClicked()) sourceTypeFilter = type.TypeId;
                if (ImGui.IsItemHovered()) ImGui.SetTooltip(type.TypeName);
            }
            finally { ImGui.PopID(); }
        }
        ImGui.SameLine();
        if (ImGui.SmallButton("Réinitialiser##SourceBrowser")) { sourceQuery = ""; sourceZoneQuery = ""; sourceTypeFilter = null; }
        if (!ReferenceEquals(sourceViewCatalog, sources) || !ReferenceEquals(sourceViewItems, items)
            || sourceViewQuery != sourceQuery || sourceViewZoneQuery != sourceZoneQuery || sourceViewTypeFilter != sourceTypeFilter)
        {
            sourceMatches = sources.Sources
                .Where(source => (sourceTypeFilter is null || source.TypeId == sourceTypeFilter)
                    && (string.IsNullOrWhiteSpace(sourceZoneQuery) || SourceContains(source.Zone, sourceZoneQuery) || SourceContains(source.Place, sourceZoneQuery)))
                .Select(source => source.ItemId).Distinct().Select(items.Find).OfType<ItemDefinition>()
                .Where(item => string.IsNullOrWhiteSpace(sourceQuery) || SourceContains(item.Name, sourceQuery) || item.Id.ToString() == sourceQuery.Trim())
                .OrderBy(item => item.Name, StringComparer.CurrentCultureIgnoreCase).ThenBy(item => item.Id).ToArray();
            sourceViewCatalog = sources; sourceViewItems = items;
            sourceViewQuery = sourceQuery; sourceViewZoneQuery = sourceZoneQuery; sourceViewTypeFilter = sourceTypeFilter;
        }
        var selectedType = sourceTypeFilter is { } typeId ? sourceTypes.FirstOrDefault(source => source.TypeId == typeId)?.TypeName ?? "Métier inconnu" : "Tous les métiers";
        ImGui.TextDisabled($"{sourceMatches.Length:N0} ressources · {selectedType}");
        if (!ImGui.BeginTable("GatheringBrowserPanels", 2, ImGuiTableFlags.SizingStretchProp | ImGuiTableFlags.Resizable)) return;
        try
        {
            ImGui.TableSetupColumn("Ressources", ImGuiTableColumnFlags.WidthStretch, 1);
            ImGui.TableSetupColumn("Lieux", ImGuiTableColumnFlags.WidthStretch, 2);
            ImGui.TableNextRow(); ImGui.TableNextColumn();
            var height = Math.Max(120, ImGui.GetContentRegionAvail().Y);
            var showList = ImGui.BeginChild("SourceItems", new Vector2(0, height), true);
            try
            {
                if (showList)
                {
                    var clipper = ImGui.ImGuiListClipper();
                    try
                    {
                        clipper.Begin(sourceMatches.Length);
                        while (clipper.Step())
                        for (var index = clipper.DisplayStart; index < clipper.DisplayEnd; index++)
                        {
                            var item = sourceMatches[index];
                            ImGui.PushID((int)item.Id);
                            try
                            {
                                DrawItemIcon(item, new Vector2(28));
                                var clicked = ImGui.IsItemClicked();
                                ImGui.SameLine();
                                if (ImGui.Selectable(item.Name, itemId == item.Id, ImGuiSelectableFlags.None, new Vector2(0, 28)) || clicked)
                                { SelectItem(item.Id); gatheringTypeFilter = sourceTypeFilter; }
                                if (ImGui.IsItemHovered()) ImGui.SetTooltip(item.Name);
                            }
                            finally { ImGui.PopID(); }
                        }
                    }
                    finally { clipper.End(); clipper.Destroy(); }
                    if (sourceMatches.Length == 0) ImGui.TextWrapped("Aucune ressource dans les sources couvertes pour ces filtres.");
                }
            }
            finally { ImGui.EndChild(); }
            ImGui.TableNextColumn();
            var showDetails = ImGui.BeginChild("SourceDetails", new Vector2(0, height), true);
            try
            {
                if (showDetails)
                {
                    if (itemId > 0)
                    {
                        if (ImGui.SmallButton("Stocks##SourceBrowser")) { page = Page.Items; focusStocksTab = true; }
                        ImGui.SameLine();
                        if (ImGui.SmallButton("Recettes##SourceBrowser")) OpenContextTool("Craftimizer");
                        ImGui.SameLine();
                        if (ImGui.SmallButton("Prix##SourceBrowser")) OpenContextTool("Price Insight");
                    }
                    DrawGathering();
                }
            }
            finally { ImGui.EndChild(); }
        }
        finally { ImGui.EndTable(); }
    }

    private static bool SourceContains(string text, string query) => System.Globalization.CultureInfo.CurrentCulture.CompareInfo
        .IndexOf(text, query.Trim(), System.Globalization.CompareOptions.IgnoreCase | System.Globalization.CompareOptions.IgnoreNonSpace) >= 0;
}
