param([string]$DotNet)
$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path -Parent $PSScriptRoot
if (-not $DotNet) {
    # Verified local toolchain; explicit parameter supports other machines.
    $taskLocalSdk = 'C:\ia-code\.tools\dotnet10\dotnet.exe'
    $DotNet = if (Test-Path -LiteralPath $taskLocalSdk) { $taskLocalSdk } else { 'dotnet' }
}
Push-Location $taskRoot
try {
    & $DotNet build TenshoAssistant.sln -c Release --nologo
    if ($LASTEXITCODE -ne 0) { throw 'Release build failed.' }
    & $DotNet run --project tests/TenshoAssistant.Tests -c Release --no-build
    if ($LASTEXITCODE -ne 0) { throw 'Managed tests failed.' }
    $taskOutput = Join-Path $taskRoot 'src\TenshoAssistant\bin\x64\Release'
    $taskManifest = Get-Content -Raw -LiteralPath (Join-Path $taskOutput 'TenshoAssistant.json') | ConvertFrom-Json
    $taskSourceManifest = Get-Content -Raw -LiteralPath (Join-Path $taskRoot 'src\TenshoAssistant\TenshoAssistant.json') | ConvertFrom-Json
    $taskAssemblyVersion = [Reflection.AssemblyName]::GetAssemblyName((Join-Path $taskOutput 'TenshoAssistant.dll')).Version.ToString()
    if ($taskManifest.InternalName -ne 'TenshoAssistant' -or $taskManifest.DalamudApiLevel -ne 15 -or $taskManifest.AssemblyVersion -ne $taskSourceManifest.AssemblyVersion -or $taskManifest.AssemblyVersion -ne $taskAssemblyVersion) {
        throw 'Packaged manifest identity/API/version mismatch.'
    }
    $taskZip = [IO.Compression.ZipFile]::OpenRead((Join-Path $taskOutput 'TenshoAssistant\latest.zip'))
    try {
        $taskEntries = @($taskZip.Entries.FullName)
        foreach ($taskExpected in @('TenshoAssistant.dll', 'TenshoAssistant.json')) {
            if ($taskExpected -notin $taskEntries) { throw "Missing package entry: $taskExpected" }
        }
        if (@($taskEntries | Where-Object { $_ -match '(^|/)(Dalamud|FFXIVClientStructs|Lumina|Dalamud.Bindings.ImGui)\.dll$' }).Count) {
            throw 'Host assemblies must not be redistributed in the plugin package.'
        }
    }
    finally { $taskZip.Dispose() }
    Write-Output 'PASS package identity, API, version, ZIP contents and host assembly exclusion'
}
finally { Pop-Location }
