using System.Numerics;

namespace TenshoAssistant.MiniGames;

public enum TriadPlayer { Blue, Red }
[Flags]
public enum TriadRules { Normal = 0, Reverse = 1, FallenAce = 2 }
public readonly record struct TriadMove(int CardIndex, int Square);
public readonly record struct TriadPlacement(int CardIndex, int Square, TriadPlayer Owner);

/// <summary>Immutable position with explicit supported rules. Instances 0..4 start in Blue's deck, 5..9 in Red's.</summary>
public readonly struct TriadPosition
{
    public IReadOnlyList<TriadCardDefinition> Cards { get; }
    internal ulong Board { get; }
    internal ushort BlueCells { get; }
    internal ushort Remaining { get; }
    public TriadPlayer Turn { get; }
    public TriadRules Rules { get; }
    public int EmptySquares => 9 - BitOperations.PopCount((uint)(1023 ^ Remaining));
    public bool IsTerminal => EmptySquares == 0;
    public bool IsInitialized => Cards is { Count: 10 };
    public int BlueScore => BitOperations.PopCount((uint)BlueCells) + BitOperations.PopCount((uint)(Remaining & 31));
    public int RedScore => 10 - BlueScore;
    internal int Difference => 2 * BlueScore - 10;

    private TriadPosition(IReadOnlyList<TriadCardDefinition> cards, ulong board, ushort blueCells, ushort remaining, TriadPlayer turn, TriadRules rules)
    { Cards = cards; Board = board; BlueCells = blueCells; Remaining = remaining; Turn = turn; Rules = rules; }

    public static TriadPosition Create(IEnumerable<TriadCardDefinition> blue, IEnumerable<TriadCardDefinition> red, TriadPlayer first, TriadRules rules = TriadRules.Normal)
        => Restore(blue, red, [], first, rules);

    public static TriadPosition Restore(IEnumerable<TriadCardDefinition> blue, IEnumerable<TriadCardDefinition> red,
        IEnumerable<TriadPlacement> placements, TriadPlayer first, TriadRules rules = TriadRules.Normal)
    {
        ArgumentNullException.ThrowIfNull(blue); ArgumentNullException.ThrowIfNull(red); ArgumentNullException.ThrowIfNull(placements);
        if (!Enum.IsDefined(first)) throw new ArgumentOutOfRangeException(nameof(first));
        if ((rules & ~(TriadRules.Reverse | TriadRules.FallenAce)) != 0) throw new ArgumentOutOfRangeException(nameof(rules), "Règles non couvertes.");
        var left = blue.ToArray(); var right = red.ToArray();
        foreach (var deck in new[] { left, right })
            if (deck.Length != 5 || deck.Any(card => card is null || !card.IsValid) || deck.Select(card => card.Id).Distinct().Count() != 5)
                throw new ArgumentException("Chaque main initiale doit contenir cinq cartes connues et distinctes.");
        var cards = Array.AsReadOnly(left.Concat(right).ToArray());
        ulong board = 0;
        ushort blueCells = 0, remaining = 1023;
        var bluePlayed = 0; var redPlayed = 0;
        foreach (var place in placements)
        {
            if (place.CardIndex is < 0 or > 9 || place.Square is < 0 or > 8 || !Enum.IsDefined(place.Owner))
                throw new ArgumentException("Carte, case ou couleur invalide.");
            if ((remaining & (1 << place.CardIndex)) == 0 || ((board >> (place.Square * 4)) & 15) != 0)
                throw new ArgumentException("Une carte et une case ne peuvent être utilisées qu'une fois.");
            board |= (ulong)(place.CardIndex + 1) << (place.Square * 4);
            remaining &= (ushort)~(1 << place.CardIndex);
            if (place.Owner == TriadPlayer.Blue) blueCells |= (ushort)(1 << place.Square);
            if (place.CardIndex < 5) bluePlayed++; else redPlayed++;
        }
        var firstCount = first == TriadPlayer.Blue ? bluePlayed : redPlayed;
        var secondCount = first == TriadPlayer.Blue ? redPlayed : bluePlayed;
        if (firstCount < secondCount || firstCount > secondCount + 1)
            throw new ArgumentException("Le nombre de cartes jouées ne correspond pas à une alternance des tours.");
        return new(cards, board, blueCells, remaining, firstCount == secondCount ? first : Other(first), rules);
    }

    public static TriadPlayer Other(TriadPlayer player) => player == TriadPlayer.Blue ? TriadPlayer.Red : TriadPlayer.Blue;
    public int CardAt(int square)
    {
        if (square is < 0 or > 8) throw new ArgumentOutOfRangeException(nameof(square));
        return (int)((Board >> (square * 4)) & 15) - 1;
    }
    public TriadPlayer? OwnerAt(int square) => CardAt(square) < 0 ? null : (BlueCells & (1 << square)) != 0 ? TriadPlayer.Blue : TriadPlayer.Red;
    public bool InHand(int index) => index is >= 0 and <= 9 && (Remaining & (1 << index)) != 0;
    public IReadOnlyList<TriadMove> LegalMoves()
    {
        if (!IsInitialized) throw new InvalidOperationException("Position non initialisée.");
        var moves = new List<TriadMove>();
        if (!IsTerminal)
            for (var card = Turn == TriadPlayer.Blue ? 0 : 5; card < (Turn == TriadPlayer.Blue ? 5 : 10); card++)
                if (InHand(card))
                    for (var square = 0; square < 9; square++) if (CardAt(square) < 0) moves.Add(new(card, square));
        return Array.AsReadOnly(moves.ToArray());
    }

    public TriadPosition Play(TriadMove move)
    {
        if (!IsInitialized || IsTerminal || !InHand(move.CardIndex) || move.Square is < 0 or > 8 || CardAt(move.Square) >= 0
            || (move.CardIndex < 5) != (Turn == TriadPlayer.Blue))
            throw new ArgumentException("Coup impossible dans cette position.");
        return PlayUnchecked(move.CardIndex, move.Square);
    }

    internal TriadPosition PlayUnchecked(int cardIndex, int square)
    {
        var previous = this;
        var color = BlueCells;
        var card = Cards[cardIndex];
        var blue = Turn == TriadPlayer.Blue;
        var row = square / 3; var column = square % 3;
        void Capture(int neighbor, int attack, Func<TriadCardDefinition, int> defense)
        {
            var index = previous.CardAt(neighbor);
            if (index < 0 || ((previous.BlueCells & (1 << neighbor)) != 0) == blue) return;
            var defending = defense(previous.Cards[index]);
            var reverse = (previous.Rules & TriadRules.Reverse) != 0;
            var wins = reverse ? attack < defending : attack > defending;
            // Fallen Ace adds a directional capture; it does not remove the ordinary opposite capture.
            if ((previous.Rules & TriadRules.FallenAce) != 0
                && (reverse ? attack == 10 && defending == 1 : attack == 1 && defending == 10)) wins = true;
            if (!wins) return;
            if (blue) color |= (ushort)(1 << neighbor); else color &= (ushort)~(1 << neighbor);
        }
        if (row > 0) Capture(square - 3, card.Top, static other => other.Bottom);
        if (column < 2) Capture(square + 1, card.Right, static other => other.Left);
        if (row < 2) Capture(square + 3, card.Bottom, static other => other.Top);
        if (column > 0) Capture(square - 1, card.Left, static other => other.Right);
        if (blue) color |= (ushort)(1 << square); else color &= (ushort)~(1 << square);
        return new(Cards, Board | ((ulong)(cardIndex + 1) << (square * 4)), color,
            (ushort)(Remaining & ~(1 << cardIndex)), Other(Turn), Rules);
    }
}
