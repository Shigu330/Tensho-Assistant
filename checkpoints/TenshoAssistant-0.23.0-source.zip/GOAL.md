# GOAL sélectionné

ID: TRIAD-001C
OBJECTIVE: Étendre les règles particulières Triple Triade, à commencer par Inversion et Tueur d'as, sans perdre l'annulation ni la distinction entre exact et estimé ; poursuivre la couverture du projet.
CURRENT_STATE: IMPLEMENTED / TESTED — Inversion/Tueur d'as intégrés en 0.23.0, 139 tests/package valides ; matrice de captures et 96 fins de partie supplémentaires comparées au moteur indépendant, probe cartes natives passant. Macro Chain attend un essai reporté par l'utilisateur, sans bloquer ce travail indépendant.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: Domaines Gathering, Inventory, Collections, Market, Quests, Character, MiniGames ; MainWindow.* ; Plugin.cs ; tests et documents.
IN_SCOPE: Combinaisons normale/Inversion/Tueur d'as ; règles dans les positions immutables, reset et invalidation du contexte, tests d'interactions ; conservation du solveur borné.
OUT_OF_SCOPE: Déclarer les 17 plugins remplacés ; prétendre une validation en jeu sans observation.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: 2026-10-28, 56 % disponibles sur 5 h et 93 % semaine au dernier relevé ; continuer selon instruction utilisateur.
NEXT_ACTION: Sauvegarder 0.23.0 puis TRIAD-001D : Identique/Plus avec captures simultanées et combos, sources primaires et cas indépendants avant activation. Ne pas annoncer une lecture du plateau non implémentée. Les autres domaines de la roadmap restent dans le goal global.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
