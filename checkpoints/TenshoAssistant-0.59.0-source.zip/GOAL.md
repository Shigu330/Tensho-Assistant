# GOAL sélectionné

ID: SORT-TEMPLATES-007
OBJECTIVE: Réutiliser les règles entre personnages/rangements compatibles, puis poursuivre les 17 domaines jusqu’à la réserve de quota de 5 %.
CURRENT_STATE: IMPLEMENTED / TESTED en 0.59.0, 385 tests/package et Newtonsoft trois modes verts ; bibliothèque sans owner/observation et chargement en brouillon. ZIP identique aux sorties canoniques par SHA-256. Rendu/application/persistance natifs non observés.
FILES: Inventory/InventorySortTemplates et validation partagée ; Configuration ; MainWindow.SortTemplates/SortRules/Tools ; InventorySortTemplateTests ; ConfigSerializationProbe ; scripts/Verify.ps1 ; docs/SORT-TEMPLATES-007.md.
IN_SCOPE: 64 modèles nommés, GUID/version, géométrie compatible, listes copiées, create/update/delete avec rollback, rebind au scope courant et aucune capture/application implicite. Configuration v1 compatible.
OUT_OF_SCOPE: Copier propriétaire/observation, rogner des zones pour une autre géométrie, mise à jour silencieuse de géométrie, tri automatique. Les 17 domaines restent PARTIAL.
VALIDATION: Verify.ps1 385/385, package/versions/ZIP/SHA-256/exclusion hôte verts, zéro avertissement/erreur ; six groupes bibliothèque et chaîne vers permutation d’une autre sacoche. Newtonsoft None/Auto/Objects avec bibliothèque imbriquée passants.
QUOTA: Relevé 2026-10-29 : 8 % disponibles sur 5 h et 48 % semaine ; réserve utilisateur 5 %. Objectif global actif.
NEXT_ACTION: Snapshot 0.59 puis BASE-AUDIT-002 : audit ciblé des 17 outils, documents/chemins et limites, sans nouvelle grosse tranche avant compteur. Garder l’inconnu GP ; essais projection/Macro Chain différés, sans les redemander.
DEFINITION_OF_DONE: Tranche intégrée compilée, tests/package verts, limites documentées et sauvegarde source ; aucun domaine global promu complet sans preuve.
