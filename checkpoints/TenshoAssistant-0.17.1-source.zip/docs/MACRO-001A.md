# MACRO-001A — séquences explicites de macros

État : READY pour la prochaine tranche ; aucun exécuteur ajouté. Base courante 0.17.1, 104 tests/package verts.

Objectif : permettre à l'utilisateur de préparer une séquence de macros personnelles/partagées, de la lancer explicitement et de l'interrompre. Ni pointeur natif conservé ni lancement implicite au chargement/à la connexion.

LOCAL_VERIFIED / 2026-10-27 : ApiProbe confirme RaptureMacroModule.Instance, GetMacro(uint book,uint index), Individual/Shared et GetLineCount. RaptureShellModule.Instance, ExecuteMacro, CancelMacro, MacroLocked, MacroCurrentLine, WaitTimeMs sont présents dans les assemblies installées. Les appels natifs doivent rester sur le framework. Résoudre de nouveau le pointeur de la macro à chaque action, copier seulement IDs/noms/lignes utiles vers l'UI.

CURRENT_VERIFIED / 2026-10-27 : source primaire https://raw.githubusercontent.com/Caraxi/MacroChain/master/MacroChain.cs (branche master, commit non épinglé) utilise MacroCurrentLine >= 0 comme état d'exécution et les livres 0/1, indices 0–99. https://raw.githubusercontent.com/aers/FFXIVClientStructs/main/FFXIVClientStructs/FFXIV/Client/UI/Shell/RaptureShellModule.cs confirme les champs/appels présents. Ces conventions sont une preuve de source, pas une observation du client local. Aucune licence de réutilisation du code MacroChain établie ; aucun code copié. Implémentation originale et tests requis.

Tranche proposée : modèle managé de séquence, identité du personnage, états Idle/Starting/Running/Waiting/Complete/Cancelled/Failed, plan copié avant lancement, limites sur nombre d'étapes et indices. Ne jamais remplacer une macro externe déjà en cours ni forcer MacroLocked à false. Pour annuler, cesser les étapes futures ; annuler la macro native seulement si sa propriété par cette séquence est démontrée. Interruption, déconnexion, changement de personnage et Dispose doivent empêcher tout lancement supplémentaire. Une macro vide ou un démarrage non observé doit rester une erreur explicite.

L'API ExecuteMacro est void et ne prouve pas seule un lancement réussi ; l'adaptateur doit traiter la fenêtre de démarrage, les macros très courtes et l'éventuelle exécution externe avant de promouvoir une séquence automatique. Étudier si un hook est nécessaire pour prouver la propriété ; ne pas conserver le pointeur de la macro ni reprendre automatiquement après une ambiguïté. Ne pas introduire un faux délai fixe qui prétend prouver la fin.

Tests : bornes, ordre, démarrage/fin observés, interruption externe, annulation avant/pending/après démarrage, changement propriétaire et disposal. Validation native ciblée avec macros sans effet externe dans une session Dalamud, après compilation. Sans preuve d'ownership, laisser l'action bloquée plutôt que modifier l'état global des macros.
