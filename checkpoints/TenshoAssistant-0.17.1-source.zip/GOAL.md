# GOAL sélectionné

ID: MACRO-001A
OBJECTIVE: Préparer des séquences explicites de macros et prouver la propriété/l'interruption avant un exécuteur natif ; voir docs/MACRO-001A.md.
CURRENT_STATE: READY — base 0.17.1 et 104 tests/package validés ; API locale et sources primaires étudiées, exécuteur non implémenté.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: Domaines Gathering, Inventory, Collections, Market, Quests, Character, MiniGames ; MainWindow.* ; Plugin.cs ; tests et documents.
IN_SCOPE: Séquence managée copiée, preuve des transitions natives, annulation/identité/ownership, interface puis tests ; aucune action implicite.
OUT_OF_SCOPE: Déclarer les 17 plugins remplacés ; prétendre une validation en jeu sans observation.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: Continuer jusqu'à la limite selon instruction utilisateur ; dernier relevé : 37 % sur 5 h et 1 % semaine restants. Sauvegarder chaque tranche.
NEXT_ACTION: Lire docs/MACRO-001A.md et vérifier si un hook est nécessaire à l'ownership. Garder 0.17.1 compilée, contrôler le quota avant nouvelle tranche.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
