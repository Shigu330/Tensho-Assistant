namespace TenshoAssistant.Inventory;

public readonly record struct InventoryPhysicalSlot(int Container,int Slot);

/// <summary>A whole permutation of the four personal bags, including empty slots. No pile is merged or moved physically.</summary>
public sealed class InventoryVisualSortPlan
{
    public ulong Owner {get;}
    public InventorySnapshot Expected {get;}
    public IReadOnlyList<InventoryPhysicalSlot> Order {get;}
    private InventoryVisualSortPlan(ulong owner,InventorySnapshot expected,InventoryPhysicalSlot[] order)
    {Owner=owner;Expected=expected;Order=Array.AsReadOnly(order);}

    private static Dictionary<InventoryPhysicalSlot,InventoryStack> Personal(InventorySnapshot snapshot,ulong owner)
    {
        if(owner==0)throw new InvalidOperationException("Personnage non observé.");
        var containers=snapshot.Containers.Values.Where(c=>c.Location.Container.Value is >=0 and <=3).ToArray();
        if(containers.Length!=4 || containers.Any(c=>c.Location.Owner.Value!=owner || c.Coverage!=InventoryCoverage.Complete))
            throw new InvalidOperationException("Les quatre sacs du personnage doivent être entièrement observés.");
        var values=new Dictionary<InventoryPhysicalSlot,InventoryStack>();var display=new HashSet<int>();
        foreach(var container in containers)
        foreach(var stack in container.Stacks)
        {
            if(stack.Slot is <0 or >=35 || stack.DisplayIndex is <0 or >=140 || !display.Add(stack.DisplayIndex))
                throw new InvalidOperationException("Ordre visuel des sacs incomplet ou incohérent.");
            values.Add(new(container.Location.Container.Value,stack.Slot),stack);
        }
        return values;
    }

    public static InventoryVisualSortPlan Build(InventorySnapshot expected,InventorySortResult preview,ulong owner)
    {
        var physical=Personal(expected,owner);
        if(preview.Capacity!=140 || preview.Stacks.Count!=physical.Count)throw new InvalidOperationException("Aperçu incompatible avec les quatre sacs.");
        var order=new List<InventoryPhysicalSlot>(140);var seen=new HashSet<InventoryPhysicalSlot>();
        foreach(var value in preview.Stacks)
        {
            var slot=new InventoryPhysicalSlot(value.Origin.Container.Value,value.Stack.Slot);
            if(value.Origin.Owner.Value!=owner || !physical.TryGetValue(slot,out var stack) || stack!=value.Stack || !seen.Add(slot))
                throw new InvalidOperationException("L’aperçu ne correspond plus aux piles observées.");
            order.Add(slot);
        }
        for(var container=0;container<4;container++)
        for(var slot=0;slot<35;slot++)
        {
            var value=new InventoryPhysicalSlot(container,slot);
            if(!physical.ContainsKey(value))order.Add(value);
        }
        if(order.Count!=140 || order.Distinct().Count()!=140)throw new InvalidOperationException("Permutation incomplète.");
        return new(owner,expected,order.ToArray());
    }

    public bool Matches(InventorySnapshot actual,ulong owner,DateTimeOffset now)
    {
        if(owner!=Owner || now<Expected.ObservedAt || now-Expected.ObservedAt>TimeSpan.FromSeconds(3)
            || now<actual.ObservedAt || now-actual.ObservedAt>TimeSpan.FromSeconds(3))return false;
        try
        {
            var before=Personal(Expected,Owner);var current=Personal(actual,Owner);
            return before.Count==current.Count && before.All(pair=>current.TryGetValue(pair.Key,out var value) && value==pair.Value);
        }
        catch(InvalidOperationException){return false;}
    }
}

public sealed record InventoryVisualSortRequest(long Revision,InventoryVisualSortPlan Plan,DateTimeOffset RequestedAt);
public sealed record InventoryVisualSortState(bool Pending,string? Message);

/// <summary>One explicit request; no sorting on preference save, login, inventory events or worker threads.</summary>
public sealed class InventoryVisualSortService : IDisposable
{
    private readonly object gate=new();private long revision;private bool disposed;
    private InventoryVisualSortRequest? pending;
    private InventoryVisualSortState state=new(false,null);
    public InventoryVisualSortState State=>Volatile.Read(ref state);
    public bool Request(InventoryVisualSortPlan plan,DateTimeOffset now)
    {
        lock(gate)
        {
            if(disposed || state.Pending)return false;
            pending=new(++revision,plan,now);state=new(true,"Tri visuel demandé ; vérification des sacs en cours.");return true;
        }
    }
    public InventoryVisualSortRequest? Take(ulong owner,DateTimeOffset now)
    {
        lock(gate)
        {
            if(disposed || pending is not { } request)return null;
            pending=null;
            if(owner==0 || owner!=request.Plan.Owner || now<request.RequestedAt || now-request.RequestedAt>TimeSpan.FromSeconds(3))
            {state=new(false,"Demande annulée : personnage ou date modifiés.");revision++;return null;}
            return request;
        }
    }
    public void Complete(InventoryVisualSortRequest request,string message)
    {lock(gate)if(!disposed && state.Pending && request.Revision==revision)state=new(false,message);}
    public void Clear(){lock(gate){pending=null;revision++;state=new(false,null);}}
    public void Dispose(){lock(gate){disposed=true;pending=null;revision++;state=new(false,null);}}
}
