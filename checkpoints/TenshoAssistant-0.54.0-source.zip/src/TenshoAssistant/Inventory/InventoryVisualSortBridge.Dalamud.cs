using Dalamud.Game.Inventory;
using Dalamud.Plugin.Services;
using FFXIVClientStructs.FFXIV.Client.Game;
using FFXIVClientStructs.FFXIV.Client.UI.Misc;

namespace TenshoAssistant.Inventory;

internal sealed class InventoryVisualSortBridge : IDisposable
{
    private static readonly GameInventoryType[] Bags=[GameInventoryType.Inventory1,GameInventoryType.Inventory2,GameInventoryType.Inventory3,GameInventoryType.Inventory4];
    private readonly InventoryVisualSortService service;
    private readonly IGameInventory inventory;
    private readonly IPlayerState player;
    private readonly IClientState client;
    private readonly IFramework framework;
    private readonly IPluginLog log;
    private readonly RegistrationScope registrations=new();
    private bool disposed;
    public InventoryVisualSortBridge(InventoryVisualSortService service,IGameInventory inventory,IPlayerState player,IClientState client,IFramework framework,IPluginLog log)
    {
        this.service=service;this.inventory=inventory;this.player=player;this.client=client;this.framework=framework;this.log=log;
        try
        {
            registrations.Register(()=>framework.Update+=Update,()=>framework.Update-=Update);
            registrations.Register(()=>client.Logout+=Logout,()=>client.Logout-=Logout);
        }
        catch{Dispose();throw;}
    }
    private void Logout(int type,int code)=>service.Clear();
    private void Update(IFramework _)
    {
        if(disposed || !framework.IsInFrameworkUpdateThread || framework.IsFrameworkUnloading)return;
        var owner=client.IsLoggedIn && player.IsLoaded ? player.ContentId:0;
        var request=service.Take(owner,DateTimeOffset.UtcNow);
        if(request is null)return;
        try
        {
            Apply(request.Plan,owner);
            service.Complete(request,"Tri visuel appliqué aux quatre sacs. Les piles physiques sont conservées ; la banque se rafraîchit sous une seconde.");
        }
        catch(Exception error){service.Complete(request,"Tri non appliqué : "+error.Message);log.Warning(error,"Tensho visual sort request rejected.");}
    }

    private unsafe void Apply(InventoryVisualSortPlan plan,ulong owner)
    {
        var module=ItemOrderModule.Instance();
        var sorter=module==null ? null:module->InventorySorter;
        if(module==null || module->CharacterContentId!=owner || sorter==null || sorter->InventoryType!=InventoryType.Inventory1
            || sorter->Items.First==null || sorter->Items.LongCount!=140 || sorter->Items.LongCapacity is <140 or >4096
            || sorter->ItemsPerPage!=35 || sorter->SortFunctionIndex!=-1)
            throw new InvalidOperationException("Ordre visuel natif indisponible ou tri du jeu en cours.");
        var vector=sorter->Items.First;
        var snapshot=InventoryNativeReader.Capture(inventory,new(owner),Bags,"Dalamud/visual-sort/verify");
        if(!plan.Matches(snapshot,owner,DateTimeOffset.UtcNow))
            throw new InvalidOperationException("Les sacs ou leur ordre ont changé depuis l’aperçu. Actualisez puis réessayez.");
        if(sorter->Items.First!=vector || sorter->Items.LongCount!=140 || sorter->SortFunctionIndex!=-1)
            throw new InvalidOperationException("Table native modifiée pendant la capture.");
        var addresses=new HashSet<nint>();
        var entries=new Dictionary<InventoryPhysicalSlot,ItemOrderModuleSorterItemEntry>();
        var destinations=new nint[140];
        var original=new ItemOrderModuleSorterItemEntry[140];
        for(var index=0;index<140;index++)
        {
            var entry=sorter->Items[index].Value;
            if(entry==null || !addresses.Add((nint)entry) || entry->Page>=4 || entry->Slot>=35
                || !entries.TryAdd(new(entry->Page,entry->Slot),*entry))
                throw new InvalidOperationException("La table native n’est pas une permutation complète des sacs.");
            destinations[index]=(nint)entry;
            original[index]=*entry;
        }
        // Validate occupied entries against the captured visual mapping, not just a pile-count total.
        foreach(var container in snapshot.Containers.Values)
        foreach(var stack in container.Stacks)
        {
            var entry=(ItemOrderModuleSorterItemEntry*)destinations[stack.DisplayIndex];
            if(entry->Page!=container.Location.Container.Value || entry->Slot!=stack.Slot)
                throw new InvalidOperationException("Ordre natif modifié pendant la vérification.");
        }
        var ordered=plan.Order.Select(slot=>entries[slot]).ToArray();
        if(!client.IsLoggedIn || !player.IsLoaded || player.ContentId!=owner || ItemOrderModule.Instance()!=module
            || module->InventorySorter!=sorter || module->CharacterContentId!=owner || sorter->SortFunctionIndex!=-1 || sorter->Items.Count!=140)
            throw new InvalidOperationException("Contexte natif modifié avant application.");
        if(sorter->Items.First!=vector)throw new InvalidOperationException("Table native remplacée avant application.");
        for(var index=0;index<140;index++)
        {
            var entry=sorter->Items[index].Value;var previous=original[index];
            if((nint)entry!=destinations[index] || entry->Page!=previous.Page || entry->Slot!=previous.Slot
                || entry->Index!=previous.Index || entry->Flags!=previous.Flags)
                throw new InvalidOperationException("Entrée native modifiée avant application.");
        }
        // All allocations/lookups and validation precede the first write. Entries include native Index/Flags unchanged.
        for(var index=0;index<140;index++)
            *(ItemOrderModuleSorterItemEntry*)destinations[index]=ordered[index];
        module->HasChanges=true;
    }
    public void Dispose(){if(disposed)return;disposed=true;try{registrations.Dispose();}finally{service.Dispose();}}
}
