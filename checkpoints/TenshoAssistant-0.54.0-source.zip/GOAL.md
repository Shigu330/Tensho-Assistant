# GOAL sélectionné

ID: SORT-NATIVE-002
OBJECTIVE: Appliquer explicitement l’aperçu au tri visuel natif, puis poursuivre les 17 domaines jusqu’à la réserve de quota de 5 %.
CURRENT_STATE: IMPLEMENTED / TESTED en 0.54.0, 355 tests/package verts ; permutation de 140 cases personnelles avec contrôles de fraîcheur, owner, piles/qualités/slots/ordre et table native. Écriture/rendu/persistance non observés en jeu.
FILES: Inventory/InventoryVisualSort et Bridge ; MainWindow.SortPreview/Tools ; MainWindow/Plugin ; InventoryVisualSortTests ; docs/SORT-NATIVE-002.md.
IN_SCOPE: Quatre sacs personnels en direct, quatre critères existants et sens, clic d’application distinct de la sauvegarde. Demande managée unique vers framework.Update, permutation complète incluant vides, entrées natives préservées, HasChanges. Aucun InventoryItem physique modifié.
OUT_OF_SCOPE: Application sur cache importé, transfert/fusion physique, tri automatique ou hook, persistance native confirmée, personnalisation complète des zones de slots. Les 17 domaines restent PARTIAL au périmètre global.
VALIDATION: Verify.ps1 355/355, package/versions/ZIP/exclusion hôte verts, zéro avertissement/erreur ; six groupes dont 48 scénarios de permutation avec oracle indépendant. Source SortaKinda et SDK installés inspectés ; protocole runtime conservé.
QUOTA: Relevé 2026-10-29 : 41 % disponibles sur 5 h et 53 % semaine ; réserve utilisateur 5 %. Objectif global actif.
NEXT_ACTION: Snapshot 0.54 puis SORT-SCOPES-003 : capture en direct des sacoches/servant réellement ouverts, revalidation et application bornée au scope ; jamais sur la seule base d’un cache importé. Garder l’inconnu GP et les essais projection/Macro Chain différés, sans les redemander.
DEFINITION_OF_DONE: Tranche intégrée compilée, tests/package verts, limites documentées et sauvegarde source ; aucun domaine global promu complet sans preuve.
