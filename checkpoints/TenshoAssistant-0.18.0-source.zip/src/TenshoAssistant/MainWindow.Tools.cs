using System.Globalization;
using System.Numerics;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface;
using TenshoAssistant.Craft;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private sealed record PlannedTool(string Group, string Name, string Reference, string Description, FontAwesomeIcon Icon);
    private PlannedTool? selectedTool;
    private bool selectedAvailableTool;
    private const string ToolDetailsPopup = "Détails de l'outil###TenshoToolDetails";

    // Product directory, not registrations of unimplemented modules. Scope remains in ROADMAP.md.
    private static readonly PlannedTool[] PlannedTools =
    [
        new("Artisanat", "Recettes, simulation et macros de craft", "Craftimizer", "Préparer une fabrication et obtenir des suggestions pendant le craft.", FontAwesomeIcon.Hammer),
        new("Récolte & pêche", "Ressources et lieux de récolte", "GatherBuddy", "Relier les objets aux points de récolte, à la pêche et aux disponibilités.", FontAwesomeIcon.Fish),
        new("Récolte & pêche", "Optimisation des GP", "LazyGatherer", "Aider à choisir les actions selon les ressources de récolte disponibles.", FontAwesomeIcon.Seedling),
        new("Objets & économie", "Organisation de l'inventaire", "SortaKinda", "Définir des règles, des filtres et un aperçu d'organisation.", FontAwesomeIcon.Boxes),
        new("Objets & économie", "Banque d'objets", "Banque d'objets", "Parcourir les servants et sacoches importés, puis sélectionner un objet dans le contexte commun.", FontAwesomeIcon.Archive),
        new("Objets & économie", "Usages des objets", "Item Use", "Découvrir les utilisations d'un objet à partir des données partagées.", FontAwesomeIcon.Recycle),
        new("Objets & économie", "Prix du marché", "Price Insight", "Consulter des prix avec leur date et leur marché d'origine.", FontAwesomeIcon.Coins),
        new("Collections & progression", "Collections", "Collections", "Découvrir les collections et suivre les acquisitions connues.", FontAwesomeIcon.Trophy),
        new("Collections & progression", "Quêtes", "QuestTracker", "Suivre progression, complétion et prérequis des quêtes.", FontAwesomeIcon.Tasks),
        new("Collections & progression", "Grimoire Mage bleu", "Blue Mage Helper", "Identifier les sorts à apprendre et leurs sources.", FontAwesomeIcon.BookOpen),
        new("Exploration & butin", "Carte", "Mappy", "Regrouper les lieux et les repères utiles sur une carte polyvalente.", FontAwesomeIcon.MapMarkedAlt),
        new("Exploration & butin", "Butin des contenus", "Duty Loot Preview", "Voir les récompenses associées à un contenu.", FontAwesomeIcon.Dungeon),
        new("Exploration & butin", "Matériaux des monstres", "Monster Loot Hunter", "Relier les matériaux recherchés aux monstres et aux lieux d'obtention.", FontAwesomeIcon.Dragon),
        new("Jeux & Gold Saucer", "Revue de mode", "Avant-Garde", "Trouver des pièces d'équipement adaptées aux indices.", FontAwesomeIcon.Tshirt),
        new("Jeux & Gold Saucer", "Mini Cactpot", "ezMiniCactpot", "Calculer le prochain choix selon le plateau connu.", FontAwesomeIcon.TicketAlt),
        new("Jeux & Gold Saucer", "Triple Triade", "TriadBuddy", "Analyser le plateau et rechercher les coups utiles.", FontAwesomeIcon.Clone),
        new("Personnage & macros", "Statistiques du personnage", "Character Panel Refined", "Présenter les statistiques utiles et leurs effets.", FontAwesomeIcon.ChartBar),
        new("Personnage & macros", "Enchaînement de macros", "Macro Chain", "Préparer des séquences de macros et leur interruption.", FontAwesomeIcon.Link),
    ];

    private void DrawTools()
    {
        Heading("Tous les outils", "Cliquez sur une icône pour consulter la fiche de l'outil.");
        ImGui.SetNextItemWidth(-1);
        ImGui.InputTextWithHint("##ToolFilter", "Filtrer par domaine, outil ou plugin de référence…", ref toolQuery, 128);
        var matches = PlannedTools.Where(tool => MatchesToolFilter($"{tool.Group} {tool.Name} {tool.Reference}")).ToArray();
        var includeAvailable = MatchesToolFilter("Objets & rangements inventaire banque recherche catalogue données communes");
        ImGui.Spacing();
        var columns = Math.Clamp((int)(ImGui.GetContentRegionAvail().X / 155), 2, 10);
        var openDetails = false;
        if (ImGui.BeginTable("ToolIconGrid", columns, ImGuiTableFlags.SizingStretchSame))
        {
            try
            {
                if (includeAvailable)
                {
                    ImGui.TableNextColumn();
                    if (DrawToolTile("AvailableItems", FontAwesomeIcon.BoxOpen, "Objets & rangements"))
                    {
                        selectedAvailableTool = true;
                        selectedTool = null;
                        openDetails = true;
                    }
                }
                foreach (var tool in matches)
                {
                    ImGui.TableNextColumn();
                    if (DrawToolTile(tool.Reference, tool.Icon, tool.Reference))
                    {
                        selectedAvailableTool = false;
                        selectedTool = tool;
                        openDetails = true;
                    }
                }
            }
            finally { ImGui.EndTable(); }
        }
        if (matches.Length == 0 && !includeAvailable) ImGui.TextWrapped("Aucun outil ne correspond à ce filtre.");
        // Open and render at the same ID-stack level, outside the table's scope.
        if (openDetails) ImGui.OpenPopup(ToolDetailsPopup);
        DrawToolDetails();
    }

    private static bool DrawToolTile(string id, FontAwesomeIcon icon, string caption)
    {
        var origin = ImGui.GetCursorPosX();
        var width = Math.Max(1, ImGui.GetContentRegionAvail().X);
        var side = Math.Min(72, width);
        ImGui.SetCursorPosX(origin + Math.Max(0, (width - side) / 2));
        var clicked = ImGui.Button($"##ToolTile{id}", new Vector2(side, 64));
        var minimum = ImGui.GetItemRectMin();
        var maximum = ImGui.GetItemRectMax();

        // Measure and draw in the host's icon font, using strictly positive tile dimensions.
        // Never retain the borrowed font across UI frames or mutate the global font scale.
        var font = UiBuilder.IconFont;
        var glyph = icon.ToIconString();
        const float iconSize = 28;
        Vector2 glyphSize;
        ImGui.PushFont(font);
        try { glyphSize = ImGui.CalcTextSize(glyph) * (iconSize / ImGui.GetFontSize()); }
        finally { ImGui.PopFont(); }
        var position = minimum + (maximum - minimum - glyphSize) / 2;
        ImGui.GetWindowDrawList().AddText(font, iconSize, position, ImGui.GetColorU32(ImGuiCol.Text), glyph);

        var captionWidth = ImGui.CalcTextSize(caption).X;
        ImGui.SetCursorPosX(origin + Math.Max(0, (width - captionWidth) / 2));
        ImGui.TextWrapped(caption);
        ImGui.SetCursorPosX(origin);
        ImGui.Spacing();
        return clicked;
    }

    private bool MatchesToolFilter(string text) => string.IsNullOrWhiteSpace(toolQuery)
        || CultureInfo.InvariantCulture.CompareInfo.IndexOf(text, toolQuery.Trim(),
            CompareOptions.IgnoreCase | CompareOptions.IgnoreNonSpace) >= 0;

    private void OpenToolDirectory(string reference)
    {
        toolQuery = reference;
        page = Page.Home;
    }

    private void OpenContextTool(string reference)
    {
        switch (reference)
        {
            case "Craftimizer":
            case "Item Use": page = Page.Items; focusCraftTab = true; break;
            case "GatherBuddy": page = Page.Items; gatheringTypeFilter = null; focusGatherTab = true; break;
            case "Price Insight": page = Page.Market; break;
            default: OpenToolDirectory(reference); break;
        }
    }

    private void DrawContextTools()
    {
        ImGui.Spacing();
        foreach (var tool in PlannedTools.Where(tool => tool.Reference is "Craftimizer" or "GatherBuddy" or "Price Insight"))
        {
            ImGui.PushID($"ContextTool{tool.Reference}");
            try
            {
                ImGui.PushFont(UiBuilder.IconFont);
                bool clicked;
                try { clicked = ImGui.Button(tool.Icon.ToIconString(), new Vector2(34, 28)); }
                finally { ImGui.PopFont(); }
                if (clicked) OpenContextTool(tool.Reference);
                if (ImGui.IsItemHovered()) ImGui.SetTooltip($"{tool.Reference} · {SelectedItem?.Name}");
                ImGui.SameLine();
            }
            finally { ImGui.PopID(); }
        }
        ImGui.NewLine();
    }

    private void DrawToolDetails()
    {
        ImGui.SetNextWindowSize(new Vector2(470, 0), ImGuiCond.Appearing);
        var open = true;
        if (!ImGui.BeginPopupModal(ToolDetailsPopup, ref open, ImGuiWindowFlags.AlwaysAutoResize)) return;
        try
        {
            if (selectedAvailableTool)
            {
                ImGui.TextColored(Accent, "Objets & rangements");
                ImGui.TextColored(Success, "Disponible");
                ImGui.Separator();
                ImGui.TextWrapped("Recherchez un objet par son nom ou son identifiant, consultez les sacs actuels et retrouvez les stocks servant/chocobo déjà importés dans la banque.");
                if (SelectedItem is { } item) ImGui.TextWrapped($"Objet en contexte : {item.Name}");
                ImGui.Spacing();
                if (ImGui.Button("Ouvrir l'outil", new Vector2(-1, 32)))
                {
                    page = Page.Items;
                    ImGui.CloseCurrentPopup();
                }
            }
            else if (selectedTool is { } tool)
            {
                ImGui.TextColored(Accent, tool.Reference);
                var itemUseAvailable = tool.Reference == "Item Use";
                var bankAvailable = tool.Reference == "Banque d'objets";
                var craftAvailable = tool.Reference == "Craftimizer";
                var gatherAvailable = tool.Reference == "GatherBuddy";
                var sortAvailable = tool.Reference == "SortaKinda";
                var collectionsAvailable = tool.Reference == "Collections";
                var marketAvailable = tool.Reference == "Price Insight";
                var questsAvailable = tool.Reference == "QuestTracker";
                var blueAvailable = tool.Reference == "Blue Mage Helper";
                var characterAvailable = tool.Reference == "Character Panel Refined";
                var cactpotAvailable = tool.Reference == "ezMiniCactpot";
                var mapAvailable = tool.Reference == "Mappy";
                var macroAvailable = tool.Reference == "Macro Chain";
                var available = itemUseAvailable || bankAvailable || craftAvailable || gatherAvailable || sortAvailable || collectionsAvailable || marketAvailable || questsAvailable || blueAvailable || characterAvailable || cactpotAvailable || mapAvailable || macroAvailable;
                ImGui.TextColored(available ? Success : Muted, available ? "Fondation disponible" : "À venir");
                ImGui.Separator();
                ImGui.TextWrapped(tool.Name);
                ImGui.TextDisabled(tool.Group);
                ImGui.Spacing();
                ImGui.TextWrapped(tool.Description);
                if (itemUseAvailable)
                {
                    ImGui.Spacing();
                    DrawItemUsePreview();
                    if (ImGui.Button("Ouvrir les usages de l'objet", new Vector2(-1, 32)))
                    {
                        page = Page.Items;
                        focusCraftTab = true;
                        ImGui.CloseCurrentPopup();
                    }
                }
                else if (macroAvailable)
                {
                    ImGui.Spacing();
                    ImGui.TextWrapped("Séquences expérimentales de macros personnelles et partagées. Chaque macro choisie doit se terminer par /tenshonext. Lancement manuel uniquement ; aucun changement automatique des macros enregistrées. Validation en jeu requise.");
                    if (ImGui.Button("Ouvrir les séquences de macros", new Vector2(-1, 32)))
                    { page = Page.MacroChain; ImGui.CloseCurrentPopup(); }
                }
                else if (mapAvailable)
                {
                    ImGui.Spacing();
                    ImGui.TextWrapped("Disponible : catalogue natif des cartes, recherche région/zone, ouverture sur coordonnées saisies et lien vers les ressources de la zone. Les repères automatiques et fonctionnalités avancées restent à développer.");
                    if (ImGui.Button("Ouvrir les cartes et repères", new Vector2(-1, 32)))
                    { page = Page.Maps; ImGui.CloseCurrentPopup(); }
                }
                else if (cactpotAvailable)
                {
                    ImGui.Spacing();
                    ImGui.TextWrapped("Disponible : solveur exact du ticket saisi, meilleure révélation et meilleures lignes. Saisissez entre un et quatre chiffres connus.");
                    if (ImGui.Button("Ouvrir le solveur Mini Cactpot", new Vector2(-1, 32)))
                    {
                        page = Page.MiniCactpot;
                        ImGui.CloseCurrentPopup();
                    }
                }
                else if (characterAvailable)
                {
                    ImGui.Spacing();
                    ImGui.TextWrapped("Disponible : attributs natifs du personnage, combat, artisanat et récolte. Les effets dérivés et formules restent à développer.");
                    if (ImGui.Button("Ouvrir les statistiques", new Vector2(-1, 32)))
                    {
                        page = Page.Character;
                        ImGui.CloseCurrentPopup();
                    }
                }
                else if (blueAvailable)
                {
                    ImGui.Spacing();
                    ImGui.TextWrapped("Disponible : grimoire du jeu, sorts appris confirmés, numéros, rangs, descriptions et lieux renseignés. Les sources non renseignées et conditions d'apprentissage restent à compléter.");
                    if (ImGui.Button("Ouvrir le grimoire Mage bleu", new Vector2(-1, 32)))
                    {
                        page = Page.BlueMagic;
                        ImGui.CloseCurrentPopup();
                    }
                }
                else if (questsAvailable)
                {
                    ImGui.Spacing();
                    ImGui.TextWrapped("Disponible : catalogue, catégories natives, quêtes en cours et terminées confirmées. Prérequis et objectifs détaillés restent à développer.");
                    if (ImGui.Button("Ouvrir le suivi des quêtes", new Vector2(-1, 32)))
                    {
                        page = Page.Quests;
                        ImGui.CloseCurrentPopup();
                    }
                }
                else if (marketAvailable)
                {
                    ImGui.Spacing();
                    ImGui.TextWrapped("Disponible : prix NQ/HQ du monde courant via Universalis, dates et cache partagé. Le survol en jeu est activable dans Réglages et reste désactivé par défaut.");
                    if (ImGui.Button("Ouvrir les prix du marché", new Vector2(-1, 32)))
                    {
                        page = Page.Market;
                        ImGui.CloseCurrentPopup();
                    }
                }
                else if (collectionsAvailable)
                {
                    ImGui.Spacing();
                    ImGui.TextWrapped("Disponible : catalogue des montures, mascottes et emotes, recherche et acquisitions confirmées du personnage. Sources d'obtention et autres collections restent à développer.");
                    if (ImGui.Button("Ouvrir les collections", new Vector2(-1, 32)))
                    {
                        page = Page.Collections;
                        ImGui.CloseCurrentPopup();
                    }
                }
                else if (sortAvailable)
                {
                    ImGui.Spacing();
                    ImGui.TextWrapped("Disponible : aperçu par nom, catégorie du jeu, quantité ou qualité, et sauvegarde de la règle. L'application dans l'inventaire du jeu n'est pas implémentée.");
                    if (ImGui.Button("Ouvrir l'aperçu d'organisation", new Vector2(-1, 32)))
                    {
                        page = Page.SortPreview;
                        ImGui.CloseCurrentPopup();
                    }
                }
                else if (gatherAvailable)
                {
                    ImGui.Spacing();
                    ImGui.TextWrapped("Disponible : lieux de récolte et de pêche connus, niveaux, filtre par type et carte de zone. Horaires, météo et pêche sous-marine restent à développer.");
                    if (ImGui.Button("Voir les lieux de récolte", new Vector2(-1, 32)))
                    {
                        page = Page.Gathering;
                        gatheringTypeFilter = null;
                        ImGui.CloseCurrentPopup();
                    }
                }
                else if (craftAvailable)
                {
                    ImGui.Spacing();
                    ImGui.TextWrapped("Disponible : recettes, carnet par métier, préparation des ingrédients et chaîne des sous-recettes pour une quantité à produire. Les stocks sont partagés entre les branches et les variantes ambiguës restent à choisir. Simulation et macros restent à développer.");
                    if (ImGui.Button("Ouvrir la préparation de fabrication", new Vector2(-1, 32)))
                    {
                        page = Page.Items;
                        focusCraftTab = true;
                        ImGui.CloseCurrentPopup();
                    }
                }
                else if (bankAvailable)
                {
                    ImGui.Spacing();
                    ImGui.TextWrapped("La banque regroupe les imports complets des servants et sacoches. Cliquez sur une ligne pour placer l'objet en contexte.");
                    if (ImGui.Button("Ouvrir la banque d'objets", new Vector2(-1, 32)))
                    {
                        page = Page.Items;
                        focusBankTab = true;
                        ImGui.CloseCurrentPopup();
                    }
                }
                else
                {
                    ImGui.Spacing();
                    ImGui.TextWrapped("Cet outil fait partie du périmètre prévu et n'est pas encore utilisable.");
                }
            }
            ImGui.Spacing();
            if (ImGui.Button("Fermer", new Vector2(-1, 28))) ImGui.CloseCurrentPopup();
        }
        finally { ImGui.EndPopup(); }
    }

    private void DrawItemUsePreview()
    {
        if (itemId <= 0)
        {
            ImGui.TextDisabled("Sélectionnez d'abord un objet dans Objets & rangements.");
            return;
        }

        if (recipeCatalog.State.Catalog is not { } catalog)
        {
            ImGui.TextDisabled("Catalogue de recettes en préparation…");
            return;
        }

        var uses = catalog.ForIngredient((uint)itemId)
            .GroupBy(recipe => recipe.ResultItemId)
            .Select(group => group.First())
            .ToArray();
        ImGui.TextColored(Accent, $"Utilisé dans ({uses.Length})");
        ImGui.TextDisabled("Recettes connues qui utilisent cet objet · cliquez sur un résultat");
        if (uses.Length == 0)
        {
            ImGui.TextDisabled("Aucune recette connue pour cet objet.");
            return;
        }

        foreach (var recipe in uses.Take(6))
        {
            var result = itemCatalog.State.Catalog?.Find(recipe.ResultItemId);
            ImGui.PushID($"ItemUse{recipe.RecipeId}");
            try
            {
                DrawItemIcon(result, new Vector2(28));
                if (ImGui.IsItemClicked())
                {
                    itemId = (int)recipe.ResultItemId;
                    focusCraftTab = true;
                    page = Page.Items;
                    ImGui.CloseCurrentPopup();
                }
                ImGui.SameLine();
                var label = result?.Name ?? $"Objet {recipe.ResultItemId}";
                if (ImGui.SmallButton($"{label}##ItemUseResult"))
                {
                    itemId = (int)recipe.ResultItemId;
                    focusCraftTab = true;
                    page = Page.Items;
                    ImGui.CloseCurrentPopup();
                }
                ImGui.SameLine();
                ImGui.TextDisabled($"{recipe.CraftType} · niv. {recipe.Level}");
            }
            finally { ImGui.PopID(); }
        }
        if (uses.Length > 6) ImGui.TextDisabled($"… et {uses.Length - 6} autre(s) résultat(s) dans Craft lié.");
    }
}
