namespace TenshoAssistant;

// Pure managed settings; the Dalamud interface is attached in a separate partial.
public sealed partial class Configuration
{
    public int Version { get; set; } = 1;
    public List<TenshoAssistant.Macros.MacroSlot> MacroChainPlan { get; set; } = [];
    public bool OpenOnLoad { get; set; }
    public bool OpenOnLogin { get; set; }
    public int SortPreviewField { get; set; }
    public bool SortPreviewDescending { get; set; }
    private bool marketPricesOnHover;
    public bool MarketPricesOnHover
    {
        get => Volatile.Read(ref marketPricesOnHover);
        set => Volatile.Write(ref marketPricesOnHover, value);
    }
}
