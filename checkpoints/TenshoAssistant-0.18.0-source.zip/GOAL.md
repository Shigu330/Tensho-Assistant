# GOAL sélectionné

ID: MACRO-001A
OBJECTIVE: Enchaîner des macros préparées avec un marqueur de dernière ligne, lancer explicitement et arrêter les étapes futures ; confirmer la réception native avant clôture.
CURRENT_STATE: IMPLEMENTED / TESTED — page et adaptateur en 0.18.0, 114 tests/package validés ; premier essai natif demandé à l'utilisateur, non observé.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: Domaines Gathering, Inventory, Collections, Market, Quests, Character, MiniGames ; MainWindow.* ; Plugin.cs ; tests et documents.
IN_SCOPE: Séquence managée copiée, preuve des transitions natives, annulation/identité/ownership, interface puis tests ; aucune action implicite.
OUT_OF_SCOPE: Déclarer les 17 plugins remplacés ; prétendre une validation en jeu sans observation.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: 2026-10-28, 88 % disponibles sur 5 h et 98 % semaine au dernier relevé. Ancien checkpoint quota terminé après instruction de reprise.
NEXT_ACTION: Obtenir le résultat des deux macros de test en jeu. En cas d'échec, exploiter ligne native, index du marqueur et noms copiés ; aucun succès déduit d'un timeout. Voir docs/MACRO-001A.md.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
