# GOAL sélectionné

ID: TRIAD-001B
OBJECTIVE: Ajouter le moteur et le solveur manuel Triple Triade pour règles normales, en réutilisant le carnet et le deck préparé ; poursuivre ensuite la couverture du projet.
CURRENT_STATE: IMPLEMENTED / TESTED — simulateur et conseil intégrés en 0.22.0, 135 tests/package valides ; fins de partie comparées à un moteur exhaustif indépendant et probe de cartes natives passant. Macro Chain attend un essai reporté par l'utilisateur, sans bloquer ce travail indépendant.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: Domaines Gathering, Inventory, Collections, Market, Quests, Character, MiniGames ; MainWindow.* ; Plugin.cs ; tests et documents.
IN_SCOPE: Règles normales, mains connues, plateau manuel, captures, score de dix cartes, conseil minimax borné et annulable ; exactitude distincte d'une estimation limitée.
OUT_OF_SCOPE: Déclarer les 17 plugins remplacés ; prétendre une validation en jeu sans observation.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: 2026-10-28, 61 % disponibles sur 5 h et 94 % semaine au dernier relevé ; continuer selon instruction utilisateur.
NEXT_ACTION: Sauvegarder 0.22.0 puis étudier TRIAD-001C : règles particulières et interactions, sources primaires avant implémentation et cas indépendants. Ne pas annoncer une lecture du plateau non implémentée. Les autres domaines de la roadmap restent dans le goal global.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
