using System.Numerics;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.Items;
using TenshoAssistant.MiniGames;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private readonly TriadSolveSession triadSolve = new();
    private readonly List<uint> triadBlueHand = [];
    private readonly List<uint> triadRedHand = [];
    private readonly Stack<TriadPosition> triadUndo = [];
    private TriadPosition? triadPosition;
    private int triadRevision;
    private int triadSelectedToken = -1;
    private int triadAddHand = 1;
    private bool triadRedStarts;
    private bool triadRulesConfirmed;
    private bool triadEditingHands = true;
    private string triadSimulationQuery = "";
    private string? triadSimulationError;
    private static readonly Vector4 TriadBlue = new(0.35f, 0.65f, 1, 1);
    private static readonly Vector4 TriadRed = new(1, 0.45f, 0.4f, 1);

    private void InvalidateTriadSimulation(bool resetBoard)
    {
        triadRevision++; triadSolve.Cancel(); triadSimulationError = null;
        if (resetBoard) { triadPosition = null; triadUndo.Clear(); triadSelectedToken = -1; triadEditingHands = true; }
    }
    private void AddTriadSimulationCard(uint id, bool red)
    {
        var hand = red ? triadRedHand : triadBlueHand;
        if (hand.Count >= 5 || hand.Contains(id))
        { triadSimulationError = "La main choisie est pleine ou contient déjà cette carte."; return; }
        hand.Add(id); InvalidateTriadSimulation(true);
    }

    private void DrawTriadSimulation()
    {
        ImGui.TextWrapped("1. Renseignez les cinq cartes initiales de chaque joueur. 2. Démarrez le plateau et rejouez les coups observés. 3. Calculez un conseil pour le joueur au trait.");
        if (ImGui.Checkbox("Je confirme : règles normales, sans règle spéciale", ref triadRulesConfirmed)) InvalidateTriadSimulation(false);
        ImGui.TextDisabled("Mains cachées, Même, Plus, Inversion, Mort subite et autres règles ne sont pas modélisées.");
        if (ImGui.RadioButton("Mains initiales", triadEditingHands)) triadEditingHands = true;
        ImGui.SameLine();
        if (ImGui.RadioButton("Plateau et conseil", !triadEditingHands)) triadEditingHands = false;
        if (triadEditingHands)
        {
            if (ImGui.SmallButton("Charger mon deck dans la main bleue"))
            {
                triadBlueHand.Clear(); triadBlueHand.AddRange(triadDeck!.Take(5));
                InvalidateTriadSimulation(true);
            }
            ImGui.SameLine();
            if (ImGui.SmallButton("Vider les deux mains"))
            { triadBlueHand.Clear(); triadRedHand.Clear(); InvalidateTriadSimulation(true); }
            ImGui.SetNextItemWidth(240);
            ImGui.InputTextWithHint("##SimulationCardSearch", "Filtrer les cartes par nom ou numéro…", ref triadSimulationQuery, 128);
            if (ImGui.RadioButton("Ajouter en bleu", triadAddHand == 0)) triadAddHand = 0;
            ImGui.SameLine();
            if (ImGui.RadioButton("Ajouter en rouge", triadAddHand == 1)) triadAddHand = 1;
            ImGui.SetNextItemWidth(320);
            if (ImGui.BeginCombo("##AddSimulationCard", "Choisir une carte du carnet…"))
            {
                try
                {
                    var target = triadAddHand == 0 ? triadBlueHand : triadRedHand;
                    var query = triadSimulationQuery.Trim();
                    foreach (var entry in triadCards.Where(entry => query.Length == 0
                        || entry.Name.Contains(query, StringComparison.OrdinalIgnoreCase) || entry.Card!.Number.ToString() == query))
                    {
                        ImGui.BeginDisabled(target.Count >= 5 || target.Contains(entry.Id));
                        try
                        {
                            if (ImGui.Selectable($"{entry.Card!.Number} · {entry.Name}##Sim{entry.Id}"))
                                AddTriadSimulationCard(entry.Id, triadAddHand == 1);
                        }
                        finally { ImGui.EndDisabled(); }
                    }
                }
                finally { ImGui.EndCombo(); }
            }
            DrawTriadHand(false, true);
            DrawTriadHand(true, true);
            if (ImGui.Checkbox("Rouge joue en premier", ref triadRedStarts)) InvalidateTriadSimulation(true);
            if (ImGui.Button("Démarrer / réinitialiser le plateau"))
            {
                InvalidateTriadSimulation(true);
                try
                {
                    TriadCardDefinition Resolve(uint id) => triadCards.FirstOrDefault(entry => entry.Id == id)?.Card
                        ?? throw new InvalidOperationException($"Carte indisponible : ID {id}.");
                    triadPosition = TriadPosition.Create(triadBlueHand.Select(Resolve), triadRedHand.Select(Resolve), triadRedStarts ? TriadPlayer.Red : TriadPlayer.Blue);
                    triadEditingHands = false;
                }
                catch (Exception error) { triadSimulationError = error.Message; }
            }
        }
        if (triadSimulationError is { } message) ImGui.TextWrapped(message);
        if (triadEditingHands) return;
        if (triadPosition is not { } position) { ImGui.TextWrapped("Renseignez les deux mains et démarrez le plateau depuis Mains initiales."); return; }
        ImGui.Separator();
        ImGui.TextColored(position.Turn == TriadPlayer.Blue ? TriadBlue : TriadRed,
            position.IsTerminal ? "Partie terminée" : $"Au tour de {(position.Turn == TriadPlayer.Blue ? "Bleu" : "Rouge")} : choisir une carte dans sa main, puis une case vide.");
        ImGui.TextUnformatted($"Bleu {position.BlueScore} — Rouge {position.RedScore} · cartes en main incluses");
        if (triadSelectedToken >= 0 && (!position.InHand(triadSelectedToken) || (triadSelectedToken < 5) != (position.Turn == TriadPlayer.Blue))) triadSelectedToken = -1;
        if (ImGui.GetContentRegionAvail().X >= 620 && ImGui.BeginTable("TriadBoardAndHands", 2, ImGuiTableFlags.SizingFixedFit))
        {
            try
            {
                ImGui.TableSetupColumn("Plateau", ImGuiTableColumnFlags.WidthFixed, 280);
                ImGui.TableSetupColumn("Mains", ImGuiTableColumnFlags.WidthStretch);
                ImGui.TableNextRow(); ImGui.TableNextColumn(); DrawTriadBoard(position);
                ImGui.TableNextColumn(); DrawTriadHand(false); DrawTriadHand(true);
            }
            finally { ImGui.EndTable(); }
        }
        else { DrawTriadBoard(position); DrawTriadHand(false); DrawTriadHand(true); }
        ImGui.BeginDisabled(triadUndo.Count == 0);
        try
        {
            if (ImGui.SmallButton("Annuler le dernier coup"))
            { triadPosition = triadUndo.Pop(); triadSelectedToken = -1; InvalidateTriadSimulation(false); }
        }
        finally { ImGui.EndDisabled(); }
        DrawTriadAdvice();
    }

    private void DrawTriadBoard(TriadPosition position)
    {
        if (ImGui.BeginTable("TriadManualBoard", 3, ImGuiTableFlags.SizingFixedFit))
        {
            try
            {
                for (var column = 0; column < 3; column++) ImGui.TableSetupColumn($"BoardColumn{column}", ImGuiTableColumnFlags.WidthFixed, 90);
                for (var square = 0; square < 9; square++)
                {
                    ImGui.TableNextColumn(); ImGui.PushID(square);
                    try
                    {
                        var token = position.CardAt(square);
                        if (token < 0)
                        {
                            ImGui.BeginDisabled(triadSelectedToken < 0 || position.IsTerminal);
                            try
                            {
                                if (ImGui.Button($"L{square / 3 + 1} C{square % 3 + 1}", new Vector2(80, 80)))
                                    ApplyTriadMove(new(triadSelectedToken, square));
                            }
                            finally { ImGui.EndDisabled(); }
                        }
                        else
                        {
                            var definition = position.Cards[token];
                            var entry = triadCards.FirstOrDefault(entry => entry.Id == definition.Id);
                            DrawItemIcon(new ItemDefinition(0, entry?.Name ?? $"Carte {definition.Number}", false, definition.IconId), new Vector2(62));
                            if (ImGui.IsItemHovered()) ImGui.SetTooltip($"{entry?.Name}\n↑{TriadCardDefinition.Value(definition.Top)} →{TriadCardDefinition.Value(definition.Right)} ↓{TriadCardDefinition.Value(definition.Bottom)} ←{TriadCardDefinition.Value(definition.Left)}");
                            var blue = position.OwnerAt(square) == TriadPlayer.Blue;
                            ImGui.TextColored(blue ? TriadBlue : TriadRed, $"{(blue ? "Bleu" : "Rouge")} · {definition.Number}");
                        }
                    }
                    finally { ImGui.PopID(); }
                }
            }
            finally { ImGui.EndTable(); }
        }
    }

    private void DrawTriadHand(bool red, bool editing = false)
    {
        var hand = red ? triadRedHand : triadBlueHand;
        var count = !editing && triadPosition is { } current
            ? $"{Enumerable.Range(red ? 5 : 0, 5).Count(current.InHand)} carte(s) en main"
            : $"{hand.Count}/5 cartes initiales";
        ImGui.TextColored(red ? TriadRed : TriadBlue, $"Main {(red ? "rouge" : "bleue")} · {count}");
        var remove = -1;
        if (!ImGui.BeginTable(red ? "RedHand" : "BlueHand", 5, ImGuiTableFlags.SizingFixedFit)) return;
        try
        {
            for (var index = 0; index < 5; index++) ImGui.TableSetupColumn($"Hand{index}", ImGuiTableColumnFlags.WidthFixed, 58);
            for (var index = 0; index < 5; index++)
            {
                ImGui.TableNextColumn(); ImGui.PushID(index + (red ? 5 : 0));
                try
                {
                    if (index >= hand.Count) { ImGui.Dummy(new Vector2(44, 44)); continue; }
                    var entry = triadCards.FirstOrDefault(entry => entry.Id == hand[index]);
                    var token = index + (red ? 5 : 0);
                    var playable = triadPosition is { IsTerminal: false } position && position.InHand(token) && (position.Turn == TriadPlayer.Red) == red;
                    ImGui.BeginDisabled(triadPosition is not null && !playable);
                    try
                    {
                        DrawItemIcon(new ItemDefinition(0, entry?.Name ?? $"ID {hand[index]}", false, entry?.IconId ?? 0), new Vector2(44));
                        if (playable && ImGui.IsItemClicked()) triadSelectedToken = token;
                        if (ImGui.IsItemHovered()) ImGui.SetTooltip($"{entry?.Name ?? "Carte indisponible"}\nCliquer pour choisir la carte à jouer.");
                        var caption = !editing && triadPosition is { } board && !board.InHand(token)
                            ? "Jouée" : triadSelectedToken == token ? "Choisie" : entry?.Card?.Number.ToString() ?? "?";
                        ImGui.TextColored(triadSelectedToken == token ? Accent : Muted, caption);
                    }
                    finally { ImGui.EndDisabled(); }
                    if (editing && ImGui.SmallButton("Retirer")) remove = index;
                }
                finally { ImGui.PopID(); }
            }
        }
        finally { ImGui.EndTable(); }
        if (remove >= 0) { hand.RemoveAt(remove); InvalidateTriadSimulation(true); }
    }

    private void ApplyTriadMove(TriadMove move)
    {
        if (triadPosition is not { } previous) return;
        try
        {
            var next = previous.Play(move);
            triadUndo.Push(previous); triadPosition = next; triadSelectedToken = -1;
            InvalidateTriadSimulation(false);
        }
        catch (Exception error) { triadSimulationError = error.Message; }
    }

    private void DrawTriadAdvice()
    {
        // The board may have changed earlier in this frame; always use the authoritative snapshot.
        if (triadPosition is not { } position) return;
        var state = triadSolve.State;
        ImGui.BeginDisabled(!triadRulesConfirmed || position.IsTerminal || state.Loading);
        try
        {
            if (ImGui.Button("Calculer un conseil (règles normales)"))
                _ = triadSolve.StartAsync(position, bankBridge.State.CharacterId, triadRevision);
        }
        finally { ImGui.EndDisabled(); }
        if (state.Loading)
        {
            ImGui.SameLine();
            if (ImGui.SmallButton("Annuler le calcul")) triadSolve.Cancel();
            ImGui.TextDisabled("Recherche en cours… limite de 3 secondes et 1 000 000 positions.");
        }
        if (state.Error is { } error) ImGui.TextWrapped(error);
        if (state.Result is not { } result || state.Revision != triadRevision) return;
        if (result.Moves.Count == 0) { ImGui.TextWrapped("Aucune profondeur complète obtenue dans la limite du calcul."); return; }
        ImGui.TextColored(result.Exact ? Success : Accent, result.Exact ? "Analyse exacte jusqu'à la fin, pour les mains et règles saisies." : "Estimation à profondeur limitée : aucun résultat final garanti.");
        ImGui.TextDisabled($"Profondeur complète : {result.CompletedDepth} · positions explorées : {result.Nodes:N0}");
        var best = result.Best(position.Turn);
        foreach (var candidate in best.Take(8))
        {
            var card = position.Cards[candidate.Move.CardIndex];
            var entry = triadCards.FirstOrDefault(entry => entry.Id == card.Id);
            var blue = (10 + candidate.BlueDifference) / 2;
            ImGui.PushID($"Advice{candidate.Move.CardIndex}/{candidate.Move.Square}");
            try
            {
                if (ImGui.SmallButton($"{entry?.Name ?? $"Carte {card.Number}"} → L{candidate.Move.Square / 3 + 1} C{candidate.Move.Square % 3 + 1} · Bleu {blue} / Rouge {10 - blue}"))
                { ApplyTriadMove(candidate.Move); break; }
                if (ImGui.IsItemHovered()) ImGui.SetTooltip("Appliquer ce coup uniquement au plateau simulé.");
            }
            finally { ImGui.PopID(); }
        }
        if (best.Count > 8) ImGui.TextDisabled($"{best.Count} coups ex æquo ; les huit premiers sont présentés.");
        ImGui.TextWrapped("Hypothèse : l'adversaire choisit ses meilleurs coups. Une estimation limitée compare les cartes contrôlées à l'horizon exploré, sans donner de probabilité de victoire.");
    }
}
