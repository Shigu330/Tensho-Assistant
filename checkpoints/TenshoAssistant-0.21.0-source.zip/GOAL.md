# GOAL sélectionné

ID: TRIAD-001A
OBJECTIVE: Construire les fondations Triple Triade : carnet des cartes natif, acquisitions, valeurs et préparation de deck reliées aux catalogues existants, puis poursuivre vers le solveur.
CURRENT_STATE: IMPLEMENTED / TESTED — carnet et préparation intégrés en 0.21.0, 129 tests/package valides ; probe de 475 cartes/icônes/objets passant. Macro Chain attend un essai reporté par l'utilisateur, sans bloquer ce travail indépendant.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: Domaines Gathering, Inventory, Collections, Market, Quests, Character, MiniGames ; MainWindow.* ; Plugin.cs ; tests et documents.
IN_SCOPE: Cartes TripleTriadCard/Resident dans Collections, confirmation native positive, typed AdditionalData dans Item commun, valeurs/rareté/type/icônes, préparation locale persistante ; fondations du solveur ensuite.
OUT_OF_SCOPE: Déclarer les 17 plugins remplacés ; prétendre une validation en jeu sans observation.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: 2026-10-28, 67 % disponibles sur 5 h et 95 % semaine au dernier relevé ; continuer selon instruction utilisateur.
NEXT_ACTION: Sauvegarder 0.21.0 puis TRIAD-001B : moteur et solveur manuel des règles normales, score incluant la dixième carte, tests indépendants et calcul annulable hors Draw. Ne pas annoncer les règles spéciales ou une lecture du plateau non implémentées.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
