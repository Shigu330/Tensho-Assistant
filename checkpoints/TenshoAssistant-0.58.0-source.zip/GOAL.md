# GOAL sélectionné

ID: SORT-FILTERS-006
OBJECTIVE: Filtrer par métadonnées natives avec Unknown explicite, puis poursuivre les 17 domaines jusqu’à la réserve de quota de 5 %.
CURRENT_STATE: IMPLEMENTED / TESTED en 0.58.0, 379 tests/package, Newtonsoft trois modes et probe natif d’équipement verts ; slots mains/pierres d’âme et filtres marché/potentiel HQ partagés. Rendu/application/persistance en jeu non observés.
FILES: Inventory/InventorySortRules ; Items/EquipmentSlots/ItemCatalogLoader ; MainWindow.SortRules/SortPreview/Tools/Fashion ; InventorySortMetadataTests ; ConfigSerializationProbe/FashionProbe ; docs/SORT-FILTERS-006.md.
IN_SCOPE: Propriétés bool? avec Oui/Non/Any, identité du type, masques natifs positifs, cache par ID, refus des valeurs invalides et compatibilité v1. Aucune nouvelle requête de prix ou lecture native.
OUT_OF_SCOPE: Présenter le type comme preuve de vente d’une pile ou d’équipement par le personnage, transformer Unknown en false, filtrer des slots non pris en charge. Tous les domaines restent PARTIAL.
VALIDATION: Verify.ps1 379/379, package/versions/ZIP/exclusion hôte verts, zéro avertissement/erreur ; cinq groupes de métadonnées. Newtonsoft None/Auto/Objects ; ApiProbe local ; FashionProbe natif sans --fetch avec 20 238 Wearable, 7 804 MainHand, 984 OffHand, 31 SoulCrystal, slots négatifs exclus.
QUOTA: Relevé 2026-10-29 : 15 % disponibles sur 5 h et 49 % semaine ; réserve utilisateur 5 %. Objectif global actif.
NEXT_ACTION: Snapshot 0.58 puis SORT-TEMPLATES-007 : modèles réutilisables de règles, sans propriétaire, compatibles avec la géométrie et chargeables en brouillon sans action native. Garder l’inconnu GP ; essais projection/Macro Chain différés, sans les redemander.
DEFINITION_OF_DONE: Tranche intégrée compilée, tests/package verts, limites documentées et sauvegarde source ; aucun domaine global promu complet sans preuve.
