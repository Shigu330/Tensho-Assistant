# État courant

CURRENT_GOAL: SORT-FILTERS-006 — IMPLEMENTED / TESTED ; équipement/marché/potentiel HQ, voir docs/SORT-FILTERS-006.md
CURRENT_MODEL_CLASS: HEAVY — métadonnées partagées et inconnus
RECOMMENDED_MODEL: HEAVY pour l’intégration native des menus/tri ; LIGHT pour les tâches mécaniques ; continuation autorisée
MODEL_ESCALATION: None
QUOTA: Relevé 2026-10-29 : 85 % consommés sur 5 h, 51 % semaine (15 % / 49 % disponibles). Réserve utilisateur 5 % ; objectif global actif.
LAST_READ: RULES/STATUS/GOAL, catalogue/helper d’équipement/éditeur relus ; champs de main/pierre d’âme confirmés par ApiProbe puis fichiers du jeu via FashionProbe. Snapshot 0.57 sauvegardé.
BUILD: COMPILED Release 0.58.0.0 ; sortie canonique bin/x64/Release
TESTS: TESTED — 379/379 tests ; package/versions/ZIP/exclusion hôte verts, zéro avertissement/erreur. Cinq groupes de métadonnées, Newtonsoft trois modes et probe natif de slots passants.
RUNTIME: Banque, stocks, carnet et préparation jusqu’à 0.5.27 confirmés par l’utilisateur. Fonctions 0.6–0.58 non validées en jeu. Tests projection et Macro Chain explicitement différés ; ne pas les redemander.
WORK_COMPLETED: Dix-sept domaines PARTIAL ; filtres type vendable marché, potentiel HQ et slots natifs (mains/pierres d’âme inclus). Métadonnées absentes ou étrangères inconnues, ni Oui ni Non ; cache par ID. Classement du type distinct de vente de pile/capacité personnage, sans réseau ni nouveau lecteur, mêmes gardes et permutation.
BLOCKER: Aucun blocage global. Le bonus natif d’Abondance reste inconnu : sources divergentes et aucun getter nommé confirmé dans les bindings étudiés. Ne pas inventer une formule ; travaux indépendants poursuivis.
RESUME_FROM: GOAL.md ; TESTING.md pour le protocole de la base.
NEXT_ACTION: Snapshot 0.58 puis SORT-TEMPLATES-007 : modèles réutilisables sans propriétaire, géométrie compatible et chargement en brouillon seulement. GP inconnu et essais craft/Macro Chain différés conservés.

| Plugin | Coverage |
|---|---|
| Avant-Garde | PARTIAL — répertoire manuel d'indices natifs, équipements signalés, emplacements/stock/contexte et source datée ; thème courant/teintures/score/attache non déduits |
| Blue Mage Helper | PARTIAL — grimoire, numéros, descriptions, lieux renseignés et acquisition confirmée |
| Character Panel Refined | PARTIAL — attributs natifs, sans formules dérivées |
| Collections | PARTIAL — montures, mascottes, emotes et cartes Triple Triade ; inconnu distinct d'absent |
| Craftimizer | PARTIAL — simulation/recherche/export/séquences, observation et projection d'un coup normal ; conditions/rotation native/recettes spéciales et runtime à compléter |
| Duty Loot Preview | PARTIAL — consultation manuelle par contenu, coffres/récompenses, icônes/contexte, provenance et cache ; drops directs non interprétés, données externes partielles |
| ezMiniCactpot | PARTIAL — solveur exact manuel et mode observé opt-in LotteryDaily ; conseil actualisé, aucune commande ; adaptation/rendu natifs non validés en jeu |
| GatherBuddy | PARTIAL — sources/maps/horaires/météo statiques et point courant observé opt-in (objets/icônes/taux affichés, contexte) ; présence/prérequis/harpon et validation native non couverts |
| Item Use | PARTIAL — recettes, mandats, candidats GC/aquarium, survol et menu Inventory opt-in ; autres usages/disponibilité, liens de discussion et runtime à compléter |
| LazyGatherer | PARTIAL — optimiseur manuel avec effets explicitement déclarés, observation du point et copie de ressources ; décodeur natif/bonus/régénération/procs/collectionnables et validation runtime à compléter |
| Macro Chain | PARTIAL — séquences à marqueur final, lancement explicite, arrêt, persistance ; natif à confirmer |
| Mappy | PARTIAL — navigateur natif, repères favoris persistants, ressources de zone et prévisions météo statiques ; météo forcée non observée |
| Monster Loot Hunter | PARTIAL — associations matériau/monstre, fiches/niveaux/lieux et carte de zone, transport/cadence partagés, contexte ; données communautaires partielles |
| Price Insight | PARTIAL — consultation manuelle et prix au survol opt-in, NQ/HQ/monde, cache/cadence/priorités partagés ; contexte mutualisé et scope owner/monde, runtime à confirmer |
| QuestTracker | PARTIAL — états natifs, séquence, fiche et liens de prérequis/suivantes ; disponibilité non calculée |
| SortaKinda | PARTIAL — profils/critères, zones protégées/filtrées avec équipement/marché/potentiel HQ, inversion et application visuelle après capture directe ; modèles réutilisables/autres filtres et runtime à compléter |
| TriadBuddy | PARTIAL — carnet/deck/solveur manuel, observation des faces opt-in expérimentale ; identités/règles/trait natifs et autres règles non établis |

