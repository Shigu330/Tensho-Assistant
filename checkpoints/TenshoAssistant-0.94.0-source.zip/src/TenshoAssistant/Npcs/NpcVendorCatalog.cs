using System.Collections.Frozen;
using TenshoAssistant.Caching;

namespace TenshoAssistant.Npcs;

public enum NpcShopKind { Gil, GrandCompany, Special }
// CurrencyItemId 0 means the game encodes the currency indirectly (RawCurrency) and it is not resolved: never guessed.
public sealed record NpcCost(uint CurrencyItemId,uint Amount,uint RawCurrency=0);
public sealed record NpcShopSale(uint ShopId,NpcShopKind Kind,string ShopName,uint ItemId,uint Quantity,bool Hq,IReadOnlyList<NpcCost> Costs);
// X/Y are map coordinates as shown in game; World* are kept to place the map flag exactly.
public sealed record NpcLocation(uint TerritoryId,uint MapId,string Zone,float X,float Y,float WorldX,float WorldY,float WorldZ);
public sealed record NpcVendor(uint NpcId,string Name,IReadOnlyList<uint> ShopIds,IReadOnlyList<NpcLocation> Locations);
public sealed record NpcVendorOffer(NpcVendor Vendor,NpcShopSale Sale);
public sealed record NpcVendorCacheData(string DataVersion,IReadOnlyList<NpcVendor> Vendors,IReadOnlyList<NpcShopSale> Sales);

/// <summary>Shop links as copied from game sheets; resolution follows direct shops, topic menus, pre-handlers and talk scripts.</summary>
public static class NpcShopLinks
{
    public const int MaximumDepth=4;
    public static IReadOnlyList<uint> Resolve(IEnumerable<uint> npcData,IReadOnlySet<uint> shops,IReadOnlyDictionary<uint,IReadOnlyList<uint>> indirections)
    {
        var found=new List<uint>();var seen=new HashSet<uint>();
        void Visit(uint id,int depth)
        {
            if(id==0 || depth>MaximumDepth || !seen.Add(id))return;
            if(shops.Contains(id)){found.Add(id);return;}
            if(indirections.TryGetValue(id,out var targets))foreach(var target in targets)Visit(target,depth+1);
        }
        foreach(var id in npcData)Visit(id,0);
        return Array.AsReadOnly(found.Distinct().Order().ToArray());
    }
    /// <summary>
    /// Cost of a special shop entry: direct item ids are exact; encoded small ids stay raw. Probe 2026-10-30
    /// (checkpoints/0.92.0-shop-currency-probe.log): scrip exchanges use type 16 id 4 for both crafter and gatherer scrips,
    /// so neither TomestonesItem nor any single table maps these ids; they are shown unresolved, never guessed.
    /// </summary>
    public static NpcCost Currency(byte encoding,uint costId,uint amount)
        =>encoding==0 || costId>=100 ? new(costId,amount)
          :ProvenCurrencies.TryGetValue((encoding,costId),out var item) ? new(item,amount):new(0,amount,costId);
    // Only codes backed by two sources: the user's in-game reading (2026-10-30) and the shop families of
    // checkpoints/0.94.0-shop-currency-probe.log. Codes 2/3 of types 2 and 4 follow the *current* tomestones, so they need
    // revisiting at each patch. Ambiguous or unobserved codes (t2:1, t4:1, t4:2, t4:4, t4:25, t16:1, …) stay unresolved.
    private static readonly IReadOnlyDictionary<(byte Type,uint Id),uint> ProvenCurrencies=new Dictionary<(byte,uint),uint>
    {
        [(16,2)]=33913,[(16,4)]=33914,[(16,6)]=41784,[(16,7)]=41785,[(16,25)]=25,   // purple/orange scrips, wolf marks
        [(2,2)]=48,[(2,3)]=49,[(4,3)]=49,                                           // mathematics, mnemonics tomestones
        [(4,27)]=27,[(4,29)]=29,                                                    // allied seals, MGP
    };
    /// <summary>Map coordinate shown in game for a world axis value (same formula as the game's map, 2048 units per map, scale = SizeFactor).</summary>
    public static float MapCoordinate(float world,int offset,uint scale)
    {
        var factor=scale/100f;
        return 41f/factor*((world+offset)*factor+1024f)/2048f+1f;
    }
}

public sealed class NpcVendorCatalog
{
    private readonly FrozenDictionary<uint,IReadOnlyList<NpcVendorOffer>> byItem;
    public string Source{get;}
    public int VendorCount{get;}
    public int SaleCount{get;}
    public IReadOnlyList<NpcVendor> Vendors{get;}
    public IReadOnlyList<NpcShopSale> Sales{get;}
    private NpcVendorCatalog(string source,IReadOnlyList<NpcVendor> vendors,IReadOnlyList<NpcShopSale> sales,FrozenDictionary<uint,IReadOnlyList<NpcVendorOffer>> byItem)
    {Source=source;Vendors=vendors;Sales=sales;this.byItem=byItem;VendorCount=vendors.Count;SaleCount=sales.Count;}

    public static NpcVendorCatalog Build(IEnumerable<NpcVendor> vendors,IEnumerable<NpcShopSale> sales,string source,CancellationToken cancellation=default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(source);
        var npcs=vendors.Where(vendor=>vendor is not null && vendor.NpcId!=0 && vendor.ShopIds.Count>0).GroupBy(vendor=>vendor.NpcId).Select(group=>group.First()).ToArray();
        var rows=sales.Where(sale=>sale is not null && sale.ItemId!=0 && sale.ShopId!=0).ToArray();
        var byShop=rows.GroupBy(sale=>sale.ShopId).ToDictionary(group=>group.Key,group=>group.ToArray());
        var offers=new Dictionary<uint,List<NpcVendorOffer>>();
        foreach(var vendor in npcs)
        {
            cancellation.ThrowIfCancellationRequested();
            foreach(var shop in vendor.ShopIds)
                if(byShop.TryGetValue(shop,out var shopSales))
                    foreach(var sale in shopSales)
                    {
                        if(!offers.TryGetValue(sale.ItemId,out var list))offers[sale.ItemId]=list=[];
                        list.Add(new(vendor,sale));
                    }
        }
        // Located vendors first, then cheapest single-currency cost, then name: the hover shows the head of this order.
        var index=offers.ToFrozenDictionary(pair=>pair.Key,pair=>(IReadOnlyList<NpcVendorOffer>)Array.AsReadOnly(pair.Value
            .OrderBy(offer=>offer.Vendor.Locations.Count==0).ThenBy(offer=>offer.Sale.Kind).ThenBy(offer=>offer.Sale.Costs.Count==1 ? offer.Sale.Costs[0].Amount:uint.MaxValue)
            .ThenBy(offer=>offer.Vendor.Name,StringComparer.OrdinalIgnoreCase).ThenBy(offer=>offer.Vendor.NpcId).ThenBy(offer=>offer.Sale.ShopId).ToArray()));
        return new(source,Array.AsReadOnly(npcs),Array.AsReadOnly(rows),index);
    }
    public IReadOnlyList<NpcVendorOffer> ForItem(uint itemId)=>byItem.GetValueOrDefault(itemId) ?? [];
}

public sealed record NpcVendorState(NpcVendorCatalog? Catalog,int Copied,int Total,string? Error);
public sealed class NpcVendorService
{
    private NpcVendorState state=new(null,0,0,null);
    public NpcVendorState State=>Volatile.Read(ref state);
    internal void Progress(int copied,int total)=>Interlocked.Exchange(ref state,new(null,copied,total,null));
    internal void Publish(NpcVendorCatalog catalog)=>Interlocked.Exchange(ref state,new(catalog,catalog.SaleCount,catalog.SaleCount,null));
    internal void Fail(Exception error)=>Interlocked.Exchange(ref state,new(null,0,0,error.Message));
    internal void Clear()=>Interlocked.Exchange(ref state,new(null,0,0,null));
}

public static class NpcVendorCache
{
    public const string Family="catalog-npc-vendors";
    public const int MaximumRows=500_000;
    // Bump when the sheet-to-record copy rules change without a change of record shape.
    // 2: FateShop links (gemstone traders). 3: InclusionShop links (scrip exchanges), encoded currencies no longer mapped (2026-10-30).
    private const int CopyRules=5; // 4: purple scrips; 5: proven (type, id) currency table (orange scrips, tomestones, seals, MGP).
    public static readonly string Shape=CatalogCacheKeys.Shape(typeof(NpcVendor),typeof(NpcLocation),typeof(NpcShopSale),typeof(NpcCost),typeof(NpcShopKind));
    public static string Version(string dataVersion)=>CatalogCacheKeys.Version(dataVersion,CopyRules,Shape);
    public static bool Valid(NpcVendorCacheData? data,string dataVersion)
        =>data is not null && data.DataVersion==dataVersion && data.Vendors is { Count:>0 and <=MaximumRows } && data.Sales is { Count:>0 and <=MaximumRows }
          && data.Vendors.All(vendor=>vendor is not null && vendor.Name is not null && vendor.ShopIds is not null && vendor.Locations is not null && vendor.Locations.All(location=>location is not null && location.Zone is not null))
          && data.Sales.All(sale=>sale is not null && sale.ShopName is not null && sale.Costs is not null && sale.Costs.All(cost=>cost is not null) && Enum.IsDefined(sale.Kind));
}
