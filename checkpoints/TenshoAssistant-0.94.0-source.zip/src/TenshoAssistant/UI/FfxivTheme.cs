using System.Numerics;
using Dalamud.Bindings.ImGui;

namespace TenshoAssistant.UI;

internal static class FfxivTheme
{
    public static readonly Vector4 Background = new(0.075f, 0.065f, 0.055f, 1);
    public static readonly Vector4 Panel = new(0.12f, 0.105f, 0.09f, 1);
    public static readonly Vector4 Border = new(0.34f, 0.27f, 0.17f, 1);
    public static readonly Vector4 Gold = new(0.94f, 0.77f, 0.46f, 1);
    public static readonly Vector4 Text = new(0.91f,0.89f,0.83f,1);
    public static readonly Vector4 TextMuted = new(0.65f, 0.69f, 0.75f, 1);
    public static readonly Vector4 Success = new(0.52f, 0.85f, 0.66f, 1);
    public static readonly Vector4 Selected = new(0.30f,0.23f,0.13f,1);
    public static readonly Vector4 Hovered = new(0.25f,0.20f,0.14f,1);
    public static readonly Vector4 Warning = new(0.91f,0.69f,0.35f,1);
    public static readonly Vector4 Error = new(0.88f,0.40f,0.35f,1);

    public static void Push()
    {
        ImGui.PushStyleColor(ImGuiCol.WindowBg, Background);
        ImGui.PushStyleColor(ImGuiCol.ChildBg, Panel);
        ImGui.PushStyleColor(ImGuiCol.Border, Border);
        ImGui.PushStyleColor(ImGuiCol.HeaderHovered, new Vector4(0.28f, 0.22f, 0.14f, 1));
        ImGui.PushStyleColor(ImGuiCol.HeaderActive, new Vector4(0.38f, 0.29f, 0.17f, 1));
        ImGui.PushStyleColor(ImGuiCol.TextDisabled, TextMuted);
        ImGui.PushStyleColor(ImGuiCol.Header, Selected);
        ImGui.PushStyleColor(ImGuiCol.Button, Panel);
        ImGui.PushStyleColor(ImGuiCol.ButtonHovered, Hovered);
        ImGui.PushStyleColor(ImGuiCol.ButtonActive, Selected);
        ImGui.PushStyleColor(ImGuiCol.FrameBg, Background);
        ImGui.PushStyleColor(ImGuiCol.FrameBgHovered, Hovered);
        ImGui.PushStyleColor(ImGuiCol.Tab, Panel);
        ImGui.PushStyleColor(ImGuiCol.TabActive, Selected);
        ImGui.PushStyleColor(ImGuiCol.TabHovered, Hovered);
        ImGui.PushStyleColor(ImGuiCol.Separator, Border);
        ImGui.PushStyleColor(ImGuiCol.Text, Text);
        ImGui.PushStyleColor(ImGuiCol.PopupBg, Panel);
        ImGui.PushStyleColor(ImGuiCol.TitleBg, Background);
        ImGui.PushStyleColor(ImGuiCol.TitleBgActive, Selected);
        ImGui.PushStyleColor(ImGuiCol.FrameBgActive, Selected);
        ImGui.PushStyleColor(ImGuiCol.CheckMark, Gold);
        ImGui.PushStyleColor(ImGuiCol.SliderGrab, Gold);
        ImGui.PushStyleColor(ImGuiCol.SliderGrabActive, Warning);
        ImGui.PushStyleColor(ImGuiCol.ScrollbarBg, Background);
        ImGui.PushStyleColor(ImGuiCol.ScrollbarGrab, Border);
        ImGui.PushStyleColor(ImGuiCol.ScrollbarGrabHovered, Hovered);
        ImGui.PushStyleColor(ImGuiCol.ScrollbarGrabActive, Gold);
        ImGui.PushStyleColor(ImGuiCol.TableHeaderBg, Selected);
        ImGui.PushStyleColor(ImGuiCol.TableBorderStrong, Border);
        ImGui.PushStyleColor(ImGuiCol.TableBorderLight, Panel);
        ImGui.PushStyleColor(ImGuiCol.TableRowBgAlt, new Vector4(Gold.X,Gold.Y,Gold.Z,0.035f));
        ImGui.PushStyleVar(ImGuiStyleVar.WindowRounding, 2);
        ImGui.PushStyleVar(ImGuiStyleVar.ChildRounding, 2);
        ImGui.PushStyleVar(ImGuiStyleVar.FrameRounding, 2);
        ImGui.PushStyleVar(ImGuiStyleVar.FramePadding, new Vector2(6, 3));
        ImGui.PushStyleVar(ImGuiStyleVar.FrameBorderSize,1);
        ImGui.PushStyleVar(ImGuiStyleVar.PopupBorderSize,1);
    }

    public static void Pop()
    {
        ImGui.PopStyleVar(6);
        ImGui.PopStyleColor(32);
    }

    public static Scope Apply() { Push();return new Scope(); }
    public readonly struct Scope : IDisposable
    {
        public void Dispose()=>Pop();
    }
}
