using Lumina;
using Lumina.Data;
using Lumina.Excel.Sheets;

// Read-only evidence for NPC-VENDORS-014: how scrip exchanges encode currencies and how NPCs reach their shops.
if(args.Length!=1)throw new ArgumentException("Supply installed sqpack directory.");
using var data=new GameData(args[0],new LuminaOptions{DefaultExcelLanguage=Language.French});
var items=data.Excel.GetSheet<Item>();
string Name(uint id)=>items.TryGetRow(id,out var row) ? row.Name.ExtractText():"?";
const uint potion=12669;
var shops=data.Excel.GetSheet<SpecialShop>();
var referencing=new HashSet<uint>();
foreach(var shop in shops)
foreach(var entry in shop.Item)
{
    if(!entry.ReceiveItems.Any(receive=>receive.Item.RowId==potion))continue;
    referencing.Add(shop.RowId);
    Console.WriteLine($"SHOP {shop.RowId} '{shop.Name.ExtractText()}' UseCurrencyType={shop.UseCurrencyType} costs="
        +string.Join(" + ",entry.ItemCosts.Where(cost=>cost.CurrencyCost>0).Select(cost=>$"{cost.CurrencyCost}x[{cost.ItemCost.RowId} '{Name(cost.ItemCost.RowId)}' type{cost.CostType}]")));
}
// Who points at these shops: NPC data, topic menus, pre-handlers, talk scripts, inclusion series.
foreach(var npc in data.Excel.GetSheet<ENpcBase>())
    foreach(var value in npc.ENpcData)if(referencing.Contains(value.RowId))Console.WriteLine($"ENPC {npc.RowId} direct -> {value.RowId}");
foreach(var topic in data.Excel.GetSheet<TopicSelect>())
    foreach(var value in topic.Shop)if(referencing.Contains(value.RowId))Console.WriteLine($"TOPIC {topic.RowId} -> {value.RowId}");
foreach(var talk in data.Excel.GetSheet<CustomTalk>())
    foreach(var script in talk.Script)if(referencing.Contains(script.ScriptArg))Console.WriteLine($"TALK {talk.RowId} -> {script.ScriptArg}");
var series=data.Excel.GetSubrowSheet<InclusionShopSeries>();
foreach(var row in series)foreach(var sub in row)if(referencing.Contains(sub.SpecialShop.RowId))Console.WriteLine($"SERIES {row.RowId}.{sub.SubrowId} -> {sub.SpecialShop.RowId}");
foreach(var category in data.Excel.GetSheet<InclusionShopCategory>())
    if(series.TryGetRow(category.InclusionShopSeries.RowId,out var list) && list.Any(sub=>referencing.Contains(sub.SpecialShop.RowId)))
        Console.WriteLine($"CATEGORY {category.RowId} '{category.Name.ExtractText()}' series {category.InclusionShopSeries.RowId}");
foreach(var inclusion in data.Excel.GetSheet<InclusionShop>())
    foreach(var category in inclusion.Category)
        if(category.RowId!=0 && data.Excel.GetSheet<InclusionShopCategory>().TryGetRow(category.RowId,out var cat)
           && series.TryGetRow(cat.InclusionShopSeries.RowId,out var list) && list.Any(sub=>referencing.Contains(sub.SpecialShop.RowId)))
            Console.WriteLine($"INCLUSION {inclusion.RowId} '{inclusion.ShopName.ExtractText()}' via category {category.RowId}");
// The Radz-at-Han scrip NPC named by the user.
var residents=data.Excel.GetSheet<ENpcResident>();
foreach(var resident in residents)
    if(resident.Singular.ExtractText().Contains("comptable des assignats",StringComparison.OrdinalIgnoreCase)
       && data.Excel.GetSheet<ENpcBase>().TryGetRow(resident.RowId,out var npc))
        Console.WriteLine($"NPC {resident.RowId} '{resident.Singular.ExtractText()}' data="+string.Join(",",npc.ENpcData.Select(value=>value.RowId).Where(id=>id!=0)));
// Encoded currency evidence: distinct (type, id) pairs below 100 across special shops.
Console.WriteLine("ENCODED "+string.Join(" ",shops.SelectMany(shop=>shop.Item.SelectMany(entry=>entry.ItemCosts)
    .Where(cost=>cost.CurrencyCost>0 && cost.ItemCost.RowId is >0 and <100).Select(cost=>(shop.UseCurrencyType,cost.ItemCost.RowId)))
    .Distinct().OrderBy(pair=>pair.UseCurrencyType).ThenBy(pair=>pair.RowId).Select(pair=>$"t{pair.UseCurrencyType}:{pair.RowId}")));
