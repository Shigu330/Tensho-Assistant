# GOAL sélectionné

ID: GATHER-FISH-WEATHER-009-STUDY
OBJECTIVE: Relier les conditions météo communautaires aux IDs natifs sur preuve multilingue, puis envisager leur intersection avec les horaires ; poursuivre les 17 domaines jusqu’à la réserve quota de 5 %.
CURRENT_STATE: Tranche précédente GATHER-FISH-WINDOWS-008 IMPLEMENTED / TESTED en 0.62.0, 401 tests/package/SHA-256 et probes réels 4915/8753/7685 verts. Conditions, appâts et monstres partagent le cache d’objet. Rendu en jeu non observé.
WHY_NOW: Les horaires et noms météo sont consultables ; les prévisions natives ne peuvent être croisées aux noms externes sans correspondance prouvée.
REFERENCES: docs/GATHER-FISH-WINDOWS-008.md ; docs/GATHER-WEATHER-001.md ; REF-GATHER-FISH-WINDOWS-008.
FILES: Community/FishingConditions ; Gathering/WeatherForecast et loader ; MainWindow.FishingSources ; tests/probes ciblés.
IN_SCOPE: Noms anglais externes et IDs Weather natifs, ambiguïtés/absents, copie native dans loader commun ; états Unknown, temps UTC/ET, horizon borné et calcul sans promesse de capture.
OUT_OF_SCOPE: Déduire météo native code 2, prises préalables/intuition, personnage débloqué, présence ou capture certaine ; aucune action de pêche. Les 17 domaines restent PARTIAL.
VALIDATION: Dernière tranche : Verify.ps1 401/401, zéro avertissement/erreur, package/API/versions/SHA-256/exclusion hôte verts. Probes 4915 et 8753 liés aux spots/appâts natifs, 7685 horaire absent, FashionProbe compilé. Toute nouvelle projection doit être prouvée/testée avant livraison.
QUOTA: Relevé 2026-10-29 : 73 % disponibles sur 5 h et 43 % semaine ; réserve 5 %, objectif global actif.
NEXT_ACTION: Finaliser le checkpoint 0.62 puis examiner la feuille Weather multilingue dans le loader/probe. GP et essais projection/Macro Chain différés, sans les redemander.
DEFINITION_OF_DONE: Étude sourcée et limites explicites ; tranche compilée et testée, docs/sauvegarde à jour ; aucun domaine global promu complet sans preuve.
