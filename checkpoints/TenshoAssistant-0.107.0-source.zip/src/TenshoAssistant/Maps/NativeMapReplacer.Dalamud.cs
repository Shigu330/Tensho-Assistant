using Dalamud.Game.Addon.Lifecycle;
using Dalamud.Game.Addon.Lifecycle.AddonArgTypes;
using Dalamud.Game.ClientState.Keys;
using Dalamud.Plugin.Services;
using FFXIVClientStructs.FFXIV.Client.UI.Agent;

namespace TenshoAssistant.Maps;

/// <summary>
/// When enabled, the game's map window (AreaMap) is closed as soon as it opens and the Tensho map shows the same map instead.
/// Holding Shift while opening keeps the game map (option). Runs from the addon lifecycle callback on the framework thread.
/// </summary>
internal sealed class NativeMapReplacer : IDisposable
{
    private readonly IAddonLifecycle lifecycle;private readonly IKeyState keys;private readonly IClientState client;private readonly IPluginLog log;
    private readonly Func<MapViewSettings> settings;private readonly Action<uint> open;
    private bool disposed;
    public NativeMapReplacer(IAddonLifecycle lifecycle,IKeyState keys,IClientState client,Func<MapViewSettings> settings,Action<uint> open,IPluginLog log)
    {
        this.lifecycle=lifecycle;this.keys=keys;this.client=client;this.settings=settings;this.open=open;this.log=log;
        lifecycle.RegisterListener(AddonEvent.PostOpen,"AreaMap",OnOpen);
    }
    private unsafe void OnOpen(AddonEvent type,AddonArgs args)
    {
        if(disposed)return;
        try
        {
            var options=settings();
            if(!options.ReplaceGameMap || options.KeepGameMapWithShift && keys[VirtualKey.SHIFT])return;
            var agent=AgentMap.Instance();
            if(agent==null)return;
            // The map the game was asked to show (a link, a flag, or the current zone) opens in the Tensho map.
            var selected=agent->SelectedMapId;
            agent->Hide();
            open(selected==0 || selected==client.MapId ? 0:selected);
        }
        catch(Exception error){log.Warning(error,"Could not replace the game map; it stays open.");}
    }
    public void Dispose(){if(disposed)return;disposed=true;lifecycle.UnregisterListener(AddonEvent.PostOpen,"AreaMap",OnOpen);}
}
