# Architecture initiale

État courant 0.40.0 (2026-10-28) : [simulation d'artisanat](docs/CRAFT-SIM-001.md), séquences manuelles en condition normale, actions natives avec icônes, attributs copiables et états détaillés par étape ; [export de macros](docs/CRAFT-MACRO-001.md) localisées avec copie manuelle et blocs de 15 lignes maximum ; [recherche de séquences](docs/CRAFT-SOLVE-001.md) bornée et annulable pour une qualité cible explicite. [Actions avancées](docs/CRAFT-ACTIONS-002.md) : 26 familles, 208 variantes natives, dont Main suprême et les interactions de solidité. [Observation de synthèse](docs/CRAFT-LIVE-001.md) expérimentale en lecture seule, désactivée par défaut ; effets partiels, aucun conseil natif. [Avant-Garde](docs/FASHION-001.md), [aide aux PR](docs/GP-001.md), [Monster Loot](docs/LOOT-001.md), [Duty Loot](docs/DUTY-001.md), [quêtes](docs/QUEST-002.md), [coûts terminaux](docs/MARKET-003.md) et [Triple Triade expérimentale](docs/TRIAD-002.md) conservés. 265/265 tests et package vérifiés. Les 17 domaines restent PARTIAL ; aucun n'est déclaré remplacé. Nouvelles fonctions non validées en jeu ; Macro Chain sera testé plus tard selon l'utilisateur.

Historique 0.5.27 : catalogue Item/Recipe, banque à ordre visuel natif, carnet par métier et préparation sont implémentés ; les sections anciennes ci-dessous décrivent leur historique. La sortie du plugin est imposée dans le csproj à bin/x64/Configuration, y compris lors d'un build direct. Les extensions réutilisent ces services ; le checkpoint actuel et GOAL.md font autorité.

Un projet plugin et un exécutable de tests sans dépendance native. CORE-000 fournit l'hôte ; CORE-001 ajoute le modèle d'inventaire commun.

CRAFT-SIM-001 : les paramètres de simulation sont des valeurs immuables de RecipeDefinition, dans le catalogue partagé. Un loader framework borné vérifie et copie 136 actions métiers, puis publie un catalogue atomique ; pas de pointeur ou ligne native dans le moteur/UI. CraftSimulation retourne un état par étape, limite 100 actions, arrête à la première impossibilité/fin/casse et accepte l'annulation. MainWindow.CraftSimulation possède la séquence et invalide les résultats à l'édition, les attributs copiés au changement de personnage. Pas de worker ni d'exécution native ajoutés.

CRAFT-MACRO-001 : export pur vers pages de 15 lignes maximum à partir des étapes d'une simulation terminée. Noms natifs cités et validés, attentes bornées, pages immuables ; l'UI lie l'export à l'identité du résultat et fournit une copie par bloc. Aucun appel au module de macros ou au bridge de Macro Chain.

CRAFT-SOLVE-001 : transition pure partagée avec le simulateur, recherche par faisceau déterministe bornée, déduplication d'état complet et replay de la proposition. Session propriétaire du worker/CTS/génération ; entrées managées copiées, invalidation owner/recette/scénario/contexte et rejet des publications tardives. Le solveur normal ne lit ni ne commande une synthèse native.

CRAFT-ACTIONS-002 étend le même moteur à 26 actions / 208 variantes natives. CraftSimState conserve deux booléens distincts pour la protection persistante de Main suprême et son utilisation unique ; leur égalité participe à la déduplication de recherche. Les efficacités progression/qualité de Travail minutieux sont séparées. Les règles d'ouverture/niveau/Parcimonie/Calme intérieur précèdent tout débit de ressources.

CRAFT-LIVE-001 ajoute un lecteur framework opt-in à 5 Hz, avec champs nommés de CraftEventHandler/AddonSynthesis et PS/statuts de LocalPlayer. Publication atomique d'un cadre managé immuable, lease propriétaire/génération, contrôles de stabilité/visibilité et bornes de lecture. Les effets bruts et étapes natives/UI restent distincts ; aucun état de solveur n'est fabriqué à partir des champs non établis. Draw ne lit aucun pointeur.

`Plugin` reçoit IDalamudPluginInterface, ICommandManager et IPluginLog par injection constructeur Dalamud. Il charge Configuration v1, refuse une version inconnue sans la remplacer, crée MainWindow et possède WindowSystem ainsi que RegistrationScope.

RegistrationScope enregistre uniquement les acquisitions réussies, nettoie dans l'ordre inverse, poursuit après une erreur et rend Dispose idempotent. Un échec du constructeur déclenche le même nettoyage. La commande `/tensho`, Draw, OpenMainUi et OpenConfigUi ont tous une désinscription.

MainWindow affiche l'état du socle et une préférence OpenOnLoad. Sa modification appelle SavePluginConfig immédiatement ; un échec restaure la valeur affichée et inscrit l'erreur dans le journal. La visibilité de la fenêtre reste temporaire. INV-001 ajoute un diagnostic de l'inventaire consommant seulement les snapshots managés ; aucune lecture native dans Draw.

Configuration.cs et RegistrationScope.cs sont partagés par inclusion avec les tests. Configuration.Dalamud.cs ajoute uniquement IPluginConfiguration au plugin. Les tests vérifient le comportement managé ; ils ne simulent pas l'hôte Dalamud ni ImGui.

## Inventaire commun — CORE-001

InventorySnapshot décrit un lot d'observation : ObservedAt normalisé UTC, Source et dictionnaire figé de conteneurs. Chaque InventoryLocation contient des types distincts InventoryOwnerId et InventoryContainerId ; InventoryItem sépare InventoryItemId de IsHighQuality. L'owner doit être non nul, le container peut être zéro. La conversion des identifiants natifs reste la responsabilité de l'adaptateur futur.

InventoryContainerSnapshot copie les piles et additionne les quantités du même objet/qualité avec détection de dépassement. Il conserve InventoryCoverage Unknown/Partial/Complete pour ce conteneur uniquement. Une observation Unknown ne peut contenir de pile. Une liste vide n'est complète que si la couverture a été explicitement déclarée Complete par le producteur ; le modèle ne peut pas prouver cette déclaration.

GetQuantity impose une portée non vide et déduplique les conteneurs demandés. Le résultat contient ObservedQuantity (borne minimale) et ExactQuantity nullable. L'exactitude exige tous les conteneurs demandés complets ; un conteneur hors snapshot est Unknown. Des observations connues mélangées à des inconnues donnent Partial. Propriétaires et qualités ne sont jamais fusionnés implicitement.

InventoryService publie un seul snapshot immuable via échange atomique. Replace remplace le lot entier, sans historique ni fusion ; Clear invalide toute observation. L'ordre de publication fait autorité, pas l'horloge murale. Un consommateur conserve une référence stable au snapshot et à ses métadonnées pendant son calcul. Le producteur devra garantir l'ordre de collecte et vider le service en cas de changement de personnage/déconnexion.

## Acquisition Dalamud — INV-001

Plugin possède maintenant InventoryService et DalamudInventoryReader. Le reader s'abonne à IFramework.Update, IGameInventory.InventoryChanged, Login et Logout via RegistrationScope. Son Dispose désabonne puis ferme le coordinateur et vide le service. Un échec de construction déclenche le même nettoyage. Aucun hook, offset, worker ou timer n'est ajouté.

Sur un callback Update confirmé par IsInFrameworkUpdateThread, le reader vérifie IsLoggedIn, IPlayerState.IsLoaded et ContentId. Il lit Inventory1–Inventory4 (identifiants locaux 0–3), consomme immédiatement chaque ReadOnlySpan<GameInventoryItem> et copie BaseItemId/IsHq/Quantity dans des piles managées. Les spans et les slots ne quittent jamais cette lecture. La portée exclut équipement, cristaux, sacoche, servants et compagnie.

L'API publique locale ne fournit pas de preuve de chargement/complétude des conteneurs. Un span vide devient Unknown, un span non vide devient Partial même si tous les slots sont vides. Aucun Complete n'est produit. Cela permet de présenter une borne minimale sans transformer une absence observée en quantité zéro exacte. Un contrat plus fort nécessitera une preuve supplémentaire, pas un simple changement de label.

Mise à jour INV-002 / 0.1.1 : ce comportement Partial systématique décrit la première version 0.1.0. L'adaptateur ajoute maintenant une preuve distincte depuis FFXIVClientStructs installé (REF-INV-LOAD), sans modifier le contrat de IGameInventory. Sur le même framework thread, InventoryManager.Instance/GetInventoryContainer fournissent l'en-tête typé du sac. IsLoaded, Items non nul, type attendu et Size positif borné autorisent la lecture. Après copie, manager/conteneur/buffer et taille doivent être stables, le sac toujours chargé, et le nombre de slots copiés égal à Size. Ces conditions produisent Complete pour ce sac. Aucun offset numérique n'est ajouté ; les pointeurs restent locaux à Capture.

Un en-tête non lisible avant/après la lecture produit Unknown et aucune pile conservée. Une lecture de taille ou buffer incohérents reste Partial. InventoryReadEvidence exprime et teste les faits managés nécessaires sans conserver d'adresse. La taille maximale 1000 est un garde-fou, pas une hypothèse que tous les sacs ont une taille fixe. Une reprise toutes les cinq secondes s'applique maintenant aux sacs Partial comme Unknown, jusqu'à complétude.

InventoryCaptureCoordinator est managé et testé : un verrou sérialise collecte, publication, invalidation et Dispose ; un compteur de génération rejette une collecte invalidée pendant son exécution. L'identité est relue avant publication ; tout lot d'un autre propriétaire est rejeté. Toute invalidation vide immédiatement le service. Les rafales sont coalescées, avec intervalle minimal de 250 ms entre lectures ; les conteneurs Unknown ou erreurs déclenchent une reprise après cinq secondes. Si tous les sacs ont été observés, seuls de nouveaux événements/changements d'identité déclenchent une nouvelle lecture. L'identité seule est vérifiée chaque frame, sans scan des sacs.

Les exceptions de collecte vident le service et sont journalisées une fois par séquence d'échecs, avec réarmement après succès. L'horloge monotone Stopwatch régit les reprises ; ObservedAt UTC date les données. Aucun historique n'est accumulé.

MainWindow présente quatre états de sac, la date UTC et une requête par identifiant de base/NQ-HQ. Le total est explicitement affiché comme minimum observé, total inconnu. Les domaines Craftimizer/GatherBuddy/SortaKinda consommeront la même instance. L'intégration est compilée mais non encore validée dans un client de jeu.

Depuis 0.1.1, MainWindow affiche aussi l'état « complet » et « Total dans les quatre sacs : X NQ/HQ » uniquement lorsque les quatre conteneurs sont complets. Les captures utilisateur de 0.1.0 valident l'affichage et les quantités d'exemples ; la preuve native ajoutée par 0.1.1 attend son propre essai live.

## Ouverture automatique — 0.1.2

Deux préférences indépendantes : OpenOnLoad ouvre la fenêtre lors de la construction du plugin ; OpenOnLogin l'ouvre sur IClientState.Login. Le callback Login est possédé par RegistrationScope et désabonné au Dispose ; il relit la préférence courante à chaque connexion. Configuration reste en version 1 : les anciens fichiers gardent OpenOnLoad et reçoivent OpenOnLogin=false par défaut. Les deux cases sont sauvegardées ensemble après une modification, et leurs valeurs précédentes sont restaurées si la sauvegarde échoue.

Depuis 0.1.3, le diagnostic affiche ensemble les deux requêtes NQ et HQ du même snapshot, puis leur somme. La case de filtre HQ est supprimée. Le résultat est exact seulement si les quatre sacs sont complets ; il reste minimal ou inconnu selon la couverture sinon. La collecte native et les préférences ne changent pas.

## Catalogue d'objets commun — ITEM-001 / 0.1.4

Plugin possède une seule instance ItemCatalogService et son loader. Le loader extrait RowId, Name.ExtractText() et CanBeHq depuis Lumina Item dans la langue de la feuille. La copie s'effectue par lots au framework (128 lignes maximum, budget souple de deux ms entre deux lignes), puis seules des définitions et chaînes managées sont confiées au worker annulable. Une génération est construite par chargement du plugin, sans nouveau scan à chaque reconnexion. Les noms vides et RowId zéro sont exclus ; un ID dupliqué est une erreur explicite.

ItemCatalog est immuable : dictionnaire figé par ID et tableau privé trié de noms normalisés. Il conserve la source, la langue, les versions des repositories du jeu et le schéma Lumina, plus le numéro de génération. Pas de timestamp par ligne statique. Find est une lecture par ID ; Search normalise casse/accents/espaces, exige tous les mots et renvoie au plus 30 résultats par défaut (limite maximale 100, requête maximale 128 caractères). L'ordre est déterministe, nom normalisé puis ID. La recherche parcourt l'index en mémoire seulement lorsque la requête ou l'instance de catalogue change ; elle ne relit pas Excel.

ItemCatalogService publie atomiquement un état immuable (progression, catalogue ou erreur). Le worker ne publie jamais directement : Update ne consomme son résultat qu'une fois terminé et sous le verrou du loader. Dispose annule le worker, désabonne, vide les références source et le service ; aucune attente bloquante. Les erreurs du worker sont capturées dans son résultat, y compris si le plugin est déchargé avant publication. Les callbacks déjà engagés sont sérialisés avec Dispose.

MainWindow met en cache les résultats (30 maximum), affiche le chargement/erreur et permet une sélection qui renseigne l'identifiant déjà consommé par les totaux NQ/HQ des sacs. Recherche/catalogue restent utilisables même si l'inventaire est momentanément inconnu. Aucun autre service d'objet par domaine n'est ajouté.

## Interface commune — UI-003 / 0.2.0

MainWindow reste une seule fenêtre propriétaire d'un contexte de sélection (itemId et requête). Sa présentation est séparée en fichiers partial : MainWindow.cs (cadre/navigation/accueil), MainWindow.Items.cs (recherche et quantités), MainWindow.Settings.cs (réglages et diagnostics) et MainWindow.Tools.cs (répertoire produit).

Cinq destinations concrètes : Accueil présente l'outil disponible et l'état des données ; Objets & inventaire recherche et affiche NQ/HQ/total ; Tous les outils décrit et filtre le périmètre futur ; Réglages conserve les deux préférences persistantes indépendantes ; Diagnostics expose version, sources, génération et couverture des sacs. Les domaines futurs sont regroupés dans le répertoire, pas enregistrés comme faux modules ni présentés comme fonctionnels.

Le répertoire comporte les 17 références autoritaires, regroupées en Artisanat, Récolte & pêche, Objets & économie, Collections & progression, Exploration & butin, Jeux & Gold Saucer, Personnage & macros. Tous les outils métier sont encore « à venir » ; le catalogue et l'inventaire communs restent des fondations disponibles, pas un dix-huitième plugin prioritaire.

Le cadre réserve 200 pixels à la navigation ; le panneau principal utilise la largeur restante. Chaque panneau défile indépendamment. Taille par défaut 1040 × 700 à la première ouverture, minimum 760 × 480. Le style Dalamud existant est conservé, avec titres or et états disponibles verts. Les tables/children/listes ont des scopes équilibrés protégés par finally. Pas de nouvelle dépendance, service par page, abonnement ou lecture du jeu ; les pages consomment les mêmes ItemCatalogService et InventoryService.

### Répertoire par icônes — UI-004 / 0.2.1

Le répertoire remplace les sections détaillées développées par une grille adaptative de deux à cinq colonnes. PlannedTool conserve une référence d'icône FontAwesome native par outil ; IconButton utilise les polices existantes de Dalamud. La grille montre uniquement icône et nom. Description, domaine et état se trouvent dans une fiche modale commune, ouverte au clic seulement, avec fermeture explicite.

La sélection d'une fiche (selectedTool ou fondation disponible) est distincte de la sélection d'objet itemId ; consulter une fiche ne perd pas l'objet en contexte. La tuile disponible ouvre la page Items via sa fiche ; les 17 références futures restent À venir. La demande d'ouverture de popup est traitée après la table, au même niveau de pile ID que son rendu. Aucun fichier d'image ni texture propriétaire n'est requis.

## Banque manuelle des rangements — BANK-001 / 0.3.0

InventoryNativeReader factorise la lecture typée des conteneurs, sa copie managée et les preuves IsLoaded/type/taille/buffer déjà utilisées pour les sacs. Le lecteur live et les imports consomment cette même implémentation ; aucune logique native par domaine craft/récolte n'est dupliquée. InventoryContainerSnapshot expose son dictionnaire figé de quantités pour la persistance, sans exposer de collection mutable.

BankKey distingue CharacterId, BankStorageKind et StorageId. Le servant utilise son ID propre comme propriétaire des sept conteneurs et comme StorageId ; sacoche standard et extension utilisent le propriétaire personnage et StorageId zéro, distinguées par Kind. BankEntry réutilise InventorySnapshot, sa source et son ObservedAt UTC. BankEntryValidator exige exactement le groupe complet prévu, le bon propriétaire et des quantités compatibles avec les bornes natives (au plus 1000 slots × Int32 par conteneur).

InventoryBankService est la source commune des relevés historiques, distincte du snapshot live InventoryService. État immuable publié atomiquement, chargement/sauvegarde sur un worker avec Channel borné, une demande en attente maximum. Un import remplace seulement sa BankKey ; publication après commit disque. Chargement corrompu bloquant pour les écritures ; échec de sauvegarde transitoire rapporté avec ancien état conservé et retry possible. Dispose ferme la file, termine les tâches publiques et empêche les publications suivantes, sans attendre un appel IO synchrone engagé.

FileInventoryBankStore encode schéma 1, SavedAtUtc distinct d'ObservedAtUtc, IDs et quantités NQ/HQ par conteneur. Fichier limité à 16 MiB, groupes/éléments bornés, propriétés JSON obligatoires et doublons refusés. Save valide le fichier existant, écrit/flush un temporaire propre à l'opération puis remplace atomiquement avec .bak ; Load ne récupère .bak que si le primaire est absent. Un primaire corrompu est préservé et signalé. Un seul writer par chemin est prévu ; coordination multi-processus non implémentée.

BankInventoryBridge observe les fenêtres, positions et identités au framework toutes les 100 ms. Aucun scan d'objet hors demande explicite. Il publie seulement des BankMenuContext managés (clé, nom, position et disponibilité), puis revalide clé/personnage/menu/conteneurs avant et après la copie d'un import demandé. GetActiveRetainer seul est insuffisant car il réfère LastSelectedRetainerId ; l'inventaire visible et les contrôles de stabilité sont requis.

BankImportOverlay dessine les panneaux compagnons même quand la fenêtre principale est fermée. Ils suivent la fenêtre de l'inventaire servant ou chocobo et restent dans le viewport. Le bouton envoie une clé managée au bridge ; il ne lit pas de mémoire native dans Draw. Une extension chocobo non chargée n'est pas importée. Les callbacks appartiennent au plugin ; les panels n'injectent ni hook ni nœud natif.

MainWindow ajoute Banque d'objets et conserve la même recherche/sélection. Les résultats montrent les stocks importés du personnage courant, propriétaires, NQ/HQ et dates, même après fermeture des inventaires. Le cumul sacs + cache est nommé « recensé » avec avertissement de décalage après transferts, jamais « total exact possédé ». Les relevés des autres personnages sont conservés mais non additionnés. Équipements/cristaux/marché des servants restent hors des sept pages ; cette portée est affichée.

## Vue unifiée illustrée — UI-005 / 0.4.0

L'interface Objets & rangements fusionne les vues Objets & inventaire et Banque d'objets de 0.3.0 ; les services sous-jacents restent distincts par nature des données, pas par outil. Le menu latéral et la fiche de l'outil disponible pointent vers cette destination unique. L'import reste manuel et sa gestion se trouve dans une section repliable, sans modifier le fichier de banque ni sa portée.

ItemDefinition contient maintenant IconId, copié depuis Item.Icon au même passage que le nom. MainWindow reçoit ITextureProvider par injection et dessine les icônes du jeu dans les résultats, la fiche et le contexte latéral. Les wraps sont empruntés uniquement pour la frame UI : aucun stockage entre frames, aucun Dispose de texture partagée, aucun worker texture propre au plugin.

ItemHoldings est une projection pure et immuable des snapshots existants, filtrée par personnage et par type de rangement. Pour le personnage, seules les quatre clés 0–3 sont demandées ; un propriétaire étranger ou un conteneur absent reste inconnu. Les relevés servant/chocobo gardent leur date et qualité. Les rubriques non importées produisent des lignes Unknown ; l'extension de sacoche est optionnelle. Les quantités sont additionnées avec contrôle des dépassements ; les lignes retournées sont détachées des collections appelantes.

Les indicateurs HasObservation/HasUnknown/HasCached/IsExact commandent la présentation. Une somme avec cache n'est jamais un total exact au présent, même si toutes ses observations étaient complètes. Le filtre Personnage seul peut être exact. Les groupes et filtres réutilisent le même itemId, sans nouvelle lecture native ou banque par page.

Le résultat projeté est mis en cache par itemId, personnage, références du snapshot live et de BankState, et filtre. Il est recalculé seulement quand ce contexte change. La recherche conserve son cache existant et limite le rendu à 30 résultats avec icônes. À partir de 720 pixels disponibles dans le contenu, recherche (300 pixels) et fiche sont côte à côte ; sinon les blocs sont empilés. La liste de résultats ajuste sa hauteur au nombre d'objets, sans grand panneau vide pour quelques résultats.

## Catalogue de recettes — CRAFT-001A / 0.5.0

RecipeCatalog est un index managé par ResultItemId. Chaque RecipeDefinition conserve son RecipeId, son rendement, le nom du CraftType, le niveau de RecipeLevelTable et la liste d'IDs/quantités d'ingrédients ; deux recettes produisant le même objet restent deux variantes. RecipeCatalogLoader copie Recipe par lots de 128 sur le thread framework, puis construit l'index sur un worker. MainWindow affiche les variantes dans une section repliable de la fiche objet. Cette tranche ne déduit pas encore la possession des ingrédients et ne lance aucune action de craft.
