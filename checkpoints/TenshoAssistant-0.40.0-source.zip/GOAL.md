# GOAL sélectionné

ID: CRAFT-LIVE-001
OBJECTIVE: Observer en lecture seule une synthèse native, avec couverture partielle explicite et données managées ; préparer les conseils sans inventer d'état.
CURRENT_STATE: IMPLEMENTED / TESTED — observation temporaire désactivée par défaut, champs nommés de CraftEventHandler/AddonSynthesis et PS natifs intégrés en 0.40.0, 265 tests/package verts. Métadonnées locales vérifiées ; aucune capture runtime ou conversion de statuts en tours/charges revendiquée. Macro Chain reporté.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: CraftLiveObservation/Reader ; MainWindow.CraftLive/Simulation/Tools ; Plugin/lifecycle ; CraftLiveTests ; ApiProbe ; documents.
IN_SCOPE: Identité par IDs/métier, ressources UI et PS courants, condition/étape/textes/flags bruts, effets partiels et statuts copiés, contrôle de stabilité/visibilité/bornes et invalidation ; lecture seulement.
OUT_OF_SCOPE: Déclarer les 17 plugins remplacés ; prétendre une validation en jeu sans observation.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: 2026-10-28, 26 % disponibles sur 5 h et 73 % semaine au dernier relevé ; continuer selon instruction utilisateur.
NEXT_ACTION: Snapshot 0.40.0 puis CRAFT-LIVE-002 : prouver correspondances d'effets/tours, combos et actions uniques avant conversion vers un état de moteur ; conditions/couverture insuffisantes restent inconnues. Conserver les 17 domaines PARTIAL et le goal global actif ; Macro Chain différé.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
