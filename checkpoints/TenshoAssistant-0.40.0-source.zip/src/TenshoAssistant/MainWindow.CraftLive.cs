using System.Numerics;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.Craft;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private void DrawCraftLive()
    {
        Heading("Synthèse en cours","Observation expérimentale en lecture seule · aucun conseil automatique");
        var state=craftLive.State;var enabled=state.Enabled;
        if(ImGui.Checkbox("Activer l'observation de la synthèse",ref enabled)) {craftLive.SetEnabled(enabled);state=craftLive.State;}
        ImGui.TextWrapped("Recette, ressources et textes visibles sont copiés depuis le jeu. Les effets, combos et l'historique d'utilisation ne sont pas encore reconstruits en état de simulation : aucun prochain coup n'est déduit de cette observation.");
        ImGui.TextUnformatted(state.Status switch {CraftLiveStatusKind.Disabled=>"Observation désactivée.",CraftLiveStatusKind.Waiting=>"En attente d'une lecture.",CraftLiveStatusKind.Offline=>"Personnage déconnecté.",CraftLiveStatusKind.AddonAbsent=>"Aucune fenêtre de synthèse ouverte.",CraftLiveStatusKind.NotReady=>"Fenêtre absente, masquée ou en transition.",CraftLiveStatusKind.Error=>"Lecture indisponible.",_=>"Observation partielle disponible."});
        if(state.Error is { } error)ImGui.TextWrapped(error);
        if(state.Frame is not { } frame)return;
        var raw=frame.Raw;var fresh=state.ObservedAt is { } date && DateTimeOffset.UtcNow-date<TimeSpan.FromSeconds(2);
        ImGui.TextDisabled($"Observation {state.ObservedAt:HH:mm:ss} UTC · {(fresh ? "récente":"ancienne : nouvelle lecture nécessaire")}");
        if(frame.Recipe is { } recipe)
        {
            var item=itemCatalog.State.Catalog?.Find(recipe.ResultItemId);DrawItemIcon(item,new Vector2(36));ImGui.SameLine();ImGui.TextColored(Accent,item?.Name ?? raw.ItemName);
            ImGui.TextUnformatted($"{recipe.CraftType} · niveau {recipe.Level} · recette {recipe.RecipeId}");
            ImGui.BeginDisabled(!fresh || frame.Animating);
            try {if(ImGui.SmallButton("Mettre le résultat en contexte et ouvrir Craft lié")){SelectItem(recipe.ResultItemId);page=Page.Items;focusCraftTab=true;}}
            finally {ImGui.EndDisabled();}
        }
        else ImGui.TextWrapped($"Identité non reliée au catalogue : {raw.ItemName}, recette native {raw.RecipeId}, objet {raw.ResultItemId}. Aucun rapprochement par nom.");
        ImGui.TextUnformatted($"Étape native {raw.Step} · étape affichée {frame.UiStep?.ToString() ?? "inconnue"}");
        ImGui.TextWrapped($"Condition affichée : {raw.ConditionText} · code natif {raw.Condition}");
        if(frame.Animating)ImGui.TextDisabled("Action/animation signalée par le jeu ; observation à ne pas utiliser pour un conseil.");
        ImGui.TextUnformatted($"Progression : {frame.Progress?.ToString("N0") ?? "inconnue"} / {raw.Numbers.MaxProgress}");
        ImGui.TextUnformatted($"Qualité : {frame.Quality?.ToString("N0") ?? "inconnue"} / {raw.Numbers.MaxQuality}");
        ImGui.TextUnformatted($"Solidité : {frame.Durability?.ToString() ?? "inconnue"} / {raw.Numbers.MaxDurability}");
        ImGui.TextUnformatted($"PS courants : {raw.Cp}/{raw.MaxCp} · Habileté {raw.Stats.Craftsmanship} · Contrôle {raw.Stats.Control} · niveau {raw.Stats.Level}");
        if(ImGui.CollapsingHeader("Effets visibles · couverture partielle",ImGuiTreeNodeFlags.DefaultOpen))
        {
            foreach(var effect in raw.Effects)ImGui.TextWrapped($"{effect.Name} · compteur affiché : {effect.Turns}");
            if(raw.Effects.Count==0)ImGui.TextDisabled("Aucun nom copié dans les neuf lignes ; cela ne certifie pas l'absence d'effet.");
            if(raw.EffectsOverflow.Length>0)ImGui.TextWrapped($"Indication supplémentaire : {raw.EffectsOverflow}");
        }
        if(ImGui.CollapsingHeader("Données brutes de vérification"))
        {
            ImGui.TextWrapped(frame.Source);ImGui.TextUnformatted($"Drapeaux état 0x{raw.StateFlags:X8} · synthèse 0x{raw.Flags:X2}");
            foreach(var status in raw.Statuses)ImGui.TextUnformatted($"Statut {status.Id} · paramètre {status.Param} · valeur temporelle brute {status.RemainingTime}");
            ImGui.TextDisabled("Paramètres et valeurs temporelles non convertis en tours ou en charges du simulateur.");
        }
    }
}
