# GOAL sélectionné

ID: CRAFT-LIVE-002
OBJECTIVE: Identifier effets/compteurs et limites de conversion de l'observation de craft, puis poursuivre les autres fonctions des 17 domaines.
CURRENT_STATE: Effets identifiés IMPLEMENTED / TESTED en 0.41.0, 270 tests/package verts ; douze statuts natifs/icônes et Param vérifiés. Conversion complète en conseil non établie : combo et historique absent restent inconnus, pas d'état natif inventé. Aucun runtime observé ; Macro Chain différé.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: CraftObservedEffects, CraftActionCatalog/Loader, CraftLiveRaw/Reader, MainWindow.CraftLive ; tests/probe natif et documents.
IN_SCOPE: Identités/compteurs natifs avec métadonnées, couverture entière explicite, doublons/bornes/effets non modélisés, historique nullable et procs bruts ; pas de conseil sans état établi.
OUT_OF_SCOPE: Déclarer les 17 plugins remplacés ; prétendre une validation en jeu sans observation.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: 2026-10-28, 19 % disponibles sur 5 h et 72 % semaine au dernier relevé ; continuer selon instruction utilisateur.
NEXT_ACTION: Snapshot 0.41.0 puis GATHER-WEATHER-001 : météo et prévisions des zones natives pour Mappy/GatherBuddy, priorité A. Conversion craft/conseils toujours à compléter avec preuves ; protocole runtime conservé, pas de suppression du scope. Les 17 domaines restent PARTIAL et le goal global actif.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
