# GOAL sélectionné

ID: QUEST-002
OBJECTIVE: Naviguer entre les prérequis et quêtes suivantes avec preuves positives de progression ; poursuivre la couverture du projet.
CURRENT_STATE: IMPLEMENTED / TESTED — fiches/liens/niveaux/zones, vues séparées/icônes et suivi persistant intégrés en 0.31.0, 177 tests/package valides ; probe 5 373 quêtes / 5 213 liens et 5 226 lieux concordants passant. Rendu en jeu non observé. Macro Chain reste reporté ; observation Triple Triade expérimentale sans liaison automatique.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: Domaines Gathering, Inventory, Collections, Market, Quests, Character, MiniGames ; MainWindow.* ; Plugin.cs ; tests et documents.
IN_SCOPE: Fiche et navigation par liens directs, jointures natives, complétions confirmées, inconnus et étapes brutes préservés ; index copié et invalidation propriétaire.
OUT_OF_SCOPE: Déclarer les 17 plugins remplacés ; prétendre une validation en jeu sans observation.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: 2026-10-28, 6 % disponibles sur 5 h et 85 % semaine au dernier relevé ; continuer selon instruction utilisateur.
NEXT_ACTION: Snapshot 0.31.0 puis étude ciblée DUTY-001 : vérifier si le client contient des associations contenu/butin fiables avant de choisir une source externe. Conserver les 17 domaines et l'objectif global actif ; aucun test Macro Chain redemandé, aucune disponibilité de quête inventée.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
