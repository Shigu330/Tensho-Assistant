# État courant

CURRENT_GOAL: CRAFT-QUALITY-TIME-002 — IMPLEMENTED / TESTED ; recherche bornée, optimum absolu non prouvé
CURRENT_MODEL_CLASS: HEAVY — identités natives, acquisition et couverture
RECOMMENDED_MODEL: HEAVY pour l’intégration native des menus/tri ; LIGHT pour les tâches mécaniques ; continuation autorisée
MODEL_ESCALATION: None
QUOTA: Relevé 2026-10-29 : 95 % consommés sur 5 h, 68 % semaine (5 % / 32 % disponibles). Réserve utilisateur atteinte ; pause conditionnelle demandée, développement global non achevé.
LAST_READ: RULES/STATUS/GOAL, modèles/actions/solveur/lecture carnet/exports et tests relus ; données natives Tacos et noms/effets Byregot/Grands progrès inspectés. Sources primaires épinglées Craftimizer et AddonRecipeNote consultées.
BUILD: COMPILED Release 0.74.0.0 ; sortie canonique bin/x64/Release
TESTS: TESTED — Verify.ps1 final 453/453, package/API/versions/SHA-256/exclusion hôte verts, zéro avertissement/erreur. Onze groupes ajoutés depuis 0.72 : collectionnables/IQ/finisseur, qualité initiale/scope/cache et priorité temps avec oracle exhaustif sur petites scènes. Probe natif de recette/projection/actions/export et comparaison 37 s passant.
RUNTIME: Jusqu’à 0.5.27 confirmé ; captures nouvelles : panneau Carnet, recette Tacos et macro 12 000/13 actions/37 s visibles, version non affichée. Cela ne valide pas tous les modules ni la lecture initiale finale 0.74. Projection live/Macro Chain restent différées.
WORK_COMPLETED: Collectionnables ordinaires et projection qualité native partagée ; lecture de qualité initiale/maximale du carnet avec rejet de valeurs absentes/incompatibles, cache/worker invalidé au changement. Finisseurs et consommation IQ vérifiés ; recherche garde les branches Byregot et évalue Grands progrès → Byregot. Critère partagé recherche/presets : cible, attentes, actions. 6 000 initiaux et paramètres fournis retrouvent 37 s/13 actions ; aucun optimum global inventé.
BLOCKER: Aucun blocage global. Le bonus natif d’Abondance reste inconnu : sources divergentes et aucun getter nommé confirmé dans les bindings étudiés. Ne pas inventer une formule ; travaux indépendants poursuivis.
RESUME_FROM: GOAL.md ; TESTING.md pour le protocole de la base.
NEXT_ACTION: Livraison 0.74 prête ; actualiser la DLL si souhaité. Meilleure séquence trouvée pour le cas fourni : 37 s, recherche et voisinages testés sans amélioration. Réduction supplémentaire/optimalité globale restent ouvertes ; objectif autonome antérieur conservé en pause.

| Plugin | Coverage |
|---|---|
| Avant-Garde | PARTIAL — répertoire manuel d'indices natifs, équipements signalés, emplacements/stock/contexte et source datée ; thème courant/teintures/score/attache non déduits |
| Blue Mage Helper | PARTIAL — grimoire, numéros, descriptions, lieux renseignés et acquisition confirmée |
| Character Panel Refined | PARTIAL — attributs natifs, sans formules dérivées |
| Collections | PARTIAL — montures, mascottes, emotes, cartes, orchestrion, titres et succès ; preuve de chargement, catégories/fiches/récompenses, runtime à confirmer |
| Craftimizer | PARTIAL — carnet natif, collectionnables ordinaires, qualité initiale et recherche orientée attentes ; optimum global, rotation adaptative et recettes spéciales à compléter |
| Duty Loot Preview | PARTIAL — consultation manuelle par contenu, coffres/récompenses, icônes/contexte, provenance et cache ; drops directs non interprétés, données externes partielles |
| ezMiniCactpot | PARTIAL — solveur exact manuel et mode observé opt-in LotteryDaily ; conseil actualisé, aucune commande ; adaptation/rendu natifs non validés en jeu |
| GatherBuddy | PARTIAL — sources/maps/horaires/météo statiques, point courant MIN/BTN opt-in, carnet natif pêche, appâts/conditions explicites et plages ET/UTC et météo localisée ; plages des critères renseignés, présence/prérequis/harpon et runtime à compléter |
| Item Use | PARTIAL — recettes, mandats, candidats GC/aquarium, orchestrion et sources de quête, survol et menu Inventory opt-in ; autres usages/disponibilité, liens de discussion et runtime à compléter |
| LazyGatherer | PARTIAL — optimiseur manuel avec effets explicitement déclarés, observation du point et copie de ressources ; décodeur natif/bonus/régénération/procs/collectionnables et validation runtime à compléter |
| Macro Chain | PARTIAL — séquences à marqueur final, lancement explicite, arrêt, persistance ; natif à confirmer |
| Mappy | PARTIAL — navigateur natif, repères favoris persistants, ressources de zone et prévisions météo statiques ; météo forcée non observée |
| Monster Loot Hunter | PARTIAL — associations matériau/monstre, fiches/niveaux/lieux et carte de zone, transport/cadence partagés, contexte ; données communautaires partielles |
| Price Insight | PARTIAL — consultation manuelle et prix au survol opt-in, NQ/HQ/monde, cache/cadence/priorités partagés ; contexte mutualisé et scope owner/monde, runtime à confirmer |
| QuestTracker | PARTIAL — états natifs, séquence, fiches/liens et récompenses conditionnelles vers Item ; sources inverses managées, couverture/inconnus et disponibilité non calculée |
| SortaKinda | PARTIAL — profils/modèles, critères, zones protégées/filtrées et inversion, application visuelle après capture directe ; autres filtres/automatisations choisies et validation runtime à compléter |
| TriadBuddy | PARTIAL — carnet/deck/solveur manuel, observation des faces opt-in expérimentale ; identités/règles/trait natifs et autres règles non établis |

