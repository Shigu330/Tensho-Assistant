# GOAL sélectionné

ID: CRAFT-QUALITY-TIME-002 — IMPLEMENTED / TESTED
OBJECTIVE: Corriger les collectionnables, respecter les matériaux HQ et les degrés de Calme intérieur/Byregot, puis privilégier le temps de macro avant le nombre d’actions, selon les demandes utilisateur.
CURRENT_STATE: Livraison 0.74.0.0 compilée, 453/453 tests/package/SHA-256 passants, zéro avertissement/erreur. Tacos natifs 35829/44232 ; qualité initiale 6 000 et attributs fournis 5 622/5 081/565 : macro terminée à 12 000, 13 actions, 37 s d’attentes trouvées. Pas de minimum absolu démontré.
REFERENCES: RULES.md ; docs/CRAFT-QUALITY-TIME-002.md ; capture Carnet/Tacos et précision utilisateur 6 000 ; sources primaires datées/épinglées et probe natif.
FILES: CraftSimulation/RecipeSimulationCopy/RecipeCatalogLoader ; CraftSolver ; CraftLog observation/reader/session/UI ; tests et CraftSimulationProbe ; versions/docs.
IN_SCOPE: Collectionnables ordinaires, qualité initiale/maximale native, absence traitée inconnue ; comparaison sur même qualité de départ ; IQ normal/double/combo/plafond/consommation ; aperçu Grands progrès → Byregot borné ; objectif partagé cible atteinte puis attentes puis actions, ExtraWait inclus ; recherche d’une réduction sur le cas fourni.
OUT_OF_SCOPE: Revendiquer une optimalité globale après pruning, forcer Grands progrès s’il n’apporte rien, recettes expertes/ajustées/spécialistes/qualité obligatoire, paliers de remise non prouvés, garantir un temps réel de client ou lancer une macro. Les 17 domaines restent PARTIAL.
VALIDATION: Verify.ps1 final 453/453 ; zéro avertissement/erreur, identité/API/versions/SHA-256/exclusion hôte verts. Probe partagé sur les données locales : recette/qualité/actions/icônes/export, recherches élargies et voisinages. Oracle de temps par énumération complète sur petites scènes ; pas une preuve d’optimalité pour Tacos.
NEXT_ACTION: Recharger 0.74 si souhaité ; vérifier que la qualité initiale suit le carnet en jeu. Pour ce cas, 37 s reste le meilleur trouvé ; ajouter Grands progrès à la fin n’est pas utile si Byregot atteint déjà la cible. Optimisation globale encore ouverte. Ancien goal autonome conservé en pause à la réserve.
DEFINITION_OF_DONE: Correctifs compilés/testés/sauvegardés, résultats et limites documentés. Le critère temps prioritaire est implémenté ; l’exigence de minimum absolu n’est pas déclarée prouvée.
