using Dalamud.Bindings.ImGui;
using TenshoAssistant.Craft;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private readonly CraftSolveSession craftSolve=new();
    private CraftSolveInput? craftSolveSignature;
    private int craftSolveRevision,craftSolveTarget,craftSolveSteps=40,craftSolveWidth=128,craftSolveBudget=100000,craftSolveContextItem;
    private void ValidateCraftSearch()
    {
        if(simulationRecipe is not { } recipe) {craftSolve.Cancel();return;}
        var signature=new CraftSolveInput(bankBridge.State.CharacterId,0,recipe,new(simulationLevel,simulationCs,simulationControl,simulationCp,simulationManipulation),simulationQuality,
            new(craftSolveTarget,craftSolveSteps,craftSolveWidth,craftSolveBudget,craftMacroExtraWait));
        if(signature!=craftSolveSignature || craftSolveContextItem!=itemId)
        {craftSolveSignature=signature; craftSolveContextItem=itemId; craftSolveRevision++; craftSolve.Cancel();}
        craftSolve.ValidateContext(signature.Owner,craftSolveRevision,recipe.RecipeId);
    }
    private void DrawCraftSearch()
    {
        ValidateCraftSearch();
        if(!ImGui.CollapsingHeader("Rechercher une séquence")) return;
        ImGui.TextWrapped($"Rechercher une synthèse terminée avec la qualité cible en condition normale. Recherche bornée parmi les {CraftActionCatalog.Specs.Count} actions modélisées : une proposition n'est pas un optimum universel et une absence de résultat ne prouve pas l'impossibilité.");
        ImGui.SetNextItemWidth(120); ImGui.InputInt("Qualité cible",ref craftSolveTarget,0); ImGui.SameLine();
        if(ImGui.SmallButton("Maximum de la recette")) craftSolveTarget=simulationRecipe!.Simulation!.Quality;
        ImGui.TextDisabled("Une cible de zéro privilégie la progression. Atteindre une cible chiffrée ne garantit pas un objet HQ dans le jeu.");
        ImGui.TextWrapped("Une fois la cible atteinte : priorité aux attentes cumulées minimales, puis au nombre d’actions. Recherche bornée : optimum global non garanti si des états sont écartés.");
        DrawToolSettingsLink("CraftSearch");
        ImGui.TextDisabled($"Limites : {craftSolveSteps} étapes · {craftSolveWidth} états/étape · {craftSolveBudget:N0} transitions");
        ValidateCraftSearch();
        var state=craftSolve.State;
        ImGui.BeginDisabled(state.Loading);
        try
        {
            if(ImGui.Button("Chercher une proposition") && craftSolveSignature is { } input)
                _=craftSolve.StartAsync(input with {Revision=craftSolveRevision});
        }
        finally {ImGui.EndDisabled();}
        if(state.Loading) {ImGui.SameLine(); if(ImGui.SmallButton("Annuler la recherche")) craftSolve.Cancel(); ImGui.TextDisabled("Recherche en cours…");}
        if(state.Error is { } error) ImGui.TextWrapped(error);
        if(state.Result is not { } result) return;
        if(result.WaitSeconds is { } waits)ImGui.TextDisabled($"Attentes planifiées : {waits} s · le temps réel dépend aussi de la latence et des pauses entre blocs.");
        ImGui.TextDisabled($"{result.Expanded:N0} transitions examinées · profondeur {result.Depth} · calcul {state.CalculatedAt:HH:mm:ss} UTC");
        if(result.BeamPruned) ImGui.TextDisabled("Des états ont été écartés pour respecter la largeur de recherche.");
        if(result.NodeLimitReached || result.DepthLimitReached) ImGui.TextDisabled("Limite de calcul atteinte ; vous pouvez augmenter les limites puis relancer.");
        if(result.Simulation is not { } simulation) {ImGui.TextWrapped("Aucune synthèse terminée trouvée dans cette recherche bornée.");return;}
        ImGui.TextColored(result.TargetReached ? Success:Accent,$"{(result.TargetReached ? "Cible atteinte dans le modèle":"Synthèse terminée, cible non atteinte")} · qualité {simulation.Final.Quality}/{result.TargetQuality} · {simulation.Steps.Count} actions · PS restants {simulation.Final.Cp}");
        if(ImGui.Button(result.TargetReached ? "Utiliser cette séquence":"Utiliser cette séquence sous la cible"))
        {
            simulationActions.Clear(); simulationActions.AddRange(simulation.Steps.Select(step=>step.Action)); simulationResult=simulation; simulationError=null;
        }
        ImGui.TextWrapped("Utiliser remplace seulement la séquence dans le simulateur. Vous pourrez inspecter les étapes et préparer les textes de macros avant tout essai en jeu.");
    }
}
