using System.Numerics;
using Dalamud.Bindings.ImGui;
using TenshoAssistant.Craft;
using TenshoAssistant.Items;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private RecipeDefinition? simulationRecipe;
    private readonly List<CraftActionKind> simulationActions=[];
    private int simulationLevel=100,simulationCs,simulationControl,simulationCp,simulationQuality;
    private bool simulationManipulation;
    private ulong simulationCopiedOwner;
    private DateTimeOffset? simulationCopiedAt;
    private CraftSimulationResult? simulationResult;
    private string? simulationError;
    private CraftSimulationResult? macroExportSimulation;
    private CraftMacroExport? craftMacroExport;
    private int craftMacroExtraWait;
    private bool craftMacroEcho=true;
    private string? craftMacroError;
    private void OpenCraftSimulation(RecipeDefinition recipe)
    {
        if(simulationRecipe?.RecipeId!=recipe.RecipeId)
        {
            simulationActions.Clear(); simulationResult=null; simulationError=null; simulationQuality=0;
            simulationCopiedAt=null; simulationCopiedOwner=0; simulationCs=simulationControl=simulationCp=0;
            simulationLevel=100; simulationManipulation=false;
            craftSolveTarget=recipe.Simulation?.Quality ?? 0;
        }
        simulationRecipe=recipe; SelectItem(recipe.ResultItemId); page=Page.CraftSimulation;
    }
    private void ValidateCraftCopy()
    {
        if(simulationCopiedOwner==0 || simulationCopiedOwner==characterStats.State.CharacterId) return;
        simulationCopiedOwner=0; simulationCopiedAt=null; simulationCs=simulationControl=simulationCp=0;
        simulationLevel=1; simulationResult=null; simulationManipulation=false;
        simulationError="Personnage déconnecté ou changé : renseignez ou recopiez les attributs.";
    }
    private void DrawCraftSimulation()
    {
        Heading("Simulation d'artisanat","Séquence manuelle · condition normale à chaque étape");
        if(ImGui.SmallButton("Synthèse en cours")) page=Page.CraftLive;
        if(ImGui.SmallButton("Retour au carnet")) { page=Page.Items; focusCraftTab=true; }
        if(simulationRecipe is not { } recipe) { ImGui.TextWrapped("Choisissez une recette dans Craft lié, puis Simuler cette recette."); return; }
        var resultItem=itemCatalog.State.Catalog?.Find(recipe.ResultItemId);
        DrawItemIcon(resultItem,new Vector2(36)); ImGui.SameLine();
        ImGui.TextColored(Accent,$"{resultItem?.Name ?? $"Objet {recipe.ResultItemId}"} · {recipe.CraftType} {recipe.Level} · recette {recipe.RecipeId}");
        if(CraftSimulation.Unsupported(recipe) is { } unsupported) { ImGui.TextWrapped(unsupported); return; }
        if(craftActions.State.Catalog is not { } catalog) { ImGui.TextWrapped(craftActions.State.Error ?? "Lecture des actions du jeu…"); return; }
        DrawCraftPresetSave();
        var p=recipe.Simulation!; var job=recipe.CraftTypeId+8;
        if(p.Collectable)ImGui.TextColored(Accent,"Collectionnable · qualité simulée ; paliers et valeur de remise non calculés");
        ImGui.TextDisabled($"Progression {p.Progress} · qualité {p.Quality} · solidité {p.Durability} · minimums {p.RequiredCraftsmanship} habileté / {p.RequiredControl} contrôle");
        ImGui.TextWrapped("Modèle déterministe, sans exécution en jeu. Les conditions favorables, déblocages de quêtes et actions non affichées ne sont pas déduits. La qualité finale ne garantit pas un résultat HQ.");
        var stats=characterStats.State;
        var canCopy=stats.CharacterId!=0 && stats.JobId==job && stats.ObservedAt is { } date && DateTimeOffset.UtcNow-date<TimeSpan.FromSeconds(5)
            && stats.Values.ContainsKey("Craftsmanship") && stats.Values.ContainsKey("Control") && stats.Values.ContainsKey("CraftingPoints");
        ImGui.BeginDisabled(!canCopy);
        try
        {
            if(ImGui.SmallButton("Copier les attributs du métier observé"))
            {
                simulationLevel=stats.Level; simulationCs=stats.Values["Craftsmanship"]; simulationControl=stats.Values["Control"]; simulationCp=stats.Values["CraftingPoints"];
                simulationCopiedOwner=stats.CharacterId; simulationCopiedAt=stats.ObservedAt; simulationResult=null; simulationError=null;
            }
        }
        finally { ImGui.EndDisabled(); }
        if(simulationCopiedAt is { } copiedAt) ImGui.TextDisabled($"Attributs copiés à {copiedAt:HH:mm:ss} UTC · PS de l'attribut, budget modifiable avant synthèse");
        var changed=false;
        if(ImGui.CollapsingHeader("Attributs et qualité initiale",ImGuiTreeNodeFlags.DefaultOpen))
        {
            ImGui.SetNextItemWidth(110); changed|=ImGui.InputInt("Niveau",ref simulationLevel,0);
            ImGui.SetNextItemWidth(110); changed|=ImGui.InputInt("Habileté",ref simulationCs,0);
            ImGui.SetNextItemWidth(110); changed|=ImGui.InputInt("Contrôle",ref simulationControl,0);
            ImGui.SetNextItemWidth(110); changed|=ImGui.InputInt("PS de départ",ref simulationCp,0);
            ImGui.SetNextItemWidth(110); changed|=ImGui.InputInt($"Qualité initiale (0–{p.MaxStartingQuality})",ref simulationQuality,0);
            changed|=ImGui.Checkbox("Manipulation débloquée pour ce scénario",ref simulationManipulation);
        }
        if(changed) { simulationCopiedOwner=0; simulationCopiedAt=null; simulationResult=null; simulationError=null; }
        DrawCraftSearch();
        if(ImGui.CollapsingHeader("Ajouter une action",ImGuiTreeNodeFlags.DefaultOpen))
        {
            var columns=Math.Max(1,(int)(ImGui.GetContentRegionAvail().X/175));
            if(ImGui.BeginTable("CraftActionPalette",columns,ImGuiTableFlags.SizingStretchSame))
            {
                try
                {
                    foreach(var spec in CraftActionCatalog.Specs)
                    {
                        var action=catalog.Find(job,spec.Kind); if(action is null) continue;
                        ImGui.TableNextColumn(); ImGui.PushID((int)spec.Kind);
                        try
                        {
                            ImGui.BeginDisabled(simulationActions.Count>=100 || simulationLevel<spec.Level || spec.Kind==CraftActionKind.Manipulation && !simulationManipulation);
                            try
                            {
                                DrawItemIcon(new ItemDefinition(0,action.Name,false,action.Icon),new Vector2(26)); var click=ImGui.IsItemClicked();
                                if(ImGui.IsItemHovered()) ImGui.SetTooltip(action.Description);
                                ImGui.SameLine(); click|=ImGui.SmallButton(action.Name);
                                if(ImGui.IsItemHovered()) ImGui.SetTooltip($"{action.Description}\nNiveau {spec.Level} · PS de base {spec.Cp}");
                                if(click && simulationActions.Count<100 && simulationLevel>=spec.Level && (spec.Kind!=CraftActionKind.Manipulation || simulationManipulation))
                                { simulationActions.Add(spec.Kind); simulationResult=null; }
                            }
                            finally { ImGui.EndDisabled(); }
                        }
                        finally { ImGui.PopID(); }
                    }
                }
                finally { ImGui.EndTable(); }
            }
        }
        ImGui.TextColored(Accent,$"Séquence : {simulationActions.Count}/100 actions");
        if(ImGui.SmallButton("Vider la séquence")) { simulationActions.Clear(); simulationResult=null; simulationError=null; }
        ImGui.SameLine();
        if(ImGui.Button("Simuler"))
        {
            try { simulationResult=CraftSimulation.Run(recipe,new(simulationLevel,simulationCs,simulationControl,simulationCp,simulationManipulation),simulationQuality,simulationActions); simulationError=null; }
            catch(ArgumentException error) { simulationResult=null; simulationError=error.Message; }
        }
        if(simulationError is { } errorText) ImGui.TextWrapped(errorText);
        if(simulationResult is { } result)
        {
            var state=result.Final;
            ImGui.TextColored(state.Finish==CraftFinish.Completed ? Success:Accent,$"{state.Finish switch {CraftFinish.Completed=>"Synthèse terminée",CraftFinish.Broken=>"Synthèse échouée",_=>"Séquence incomplète"}} · progression {state.Progress}/{p.Progress} · qualité {state.Quality}/{p.Quality} · solidité {state.Durability} · PS {state.Cp}");
            if(result.InvalidAction is { } invalid) ImGui.TextWrapped($"Action {invalid+1} non exécutée : {result.Error}");
            if(result.Steps.Count<result.PlannedActions) ImGui.TextDisabled($"{result.PlannedActions-result.Steps.Count} action(s) prévue(s) non exécutée(s)");
            DrawCraftConditionEnvelope(result);
            DrawCraftMacroExport(result,job,catalog);
        }
        if(ImGui.BeginTable("CraftSequence",6,ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingStretchProp))
        {
            try
            {
                foreach(var title in new[]{"Action / ordre","Progression","Qualité","Solidité","PS / coût","Calme intérieur"}) ImGui.TableSetupColumn(title);
                ImGui.TableHeadersRow();
                for(var i=0;i<simulationActions.Count;i++)
                {
                    var kind=simulationActions[i]; var metadata=catalog.Find(job,kind); var step=simulationResult?.Steps.ElementAtOrDefault(i);
                    ImGui.TableNextRow(); ImGui.TableNextColumn(); ImGui.PushID(i);
                    try
                    {
                        DrawItemIcon(metadata is null ? null:new ItemDefinition(0,metadata.Name,false,metadata.Icon),new Vector2(24)); ImGui.SameLine();
                        ImGui.TextWrapped($"{i+1}. {metadata?.Name ?? kind.ToString()}");
                        if(ImGui.IsItemHovered() && step is not null) ImGui.SetTooltip($"Vénération {step.After.Veneration} · Innovation {step.After.Innovation} · Grands progrès {step.After.GreatStrides}\nParcimonie {step.After.WasteNot} · Manipulation {step.After.Manipulation} · Mémoire musculaire {step.After.MuscleMemory}\nMain suprême : {(step.After.TrainedPerfection ? "protection en attente":step.After.UsedTrainedPerfection ? "déjà utilisée":"disponible")}");
                        if(ImGui.SmallButton("Retirer")) { simulationActions.RemoveAt(i); simulationResult=null; break; }
                        if(i>0) { ImGui.SameLine(); if(ImGui.SmallButton("Monter")) { (simulationActions[i-1],simulationActions[i])=(simulationActions[i],simulationActions[i-1]); simulationResult=null; break; } }
                        if(i+1<simulationActions.Count) { ImGui.SameLine(); if(ImGui.SmallButton("Descendre")) { (simulationActions[i+1],simulationActions[i])=(simulationActions[i],simulationActions[i+1]); simulationResult=null; break; } }
                    }
                    finally { ImGui.PopID(); }
                    ImGui.TableNextColumn(); ImGui.TextUnformatted(step is null ? "—":$"{step.After.Progress} (+{step.ProgressGain})");
                    ImGui.TableNextColumn(); ImGui.TextUnformatted(step is null ? "—":$"{step.After.Quality} (+{step.QualityGain})");
                    ImGui.TableNextColumn(); ImGui.TextUnformatted(step?.After.Durability.ToString() ?? "—");
                    ImGui.TableNextColumn(); ImGui.TextUnformatted(step is null ? "—":$"{step.After.Cp} (−{step.CpCost})");
                    ImGui.TableNextColumn(); ImGui.TextUnformatted(step?.After.InnerQuiet.ToString() ?? "—");
                }
            }
            finally { ImGui.EndTable(); }
        }
    }

    private void DrawCraftMacroExport(CraftSimulationResult result,uint job,CraftActionCatalog catalog)
    {
        if(!ReferenceEquals(macroExportSimulation,result)) { craftMacroExport=null; craftMacroError=null; macroExportSimulation=result; }
        if(!ImGui.CollapsingHeader("Macros · copie manuelle")) return;
        ImGui.TextWrapped("Chaque bloc contient au plus 15 lignes. Copiez-le dans une macro du jeu et lancez les blocs vous-même, dans l'ordre. Les attentes sont proposées pour les animations ; elles ne garantissent pas le résultat selon la latence ou les conditions réelles. Essayez d'abord en synthèse d'essai avec les mêmes attributs.");
        DrawToolSettingsLink("CraftMacroExport");
        ImGui.TextDisabled($"Attente supplémentaire : {craftMacroExtraWait} s · message sonore : {(craftMacroEcho ? "oui":"non")}");
        ImGui.BeginDisabled(result.Final.Finish!=CraftFinish.Completed || result.Error is not null);
        try
        {
            if(ImGui.Button("Préparer le texte des macros"))
            {
                try { craftMacroExport=CraftMacroExporter.Build(result,job,catalog,craftMacroExtraWait,craftMacroEcho); craftMacroError=null; }
                catch(ArgumentException error) { craftMacroExport=null; craftMacroError=error.Message; }
            }
        }
        finally { ImGui.EndDisabled(); }
        if(result.Final.Finish!=CraftFinish.Completed || result.Error is not null) ImGui.TextDisabled("Une simulation terminée sans erreur est requise pour exporter.");
        if(craftMacroError is { } errorText) ImGui.TextWrapped(errorText);
        if(craftMacroExport is not { } export) return;
        ImGui.TextDisabled($"{export.Actions} actions · {export.Pages.Count} bloc(s) · somme des attentes {export.WaitSeconds} s");
        if(export.OmittedActions>0) ImGui.TextWrapped($"{export.OmittedActions} action(s) après la fin de la synthèse simulée exclue(s) de l'export.");
        foreach(var block in export.Pages)
        {
            ImGui.PushID(block.Number);
            try
            {
                if(ImGui.CollapsingHeader($"Macro {block.Number}/{export.Pages.Count} · {block.Lines.Count}/15 lignes",ImGuiTreeNodeFlags.DefaultOpen))
                {
                    if(ImGui.SmallButton("Copier ce bloc")) ImGui.SetClipboardText(block.Text);
                    foreach(var line in block.Lines) ImGui.TextUnformatted(line);
                }
            }
            finally { ImGui.PopID(); }
        }
    }
}
