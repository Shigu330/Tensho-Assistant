# GOAL sélectionné

ID: GATHER-FISH-006
OBJECTIVE: Enrichir la pêche sur des preuves natives, puis poursuivre les 17 domaines jusqu’à la réserve de quota de 5 %.
CURRENT_STATE: IMPLEMENTED / TESTED en 0.60.0, 389 tests/package/SHA-256 et probes natifs verts. Carnet partagé : 2 461 fiches/notes concordantes, 296 tomes ; 491 codes météo conservés inconnus. Rendu/framework en jeu non observés.
FILES: Gathering/FishingNotebook, Copy.Lumina, GatheringCatalog/Loader ; MainWindow.FishingNotebook/Gathering/Tools ; FishingNotebookTests ; FishingNotebookProbe et projet GatheringProbe ; docs/GATHER-FISH-006.md.
IN_SCOPE: Métadonnées FishParameter/FishingNoteInfo strictement jointes, Item standard, variantes et IDs distincts ; texte/tome statiques et restrictions 0/1, codes autres inconnus. Copie bornée par le loader commun, index managé et lifecycle existant.
OUT_OF_SCOPE: Déduire appât, heures précises, météo requise, prises/déblocages du personnage ou disponibilité actuelle ; aucun enrichissement externe importé ni action de pêche. Les 17 domaines restent PARTIAL.
VALIDATION: Verify.ps1 389/389, zéro avertissement/erreur, package/versions/SHA-256/exclusion hôte verts. FishingNotebookProbe projection partagée, notes manquantes/étrangères refusées, Item/spot résolus. GatheringProbe antérieur passant sans option réseau.
QUOTA: Relevé de reprise 2026-10-29 : 94 % disponibles sur 5 h et 46 % semaine ; réserve 5 %, objectif global actif. L’ancienne pause à 5 % est levée par la demande utilisateur de continuer.
NEXT_ACTION: Snapshot 0.60 puis GATHER-FISH-CONDITIONS-007-STUDY : code météo 2 et source explicite d’appâts/conditions, provenance/licence avant intégration. Préserver les inconnus ; GP et essais projection/Macro Chain différés, sans les redemander.
DEFINITION_OF_DONE: Tranche intégrée compilée, tests/package verts, preuves/limites et sauvegarde à jour ; aucun domaine global promu complet sans preuve.
