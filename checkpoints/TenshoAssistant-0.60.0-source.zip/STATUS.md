# État courant

CURRENT_GOAL: GATHER-FISH-006 — IMPLEMENTED / TESTED ; carnet natif dans le catalogue commun, voir docs/GATHER-FISH-006.md
CURRENT_MODEL_CLASS: HEAVY — jointures et preuves de pêche
RECOMMENDED_MODEL: HEAVY pour l’intégration native des menus/tri ; LIGHT pour les tâches mécaniques ; continuation autorisée
MODEL_ESCALATION: None
QUOTA: Relevé 2026-10-29 après reprise : 6 % consommés sur 5 h, 54 % semaine (94 % / 46 % disponibles). Réserve utilisateur 5 % conservée ; objectif global actif.
LAST_READ: RULES/STATUS/GOAL, audit, documents récolte et racine relus ; sources primaires Fish/CatchData/DataBase/Data2.0 et métadonnées locales inspectées. Snapshot 0.59-audit conservé.
BUILD: COMPILED Release 0.60.0.0 ; sortie canonique bin/x64/Release
TESTS: TESTED — 389/389 tests ; package/versions/SHA-256/exclusion hôte verts, zéro avertissement/erreur. FishingNotebookProbe : 2 461 fiches/notes concordantes, 296 tomes, 491 codes météo inconnus. GatheringProbe antérieur passant.
RUNTIME: Banque, stocks, carnet et préparation jusqu’à 0.5.27 confirmés par l’utilisateur. Fonctions 0.6–0.60 non validées en jeu. Tests projection et Macro Chain explicitement différés ; ne pas les redemander.
WORK_COMPLETED: Dix-sept domaines PARTIAL ; carnet de pêche natif partagé (description/restrictions/tome), identité Fish/Item/spot distincte, copie bornée framework vers worker managé. Notes absentes/étrangères et codes autres que 0/1 restent inconnus ; aucun appât ni déblocage supposé, aucun réseau ajouté.
BLOCKER: Aucun blocage global. Le bonus natif d’Abondance reste inconnu : sources divergentes et aucun getter nommé confirmé dans les bindings étudiés. Ne pas inventer une formule ; travaux indépendants poursuivis.
RESUME_FROM: GOAL.md ; TESTING.md pour le protocole de la base.
NEXT_ACTION: Snapshot 0.60 puis GATHER-FISH-CONDITIONS-007-STUDY : signification du code météo 2 et source explicite d’appâts/conditions avec provenance/licence. Préserver Unknown ; GP inconnu et essais craft/Macro Chain différés conservés.

| Plugin | Coverage |
|---|---|
| Avant-Garde | PARTIAL — répertoire manuel d'indices natifs, équipements signalés, emplacements/stock/contexte et source datée ; thème courant/teintures/score/attache non déduits |
| Blue Mage Helper | PARTIAL — grimoire, numéros, descriptions, lieux renseignés et acquisition confirmée |
| Character Panel Refined | PARTIAL — attributs natifs, sans formules dérivées |
| Collections | PARTIAL — montures, mascottes, emotes et cartes Triple Triade ; inconnu distinct d'absent |
| Craftimizer | PARTIAL — simulation/recherche/export/séquences, observation et projection d'un coup normal ; conditions/rotation native/recettes spéciales et runtime à compléter |
| Duty Loot Preview | PARTIAL — consultation manuelle par contenu, coffres/récompenses, icônes/contexte, provenance et cache ; drops directs non interprétés, données externes partielles |
| ezMiniCactpot | PARTIAL — solveur exact manuel et mode observé opt-in LotteryDaily ; conseil actualisé, aucune commande ; adaptation/rendu natifs non validés en jeu |
| GatherBuddy | PARTIAL — sources/maps/horaires/météo statiques, point courant MIN/BTN opt-in et carnet natif pêche (restrictions/tomes) ; appâts/conditions précises, présence/prérequis/harpon et runtime à compléter |
| Item Use | PARTIAL — recettes, mandats, candidats GC/aquarium, survol et menu Inventory opt-in ; autres usages/disponibilité, liens de discussion et runtime à compléter |
| LazyGatherer | PARTIAL — optimiseur manuel avec effets explicitement déclarés, observation du point et copie de ressources ; décodeur natif/bonus/régénération/procs/collectionnables et validation runtime à compléter |
| Macro Chain | PARTIAL — séquences à marqueur final, lancement explicite, arrêt, persistance ; natif à confirmer |
| Mappy | PARTIAL — navigateur natif, repères favoris persistants, ressources de zone et prévisions météo statiques ; météo forcée non observée |
| Monster Loot Hunter | PARTIAL — associations matériau/monstre, fiches/niveaux/lieux et carte de zone, transport/cadence partagés, contexte ; données communautaires partielles |
| Price Insight | PARTIAL — consultation manuelle et prix au survol opt-in, NQ/HQ/monde, cache/cadence/priorités partagés ; contexte mutualisé et scope owner/monde, runtime à confirmer |
| QuestTracker | PARTIAL — états natifs, séquence, fiche et liens de prérequis/suivantes ; disponibilité non calculée |
| SortaKinda | PARTIAL — profils/modèles, critères, zones protégées/filtrées et inversion, application visuelle après capture directe ; autres filtres/automatisations choisies et validation runtime à compléter |
| TriadBuddy | PARTIAL — carnet/deck/solveur manuel, observation des faces opt-in expérimentale ; identités/règles/trait natifs et autres règles non établis |

