# GOAL sélectionné

ID: MARKET-003
OBJECTIVE: Chiffrer les besoins terminaux d'une chaîne sans double déduction des stocks ni disparition des branches non résolues ; poursuivre la couverture du projet.
CURRENT_STATE: IMPLEMENTED / TESTED — coût terminal intégré en 0.28.0, 170 tests/package valides ; probe recette native avec stocks/prix simulés passant. Rendu en jeu non observé. Macro Chain reste reporté ; observation Triple Triade expérimentale sans liaison automatique.
COMPLETED_SLICES: GATHER-001A (sources statiques), SORT-001A (aperçu), COLL-001A (catalogue/acquisition confirmée), MARKET-001A (consultation manuelle), QUEST-001A (états natifs), BLU-001A (grimoire), CHAR-001A (attributs), CACT-001A (solveur manuel).
FILES: Domaines Gathering, Inventory, Collections, Market, Quests, Character, MiniGames ; MainWindow.* ; Plugin.cs ; tests et documents.
IN_SCOPE: Adaptation des besoins terminaux vers le modèle de coût commun, branches et observations manquantes, provenance, révision des choix et annulation ; mêmes cache/cadence/liste possédés.
OUT_OF_SCOPE: Déclarer les 17 plugins remplacés ; prétendre une validation en jeu sans observation.
VALIDATION: Verify.ps1 ; fichiers du jeu pour jointures statiques ; tests managés pour caches, inconnus, identités, annulation et solveur. Essais Dalamud séparés dans TESTING.md.
QUOTA: 2026-10-28, 19 % disponibles sur 5 h et 87 % semaine au dernier relevé ; continuer selon instruction utilisateur.
NEXT_ACTION: Sauvegarder 0.28.0 puis QUEST-002 : inspecter données de prérequis/liens de quête et modes de jointure locaux, vérifier leur sémantique avant adaptation. Aucune disponibilité de quête déduite de négatifs non confirmés. Les autres domaines de la roadmap restent dans le goal global.
DEFINITION_OF_DONE: Base intégrée compilée, tests/package verts, limites et protocole runtime documentés ; aucun outil vide promu disponible.
