# GOAL sélectionné

ID: QUEST-ITEM-SOURCES-004
OBJECTIVE: Relier un Item aux quêtes qui le renseignent en récompense dans le catalogue partagé, avec conditions et couverture ; poursuivre les 17 domaines jusqu’à la réserve quota de 5 %.
CURRENT_STATE: QUEST-REWARDS-003 IMPLEMENTED / TESTED en 0.67.0, 426 tests/package/SHA-256 et probe natif verts. 5 373 quêtes/9 313 lignes, quatre quantités et quinze monnaies explicitement inconnues. Rendu/réception en jeu non observés.
WHY_NOW: Compléter le lien inverse objet → quête → fiche, à partir des snapshots déjà copiés ; pas de nouveau lecteur natif ni requête réseau.
REFERENCES: docs/QUEST-REWARDS-003.md ; docs/QUEST-002.md ; contrats des catalogues et contexte Item communs.
FILES: Quests/QuestService, QuestRewards et index managé ; MainWindow.ItemUses/Quests ; tests/probes ciblés.
IN_SCOPE: Index immuable/cancellable depuis snapshots managés, publication atomique/génération/cleanup, toutes les variantes d’un Item par quête ; couverture source/inconnus, clic vers fiche sans changer la progression ni inférer obtention.
OUT_OF_SCOPE: Nouvelle lecture native dans Draw/worker, disponibilité/choix/réception effective, mapping de monnaies ou rang non prouvé, requête/commande native. Les 17 restent PARTIAL.
VALIDATION: Dernière tranche Verify.ps1 426/426, zéro avertissement/erreur, package/API/versions/SHA-256/exclusion hôte verts ; projection native Item/teintes résolue, inconnus conservés. Index/lifecycle et concurrence à tester avant livraison.
QUOTA: Relevé 2026-10-29 : 30 % disponibles sur 5 h et 36 % semaine ; réserve 5 %, objectif global actif.
NEXT_ACTION: Checkpoint 0.67 puis étendre le service Quest avec index managé sans travail massif dans Draw, tests d’annulation/réponse tardive/owner et navigation contexte. GP et essais projection/Macro Chain différés, sans les redemander.
DEFINITION_OF_DONE: Tranche utile compilée/testée, preuves/limites/docs/sauvegarde à jour ; aucun domaine global promu complet sans preuve.
