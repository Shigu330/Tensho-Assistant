# État courant

CURRENT_GOAL: QUEST-REWARDS-003 — IMPLEMENTED / TESTED ; récompenses natives et contexte, voir docs/QUEST-REWARDS-003.md
CURRENT_MODEL_CLASS: HEAVY — identités natives, acquisition et couverture
RECOMMENDED_MODEL: HEAVY pour l’intégration native des menus/tri ; LIGHT pour les tâches mécaniques ; continuation autorisée
MODEL_ESCALATION: None
QUOTA: Relevé 2026-10-29 : 70 % consommés sur 5 h, 64 % semaine (30 % / 36 % disponibles). Réserve utilisateur 5 % conservée ; objectif global actif.
LAST_READ: RULES/STATUS/GOAL, audit, documents récolte et racine relus ; sources primaires Fish/CatchData/DataBase/Data2.0 et métadonnées locales inspectées. Snapshot 0.59-audit conservé.
BUILD: COMPILED Release 0.67.0.0 ; sortie canonique bin/x64/Release
TESTS: TESTED — 426/426 ; package/API/versions/SHA-256/exclusion hôte verts, zéro avertissement/erreur. QuestRewardsProbe : 5 373 snapshots/9 313 lignes, identités Item/teintes résolues ; 4 quantités et 15 monnaies inconnues conservées. GatheringProbe recompilé.
RUNTIME: Banque, stocks, carnet et préparation jusqu’à 0.5.27 confirmés par l’utilisateur. Fonctions 0.6–0.67 non validées en jeu. Tests projection et Macro Chain explicitement différés ; ne pas les redemander.
WORK_COMPLETED: Dix-sept domaines PARTIAL ; récompenses natives de quête, objets/choix/genre/métier/rang et monnaies séparés, toutes les sous-lignes/slots, provenance versionnée et lien Item/stocks. Inconnus et alternatives conservés sans maximum/cumul ni obtention inférée ; autres capacités conservées.
BLOCKER: Aucun blocage global. Le bonus natif d’Abondance reste inconnu : sources divergentes et aucun getter nommé confirmé dans les bindings étudiés. Ne pas inventer une formule ; travaux indépendants poursuivis.
RESUME_FROM: GOAL.md ; TESTING.md pour le protocole de la base.
NEXT_ACTION: QUEST-ITEM-SOURCES-004 : index partagé managé des quêtes pouvant renseigner un Item, liens depuis Usages vers la fiche ; coverage et variantes, aucune obtention garantie. GP et essais craft/Macro Chain différés.

| Plugin | Coverage |
|---|---|
| Avant-Garde | PARTIAL — répertoire manuel d'indices natifs, équipements signalés, emplacements/stock/contexte et source datée ; thème courant/teintures/score/attache non déduits |
| Blue Mage Helper | PARTIAL — grimoire, numéros, descriptions, lieux renseignés et acquisition confirmée |
| Character Panel Refined | PARTIAL — attributs natifs, sans formules dérivées |
| Collections | PARTIAL — montures, mascottes, emotes, cartes, orchestrion, titres et succès ; preuve de chargement, catégories/fiches/récompenses, runtime à confirmer |
| Craftimizer | PARTIAL — simulation/recherche/export/séquences, observation et projection d'un coup normal ; conditions/rotation native/recettes spéciales et runtime à compléter |
| Duty Loot Preview | PARTIAL — consultation manuelle par contenu, coffres/récompenses, icônes/contexte, provenance et cache ; drops directs non interprétés, données externes partielles |
| ezMiniCactpot | PARTIAL — solveur exact manuel et mode observé opt-in LotteryDaily ; conseil actualisé, aucune commande ; adaptation/rendu natifs non validés en jeu |
| GatherBuddy | PARTIAL — sources/maps/horaires/météo statiques, point courant MIN/BTN opt-in carnet natif pêche, appâts/conditions explicites plages ET/UTC et météo localisée ; plages des critères renseignés, présence/prérequis/harpon et runtime à compléter |
| Item Use | PARTIAL — recettes, mandats, candidats GC/aquarium, survol et menu Inventory opt-in ; autres usages/disponibilité, liens de discussion et runtime à compléter |
| LazyGatherer | PARTIAL — optimiseur manuel avec effets explicitement déclarés, observation du point et copie de ressources ; décodeur natif/bonus/régénération/procs/collectionnables et validation runtime à compléter |
| Macro Chain | PARTIAL — séquences à marqueur final, lancement explicite, arrêt, persistance ; natif à confirmer |
| Mappy | PARTIAL — navigateur natif, repères favoris persistants, ressources de zone et prévisions météo statiques ; météo forcée non observée |
| Monster Loot Hunter | PARTIAL — associations matériau/monstre, fiches/niveaux/lieux et carte de zone, transport/cadence partagés, contexte ; données communautaires partielles |
| Price Insight | PARTIAL — consultation manuelle et prix au survol opt-in, NQ/HQ/monde, cache/cadence/priorités partagés ; contexte mutualisé et scope owner/monde, runtime à confirmer |
| QuestTracker | PARTIAL — états natifs, séquence, fiches/liens et récompenses conditionnelles vers Item ; sources inverses et disponibilité non calculées |
| SortaKinda | PARTIAL — profils/modèles, critères, zones protégées/filtrées et inversion, application visuelle après capture directe ; autres filtres/automatisations choisies et validation runtime à compléter |
| TriadBuddy | PARTIAL — carnet/deck/solveur manuel, observation des faces opt-in expérimentale ; identités/règles/trait natifs et autres règles non établis |

