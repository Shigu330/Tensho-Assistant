using Dalamud.Bindings.ImGui;
using System.Numerics;
using System.Globalization;
using TenshoAssistant.Items;
using TenshoAssistant.Quests;

namespace TenshoAssistant;

internal sealed partial class MainWindow
{
    private QuestState? questViewState;
    private string questViewQuery = "";
    private string questViewCategory = "";
    private int questViewFilter = -1;
    private string[] questCategories = [];
    private QuestEntry[] questMatches = [];
    private int questActiveCount;
    private int questCompleteCount;
    private QuestLinks questLinks = new(Array.Empty<QuestEntry>());
    private uint selectedQuestId;
    private bool questShowDetails;
    private string? questFollowError;
    private readonly Stack<uint> questNavigation = new();

    private void DrawQuests()
    {
        Heading("Suivi des quêtes", "Catalogue et progression observée du personnage courant");
        var state = quests.State;
        if (!ReferenceEquals(questViewState, state))
        {
            questLinks = new(state.Entries);
            questCategories = state.Entries.Select(entry => entry.Category).Where(name => !string.IsNullOrWhiteSpace(name))
                .Distinct(StringComparer.Ordinal).OrderBy(name => name, StringComparer.Ordinal).ToArray();
            questActiveCount = state.Entries.Count(entry => entry.Progress == QuestProgress.Active);
            questCompleteCount = state.Entries.Count(entry => entry.Progress == QuestProgress.Complete);
        }
        if (ImGui.Button("Actualiser les quêtes")) quests.RequestRefresh();
        ImGui.SameLine();
        ImGui.TextDisabled(state.Loading ? "Lecture en cours…" : state.ObservedAt is { } date ? $"Observation : {date:HH:mm:ss} UTC" : "Personnage non observé");
        if (state.Error is { } error) ImGui.TextWrapped(error);
        DrawFollowedQuests();
        if (ImGui.SmallButton("Catalogue##QuestView")) questShowDetails = false;
        if (selectedQuestId != 0)
        {
            ImGui.SameLine();
            if (ImGui.SmallButton("Fiche sélectionnée##QuestView")) questShowDetails = true;
        }
        if (questShowDetails && selectedQuestId != 0) { DrawQuestDetails(); return; }
        ImGui.SetNextItemWidth(-1);
        ImGui.InputTextWithHint("##QuestSearch", "Nom ou identifiant de quête…", ref questQuery, 128);
        ImGui.SetNextItemWidth(260);
        if (ImGui.BeginCombo("Catégorie", string.IsNullOrWhiteSpace(questCategory) ? "Toutes" : questCategory))
        {
            try
            {
                if (ImGui.Selectable("Toutes", string.IsNullOrWhiteSpace(questCategory))) questCategory = string.Empty;
                foreach (var category in questCategories)
                    if (ImGui.Selectable(category, questCategory == category)) questCategory = category;
            }
            finally { ImGui.EndCombo(); }
        }
        var labels = new[] { "Toutes", "En cours", "Terminées", "Non confirmées" };
        for (var index = 0; index < labels.Length; index++)
        {
            if (index > 0) ImGui.SameLine();
            if (ImGui.RadioButton(labels[index], questFilter == index)) questFilter = index;
        }
        ImGui.TextDisabled($"{questActiveCount} en cours · {questCompleteCount:N0} terminées confirmées");
        ImGui.TextWrapped("Cliquez sur une quête pour ses liens. Non confirmée ne signifie pas disponible ; les autres conditions d'accès restent à vérifier.");
        if (!ReferenceEquals(questViewState, state) || questViewQuery != questQuery
            || questViewCategory != questCategory || questViewFilter != questFilter)
        {
            questMatches = state.Entries.Where(entry => (string.IsNullOrWhiteSpace(questCategory) || entry.Category == questCategory)
                && (questFilter == 0 || entry.Progress == (questFilter == 1 ? QuestProgress.Active : questFilter == 2 ? QuestProgress.Complete : QuestProgress.Unconfirmed))
                && (string.IsNullOrWhiteSpace(questQuery) || entry.Name.Contains(questQuery.Trim(), StringComparison.OrdinalIgnoreCase)
                    || entry.Id.ToString(CultureInfo.InvariantCulture) == questQuery.Trim())).ToArray();
            questViewState = state; questViewQuery = questQuery;
            questViewCategory = questCategory; questViewFilter = questFilter;
        }
        var matches = questMatches;
        if (matches.Length == 0) { ImGui.TextDisabled("Aucune quête observée correspondant à ces filtres."); return; }
        if (!ImGui.BeginTable("QuestEntries", 3, ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingStretchProp)) return;
        try
        {
            ImGui.TableSetupColumn("Quête", ImGuiTableColumnFlags.WidthStretch, 2);
            ImGui.TableSetupColumn("Catégorie");
            ImGui.TableSetupColumn("Progression");
            ImGui.TableHeadersRow();
            var clipper = ImGui.ImGuiListClipper();
            try
            {
            clipper.Begin(matches.Length);
            while (clipper.Step())
            for (var index = clipper.DisplayStart; index < clipper.DisplayEnd; index++)
            {
                var entry = matches[index];
                ImGui.TableNextRow(); ImGui.TableNextColumn();
                DrawItemIcon(new ItemDefinition(0, entry.Name, false, entry.Icon), new Vector2(24));
                if (ImGui.IsItemClicked()) SelectQuest(entry.Id);
                ImGui.SameLine();
                if (ImGui.Selectable($"{entry.Name}##quest{entry.Id}", selectedQuestId == entry.Id)) SelectQuest(entry.Id);
                if (ImGui.IsItemHovered()) ImGui.SetTooltip($"{entry.Name}\n{entry.Category}\nID quête : {entry.Id}");
                ImGui.TableNextColumn(); ImGui.TextUnformatted(entry.Category);
                ImGui.TableNextColumn();
                ImGui.TextColored(entry.Progress == QuestProgress.Complete ? Success : Muted,
                    entry.Progress switch { QuestProgress.Active => $"En cours · séquence {entry.Sequence}", QuestProgress.Complete => "Terminée confirmée", _ => "Non confirmée" });
            }
            }
            finally { clipper.End(); clipper.Destroy(); }
        }
        finally { ImGui.EndTable(); }
    }

    private void SelectQuest(uint id)
    {
        questShowDetails = true;
        if (id == selectedQuestId) return;
        if (selectedQuestId != 0)
        {
            if (questNavigation.Count >= 64) questNavigation.Clear();
            questNavigation.Push(selectedQuestId);
        }
        selectedQuestId = id;
    }

    private void DrawQuestDetails()
    {
        if (selectedQuestId == 0) return;
        if (!ImGui.CollapsingHeader("Fiche de quête", ImGuiTreeNodeFlags.DefaultOpen)) return;
        if (questNavigation.Count > 0)
        {
            if (ImGui.SmallButton("Retour##Quest")) selectedQuestId = questNavigation.Pop();
            ImGui.SameLine();
        }
        if (ImGui.SmallButton("Fermer la fiche")) { selectedQuestId = 0; questShowDetails = false; questNavigation.Clear(); return; }
        var entry = questLinks.Find(selectedQuestId);
        if (entry is null) { ImGui.TextDisabled($"Quête {selectedQuestId} non présente dans le catalogue nommé."); return; }
        DrawItemIcon(new ItemDefinition(0, entry.Name, false, entry.Icon), new Vector2(36));
        ImGui.SameLine(); ImGui.TextColored(Accent, entry.Name);
        var followed = configuration.FollowedQuests?.Contains(entry.Id) == true;
        if (ImGui.SmallButton(followed ? "Ne plus suivre cette quête" : "Suivre cette quête")) SaveFollowedQuest(entry.Id, !followed);
        ImGui.TextDisabled($"ID {entry.Id} · {entry.Category}{(entry.IsRepeatable ? " · Répétable" : "")}");
        ImGui.TextUnformatted(QuestProgressLabel(entry));
        DrawQuestRewards(entry);
        if (entry.Level != 0)
            ImGui.TextUnformatted($"Niveau renseigné : {entry.Level}{(entry.AdditionalLevel == 0 ? "" : $" · autre seuil : {entry.AdditionalLevel}")}");
        if (!string.IsNullOrWhiteSpace(entry.Zone)) ImGui.TextUnformatted($"Zone : {entry.Zone}");
        if (entry.IssuerId != 0) ImGui.TextDisabled($"Donneur référencé : {entry.IssuerId}");
        if (entry.IssuerMapId != 0 && entry.IssuerTerritoryId != 0)
        {
            var issuerMap = maps.State.Catalog?.Find(entry.IssuerMapId);
            if (issuerMap is not null && issuerMap.TerritoryId == entry.IssuerTerritoryId)
            {
                if (ImGui.SmallButton("Consulter la carte de la zone##Quest"))
                {
                    selectedMapId = issuerMap.MapId; mapQuery = "";
                    selectedBookmark = Guid.Empty; bookmarkName = ""; bookmarkSaved = false;
                    mapX = 20.5f; mapY = 20.5f; mapOpenError = null; page = Page.Maps;
                }
                if (ImGui.IsItemHovered()) ImGui.SetTooltip("Ouvre le navigateur de cartes de cette zone, sans position précise du donneur ni vérification d'accès.");
            }
            else ImGui.TextDisabled($"Carte du donneur non disponible dans le catalogue : {entry.IssuerMapId}");
        }
        if (ImGui.TreeNodeEx("Prérequis liés", ImGuiTreeNodeFlags.DefaultOpen))
        {
            try
            {
                if (entry.PreviousQuestIds.Count == 0) ImGui.TextDisabled("Aucun lien de quête précédente renseigné ; autres conditions possibles.");
                else
                {
                    ImGui.TextUnformatted(QuestLinks.JoinLabel(entry.PreviousQuestJoin));
                    foreach (var id in entry.PreviousQuestIds) DrawQuestLink(id, "previous");
                    if (entry.PreviousQuestStep != 0)
                        ImGui.TextWrapped($"Condition d'étape à vérifier (valeur brute {entry.PreviousQuestStep}, premier lien). Aucun état intermédiaire déduit.");
                    ImGui.TextWrapped(questLinks.CompletionEvidence(entry)
                        ? "Fins de quête requises confirmées selon ces liens. Cela ne confirme pas la disponibilité de cette quête."
                        : "Fins de quête requises non confirmées selon ces liens ; cela ne prouve pas un blocage.");
                }
            }
            finally { ImGui.TreePop(); }
        }
        var following = questLinks.Following(entry.Id);
        if (ImGui.TreeNode($"Quêtes qui référencent celle-ci ({following.Count})"))
        {
            try { foreach (var next in following) DrawQuestLink(next.Id, "next"); }
            finally { ImGui.TreePop(); }
        }
        if (entry.IsRepeatable) ImGui.TextWrapped("La fin confirmée ne renseigne pas la prochaine réinitialisation de cette quête répétable.");
        ImGui.Separator();
    }

    private void DrawQuestLink(uint id, string direction)
    {
        var linked = questLinks.Find(id);
        if (linked is not null)
        {
            DrawItemIcon(new ItemDefinition(0, linked.Name, false, linked.Icon), new Vector2(24));
            if (ImGui.IsItemClicked()) SelectQuest(id);
            ImGui.SameLine();
        }
        if (ImGui.SmallButton($"{linked?.Name ?? $"Quête {id}"}##{direction}{id}")) SelectQuest(id);
        ImGui.SameLine();
        ImGui.TextDisabled(linked is null ? "Lien absent du catalogue nommé" : QuestProgressLabel(linked));
    }

    private static string QuestProgressLabel(QuestEntry entry) => entry.Progress switch
    {
        QuestProgress.Complete => "Terminée confirmée",
        QuestProgress.Active => $"En cours · séquence {entry.Sequence}",
        _ => "Non confirmée"
    };

    private void SaveFollowedQuest(uint id, bool follow)
    {
        var old = configuration.FollowedQuests;
        var updated = (old ?? []).Where(value => value != 0).Distinct().ToList();
        if (follow && !updated.Contains(id))
        {
            if (updated.Count >= 64) { questFollowError = "64 quêtes suivies au maximum ; retirez une entrée pour en ajouter une."; return; }
            updated.Add(id);
        }
        else if (!follow) updated.Remove(id);
        try
        {
            configuration.FollowedQuests = updated; save(); questFollowError = null;
        }
        catch (Exception error)
        {
            configuration.FollowedQuests = old!;
            questFollowError = "Le suivi n'a pas été sauvegardé ; la liste précédente a été conservée.";
            log.Warning(error, "Could not save followed quests.");
        }
    }

    private void DrawFollowedQuests()
    {
        var followed = configuration.FollowedQuests;
        if (ImGui.CollapsingHeader($"Quêtes suivies ({followed?.Count ?? 0})"))
        {
            ImGui.TextDisabled("Liste personnelle partagée ; progression du personnage courant uniquement.");
            if (followed is not { Count: > 0 }) ImGui.TextWrapped("Sélectionnez une quête puis cliquez sur Suivre cette quête dans sa fiche.");
            else
            {
                uint? remove = null;
                var visible = ImGui.BeginChild("FollowedQuestList", new Vector2(0, 140), true);
                try
                {
                    if (visible)
                    for (var index = 0; index < followed.Count; index++)
                    {
                        var id = followed[index];
                        ImGui.PushID(index);
                        try
                        {
                            if (ImGui.SmallButton("Retirer")) remove = id;
                            ImGui.SameLine(); DrawQuestLink(id, "followed");
                        }
                        finally { ImGui.PopID(); }
                    }
                }
                finally { ImGui.EndChild(); }
                if (remove is { } removed) SaveFollowedQuest(removed, false);
            }
        }
        if (questFollowError is { } errorText) ImGui.TextWrapped(errorText);
    }
}
